import os
import shutil
import tempfile
from qgis.core import QgsMessageLog, Qgis

class CacheService:
    @staticmethod
    def clear_plugin_cache():
        """
        Limpia archivos temporales y residuos que puedan interferir.
        """
        try:
            # 1. Limpiar carpeta temporal del sistema relacionada con el plugin
            temp_dir = os.path.join(tempfile.gettempdir(), 'AudiNOT')
            if os.path.exists(temp_dir):
                shutil.rmtree(temp_dir)
            
            # 2. Asegurar que las carpetas de salida temporales se limpian
            # Esto se llamará también al inicio de cada proceso principal
            
            QgsMessageLog.logMessage("AudiNOT: Caché y residuos limpiados correctamente.", 'AudiNOT', Qgis.Info)
            return True
        except Exception as e:
            QgsMessageLog.logMessage(f"AudiNOT: Error al limpiar caché: {str(e)}", 'AudiNOT', Qgis.Critical)
            return False
