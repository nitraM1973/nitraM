import os
from PyQt5.QtWidgets import QAction
from PyQt5.QtGui import QIcon
from qgis.core import QgsProject
from qgis.gui import QgisInterface

class ToolbarService:
    def __init__(self, iface: QgisInterface):
        self.iface = iface
        self.tb_name = "ValCAD"
        self.plugin_name = "AudiNOT"
        
    def get_or_create_toolbar(self):
        """
        Busca la barra de herramientas 'ValCAD' o la crea si no existe.
        Mejorado para persistencia robusta: busca por título y fuerza visibilidad.
        """
        from PyQt5.QtWidgets import QToolBar
        
        toolbar = None
        tb_object_name = "ValCADToolBar"
        
        # 1. Estrategia de búsqueda exhaustiva
        toolbars = self.iface.mainWindow().findChildren(QToolBar)
        
        for tb in toolbars:
            # Buscamos por objectName de ValCAD o por Título visible
            if tb.objectName() == tb_object_name or tb.windowTitle() == self.tb_name:
                toolbar = tb
                break
        
        # 2. Creación si no existe
        if not toolbar:
            toolbar = self.iface.addToolBar(self.tb_name)
            toolbar.setObjectName(tb_object_name)
        
        # 3. Asegurar persistencia y visibilidad
        if toolbar.objectName() != tb_object_name:
            toolbar.setObjectName(tb_object_name)
            
        return toolbar

    def add_plugin_action(self, icon_path, callback):
        """
        Añade el plugin a la barra de herramientas y al menú Complementos.
        """
        icon = QIcon(icon_path)
        action = QAction(icon, self.plugin_name, self.iface.mainWindow())
        action.setObjectName("AudiNOTAction")  # CRÍTICO para persistencia tras reinicio
        action.triggered.connect(callback)
        
        # Añadir al menú Complementos (Agrupado en ValCAD como el resto de la suite)
        self.iface.addPluginToMenu("ValCAD", action)
        
        # Añadir a la barra ValCAD
        toolbar = self.get_or_create_toolbar()
        toolbar.addAction(action)
        
        return action

    def remove_plugin_action(self, action):
        """
        Elimina el plugin de la barra de herramientas y del menú Complementos.
        """
        if not action:
            return
            
        # Eliminar del menú Complementos
        self.iface.removePluginMenu(self.plugin_name, action)
        
        # Eliminar de la barra ValCAD
        toolbar = self.get_or_create_toolbar()
        toolbar.removeAction(action)
        
        # Opcional: Si la barra queda vacía y es la nuestra, podríamos ocultarla/borrarla
        # pero siendo 'ValCAD' una barra compartida, mejor solo quitar nuestra acción.
