from PyQt5.QtCore import QTimer
import os
import sys
from qgis.gui import QgisInterface
from .infra.cache_service import CacheService
from .infra.toolbar_service import ToolbarService
from .ui.dock_manager import AudiNOTDockManager

class AudiNOTPlugin:
    def __init__(self, iface: QgisInterface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        
        # Servicios
        self.cache_service = CacheService()
        self.toolbar_service = ToolbarService(self.iface)
        
        # UI
        self.dock_manager = AudiNOTDockManager(self.iface)
        self.action = None

    def initGui(self):
        """
        Inicialización de la interfaz del plugin al cargarse en QGIS.
        """
        # 1. Limpiar caché al instalar/cargar (requisito)
        self.cache_service.clear_plugin_cache()
        
        # 2. Inicialización diferida de UI para evitar problemas de timing en el arranque
        QTimer.singleShot(0, self.setup_ui)
        
    def setup_ui(self):
        """
        Configuración real de la interfaz una vez que QGIS está listo.
        """
        # 1. Configurar icono y acción
        icon_path = os.path.join(self.plugin_dir, "resources", "icon.png")
        self.action = self.toolbar_service.add_plugin_action(icon_path, self.run)
        
        # 2. Inicializar Dock Widget
        self.dock_manager.setup_ui()
        
    def unload(self):
        """
        Limpieza al descargar el plugin.
        """
        # 1. Eliminar acción de toolbar y menús usando el servicio
        if self.action:
            self.toolbar_service.remove_plugin_action(self.action)
        
        # 2. Eliminar el dock widget
        if self.dock_manager.dock:
            self.iface.removeDockWidget(self.dock_manager.dock)
            self.dock_manager.dock.deleteLater()

        # 3. Purgar del caché de módulos de Python (sys.modules) tanto el
        # paquete raíz como TODOS sus submódulos (core, ui, infra, ...).
        # Sin esto, cuando el Administrador de Complementos actualiza el
        # plugin sin reiniciar QGIS -- sobrescribe los .py en disco y
        # vuelve a llamar a initGui() sin reiniciar el intérprete --
        # Python reutiliza los módulos ya cargados en memoria en vez de
        # releer los archivos nuevos, y el usuario sigue viendo la
        # versión antigua hasta que reinicia QGIS. Borrando las entradas
        # aquí forzamos que el siguiente import vuelva a leer del disco.
        # No afecta a la ejecución de este unload() en curso: los objetos
        # ya creados siguen funcionando aunque se borre la entrada de su
        # módulo en sys.modules.
        pkg_prefix = __name__.rsplit('.', 1)[0] if '.' in __name__ else __name__
        stale = [name for name in list(sys.modules.keys())
                 if name == pkg_prefix or name.startswith(pkg_prefix + '.')]
        for name in stale:
            sys.modules.pop(name, None)
        
    def run(self):
        """
        Punto de entrada al hacer clic en el icono.
        """
        self.dock_manager.show()

