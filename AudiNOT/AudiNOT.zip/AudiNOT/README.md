# AudiNOT - Auditoría Gráfica Automatizada

**AudiNOT** es un potente plugin para QGIS diseñado para el **análisis comparativo técnico y jurídico de recintos parcelarios**. Permite automatizar la auditoría de variaciones entre dos estados (ANTES y DESPUÉS), detectando cambios geométricos, trasvases de propiedad e interpretando la evolución de elementos técnicos (aditamentos).

![AudiNOT Logo](appicon.png)

## 📋 Características Principales

- **Análisis Comparativo Espacial**: Comparación automática de capas de recintos (SHP, GPKG) para detectar diferencias entre el estado original y la propuesta.
- **Detección de Cambios Geométricos**: Cálculo de variaciones en Área, Perímetro, Coeficiente de Gravelius y Desplazamiento de Centroides.
- **Auditoría de Aditamentos**: Soporte para capas DXF (muros, vallas, líneas, etc.) con detección de nuevos elementos, eliminados o desplazados.
- **Gestión de Invasiones y Expansiones**: Distingue automáticamente entre solapes con otros titulares (Invasiones) y fusiones de parcelas propias (Expansiones).
- **Cálculo de Fachadas y Accesos**: Análisis desglosado de longitudes de contacto con Viales, Edificaciones y Cursos de Agua.
- **Informes Profesionales**: Generación de reportes HTML interactivos con alineación de precisión quirúrgica (7 columnas) y optimización para impresión legal.

---

## 📈 Guía de Interpretación de Métricas

El informe de AudiNOT está diseñado con un estándar **"Senior Expert"** para facilitar auditorías legales. A continuación se detalla cómo interpretar cada bloque del reporte:

### 1. Métricas Geométricas (Aislamiento de la Parcela)
Este bloque analiza la parcela como un ente geométrico independiente, comparando su forma en el estado previo vs. el estado final.

- **Superficie (m²)**: Diferencia neta de área. Un cambio puede deberse a ajustes topográficos o a una reconfiguración de linderos. 
    - *Alerta*: Se marca con `*` si la variación (en m² o %) supera el umbral configurado.
- **Perímetro (m)**: Variación en la longitud del contorno. Un aumento significativo con el mismo área suele indicar mayor irregularidad o perímetros "serpentinos".
- **Irregularidad (K - Coeficiente de Gravelius)**:
    - `K = 1.0`: La parcela es un círculo perfecto (máxima compacidad).
    - `K > 1.0`: Cuanto mayor es el valor, más alargada o irregular es la forma.
    - *Interpretación*: Un aumento en `K` indica una parcela menos eficiente o con linderos más incidentados.
- **No. Islas/Partes**: Indica si la parcela es una única unidad geométrica o si está fragmentada. Un aumento aquí suele indicar que un vial o elemento externo ha "cortado" la parcela en dos o más piezas.
- **Sup. Huecos (m²)**: Área interna que no pertenece a la parcela (huecos). Vital para detectar cesiones internas o intrusiones de terceros en el "corazón" del recinto.

### 2. Interacción con el Entorno (Fachadas y Accesos)
Analiza cómo "toca" la parcela a los elementos exteriores críticos. El plugin mide la **longitud de contacto** exacta.

- **VIALES**: Longitud de fachada aprovechable para acceso rodado o peatonal. Una pérdida aquí compromete la funcionalidad del recinto.
- **CURSOS AGUA**: Contacto con ríos o regatos. Importante para servidumbres legales de aguas (dominio público hidráulico).
- **EDIFICACIONES**: Contacto directo con muros de construcciones existentes. Detecta adosamientos o irregularidades constructivas.
- **EXCLUIDO**: Longitud de linderos que no tocan ningún elemento de interés configurado.

### 3. Dinámica Territorial (Matriz de Trasvases)
Es el bloque más potente para la auditoría de linderos. Responde a la pregunta: **¿A quién le he dado terreno y de quién lo he recibido?**

- **ORIGEN (INPUTS)**: Muestra de qué parcelas del estado "Antes" proviene la superficie de la parcela actual.
    - *Ejemplo*: Si mi parcela ahora es más grande, aquí veré qué parcelas colindantes me han "cedido" terreno.
- **DESTINO (OUTPUTS)**: Muestra hacia dónde se ha ido la superficie del estado "Antes".
    - *Ejemplo*: Si mi parcela ha desaparecido o encogido, aquí veré qué nuevas parcelas están ocupando ese espacio.
- **Marcado Especial**: Propietarios como **AGADER**, **MASA COMÚN** o **DESCONOCIDOS** se marcan con símbolos numéricos (¹, ², ³) para resaltar gestiones administrativas especiales.

### 4. Auditoría de Aditamentos (Elementos Técnicos)
Analiza la evolución de elementos físicos (provenientes de DXF) en relación con el recinto.

- **Longitud (Líneas)**: Variación en el metraje de cierres, muros o viales internos.
- **Superficie y Cantidad (Polígonos)**: Detección de cierres de muro o rellenos.
- **Unidades (Puntos)**: Conteo de elementos puntuales (postes, arquetas, árboles).
- *Interpretación*: Detecta si un muro ha desaparecido tras la transformación parcelaria o si han aparecido nuevos elementos obstructivos.

---

## 🛠️ Detalles de Implementación

AudiNOT utiliza una arquitectura de **"Siete Columnas de Precisión"** en sus tablas para garantizar que las cifras sean legibles en sede judicial:

| Columna | Función |
| :--- | :--- |
| **1-3** | Parámetro y valores de los estados Antes/Después. |
| **4** | **Var**: Diferencia absoluta. |
| **5** | **Slot Alerta (Var)**: Columna fija de 14px para el asterisco `*`. |
| **6** | **%**: Porcentaje de cambio. |
| **7** | **Slot Alerta (%)**: Columna fija de 14px para el asterisco `*`. |

Esta estructura evita que la aparición de una alerta empuje el resto de los números, manteniendo los decimales siempre alineados en vertical.

---

## 🚀 Instalación y Requisitos

1. Descargue el código en su carpeta de plugins de QGIS:
   - `%AppData%\Roaming\QGIS\QGIS3\profiles\default\python\plugins\AudiNOT`
2. El plugin requiere que las capas tengan un **Sistema de Referencia de Coordenadas (SRC) proyectado** (p.ej. ETRS89 / UTM zone 29N) para cálculos métricos precisos.

---
**Autor:** José Martín Vázquez Morandeira  
**Versión:** 1.0.0  
**Enfoque:** Auditoría Legal / Ingeniería Geográfica / Catastro de Precisión
