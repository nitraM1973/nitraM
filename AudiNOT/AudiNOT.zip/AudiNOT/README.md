# AudiNOT - Auditoría Gráfica Automatizada

**AudiNOT** es un potente plugin para QGIS diseñado para el **análisis comparativo técnico y jurídico de recintos parcelarios**. Permite automatizar la auditoría de variaciones entre dos estados (ANTES y DESPUÉS), detectando cambios geométricos, trasvases de propiedad e interpretando la evolución de elementos técnicos (aditamentos).

![AudiNOT Logo](appicon.png)

## 📋 Características Principales

- **Análisis Comparativo Espacial**: Comparación automática de capas de recintos (SHP, GPKG) para detectar diferencias entre el estado original y la propuesta.
- **Detección de Cambios Geométricos**: Cálculo de variaciones en Área, Perímetro, Coeficiente de Gravelius y Desplazamiento de Centroides.
- **Auditoría de Aditamentos**: Soporte para capas DXF (muros, vallas, líneas, etc.) con detección de nuevos elementos, eliminados o desplazados.
- **Gestión de Invasiones y Expansiones**: Distingue automáticamente entre solapes con otros titulares (Invasiones) y fusiones de parcelas propias (Expansiones).
- **Cálculo de Fachadas y Accesos**: Análisis desglosado de longitudes de contacto con Viales, Edificaciones y Cursos de Agua.
- **Informes Profesionales**: Generación de reportes HTML interactivos, optimizados para revisión en pantalla y listos para impresión legal.

## 🚀 Flujo de Trabajo

El plugin se organiza en tres pasos lógicos accesibles desde su panel lateral:

### 1. Datos de Entrada
Selección de las capas de trabajo:
- **Capa ANTES**: El estado original o catastral actual.
- **Capa DESPUÉS**: La propuesta de proyecto o nuevo estado.
- **Aditamentos (Opcional)**: Archivos DXF para comparar elementos físicos/constructivos.
- **Carpeta de Salida**: Donde se guardarán los resultados y el informe final.

### 2. Mapeo de Campos
Configuración de la lógica de negocio:
- **Identificadores**: Selección del campo que actúa como Referencia Catastral (REF/REC).
- **Titulares**: Mapeo del campo de propietarios para analizar trasvases de superficie.
- **Recintos Especiales**: Identificación de tipos de suelo (Vial, Agua, Construcción) para el cálculo de fachadas.

### 3. Configuración de Umbrales
Ajuste de la sensibilidad del análisis para evitar "ruido" por errores milimétricos:
- Tolerancia en áreas y perímetros.
- Filtros para tipos de propietarios específicos.
- Umbrales de desplazamiento para alertas críticas.

## 🛠️ Detalles Técnicos

AudiNOT está construido con una arquitectura modular en Python:

- **`core/analysis_engine.py`**: El motor que orquesta el procesamiento espacial.
- **`core/metrics_calculation.py`**: Motor geométrico para cálculos de alta precisión.
- **`core/adit_service.py`**: Lógica especializada para el análisis de elementos técnicos.
- **`core/report_service.py`**: Generador de informes basado en plantillas HTML/CSS.
- **`core/dxf_service.py`**: Procesador de geometrías provenientes de CAD/DXF.

## 📦 Instalación

1. Descargue el código o clone el repositorio en su carpeta de plugins de QGIS:
   - Windows: `%AppData%\Roaming\QGIS\QGIS3\profiles\default\python\plugins\AudiNOT`
   - Linux/Mac: `~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/AudiNOT`
2. Reinicie QGIS.
3. Active el plugin desde el **Administrador de Complementos**.

## 📖 Ayuda y Soporte

El plugin incluye un manual detallado accesible pulsando el botón **"?"** en la parte superior del panel AudiNOT.

---
**Autor:** José Martín Vázquez Morandeira
**Versión:** 1.0.0
**Categoría:** Auditoría / Geometría / Catastro
