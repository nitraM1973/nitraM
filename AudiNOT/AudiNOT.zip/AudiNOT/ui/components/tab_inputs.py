from PyQt5.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QCheckBox, QPushButton, QTextEdit, QGroupBox, QGridLayout
from PyQt5.QtCore import pyqtSignal
from qgis.gui import QgsFileWidget
from qgis.core import Qgis, QgsProject, QgsVectorLayer
import os

class TabInputs(QWidget):
    layerLoaded = pyqtSignal(str, object) # label, layer
    
    def __init__(self, iface):
        super().__init__()
        self.iface = iface
        self.layer_antes = None
        self.layer_desp = None
        self.layer_antes_id = None
        self.layer_desp_id = None
        self.dxf_antes_path = None
        self.dxf_desp_path = None
        self.adit_layers = {}
        self.project_root_path = None
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        self.main_layout = layout
        
        # 1. Carpeta de Salida
        layout.addWidget(QLabel("<b>Carpeta de Salida:</b>"))
        self.file_output = QgsFileWidget()
        self.file_output.setStorageMode(QgsFileWidget.GetDirectory)
        self.file_output.fileChanged.connect(self.on_output_folder_changed)
        layout.addWidget(self.file_output)
        
        layout.addSpacing(10)
        
        # 2. Archivo ANTES
        layout.addWidget(QLabel("<b>Situación ANTES (Archivo SHP/GPKG):</b>"))
        self.file_antes = QgsFileWidget()
        self.file_antes.setFilter("Vector Files (*.shp *.gpkg *.geojson)")
        self.file_antes.fileChanged.connect(lambda p: self.on_file_changed(p, "ANTES"))
        layout.addWidget(self.file_antes)
        
        layout.addSpacing(5)
        
        # 3. Archivo DESPUÉS
        layout.addWidget(QLabel("<b>Situación DESPUÉS (Archivo SHP/GPKG):</b>"))
        self.file_desp = QgsFileWidget()
        self.file_desp.setFilter("Vector Files (*.shp *.gpkg *.geojson)")
        self.file_desp.fileChanged.connect(lambda p: self.on_file_changed(p, "DESPUÉS"))
        layout.addWidget(self.file_desp)
        
        layout.addSpacing(10)
        
        # 4. Archivos DXF (Opcionales)
        layout.addWidget(QLabel("<b>DXF ANTES (Opcional):</b>"))
        self.file_dxf_antes = QgsFileWidget()
        self.file_dxf_antes.setFilter("AutoCAD DXF (*.dxf)")
        self.file_dxf_antes.fileChanged.connect(lambda p: self.on_dxf_changed(p, "DXF_ANTES"))
        layout.addWidget(self.file_dxf_antes)
        
        layout.addWidget(QLabel("<b>DXF DESPUÉS (Opcional):</b>"))
        self.file_dxf_despues = QgsFileWidget()
        self.file_dxf_despues.setFilter("AutoCAD DXF (*.dxf)")
        self.file_dxf_despues.fileChanged.connect(lambda p: self.on_dxf_changed(p, "DXF_DESPUÉS"))
        layout.addWidget(self.file_dxf_despues)

        # Punto de inserción para los botones de guardar/cargar parámetros
        # (ver add_param_buttons): justo debajo del cuadro DXF DESPUÉS,
        # antes del resto de la ficha. Los botones en sí los sigue
        # creando y gestionando AudiNOTDockManager -esta ficha solo los
        # aloja aquí-, igual patrón que ya usa add_run_controls con el
        # botón EJECUTAR ANÁLISIS.
        self._param_buttons_index = layout.count()

        layout.addSpacing(10)
        layout.addSpacing(10)
        
        # 5. Filtro de Propietario
        layout.addWidget(QLabel("<b>Filtrar por Propietario:</b>"))
        row_prop = QHBoxLayout()
        self.chk_prop = QCheckBox()
        self.txt_prop = QLineEdit()
        self.txt_prop.setPlaceholderText("ID Propietario")
        self.txt_prop.setEnabled(False)
        self.chk_prop.toggled.connect(self.txt_prop.setEnabled)
        row_prop.addWidget(self.chk_prop)
        row_prop.addWidget(self.txt_prop)
        layout.addLayout(row_prop)
        
        layout.addSpacing(10)
        
        # 6. Log de Seguimiento
        layout.addWidget(QLabel("<b>Log de Seguimiento:</b>"))
        self.log_box = QTextEdit()
        self.log_box.setReadOnly(True)
        self.log_box.setStyleSheet("background-color: #f0f0f0; font-family: Consolas; font-size: 9pt;")
        layout.addWidget(self.log_box, 1)
        
        self.set_controls_enabled(False)

    def add_param_buttons(self, btn_save_params, btn_load_params):
        """Aloja los botones de guardar/cargar parámetros (Umbrales,
        Rangos REC y Propietarios Especiales) justo debajo de "DXF
        DESPUÉS (Opcional)". AudiNOTDockManager sigue siendo quien los
        crea y conecta su señal clicked (ahí vive la lógica real de
        leer/escribir el .anot); esta ficha solo los coloca en su propio
        layout -- igual patrón que add_run_controls con EJECUTAR
        ANÁLISIS. Antes vivían arriba a la derecha del dock, junto al
        botón de ayuda; se movieron aquí por ser más coherente con el
        resto de "1: Datos Entrada", donde ya está todo lo demás que se
        configura antes de ejecutar el análisis."""
        row = QHBoxLayout()
        row.addWidget(btn_save_params)
        row.addWidget(btn_load_params)
        row.addStretch()
        self.main_layout.insertLayout(self._param_buttons_index, row)
        self.main_layout.insertSpacing(self._param_buttons_index + 1, 10)

    def add_run_controls(self, btn_run, progress_widgets=None):
        """Aloja el botón EJECUTAR ANÁLISIS (y, si se pasa, la barra de
        progreso/etiqueta de estado) al final de esta ficha. El botón lo
        sigue creando y gestionando AudiNOTDockManager (es quien conecta
        la señal clicked y quien lo habilita/deshabilita/renombra durante
        el análisis); esta ficha solo lo coloca en su propio layout para
        que quede visible en "1: Datos Entrada" en vez de fuera de las
        pestañas.

        Justo a la izquierda del botón se añade un checkbox "Informe
        HTML" (desactivado por defecto): controla si al pulsar EJECUTAR
        ANÁLISIS se generan también los informes HTML (ampliado y
        resumen) -- ver get_generar_informe_html(), usado por
        AudiNOTDockManager.on_run_analysis al construir 'settings'. Vive
        aquí (no en AudiNOTDockManager) por ser una preferencia de
        entrada más, igual criterio que get_filter_settings().
        """
        self.chk_informe_html = QCheckBox("Informe HTML")
        self.chk_informe_html.setChecked(False)
        self.chk_informe_html.setToolTip(
            "Si está marcado, EJECUTAR ANÁLISIS genera también los informes HTML "
            "(ampliado y resumen), además de actualizar la capa de auditoría "
            "(Ficha 4). Desmarcado por defecto porque generarlos puede tardar "
            "bastante según el volumen de cambios detectados; la capa de "
            "auditoría se actualiza igualmente en ambos casos."
        )

        row_run = QHBoxLayout()
        row_run.addWidget(self.chk_informe_html)
        row_run.addWidget(btn_run, stretch=1)

        self.main_layout.addSpacing(10)
        self.main_layout.addLayout(row_run)
        for w in (progress_widgets or []):
            self.main_layout.addWidget(w)

    def get_generar_informe_html(self):
        """True si el checkbox "Informe HTML" (junto a EJECUTAR ANÁLISIS)
        está marcado. Ver add_run_controls()."""
        return self.chk_informe_html.isChecked()

    def get_filter_settings(self):
        return {
            'owner_active': self.chk_prop.isChecked(),
            'owner_id': self.txt_prop.text().strip()
        }

    def add_log(self, message):
        from datetime import datetime
        from PyQt5.QtCore import QCoreApplication
        
        time_str = datetime.now().strftime("%H:%M:%S")
        self.log_box.append(f"[{time_str}] {message}")
        self.log_box.repaint()
        QCoreApplication.processEvents()
        sb = self.log_box.verticalScrollBar()
        sb.setValue(sb.maximum())
    
    def clear_log(self):
        self.log_box.clear()

    def on_output_folder_changed(self, path):
        if not path or not os.path.isdir(path):
            self.set_controls_enabled(False)
            if path:
                self.add_log("<font color='orange'>AVISO: La ruta especificada no es válida.</font>")
            return

        # Si la ruta ya es la propia carpeta "RESULTADO" (p.ej. porque la
        # acabamos de fijar nosotros mismos más abajo, o porque el usuario
        # navegó manualmente hasta ella), la raíz del proyecto es su carpeta
        # padre. En cualquier otro caso, la ruta elegida por el usuario ES
        # la raíz del proyecto (donde ya están los shapes y DXF).
        norm_path = os.path.normpath(path)
        if os.path.basename(norm_path).upper() == "RESULTADO":
            root_path = os.path.dirname(norm_path)
            resultado_path = norm_path
        else:
            root_path = norm_path
            resultado_path = os.path.join(norm_path, "RESULTADO")

        if not os.path.isdir(resultado_path):
            try:
                os.makedirs(resultado_path)
                self.add_log(f"Carpeta 'RESULTADO' creada en: {root_path}")
            except OSError as e:
                self.set_controls_enabled(False)
                self.add_log(f"<font color='red'>ERROR: No se pudo crear la carpeta 'RESULTADO': {e}</font>")
                return

        # Los shapes/DXF de trabajo ya están en la raíz del proyecto: que
        # los diálogos de selección se abran ahí por defecto, para que el
        # usuario no tenga que navegar cada vez.
        self.file_antes.setDefaultRoot(root_path)
        self.file_desp.setDefaultRoot(root_path)
        self.file_dxf_antes.setDefaultRoot(root_path)
        self.file_dxf_despues.setDefaultRoot(root_path)

        # Reflejar en el campo la carpeta de salida real (RESULTADO), sin
        # reentrar en este mismo método al fijarla por código.
        if norm_path != resultado_path:
            self.file_output.blockSignals(True)
            self.file_output.setFilePath(resultado_path)
            self.file_output.blockSignals(False)

        self.project_root_path = root_path
        self.set_controls_enabled(True)
        self.add_log(f"<font color='green'>✓ Carpeta de salida configurada: {resultado_path}</font>")
    
    def reset_to_empty(self):
        """Llamado por AudiNOTDockManager.on_click_close ('Cerrar'):
        vacía SOLO los campos de esta ficha que no tienen un valor por
        defecto sensato (rutas de carpeta/ficheros, filtro de
        propietario) y quita del proyecto QGIS las capas ANTES/DESPUÉS
        que hubiera cargadas -- así ningún fichero referenciado desde
        aquí queda bloqueado. Los Umbrales, Rangos REC y Propietarios
        Especiales (Fichas 2/3, que sí tienen valores por defecto) no
        se tocan desde aquí."""
        self.remove_layers_by_label("ANTES")
        self.remove_layers_by_label("DESPUES")

        ids = [lyr.id() for lyr in self.adit_layers.values()
               if lyr is not None and lyr.id() in QgsProject.instance().mapLayers()]
        if ids:
            QgsProject.instance().removeMapLayers(ids)
        self.adit_layers = {}

        self.dxf_antes_path = None
        self.dxf_desp_path = None
        self.project_root_path = None

        for widget in (self.file_output, self.file_antes, self.file_desp,
                       self.file_dxf_antes, self.file_dxf_despues):
            widget.blockSignals(True)
            widget.setFilePath("")
            widget.blockSignals(False)

        self.chk_prop.setChecked(False)
        self.txt_prop.clear()

        self.set_controls_enabled(False)

        # El LOG de esta ficha (todo lo escrito durante la sesión que se
        # cierra: carga de capas, avisos, errores...) tampoco tiene
        # sentido conservarlo tras cerrar el proyecto o pulsar 'Cerrar':
        # se vacía junto con el resto de controles de la sesión.
        self.clear_log()

    def set_controls_enabled(self, enabled):
        self.file_antes.setEnabled(enabled)
        self.file_desp.setEnabled(enabled)
        self.file_dxf_antes.setEnabled(enabled)
        self.file_dxf_despues.setEnabled(enabled)
        self.chk_prop.setEnabled(enabled)
        self.txt_prop.setEnabled(enabled and self.chk_prop.isChecked())

    def on_file_changed(self, path, label):
        if not path or path.strip() == "":
            self.remove_layers_by_label(label)
        else:
            self.load_vector_layer(path, label)

    def on_dxf_changed(self, path, label):
        if not path or path.strip() == "":
            if label == "DXF_ANTES":
                self.dxf_antes_path = None
            else:
                self.dxf_desp_path = None
            self.add_log(f"{label} eliminado.")
        else:
            if label == "DXF_ANTES":
                self.dxf_antes_path = path
            else:
                self.dxf_desp_path = path
            self.add_log(f"<font color='green'>✓ {label} seleccionado: {os.path.basename(path)}</font>")

    def remove_layers_by_label(self, label):
        layers_to_remove = []
        
        if label == "ANTES":
            if self.layer_antes_id and self.layer_antes_id in QgsProject.instance().mapLayers():
                layers_to_remove.append(self.layer_antes_id)
            self.layer_antes = None
            self.layer_antes_id = None
        else:
            if self.layer_desp_id and self.layer_desp_id in QgsProject.instance().mapLayers():
                layers_to_remove.append(self.layer_desp_id)
            self.layer_desp = None
            self.layer_desp_id = None
        
        if layers_to_remove:
            try:
                QgsProject.instance().removeMapLayers(layers_to_remove)
                self.add_log(f"Capas de {label} eliminadas del proyecto.")
            except Exception:
                pass

    def load_vector_layer(self, path, label):
        if not path or not os.path.exists(path):
            return
            
        name = os.path.basename(path)
        self.add_log(f"Cargando {label}: {name}...")
        
        layer = QgsVectorLayer(path, f"{label}_{name}", "ogr")
        if not layer.isValid():
            self.add_log(f"<font color='red'>ERROR: La capa {label} no es válida.</font>")
            return
        
        project_crs = QgsProject.instance().crs()
        if not layer.crs().isValid():
            layer.setCrs(project_crs)
            self.add_log(f"SRC asignado: {project_crs.authid()}")
            
        QgsProject.instance().addMapLayer(layer)
        self.add_log(f"<font color='green'>✓ Capa {label} añadida al proyecto.</font>")
        
        if label == "ANTES":
            self.layer_antes = layer
            self.layer_antes_id = layer.id()
        elif label == "DESPUÉS":
            self.layer_desp = layer
            self.layer_desp_id = layer.id()
        else:
            self.adit_layers[label] = layer
            
        self.layerLoaded.emit(label, layer)

    def get_adit_paths(self):
        return {}

    def get_restricted_widgets(self):
        """Widgets de esta ficha que deben desactivarse en rol Revisor 2
        (ver AudiNOTDockManager.aplicar_restricciones_por_rol, único sitio
        que decide si de verdad se aplica). Se excluye deliberadamente
        file_output (el selector de "Carpeta de Salida"): sin él, Revisor 2
        no podría ni siquiera abrir un proyecto existente para consultarlo."""
        return [
            self.file_antes, self.file_desp,
            self.file_dxf_antes, self.file_dxf_despues,
            self.chk_prop, self.txt_prop,
        ]