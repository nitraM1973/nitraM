from PyQt5.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QCheckBox, QPushButton, QTextEdit, QGroupBox, QGridLayout
from PyQt5.QtCore import pyqtSignal
from qgis.gui import QgsFileWidget
from qgis.core import Qgis, QgsProject, QgsVectorLayer
import os

class TabInputs(QWidget):
    layerLoaded = pyqtSignal(str, object) # label, layer
    
    def __init__(self, iface):
        super().__init__()
        self.iface = iface
        self.layer_antes = None
        self.layer_desp = None
        self.dxf_antes_path = None
        self.dxf_desp_path = None
        self.adit_layers = {} # {label: QgsVectorLayer}
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        
        # 1. Carpeta de Salida
        layout.addWidget(QLabel("<b>Carpeta de Salida:</b>"))
        self.file_output = QgsFileWidget()
        self.file_output.setStorageMode(QgsFileWidget.GetDirectory)
        self.file_output.fileChanged.connect(self.on_output_folder_changed)
        layout.addWidget(self.file_output)
        
        layout.addSpacing(10)
        
        # 2. Archivo ANTES
        layout.addWidget(QLabel("<b>Situación ANTES (Archivo SHP/GPKG):</b>"))
        self.file_antes = QgsFileWidget()
        self.file_antes.setFilter("Vector Files (*.shp *.gpkg *.geojson)")
        self.file_antes.fileChanged.connect(lambda p: self.on_file_changed(p, "ANTES"))
        layout.addWidget(self.file_antes)
        
        layout.addSpacing(5)
        
        # 3. Archivo DESPUÉS
        layout.addWidget(QLabel("<b>Situación DESPUÉS (Archivo SHP/GPKG):</b>"))
        self.file_desp = QgsFileWidget()
        self.file_desp.setFilter("Vector Files (*.shp *.gpkg *.geojson)")
        self.file_desp.fileChanged.connect(lambda p: self.on_file_changed(p, "DESPUÉS"))
        layout.addWidget(self.file_desp)
        
        layout.addSpacing(10)
        
        # 4. Archivos DXF (Opcionales)
        layout.addWidget(QLabel("<b>DXF ANTES (Opcional):</b>"))
        self.file_dxf_antes = QgsFileWidget()
        self.file_dxf_antes.setFilter("AutoCAD DXF (*.dxf)")
        self.file_dxf_antes.fileChanged.connect(lambda p: self.on_dxf_changed(p, "DXF_ANTES"))
        layout.addWidget(self.file_dxf_antes)
        
        layout.addWidget(QLabel("<b>DXF DESPUÉS (Opcional):</b>"))
        self.file_dxf_despues = QgsFileWidget()
        self.file_dxf_despues.setFilter("AutoCAD DXF (*.dxf)")
        self.file_dxf_despues.fileChanged.connect(lambda p: self.on_dxf_changed(p, "DXF_DESPUÉS"))
        layout.addWidget(self.file_dxf_despues)
        
        layout.addSpacing(10)
        

        
        layout.addSpacing(10)
        
        # 6. Filtro de Propietario
        layout.addWidget(QLabel("<b>Filtrar por Propietario:</b>"))
        row_prop = QHBoxLayout()
        self.chk_prop = QCheckBox()
        self.txt_prop = QLineEdit()
        self.txt_prop.setPlaceholderText("ID Propietario")
        self.txt_prop.setEnabled(False)
        self.chk_prop.toggled.connect(self.txt_prop.setEnabled)
        row_prop.addWidget(self.chk_prop)
        row_prop.addWidget(self.txt_prop)
        layout.addLayout(row_prop)
        
        layout.addSpacing(10)
        
        # 6. Log de Seguimiento (EXPANDIDO)
        layout.addWidget(QLabel("<b>Log de Seguimiento:</b>"))
        self.log_box = QTextEdit()
        self.log_box.setReadOnly(True)
        self.log_box.setStyleSheet("background-color: #f0f0f0; font-family: Consolas; font-size: 9pt;")
        # El log ahora se expande para ocupar todo el espacio disponible
        layout.addWidget(self.log_box, 1)  # El '1' hace que se expanda
        
        # Inicialmente deshabilitar todos los controles excepto carpeta de salida
        self.set_controls_enabled(False)

    def get_filter_settings(self):
        """
        Retorna la configuración de filtrado por propietario.
        """
        return {
            'owner_active': self.chk_prop.isChecked(),
            'owner_id': self.txt_prop.text().strip()
        }

    def add_log(self, message):
        from datetime import datetime
        from PyQt5.QtCore import QCoreApplication
        
        time_str = datetime.now().strftime("%H:%M:%S")
        self.log_box.append(f"[{time_str}] {message}")
        
        # Force UI update
        self.log_box.repaint()
        QCoreApplication.processEvents()
        
        # Auto-scroll
        sb = self.log_box.verticalScrollBar()
        sb.setValue(sb.maximum())
    
    def clear_log(self):
        """
        Limpia el contenido del log.
        """
        self.log_box.clear()

    def on_output_folder_changed(self, path):
        """
        Habilita o deshabilita los controles según si hay carpeta de salida.
        """
        if path and os.path.isdir(path):
            self.set_controls_enabled(True)
            self.add_log(f"<font color='green'>✓ Carpeta de salida configurada: {path}</font>")
        else:
            self.set_controls_enabled(False)
            if path:  # Si hay algo pero no es válido
                self.add_log("<font color='orange'>AVISO: La ruta especificada no es válida.</font>")
    
    def set_controls_enabled(self, enabled):
        """
        Habilita o deshabilita todos los controles excepto la carpeta de salida.
        """
        self.file_antes.setEnabled(enabled)
        self.file_desp.setEnabled(enabled)
        self.file_dxf_antes.setEnabled(enabled)
        self.file_dxf_despues.setEnabled(enabled)
        self.chk_prop.setEnabled(enabled)
        self.txt_prop.setEnabled(enabled and self.chk_prop.isChecked())

    def on_file_changed(self, path, label):
        """
        Maneja cambios en los selectores de archivos SHP.
        Si se borra el archivo, elimina las capas del proyecto.
        """
        if not path or path.strip() == "":
            # Usuario borró el archivo - eliminar capas
            self.remove_layers_by_label(label)
        else:
            # Usuario seleccionó un archivo - cargar SOLO la capa original
            self.load_vector_layer(path, label)

    def on_dxf_changed(self, path, label):
        """
        Maneja cambios en los selectores de archivos DXF.
        Solo guarda la ruta, no procesa hasta EJECUTAR ANÁLISIS.
        """
        if not path or path.strip() == "":
            # Usuario borró el archivo
            if label == "DXF_ANTES":
                self.dxf_antes_path = None
            else:
                self.dxf_desp_path = None
            self.add_log(f"{label} eliminado.")
        else:
            # Guardar ruta para procesar luego
            if label == "DXF_ANTES":
                self.dxf_antes_path = path
            else:
                self.dxf_desp_path = path
            self.add_log(f"<font color='green'>✓ {label} seleccionado: {os.path.basename(path)}</font>")

    def remove_layers_by_label(self, label):
        """
        Elimina del proyecto las capas asociadas a un label (ANTES o DESPUÉS).
        """
        layers_to_remove = []
        
        if label == "ANTES":
            if self.layer_antes and self.layer_antes.id() in QgsProject.instance().mapLayers():
                layers_to_remove.append(self.layer_antes.id())
            self.layer_antes = None
        else:
            if self.layer_desp and self.layer_desp.id() in QgsProject.instance().mapLayers():
                layers_to_remove.append(self.layer_desp.id())
            self.layer_desp = None
        
        if layers_to_remove:
            try:
                QgsProject.instance().removeMapLayers(layers_to_remove)
                self.add_log(f"Capas de {label} eliminadas del proyecto.")
            except Exception:
                # Ignorar error si la capa ya no existe en el registro
                pass

    def load_vector_layer(self, path, label):
        """
        Carga SOLO la capa original al proyecto, sin corrección automática.
        """
        if not path or not os.path.exists(path):
            return
            
        name = os.path.basename(path)
        self.add_log(f"Cargando {label}: {name}...")
        
        layer = QgsVectorLayer(path, f"{label}_{name}", "ogr")
        if not layer.isValid():
            self.add_log(f"<font color='red'>ERROR: La capa {label} no es válida.</font>")
            return
        
        # Asignar SRC del proyecto si no tiene
        project_crs = QgsProject.instance().crs()
        if not layer.crs().isValid():
            layer.setCrs(project_crs)
            self.add_log(f"SRC asignado: {project_crs.authid()}")
            
        QgsProject.instance().addMapLayer(layer)
        self.add_log(f"<font color='green'>✓ Capa {label} añadida al proyecto.</font>")
        
        if label == "ANTES":
            self.layer_antes = layer
        elif label == "DESPUÉS":
            self.layer_desp = layer
        else:
            # Es un aditamento
            self.adit_layers[label] = layer
            
        # EMITIR SEÑAL para mapeo de campos
        self.layerLoaded.emit(label, layer)

    def get_adit_paths(self):
        """Retorna vacío ya que se ha eliminado la entrada manual."""
        return {}
