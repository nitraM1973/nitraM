"""
TabRevision -- Ficha "5: Revisión" (Fase 2).

Módulo NUEVO y AISLADO, mismo espíritu que TabAudit (Ficha 4): puramente
de lectura/agregación sobre AudiNOT_Historial + AudiNOT_Checkpoints + el
campo 'revision_rol' de AUDIT_LAYER_NAME (todo ya existente, ver
core/audit_service.py -> get_cambios_desde_checkpoint). No reimplementa
el guardado de revisión (Ficha 4) ni el cálculo de métricas; el único
dato que escribe esta ficha es un checkpoint nuevo
(AuditService.add_checkpoint).

Deliberadamente NO abre su propia conexión a AUDIT_LAYER_NAME: reutiliza
la MISMA capa que ya tiene abierta (y añadida al proyecto) la Ficha 4,
inyectada por AudiNOTDockManager vía set_audit_layer_provider -- igual
motivo por el que TabAudit.reload_layer() quita las instancias
anteriores de la capa antes de volver a abrirla (varias conexiones GDAL
al mismo .gpkg pueden acabar bloqueando el fichero, sobre todo en
Windows). Si la Ficha 4 todavía no ha cargado su capa (p.ej. el usuario
entra primero en la Ficha 5), es AudiNOTDockManager quien se encarga de
forzar esa carga antes de llamar a refresh() (ver
_on_tab_changed_revision).
"""

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QComboBox,
    QListWidget, QListWidgetItem, QSplitter, QTableWidget, QTableWidgetItem,
    QHeaderView, QAbstractItemView, QMessageBox
)
from PyQt5.QtCore import Qt

from qgis.core import QgsFeatureRequest

from .historial_dialog import HistorialDialog, ORIGEN_LABELS

# Claves internas <-> etiquetas del combo de filtro / categorías (ver
# AuditService.get_cambios_desde_checkpoint, que devuelve un dict con
# exactamente estas 4 claves).
CATEGORIAS = [
    ('mios', "Mis cambios nuevos", "🆕"),
    ('pendientes', "Pendiente de mi revisión", "⏳"),
    ('revisados_ambos', "Ya revisado", "✅"),
    ('sin_rol', "Sin rol registrado", "❔"),
]
CATEGORIA_LABEL = {clave: label for clave, label, _icon in CATEGORIAS}
CATEGORIA_ICON = {clave: icon for clave, _label, icon in CATEGORIAS}

FILTRO_ITEMS = ["Todo"] + [label for _clave, label, _icon in CATEGORIAS]


def _audinot_id_sort_key(audinot_id):
    """Misma clave de ordenación jerárquica (Polígono/Masa-Submasa/
    Recinto-Subrecinto) que TabAudit._audinot_id_sort_key -- duplicada
    aquí en vez de importada para mantener esta ficha tan aislada de la
    Ficha 4 como sea razonable (solo comparte la capa, no código de UI)."""
    def _num(token):
        try:
            return (0, float(token))
        except (TypeError, ValueError):
            return (1, token or '')

    aid = audinot_id or ''
    pol_part, _, rest = aid.partition('/')
    masa_part, _, rec_part = rest.partition('/')
    masa, _, submasa = masa_part.partition('-')
    rec, _, subrec = rec_part.partition('-')

    submasa_key = (0,) if submasa == '' else (1, _num(submasa))
    subrec_key = (0,) if subrec == '' else (1, _num(subrec))

    return (_num(pol_part), _num(masa), submasa_key, _num(rec), subrec_key)


class TabRevision(QWidget):
    """Ficha "5: Revisión". Visible para cualquier rol (sin restricción
    de acceso, ver RESTRICCIONES_REVISOR2 en dock_manager.py)."""

    def __init__(self, iface):
        super().__init__()
        self.iface = iface
        self._audit_service_provider = None
        self._audit_layer_provider = None
        self._role_provider = None
        # fn(bool) inyectada por AudiNOTDockManager -- envuelve
        # TabAudit.set_suppress_activate. Se usa en _zoom_to para que la
        # selección programática que hacemos aquí sobre la capa
        # compartida no dispare el requestActivateTab de la Ficha 4 (ver
        # TabAudit.on_layer_selection_changed): en esta ficha, seleccionar
        # una finca de la lista debe hacer zoom y quedarse en la Ficha
        # "5: Revisión", no saltar a la Ficha "4: Auditoría".
        self._suppress_activate_provider = None

        # Último resultado de get_cambios_desde_checkpoint (dict de 4
        # listas) y el checkpoint que lo originó, cacheados para que
        # apply_filter() no tenga que releer el .gpkg cada vez que
        # cambia el combo de filtro.
        self._cambios = {'mios': [], 'pendientes': [], 'revisados_ambos': [], 'sin_rol': []}
        self._checkpoint = None
        # Lista plana (categoria, entrada) que corresponde 1:1 con las
        # filas actualmente mostradas en self.list_widget.
        self._filas_actuales = []

        self.init_ui()

    # ------------------------------------------------------------------
    # Inyección de dependencias (mismo patrón que TabAudit/TabAdmin)
    # ------------------------------------------------------------------
    def set_audit_service_provider(self, fn):
        """`fn()` debe devolver el AuditService ya asociado a la carpeta
        de proyecto actual (el mismo que usa la Ficha 4), o None si esa
        ficha todavía no lo tiene."""
        self._audit_service_provider = fn

    def set_audit_layer_provider(self, fn):
        """`fn()` debe devolver la capa AUDIT_LAYER_NAME ya abierta por
        la Ficha 4 (self.tab_audit.layer), o None si todavía no está
        cargada."""
        self._audit_layer_provider = fn

    def set_role_provider(self, fn):
        """`fn()` debe devolver el rol activo actual (AudiNOT_Admin),
        igual criterio que AudiNOTDockManager._current_role()."""
        self._role_provider = fn

    def set_suppress_activate_provider(self, fn):
        """`fn(bool)` debe envolver TabAudit.set_suppress_activate --
        ver _zoom_to."""
        self._suppress_activate_provider = fn

    def get_restricted_widgets(self):
        """Sin uso actual: la Ficha 5 no tiene restricción de rol (ver
        RESTRICCIONES_REVISOR2['tab_revision'] = None), pero se expone
        por coherencia con el resto de fichas por si en el futuro
        cambiara ese criterio."""
        return []

    # ------------------------------------------------------------------
    # UI
    # ------------------------------------------------------------------
    def init_ui(self):
        layout = QVBoxLayout(self)

        header = QHBoxLayout()
        self.lbl_checkpoint = QLabel("Sin capa de auditoría cargada todavía.")
        self.lbl_checkpoint.setWordWrap(True)
        self.lbl_checkpoint.setStyleSheet("font-weight:bold; color:#2c3e50;")
        header.addWidget(self.lbl_checkpoint, stretch=1)
        layout.addLayout(header)

        filter_row = QHBoxLayout()
        filter_row.addWidget(QLabel("Filtro:"))
        self.cmb_filtro = QComboBox()
        self.cmb_filtro.addItems(FILTRO_ITEMS)
        self.cmb_filtro.currentIndexChanged.connect(self.apply_filter)
        filter_row.addWidget(self.cmb_filtro)
        filter_row.addStretch()
        self.lbl_count = QLabel("0 fincas")
        self.lbl_count.setStyleSheet("color:#666;")
        filter_row.addWidget(self.lbl_count)
        layout.addLayout(filter_row)

        splitter = QSplitter(Qt.Horizontal)

        self.list_widget = QListWidget()
        self.list_widget.setMinimumWidth(200)
        self.list_widget.currentRowChanged.connect(self.on_select_row)
        self.list_widget.itemClicked.connect(self.on_click_zoom)
        splitter.addWidget(self.list_widget)

        detail_container = QWidget()
        detail_v = QVBoxLayout(detail_container)
        detail_v.setContentsMargins(0, 0, 0, 0)

        self.lbl_detail_title = QLabel("Ninguna finca seleccionada")
        self.lbl_detail_title.setStyleSheet("font-weight:bold;")
        detail_v.addWidget(self.lbl_detail_title)

        self.lbl_detail_nota = QLabel("")
        self.lbl_detail_nota.setWordWrap(True)
        self.lbl_detail_nota.setStyleSheet("color:#888; font-style:italic;")
        self.lbl_detail_nota.setVisible(False)
        detail_v.addWidget(self.lbl_detail_nota)

        # Misma tabla/columnas que HistorialDialog (Fecha/Usuario/Evento/
        # Detalle), reutilizando su formateo (_format_detalle,
        # ORIGEN_LABELS) tal cual -- no se reescribe la lógica de pintado
        # de un evento, ver docstring del módulo.
        self.table_eventos = QTableWidget(0, 4)
        self.table_eventos.setHorizontalHeaderLabels(["Fecha", "Usuario", "Evento", "Detalle"])
        self.table_eventos.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table_eventos.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table_eventos.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table_eventos.verticalHeader().setVisible(False)
        self.table_eventos.setWordWrap(True)
        self.table_eventos.setAlternatingRowColors(True)
        header_ev = self.table_eventos.horizontalHeader()
        header_ev.setSectionResizeMode(0, QHeaderView.Interactive)
        header_ev.setSectionResizeMode(1, QHeaderView.Interactive)
        header_ev.setSectionResizeMode(2, QHeaderView.Interactive)
        header_ev.setSectionResizeMode(3, QHeaderView.Stretch)
        header_ev.sectionResized.connect(lambda *args: self.table_eventos.resizeRowsToContents())
        detail_v.addWidget(self.table_eventos, stretch=1)

        splitter.addWidget(detail_container)
        splitter.setStretchFactor(0, 0)
        splitter.setStretchFactor(1, 1)
        layout.addWidget(splitter, stretch=1)

        self.btn_checkpoint = QPushButton("✔ Marcar todo como revisado hasta hoy")
        self.btn_checkpoint.setToolTip(
            "Fija un nuevo checkpoint con la fecha, usuario y rol actuales. A partir de "
            "ahora, esta ficha solo mostrará lo que cambie DESPUÉS de este momento."
        )
        self.btn_checkpoint.clicked.connect(self.on_click_checkpoint)
        layout.addWidget(self.btn_checkpoint)

    # ------------------------------------------------------------------
    # Carga / refresco
    # ------------------------------------------------------------------
    def refresh(self):
        """Vuelve a leer AudiNOT_Historial/AudiNOT_Checkpoints y a
        clasificar las fincas. Llamado por AudiNOTDockManager cada vez
        que se entra en esta pestaña (ver _on_tab_changed_revision)."""
        audit_service = self._audit_service_provider() if self._audit_service_provider else None
        layer = self._audit_layer_provider() if self._audit_layer_provider else None

        if audit_service is None or layer is None:
            self.lbl_checkpoint.setText(
                "Sin capa de auditoría cargada todavía. Entra primero en la Ficha "
                "\"4: Auditoría\" (o indica una \"Carpeta de Salida\" válida en la Ficha 1)."
            )
            self._cambios = {'mios': [], 'pendientes': [], 'revisados_ambos': [], 'sin_rol': []}
            self._checkpoint = None
            self.list_widget.clear()
            self._filas_actuales = []
            self._render_detail_empty()
            self._update_count_label()
            self.btn_checkpoint.setEnabled(False)
            return

        self.btn_checkpoint.setEnabled(True)
        rol_actual = self._role_provider() if self._role_provider else None

        try:
            self._checkpoint = audit_service.get_last_checkpoint()
            self._cambios = audit_service.get_cambios_desde_checkpoint(layer, rol_actual)
        except Exception as e:
            self.lbl_checkpoint.setText(f"No se pudo leer el estado de revisión: {e}")
            self._cambios = {'mios': [], 'pendientes': [], 'revisados_ambos': [], 'sin_rol': []}
            self.list_widget.clear()
            self._filas_actuales = []
            self._render_detail_empty()
            self._update_count_label()
            return

        self._update_checkpoint_label(rol_actual)
        self.apply_filter()

    def _update_checkpoint_label(self, rol_actual):
        rol_txt = (rol_actual or '?').upper()
        if self._checkpoint:
            cp = self._checkpoint
            tipo_txt = "envío" if cp['tipo'] == 'envio' else "marcado como visto"
            self.lbl_checkpoint.setText(
                f"Viendo como {rol_txt} — cambios desde el último checkpoint "
                f"({tipo_txt} el {cp['fecha']} por {cp['usuario']}, rol {cp['rol'].upper() if cp['rol'] else '?'})."
            )
        else:
            self.lbl_checkpoint.setText(
                f"Viendo como {rol_txt} — todavía no se ha fijado ningún checkpoint: "
                "se muestran los cambios desde siempre."
            )

    # ------------------------------------------------------------------
    # Filtro / lista maestra
    # ------------------------------------------------------------------
    def apply_filter(self):
        self.list_widget.clear()
        self._filas_actuales = []

        seleccion = self.cmb_filtro.currentText()
        if seleccion == "Todo":
            claves = [clave for clave, _label, _icon in CATEGORIAS]
        else:
            claves = [clave for clave, label, _icon in CATEGORIAS if label == seleccion]

        filas = []
        for clave in claves:
            for entrada in self._cambios.get(clave, []):
                filas.append((clave, entrada))

        filas.sort(key=lambda par: _audinot_id_sort_key(par[1]['audinot_id']))

        for clave, entrada in filas:
            icon = CATEGORIA_ICON[clave]
            audinot_id = entrada['audinot_id']
            n = entrada['n_eventos']
            item = QListWidgetItem(f"{icon} {audinot_id}  ({n} evento{'s' if n != 1 else ''})")
            item.setToolTip(CATEGORIA_LABEL[clave] + (f"\n{entrada['nota']}" if entrada.get('nota') else ""))
            self.list_widget.addItem(item)
            self._filas_actuales.append((clave, entrada))

        self._update_count_label()
        if self._filas_actuales:
            self.list_widget.setCurrentRow(0)
        else:
            self._render_detail_empty()

    def _update_count_label(self):
        n = self.list_widget.count()
        self.lbl_count.setText(f"{n} finca" if n == 1 else f"{n} fincas")

    # ------------------------------------------------------------------
    # Selección / detalle
    # ------------------------------------------------------------------
    def on_select_row(self, row):
        if row < 0 or row >= len(self._filas_actuales):
            self._render_detail_empty()
            return
        clave, entrada = self._filas_actuales[row]
        self._render_detail(clave, entrada)

    def _render_detail_empty(self):
        self.lbl_detail_title.setText("Ninguna finca seleccionada")
        self.lbl_detail_nota.setVisible(False)
        self.table_eventos.setRowCount(0)

    def _render_detail(self, clave, entrada):
        audinot_id = entrada['audinot_id']
        n = entrada['n_eventos']
        self.lbl_detail_title.setText(
            f"Finca {audinot_id} — {CATEGORIA_LABEL[clave]} — {n} evento{'s' if n != 1 else ''} "
            "desde el checkpoint"
        )
        if entrada.get('nota'):
            self.lbl_detail_nota.setText(entrada['nota'])
            self.lbl_detail_nota.setVisible(True)
        else:
            self.lbl_detail_nota.setVisible(False)

        # Más reciente primero, igual criterio que HistorialDialog.
        eventos_desc = list(reversed(entrada['eventos']))
        self.table_eventos.setRowCount(0)
        for evento in eventos_desc:
            row = self.table_eventos.rowCount()
            self.table_eventos.insertRow(row)
            self.table_eventos.setItem(row, 0, QTableWidgetItem(evento.get('fecha') or ''))
            self.table_eventos.setItem(row, 1, QTableWidgetItem(evento.get('usuario') or ''))
            origen = evento.get('origen') or ''
            self.table_eventos.setItem(row, 2, QTableWidgetItem(ORIGEN_LABELS.get(origen, origen)))
            self.table_eventos.setItem(row, 3, QTableWidgetItem(HistorialDialog._format_detalle(origen, evento)))
        self.table_eventos.resizeRowsToContents()

    def on_click_zoom(self, item):
        """Doble/clic simple sobre la finca -> zoom en el lienzo, mismo
        patrón que TabAudit.on_click_zoom / zoom_to_current."""
        row = self.list_widget.row(item)
        if row < 0 or row >= len(self._filas_actuales):
            return
        _clave, entrada = self._filas_actuales[row]
        self._zoom_to(entrada['audinot_id'])

    def _zoom_to(self, audinot_id):
        layer = self._audit_layer_provider() if self._audit_layer_provider else None
        if layer is None:
            return

        safe_id = str(audinot_id).replace("'", "''")
        req = QgsFeatureRequest().setFilterExpression(f"audinot_id = '{safe_id}'")
        feat = next(layer.getFeatures(req), None)
        if feat is None:
            return

        geom = feat.geometry()
        if geom is None or geom.isEmpty():
            QMessageBox.information(self, "AudiNOT", "Esta finca no tiene geometría para hacer zoom.")
            return

        canvas = self.iface.mapCanvas()
        rect = geom.boundingBox()
        rect.scale(1.3)
        canvas.setExtent(rect)
        canvas.refresh()
        # layer.select(...) dispara layer.selectionChanged, y la Ficha 4
        # está escuchando esa señal para auto-activarse (ver
        # TabAudit.on_layer_selection_changed). Aquí solo queremos hacer
        # zoom/resaltar sin abandonar la Ficha "5: Revisión", así que se
        # suprime ese salto de ficha mientras dura la selección
        # programática.
        if self._suppress_activate_provider:
            self._suppress_activate_provider(True)
        try:
            layer.removeSelection()
            layer.select(feat.id())
            canvas.flashFeatureIds(layer, [feat.id()])
        except Exception:
            pass
        finally:
            if self._suppress_activate_provider:
                self._suppress_activate_provider(False)

    # ------------------------------------------------------------------
    # Checkpoint
    # ------------------------------------------------------------------
    def on_click_checkpoint(self):
        audit_service = self._audit_service_provider() if self._audit_service_provider else None
        if audit_service is None:
            return
        rol_actual = self._role_provider() if self._role_provider else None

        resp = QMessageBox.question(
            self, "AudiNOT — Marcar como revisado",
            "Esto fija un nuevo checkpoint con la fecha, tu usuario y tu rol activo "
            f"({(rol_actual or '?').upper()}).\n\n"
            "A partir de ahora, esta ficha solo mostrará los cambios que se produzcan "
            "DESPUÉS de este momento -- no se pierde nada del historial completo (sigue "
            "disponible en la Ficha 4 -> 📜 Ver historial), solo cambia el punto de "
            "partida de esta vista.\n\n¿Continuar?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        if resp != QMessageBox.Yes:
            return

        try:
            audit_service.add_checkpoint('marcado_visto', rol=rol_actual)
        except Exception as e:
            QMessageBox.critical(self, "AudiNOT", f"No se pudo fijar el checkpoint:\n{e}")
            return

        self.refresh()
