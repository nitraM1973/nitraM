"""
TabRevision -- Ficha "5: Revisión" (Fase 2).

Módulo NUEVO y AISLADO, mismo espíritu que TabAudit (Ficha 4): puramente
de lectura/agregación sobre AudiNOT_Historial + AudiNOT_Checkpoints + el
campo 'revision_rol' de AUDIT_LAYER_NAME (todo ya existente, ver
core/audit_service.py -> get_cambios_desde_checkpoint). No reimplementa
el guardado de revisión (Ficha 4) ni el cálculo de métricas; el único
dato que escribe esta ficha es un checkpoint nuevo
(AuditService.add_checkpoint).

Fase 3/4 -- frontera híbrida en INTERVALO: la fecha "desde la que se
consideran cambios nuevos" ya NO depende únicamente de que alguien
pulse "Marcar como revisado". Por defecto (self.cmb_frontera en
"Automático") se calcula sola combinando ese checkpoint manual con el
último cambio de rol hacia REVISOR 2 (la entrega TTEC → SP, que ya deja
timestamp por sí sola porque es la puerta del propio control de acceso,
ver AuditService.get_frontera_automatica). Dos desplegables, "Desde" y
"Hasta" (self.cmb_frontera / self.cmb_frontera_hasta), permiten además
acotar un intervalo concreto a mano (fecha exacta, o "Siempre"/"Hoy" en
sus extremos) para los casos límite en que la automática no encaje; el
botón "Marcar como revisado" se mantiene como vía manual explícita,
ahora como complemento y no como único mecanismo. La etiqueta superior
se muestra deliberadamente corta ("REVISOR1 · 20/07 10:15 → hoy"); el
detalle completo (de dónde sale cada fecha, qué hizo el otro rol) va en
su tooltip, no en el texto visible.

Deliberadamente NO abre su propia conexión a AUDIT_LAYER_NAME: reutiliza
la MISMA capa que ya tiene abierta (y añadida al proyecto) la Ficha 4,
inyectada por AudiNOTDockManager vía set_audit_layer_provider -- igual
motivo por el que TabAudit.reload_layer() quita las instancias
anteriores de la capa antes de volver a abrirla (varias conexiones GDAL
al mismo .gpkg pueden acabar bloqueando el fichero, sobre todo en
Windows). Si la Ficha 4 todavía no ha cargado su capa (p.ej. el usuario
entra primero en la Ficha 5), es AudiNOTDockManager quien se encarga de
forzar esa carga antes de llamar a refresh() (ver
_on_tab_changed_revision).
"""

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QComboBox,
    QListWidget, QListWidgetItem, QSplitter, QTableWidget, QTableWidgetItem,
    QHeaderView, QAbstractItemView, QMessageBox
)
from PyQt5.QtCore import Qt
from datetime import datetime

from qgis.core import QgsFeatureRequest

from ..busy_indicator import BusyCursor
from .historial_dialog import HistorialDialog, ORIGEN_LABELS, ESTADO_LABELS

# Claves internas <-> etiquetas del combo de filtro / categorías (ver
# AuditService.get_cambios_desde_checkpoint, que devuelve un dict con
# exactamente estas 4 claves).
CATEGORIAS = [
    ('mios', "Mis cambios nuevos", "🆕"),
    ('pendientes', "Pendiente de mi revisión", "⏳"),
    ('revisados_ambos', "Ya revisado", "✅"),
    ('sin_rol', "Sin rol registrado", "❔"),
]
CATEGORIA_LABEL = {clave: label for clave, label, _icon in CATEGORIAS}
CATEGORIA_ICON = {clave: icon for clave, _label, icon in CATEGORIAS}

FILTRO_ITEMS = ["Todo"] + [label for _clave, label, _icon in CATEGORIAS]


def _fmt_fecha_corta(fecha_iso):
    """Formato corto 'dd/mm HH:MM' para la etiqueta de frontera (ver
    _update_checkpoint_label) -- duplicado a propósito de
    AuditService._fmt_fecha_corta, mismo criterio de aislamiento que
    _audinot_id_sort_key: esta ficha no importa código de UI de otras
    fichas ni depende de detalles internos de AuditService más allá de
    los métodos públicos ya usados."""
    if not fecha_iso:
        return ''
    try:
        return datetime.fromisoformat(fecha_iso).strftime('%d/%m %H:%M')
    except (ValueError, TypeError):
        return str(fecha_iso)[:16]


def _audinot_id_sort_key(audinot_id):
    """Misma clave de ordenación jerárquica (Polígono/Masa-Submasa/
    Recinto-Subrecinto) que TabAudit._audinot_id_sort_key -- duplicada
    aquí en vez de importada para mantener esta ficha tan aislada de la
    Ficha 4 como sea razonable (solo comparte la capa, no código de UI)."""
    def _num(token):
        try:
            return (0, float(token))
        except (TypeError, ValueError):
            return (1, token or '')

    aid = audinot_id or ''
    pol_part, _, rest = aid.partition('/')
    masa_part, _, rec_part = rest.partition('/')
    masa, _, submasa = masa_part.partition('-')
    rec, _, subrec = rec_part.partition('-')

    submasa_key = (0,) if submasa == '' else (1, _num(submasa))
    subrec_key = (0,) if subrec == '' else (1, _num(subrec))

    return (_num(pol_part), _num(masa), submasa_key, _num(rec), subrec_key)


class TabRevision(QWidget):
    """Ficha "5: Revisión". Visible para cualquier rol (sin restricción
    de acceso, ver RESTRICCIONES_REVISOR2 en dock_manager.py)."""

    def __init__(self, iface):
        super().__init__()
        self.iface = iface
        self._audit_service_provider = None
        self._audit_layer_provider = None
        self._role_provider = None
        # fn(bool) inyectada por AudiNOTDockManager -- envuelve
        # TabAudit.set_suppress_activate. Se usa en _zoom_to para que la
        # selección programática que hacemos aquí sobre la capa
        # compartida no dispare el requestActivateTab de la Ficha 4 (ver
        # TabAudit.on_layer_selection_changed): en esta ficha, seleccionar
        # una finca de la lista debe hacer zoom y quedarse en la Ficha
        # "5: Revisión", no saltar a la Ficha "4: Auditoría".
        self._suppress_activate_provider = None

        # Último resultado de get_cambios_desde_checkpoint (dict de 4
        # listas + 'frontera'/'frontera_personalizada'/'fecha_hasta'/
        # 'checkpoint_otro_rol'), cacheado para que apply_filter() no
        # tenga que releer el .gpkg cada vez que cambia el combo de
        # filtro. self.cmb_frontera / self.cmb_frontera_hasta
        # (desplegables "Desde"/"Hasta", ver init_ui) son quienes deciden
        # qué intervalo de fechas se pide en la próxima llamada; no se
        # duplica aquí ningún dato de frontera aparte de este dict.
        self._cambios = {'mios': [], 'pendientes': [], 'revisados_ambos': [], 'sin_rol': []}
        # Lista plana (categoria, entrada) que corresponde 1:1 con las
        # filas actualmente mostradas en self.list_widget.
        self._filas_actuales = []
        # Distingue "el desplegable Desde/Hasta está vacío porque este
        # .gpkg todavía no tiene ningún cambio de rol ni checkpoint" (caso
        # normal, None) de "está vacío porque falló la lectura" (mensaje
        # de error aquí, ver _populate_frontera_combos).
        self._error_fronteras = None

        self.init_ui()

    # ------------------------------------------------------------------
    # Inyección de dependencias (mismo patrón que TabAudit/TabAdmin)
    # ------------------------------------------------------------------
    def set_audit_service_provider(self, fn):
        """`fn()` debe devolver el AuditService ya asociado a la carpeta
        de proyecto actual (el mismo que usa la Ficha 4), o None si esa
        ficha todavía no lo tiene."""
        self._audit_service_provider = fn

    def set_audit_layer_provider(self, fn):
        """`fn()` debe devolver la capa AUDIT_LAYER_NAME ya abierta por
        la Ficha 4 (self.tab_audit.layer), o None si todavía no está
        cargada."""
        self._audit_layer_provider = fn

    def set_role_provider(self, fn):
        """`fn()` debe devolver el rol activo actual (AudiNOT_Admin),
        igual criterio que AudiNOTDockManager._current_role()."""
        self._role_provider = fn

    def set_suppress_activate_provider(self, fn):
        """`fn(bool)` debe envolver TabAudit.set_suppress_activate --
        ver _zoom_to."""
        self._suppress_activate_provider = fn

    def get_restricted_widgets(self):
        """Sin uso actual: la Ficha 5 no tiene restricción de rol (ver
        RESTRICCIONES_REVISOR2['tab_revision'] = None), pero se expone
        por coherencia con el resto de fichas por si en el futuro
        cambiara ese criterio."""
        return []

    # ------------------------------------------------------------------
    # UI
    # ------------------------------------------------------------------
    def init_ui(self):
        layout = QVBoxLayout(self)

        header = QHBoxLayout()
        self.lbl_checkpoint = QLabel("Sin capa cargada.")
        self.lbl_checkpoint.setWordWrap(True)
        self.lbl_checkpoint.setStyleSheet("font-weight:bold; color:#2c3e50;")
        header.addWidget(self.lbl_checkpoint, stretch=1)
        layout.addLayout(header)

        # Selector de intervalo (Fase 3/4): "Desde" por defecto en
        # "Automático" (combina el checkpoint manual propio con el
        # último cambio de rol hacia REVISOR 2, ver
        # AuditService.get_frontera_automatica -- sin que nadie tenga
        # que pulsar nada aparte). "Hasta" por defecto en blanco = hoy.
        # Ambos se rellenan con las mismas fechas conocidas (cambios de
        # rol + checkpoints), para acotar un intervalo concreto cuando
        # la automática no encaje.
        frontera_row = QHBoxLayout()
        frontera_row.addWidget(QLabel("Desde:"))
        self.cmb_frontera = QComboBox()
        self.cmb_frontera.setMinimumWidth(160)
        self._tooltip_base_desde = (
            "Automático: se calcula solo (último checkpoint propio o cambio de rol a "
            "REVISOR 2, el más reciente de los dos). Siempre: sin límite inferior. "
            "O elige una fecha concreta de la lista."
        )
        self.cmb_frontera.setToolTip(self._tooltip_base_desde)
        self.cmb_frontera.currentIndexChanged.connect(self.on_change_frontera)
        frontera_row.addWidget(self.cmb_frontera, stretch=1)
        frontera_row.addWidget(QLabel("Hasta:"))
        self.cmb_frontera_hasta = QComboBox()
        self.cmb_frontera_hasta.setMinimumWidth(160)
        self._tooltip_base_hasta = (
            "Hoy: sin límite superior. O elige una fecha concreta de la lista para "
            "acotar el intervalo."
        )
        self.cmb_frontera_hasta.setToolTip(self._tooltip_base_hasta)
        self.cmb_frontera_hasta.currentIndexChanged.connect(self.on_change_frontera)
        frontera_row.addWidget(self.cmb_frontera_hasta, stretch=1)
        layout.addLayout(frontera_row)

        filter_row = QHBoxLayout()
        filter_row.addWidget(QLabel("Filtro:"))
        self.cmb_filtro = QComboBox()
        self.cmb_filtro.addItems(FILTRO_ITEMS)
        self.cmb_filtro.currentIndexChanged.connect(self.apply_filter)
        filter_row.addWidget(self.cmb_filtro)
        filter_row.addStretch()
        self.lbl_count = QLabel("0 fincas")
        self.lbl_count.setStyleSheet("color:#666;")
        filter_row.addWidget(self.lbl_count)
        layout.addLayout(filter_row)

        splitter = QSplitter(Qt.Horizontal)

        self.list_widget = QListWidget()
        self.list_widget.setMinimumWidth(200)
        self.list_widget.currentRowChanged.connect(self.on_select_row)
        self.list_widget.itemClicked.connect(self.on_click_zoom)
        splitter.addWidget(self.list_widget)

        detail_container = QWidget()
        detail_v = QVBoxLayout(detail_container)
        detail_v.setContentsMargins(0, 0, 0, 0)

        self.lbl_detail_title = QLabel("Ninguna finca seleccionada")
        self.lbl_detail_title.setStyleSheet("font-weight:bold;")
        detail_v.addWidget(self.lbl_detail_title)

        self.lbl_detail_nota = QLabel("")
        self.lbl_detail_nota.setWordWrap(True)
        self.lbl_detail_nota.setStyleSheet("color:#888; font-style:italic;")
        self.lbl_detail_nota.setVisible(False)
        detail_v.addWidget(self.lbl_detail_nota)

        # Misma tabla/columnas que HistorialDialog (Fecha/Usuario/Evento/
        # Detalle), reutilizando su formateo (_format_detalle,
        # ORIGEN_LABELS) tal cual -- no se reescribe la lógica de pintado
        # de un evento, ver docstring del módulo.
        self.table_eventos = QTableWidget(0, 4)
        self.table_eventos.setHorizontalHeaderLabels(["Fecha", "Usuario", "Evento", "Detalle"])
        self.table_eventos.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table_eventos.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table_eventos.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table_eventos.verticalHeader().setVisible(False)
        self.table_eventos.setWordWrap(True)
        self.table_eventos.setAlternatingRowColors(True)
        header_ev = self.table_eventos.horizontalHeader()
        header_ev.setSectionResizeMode(0, QHeaderView.Interactive)
        header_ev.setSectionResizeMode(1, QHeaderView.Interactive)
        header_ev.setSectionResizeMode(2, QHeaderView.Interactive)
        header_ev.setSectionResizeMode(3, QHeaderView.Stretch)
        header_ev.sectionResized.connect(lambda *args: self.table_eventos.resizeRowsToContents())
        detail_v.addWidget(self.table_eventos, stretch=1)

        splitter.addWidget(detail_container)
        splitter.setStretchFactor(0, 0)
        splitter.setStretchFactor(1, 1)
        layout.addWidget(splitter, stretch=1)

        self.btn_checkpoint = QPushButton("✔ Marcar todo como revisado hasta hoy (mi rol)")
        self.btn_checkpoint.setToolTip(
            "Fija TU propio checkpoint manual (con la fecha, usuario y rol actuales). "
            "Normalmente no hace falta pulsarlo: la frontera \"Automático\" de arriba ya "
            "se actualiza sola con cada cambio de rol hacia REVISOR 2. Úsalo solo si "
            "quieres cerrar tu ronda ahora mismo SIN que haya de por medio un cambio de "
            "rol (p.ej. dos revisiones tuyas seguidas sin que el otro rol intervenga "
            "entre medias). Es individual por rol: a partir de ahora, ESTA FICHA -- "
            "cuando vuelvas a entrar con tu mismo rol -- solo te mostrará lo que cambie "
            "DESPUÉS de este momento. No afecta a lo que vea el otro rol: si es él quien "
            "recibe el fichero después, seguirá viendo todo desde SU propia frontera, "
            "sin que este checkpoint se la tape."
        )
        self.btn_checkpoint.clicked.connect(self.on_click_checkpoint)
        layout.addWidget(self.btn_checkpoint)

    # ------------------------------------------------------------------
    # Carga / refresco
    # ------------------------------------------------------------------
    def refresh(self):
        """Vuelve a leer AudiNOT_Historial/AudiNOT_Checkpoints, repuebla
        los desplegables "Desde"/"Hasta" y reclasifica las fincas.
        Llamado por AudiNOTDockManager cada vez que se entra en esta
        pestaña (ver _on_tab_changed_revision)."""
        audit_service = self._audit_service_provider() if self._audit_service_provider else None
        layer = self._audit_layer_provider() if self._audit_layer_provider else None

        if audit_service is None or layer is None:
            self.lbl_checkpoint.setText("Sin capa de auditoría cargada.")
            self.lbl_checkpoint.setToolTip(
                "Entra primero en la Ficha \"4: Auditoría\" (o indica una \"Carpeta de "
                "Salida\" válida en la Ficha 1)."
            )
            self._cambios = {'mios': [], 'pendientes': [], 'revisados_ambos': [], 'sin_rol': []}
            for combo in (self.cmb_frontera, self.cmb_frontera_hasta):
                combo.blockSignals(True)
                combo.clear()
                combo.blockSignals(False)
                combo.setEnabled(False)
            self.list_widget.clear()
            self._filas_actuales = []
            self._render_detail_empty()
            self._update_count_label()
            self.btn_checkpoint.setEnabled(False)
            return

        self.btn_checkpoint.setEnabled(True)
        self.cmb_frontera.setEnabled(True)
        self.cmb_frontera_hasta.setEnabled(True)
        rol_actual = self._role_provider() if self._role_provider else None

        self._populate_frontera_combos(audit_service, rol_actual)
        self._recompute_cambios()

    def _populate_frontera_combos(self, audit_service, rol_actual):
        """Rellena self.cmb_frontera ("Desde") y self.cmb_frontera_hasta
        ("Hasta") con las mismas fechas conocidas (cambios de rol +
        checkpoints, ver AuditService.get_fronteras_disponibles).
        "Desde" empieza en "Automático" (fecha_desde=None -> ver
        AuditService.get_frontera_automatica) y también ofrece "Siempre"
        (fecha_desde=''); "Hasta" empieza en "Hoy" (fecha_hasta=None,
        sin límite superior). Conserva la selección previa de cada combo
        si sigue existiendo entre las opciones nuevas (p.ej. tras fijar
        un checkpoint nuevo, que añade una entrada más a la lista pero
        no cambia lo que ya se estaba mirando)."""
        try:
            candidatos = audit_service.get_fronteras_disponibles(rol_actual)
            self._error_fronteras = None
        except Exception as e:
            candidatos = []
            # Guardado para que refresh()/_recompute_cambios() lo pueda
            # mostrar en el tooltip -- si esto se queda en None, el
            # desplegable vacío es simplemente "todavía no hay ningún
            # cambio de rol ni checkpoint en este .gpkg", NO un fallo.
            self._error_fronteras = str(e)

        def _repoblar(combo, items_fijos):
            previa = combo.itemData(combo.currentIndex()) if combo.count() else None
            habia_seleccion = combo.count() > 0
            combo.blockSignals(True)
            combo.clear()
            for label, data in items_fijos:
                combo.addItem(label, data)
            for cand in candidatos:
                combo.addItem(cand['label'], cand['fecha'])
            idx_restaurar = 0
            if habia_seleccion:
                for i in range(combo.count()):
                    if combo.itemData(i) == previa:
                        idx_restaurar = i
                        break
            combo.setCurrentIndex(idx_restaurar)
            combo.blockSignals(False)

        _repoblar(self.cmb_frontera, [("Automático", None), ("Siempre", "")])
        _repoblar(self.cmb_frontera_hasta, [("Hoy", None)])

        if self._error_fronteras:
            aviso = f"⚠ No se pudieron leer las fechas conocidas: {self._error_fronteras}"
        elif not candidatos:
            aviso = (
                "Sin fechas registradas todavía en este proyecto: no ha habido ningún "
                "cambio de rol (Ficha 7) ni checkpoint manual (botón de abajo)."
            )
        else:
            aviso = None
        for combo, base_tip in (
            (self.cmb_frontera, self._tooltip_base_desde),
            (self.cmb_frontera_hasta, self._tooltip_base_hasta),
        ):
            combo.setToolTip(f"{base_tip}\n\n{aviso}" if aviso else base_tip)

    def on_change_frontera(self):
        """El usuario ha cambiado "Desde" y/o "Hasta" -- recalcula la
        clasificación con el intervalo elegido, sin repoblar los combos
        (no hace falta solo por cambiar de fila)."""
        self._recompute_cambios()

    def _recompute_cambios(self):
        """Vuelve a llamar a get_cambios_desde_checkpoint con el
        intervalo que marquen self.cmb_frontera ("Desde": None =
        automático, '' = siempre, o fecha concreta) y
        self.cmb_frontera_hasta ("Hasta": None = hoy, o fecha concreta),
        y refresca la etiqueta y la lista. Separado de refresh() para
        que cambiar los combos no tenga que repoblarlos ni releer capas."""
        audit_service = self._audit_service_provider() if self._audit_service_provider else None
        layer = self._audit_layer_provider() if self._audit_layer_provider else None
        if audit_service is None or layer is None:
            return

        rol_actual = self._role_provider() if self._role_provider else None
        fecha_desde = (
            self.cmb_frontera.itemData(self.cmb_frontera.currentIndex())
            if self.cmb_frontera.count() else None
        )
        fecha_hasta = (
            self.cmb_frontera_hasta.itemData(self.cmb_frontera_hasta.currentIndex())
            if self.cmb_frontera_hasta.count() else None
        )

        try:
            with BusyCursor():
                self._cambios = audit_service.get_cambios_desde_checkpoint(
                    layer, rol_actual, fecha_desde=fecha_desde, fecha_hasta=fecha_hasta
                )
        except Exception as e:
            self.lbl_checkpoint.setText("Error al leer la revisión.")
            self.lbl_checkpoint.setToolTip(str(e))
            self._cambios = {'mios': [], 'pendientes': [], 'revisados_ambos': [], 'sin_rol': []}
            self.list_widget.clear()
            self._filas_actuales = []
            self._render_detail_empty()
            self._update_count_label()
            return

        self._update_checkpoint_label(rol_actual)
        self.apply_filter()

    def _update_checkpoint_label(self, rol_actual):
        """Etiqueta corta de una sola línea ("REVISOR1 · 20/07 10:15 →
        hoy"); el detalle completo (de dónde sale cada fecha, qué hizo
        el otro rol) va en el tooltip, no en el texto visible -- así no
        satura la ficha con un párrafo cada vez que se entra en ella."""
        rol_txt = (rol_actual or '?').upper()
        otro_rol_txt = "REVISOR1" if rol_actual == 'revisor2' else "REVISOR2"

        frontera = self._cambios.get('frontera')
        fecha_hasta = self._cambios.get('fecha_hasta')

        tag_origen = {
            'checkpoint_manual': 'chk', 'cambio_rol': 'rol',
            'cambio_rol_auto': 'rol auto', 'personalizada': 'manual',
        }
        if frontera is None:
            desde_txt = "siempre"
        else:
            tag = tag_origen.get(frontera.get('origen'), '')
            desde_txt = _fmt_fecha_corta(frontera['fecha']) + (f" ({tag})" if tag else "")
        hasta_txt = "hoy" if not fecha_hasta else _fmt_fecha_corta(fecha_hasta)

        texto = f"{rol_txt} · {desde_txt} → {hasta_txt}"
        if frontera and fecha_hasta and fecha_hasta < frontera['fecha']:
            texto += "  ⚠ intervalo vacío"
        self.lbl_checkpoint.setText(texto)

        origen_txt = {
            'checkpoint_manual': 'tu checkpoint manual ("Marcar como revisado")',
            'cambio_rol': 'el último cambio de rol a REVISOR 2 (entrega TTEC → SP)',
            'cambio_rol_auto': 'el último cambio de rol a REVISOR 2 (automático, por seguridad)',
            'personalizada': 'la fecha elegida a mano',
        }
        partes_tooltip = [f"Viendo como {rol_txt}."]
        if frontera is None:
            partes_tooltip.append("Sin checkpoint ni cambio de rol todavía: historial completo.")
        else:
            quien = f" por {frontera['usuario']}" if frontera.get('usuario') else ""
            partes_tooltip.append(
                f"Desde {origen_txt.get(frontera.get('origen'), 'la última referencia')} "
                f"({frontera['fecha']}{quien})."
            )
        partes_tooltip.append(f"Hasta {fecha_hasta}." if fecha_hasta else "Hasta ahora mismo.")

        cp_otro = self._cambios.get('checkpoint_otro_rol')
        if cp_otro:
            tipo_otro_txt = "envío" if cp_otro['tipo'] == 'envio' else "marcado como visto"
            partes_tooltip.append(
                f"{otro_rol_txt}: último checkpoint manual ({tipo_otro_txt}) el "
                f"{cp_otro['fecha']} por {cp_otro['usuario']}."
            )
        else:
            partes_tooltip.append(f"{otro_rol_txt}: sin checkpoint manual propio todavía.")

        self.lbl_checkpoint.setToolTip(" ".join(partes_tooltip))

    # ------------------------------------------------------------------
    # Filtro / lista maestra
    # ------------------------------------------------------------------
    def apply_filter(self):
        self.list_widget.clear()
        self._filas_actuales = []

        seleccion = self.cmb_filtro.currentText()
        if seleccion == "Todo":
            claves = [clave for clave, _label, _icon in CATEGORIAS]
        else:
            claves = [clave for clave, label, _icon in CATEGORIAS if label == seleccion]

        filas = []
        for clave in claves:
            for entrada in self._cambios.get(clave, []):
                filas.append((clave, entrada))

        filas.sort(key=lambda par: _audinot_id_sort_key(par[1]['audinot_id']))

        for clave, entrada in filas:
            icon = CATEGORIA_ICON[clave]
            audinot_id = entrada['audinot_id']
            n = entrada['n_eventos']
            estado_actual = entrada.get('revision_estado_actual', '')
            estado_txt = ESTADO_LABELS.get(estado_actual, estado_actual)
            item = QListWidgetItem(
                f"{icon} {audinot_id}  ({n} evento{'s' if n != 1 else ''}) — {estado_txt}"
            )
            item.setToolTip(CATEGORIA_LABEL[clave] + (f"\n{entrada['nota']}" if entrada.get('nota') else ""))
            self.list_widget.addItem(item)
            self._filas_actuales.append((clave, entrada))

        self._update_count_label()
        if self._filas_actuales:
            self.list_widget.setCurrentRow(0)
        else:
            self._render_detail_empty()

    def _update_count_label(self):
        n = self.list_widget.count()
        self.lbl_count.setText(f"{n} finca" if n == 1 else f"{n} fincas")

    # ------------------------------------------------------------------
    # Selección / detalle
    # ------------------------------------------------------------------
    def on_select_row(self, row):
        if row < 0 or row >= len(self._filas_actuales):
            self._render_detail_empty()
            return
        clave, entrada = self._filas_actuales[row]
        self._render_detail(clave, entrada)

    def _render_detail_empty(self):
        self.lbl_detail_title.setText("Ninguna finca seleccionada")
        self.lbl_detail_nota.setVisible(False)
        self.table_eventos.setRowCount(0)

    def _render_detail(self, clave, entrada):
        audinot_id = entrada['audinot_id']
        n = entrada['n_eventos']
        estado_actual = entrada.get('revision_estado_actual', '')
        estado_txt = ESTADO_LABELS.get(estado_actual, estado_actual)
        self.lbl_detail_title.setText(
            f"Finca {audinot_id} — {CATEGORIA_LABEL[clave]} — {n} evento{'s' if n != 1 else ''} "
            f"desde el checkpoint — Estado actual: {estado_txt}"
        )
        if entrada.get('nota'):
            self.lbl_detail_nota.setText(entrada['nota'])
            self.lbl_detail_nota.setVisible(True)
        else:
            self.lbl_detail_nota.setVisible(False)

        # Más reciente primero, igual criterio que HistorialDialog.
        eventos_desc = list(reversed(entrada['eventos']))
        self.table_eventos.setRowCount(0)
        for evento in eventos_desc:
            row = self.table_eventos.rowCount()
            self.table_eventos.insertRow(row)
            self.table_eventos.setItem(row, 0, QTableWidgetItem(evento.get('fecha') or ''))
            self.table_eventos.setItem(row, 1, QTableWidgetItem(evento.get('usuario') or ''))
            origen = evento.get('origen') or ''
            self.table_eventos.setItem(row, 2, QTableWidgetItem(ORIGEN_LABELS.get(origen, origen)))
            self.table_eventos.setItem(row, 3, QTableWidgetItem(HistorialDialog._format_detalle(origen, evento)))
        self.table_eventos.resizeRowsToContents()

    def on_click_zoom(self, item):
        """Doble/clic simple sobre la finca -> zoom en el lienzo, mismo
        patrón que TabAudit.on_click_zoom / zoom_to_current."""
        row = self.list_widget.row(item)
        if row < 0 or row >= len(self._filas_actuales):
            return
        _clave, entrada = self._filas_actuales[row]
        self._zoom_to(entrada['audinot_id'])

    def _zoom_to(self, audinot_id):
        layer = self._audit_layer_provider() if self._audit_layer_provider else None
        if layer is None:
            return

        safe_id = str(audinot_id).replace("'", "''")
        req = QgsFeatureRequest().setFilterExpression(f"audinot_id = '{safe_id}'")
        feat = next(layer.getFeatures(req), None)
        if feat is None:
            return

        geom = feat.geometry()
        if geom is None or geom.isEmpty():
            QMessageBox.information(self, "AudiNOT", "Esta finca no tiene geometría para hacer zoom.")
            return

        canvas = self.iface.mapCanvas()
        rect = geom.boundingBox()
        rect.scale(1.3)
        canvas.setExtent(rect)
        canvas.refresh()
        # layer.select(...) dispara layer.selectionChanged, y la Ficha 4
        # está escuchando esa señal para auto-activarse (ver
        # TabAudit.on_layer_selection_changed). Aquí solo queremos hacer
        # zoom/resaltar sin abandonar la Ficha "5: Revisión", así que se
        # suprime ese salto de ficha mientras dura la selección
        # programática.
        if self._suppress_activate_provider:
            self._suppress_activate_provider(True)
        try:
            layer.removeSelection()
            layer.select(feat.id())
            canvas.flashFeatureIds(layer, [feat.id()])
        except Exception:
            pass
        finally:
            if self._suppress_activate_provider:
                self._suppress_activate_provider(False)

    # ------------------------------------------------------------------
    # Checkpoint
    # ------------------------------------------------------------------
    def on_click_checkpoint(self):
        audit_service = self._audit_service_provider() if self._audit_service_provider else None
        if audit_service is None:
            return
        rol_actual = self._role_provider() if self._role_provider else None

        resp = QMessageBox.question(
            self, "AudiNOT — Marcar como revisado",
            "Esto fija TU PROPIO checkpoint manual, con la fecha, tu usuario y tu rol "
            f"activo ({(rol_actual or '?').upper()}).\n\n"
            "Normalmente no hace falta: la frontera \"Automático\" ya se actualiza sola "
            "en cada cambio de rol hacia REVISOR 2. Usa esto solo para cerrar tu ronda "
            "ahora mismo sin que haya de por medio un cambio de rol.\n\n"
            "Es individual por rol: la próxima vez que ENTRES TÚ con este mismo rol (y "
            "sigas en \"Automático\"), esta ficha solo te mostrará los cambios que se "
            "produzcan DESPUÉS de este momento -- no se pierde nada del historial "
            "completo (sigue disponible en la Ficha 4 → 📜 Ver historial), solo cambia "
            "tu punto de partida.\n\n"
            "No afecta al otro rol: cuando reciba el fichero, seguirá viendo todo lo "
            "que hagas a partir de ahora, sin que este checkpoint se lo oculte.\n\n"
            "¿Continuar?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        if resp != QMessageBox.Yes:
            return

        try:
            audit_service.add_checkpoint('marcado_visto', rol=rol_actual)
        except Exception as e:
            QMessageBox.critical(self, "AudiNOT", f"No se pudo fijar el checkpoint:\n{e}")
            return

        self.refresh()
