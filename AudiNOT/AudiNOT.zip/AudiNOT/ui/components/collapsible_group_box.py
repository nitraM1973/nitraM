from PyQt5.QtWidgets import QWidget, QVBoxLayout, QToolButton, QFrame
from PyQt5.QtCore import Qt


class CollapsibleGroupBox(QWidget):
    """Sustituto de QGroupBox cuyo título es clicable para
    colapsar/expandir el contenido del apartado. Delante del título se
    muestra una flecha (▼ expandido / ▶ colapsado, vía QToolButton con
    setArrowType) que se actualiza sola al pulsar. El contenido se
    asigna con `set_content_layout(layout)` en vez de `setLayout(layout)`
    (ese sigue reservado internamente para el layout fijo del propio
    widget contenedor). Compartido entre Ficha 2 (Mapeo de Campos),
    Ficha 3 (Umbrales) y Ficha 4 (Auditoría, bloque de Filtro) para no
    duplicar la misma implementación en cada una."""

    def __init__(self, title, parent=None, collapsed=False):
        super().__init__(parent)

        self.toggle_button = QToolButton(self)
        self.toggle_button.setText(title)
        self.toggle_button.setCheckable(True)
        self.toggle_button.setChecked(not collapsed)
        self.toggle_button.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
        self.toggle_button.setArrowType(Qt.DownArrow if not collapsed else Qt.RightArrow)
        self.toggle_button.setCursor(Qt.PointingHandCursor)
        self.toggle_button.setStyleSheet(
            "QToolButton { border: none; font-weight: bold; font-size: 10pt; "
            "padding: 4px 2px; } QToolButton:hover { color: #2c3e50; }"
        )
        self.toggle_button.clicked.connect(self._on_toggled)

        # Marco con borde (mismo efecto visual que el recuadro de un
        # QGroupBox) que envuelve el contenido real de la sección y es
        # lo único que se oculta/muestra al colapsar.
        self.content_frame = QFrame(self)
        self.content_frame.setFrameShape(QFrame.StyledPanel)
        self.content_frame.setVisible(not collapsed)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(2)
        outer.addWidget(self.toggle_button)
        outer.addWidget(self.content_frame)

    def _on_toggled(self, checked):
        self.toggle_button.setArrowType(Qt.DownArrow if checked else Qt.RightArrow)
        self.content_frame.setVisible(checked)

    def set_content_layout(self, layout):
        self.content_frame.setLayout(layout)

    def setToolTip(self, text):
        # Se pone en el botón del título (lo único visible/clicable
        # siempre, colapsado o no) en vez de en el contenedor entero.
        self.toggle_button.setToolTip(text)

    def is_expanded(self):
        return self.toggle_button.isChecked()

    def set_expanded(self, expanded):
        if self.toggle_button.isChecked() != expanded:
            self.toggle_button.setChecked(expanded)
            self._on_toggled(expanded)
