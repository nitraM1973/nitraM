"""
HistorialDialog
================

Ventana NO MODAL que muestra el historial completo (tabla
`AudiNOT_Historial` del GeoPackage de auditoría, ver
core/audit_service.py) de la finca actualmente seleccionada en la
Ficha "4: Auditoría".

Se abre con el botón "📜 Ver historial" del panel de revisión
(TabAudit.toggle_historial_dialog) y se mantiene sincronizada con la
selección de la lista: TabAudit la refresca sola
(TabAudit._refresh_historial_dialog) cada vez que cambia la finca
seleccionada, se guarda una revisión, se hace doble clic para alternar
NOTIFICAR/NO NOTIFICAR, o se ejecuta una acción masiva -- sin que el
usuario tenga que cerrarla y volver a abrirla.

Deliberadamente NO modal: así se puede dejar abierta en una esquina de
la pantalla mientras se sigue trabajando con el resto de la Ficha 4
(cambiar de finca en la lista, guardar revisiones...), que es
precisamente lo que la hace útil como consulta rápida en vez de un
diálogo bloqueante que obligaría a cerrarla para seguir revisando.
"""

import html as _html
from datetime import datetime

from PyQt5.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QTableWidget, QTableWidgetItem,
    QHeaderView, QAbstractItemView, QPushButton, QMessageBox
)
from PyQt5.QtGui import QTextDocument
from PyQt5.QtPrintSupport import QPrinter, QPrintDialog

# Etiqueta legible para cada valor de 'origen' (ver
# diseno_historial_ficha4.md, punto 2, columna 'origen').
ORIGEN_LABELS = {
    'panel': '📝 Revisión (panel)',
    'doble_clic': '🖱 Revisión (doble clic)',
    'bulk_no_notificar': '⚡ Masiva: pendientes → NO NOTIFICAR',
    'bulk_reset': '⚡ Masiva: reset a Sin revisar',
    'recalculo_metricas': '🔄 Recálculo de métricas',
    'aparicion': '↩ Reaparece en el cálculo',
    'desaparicion': '⛔ Desaparece del cálculo',
    'migracion_inicial': '📦 Estado inicial (versión anterior)',
}

ESTADO_LABELS = {
    '': 'Sin revisar', 'rev': '👁 Revisar', 'si': '✔ Notificar', 'no': '✘ No notificar',
}

# Etiqueta legible para el campo 'rol' de AudiNOT_Historial. '' cubre
# tanto las entradas de 'migracion_inicial' (rol deliberadamente no
# reconstruido, ver _seed_historial_from_existing_reviews) como
# cualquier fila escrita antes de que esta columna existiera en
# versiones anteriores del plugin (ver _migrate_historial_schema).
ROL_LABELS = {
    'revisor1': 'Revisor 1', 'revisor2': 'Revisor 2', '': '—',
}

# Orígenes que corresponden a una revisión humana hecha CON el
# historial ya activo (estado_anterior/estado_nuevo y obs_nueva tienen
# sentido tal cual). 'migracion_inicial' se formatea aparte (ver
# _detalle_lines): no tiene un estado_anterior real que mostrar.
_REVISION_HUMANA_ORIGENES = {'panel', 'doble_clic', 'bulk_no_notificar', 'bulk_reset'}


class HistorialDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("AudiNOT — Historial de la finca")
        self.setModal(False)
        self.resize(760, 420)

        layout = QVBoxLayout(self)

        header_row = QHBoxLayout()
        self.lbl_title = QLabel("")
        self.lbl_title.setStyleSheet("font-weight:bold; font-size:13px;")
        header_row.addWidget(self.lbl_title, stretch=1)

        self.btn_print = QPushButton("🖨 Imprimir / PDF")
        self.btn_print.setToolTip(
            "Abre el diálogo de impresión con un documento formateado para "
            "imprimir en papel o guardar como PDF (elige la impresora "
            "'Microsoft Print to PDF' en el propio diálogo)."
        )
        self.btn_print.clicked.connect(self._print_historial)
        header_row.addWidget(self.btn_print)
        layout.addLayout(header_row)

        # Finca y entradas actualmente mostradas (se guardan aparte de la
        # QTableWidget para no tener que releer la tabla al imprimir, y
        # para poder generar el documento impreso en orden cronológico
        # distinto al de la tabla en pantalla -- ver _print_historial).
        self._audinot_id = None
        self._entries = []

        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(["Fecha", "Usuario", "Rol", "Evento", "Detalle"])
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.verticalHeader().setVisible(False)
        self.table.setWordWrap(True)
        self.table.setAlternatingRowColors(True)

        header = self.table.horizontalHeader()
        # Interactive en las 4 primeras: el usuario puede arrastrar las
        # divisorias a mano (antes eran ResizeToContents/Stretch, que en
        # Qt bloquean el arrastre -- ninguna divisoria era manejable).
        # Detalle sigue en Stretch para que ocupe siempre el resto del
        # ancho disponible sin que el usuario tenga que tocarla.
        header.setSectionResizeMode(0, QHeaderView.Interactive)
        header.setSectionResizeMode(1, QHeaderView.Interactive)
        header.setSectionResizeMode(2, QHeaderView.Interactive)
        header.setSectionResizeMode(3, QHeaderView.Interactive)
        header.setSectionResizeMode(4, QHeaderView.Stretch)
        # Recalcula el alto de las filas cada vez que una divisoria se
        # mueve (a mano o porque Detalle se reajusta en Stretch al
        # cambiar las demás): con word wrap activo, el nº de líneas que
        # ocupa el texto de Detalle depende del ancho que le quede, así
        # que el alto de fila tiene que recalcularse, no quedar fijo del
        # primer cálculo.
        header.sectionResized.connect(lambda *args: self.table.resizeRowsToContents())
        layout.addWidget(self.table, stretch=1)

        self.lbl_status = QLabel("")
        self.lbl_status.setStyleSheet("color:#888;")
        self.lbl_status.setWordWrap(True)
        layout.addWidget(self.lbl_status)

    # ------------------------------------------------------------------
    def show_empty(self):
        """Sin ninguna finca seleccionada en la Ficha 4 (p.ej. lista
        vacía tras un filtro que no devuelve resultados)."""
        self._audinot_id = None
        self._entries = []
        self.lbl_title.setText("Ninguna finca seleccionada")
        self.table.setRowCount(0)
        self.lbl_status.setText("Selecciona una finca en la lista de la Ficha 4 para ver su historial.")

    def show_error(self, message):
        self._audinot_id = None
        self._entries = []
        self.lbl_title.setText("Error")
        self.table.setRowCount(0)
        self.lbl_status.setText(f"No se pudo leer el historial: {message}")

    def set_entries(self, audinot_id, entries):
        """entries: lista de dicts (ver AuditService.get_historial_for_finca),
        ya ordenados por fecha descendente."""
        self._audinot_id = audinot_id
        self._entries = entries

        self.lbl_title.setText(f"Finca {audinot_id} — {len(entries)} entrada(s) de historial")
        self.table.setRowCount(0)

        if not entries:
            self.lbl_status.setText(
                "Sin entradas todavía para esta finca. El historial solo registra "
                "revisiones y recálculos hechos con esta versión del plugin; no hay "
                "entradas retroactivas de antes de activar el historial."
            )
            return
        self.lbl_status.setText("")

        for entry in entries:
            row = self.table.rowCount()
            self.table.insertRow(row)

            self.table.setItem(row, 0, QTableWidgetItem(entry.get('fecha') or ''))
            self.table.setItem(row, 1, QTableWidgetItem(entry.get('usuario') or ''))

            rol = entry.get('rol') or ''
            self.table.setItem(row, 2, QTableWidgetItem(ROL_LABELS.get(rol, rol)))

            origen = entry.get('origen') or ''
            self.table.setItem(row, 3, QTableWidgetItem(ORIGEN_LABELS.get(origen, origen)))
            self.table.setItem(row, 4, QTableWidgetItem(self._format_detalle(origen, entry)))

        self.table.resizeRowsToContents()
        # Anchos iniciales sensatos para las 3 primeras columnas: al ser
        # ahora Interactive (ver __init__), ya no se autoajustan solas al
        # contenido como con ResizeToContents -- se fijan aquí, una vez,
        # a partir de los datos recién insertados; a partir de ahí el
        # usuario puede arrastrarlas a su gusto sin que se le "resistan".
        self.table.resizeColumnToContents(0)
        self.table.resizeColumnToContents(1)
        self.table.resizeColumnToContents(2)
        self.table.resizeColumnToContents(3)

    def resizeEvent(self, event):
        """Al redimensionar la ventana del diálogo, Detalle (columna
        Stretch) cambia de ancho automáticamente, así que el nº de
        líneas que necesita el texto envuelto también cambia: sin este
        recálculo, las filas se quedaban con el alto del último cálculo
        y el texto podía quedar cortado (o sobrar hueco vacío)."""
        super().resizeEvent(event)
        self.table.resizeRowsToContents()

    # ------------------------------------------------------------------
    # Impresión / PDF
    # ------------------------------------------------------------------
    def _print_historial(self):
        if not self._entries:
            QMessageBox.information(
                self, "AudiNOT",
                "No hay entradas de historial para esta finca todavía; no hay nada que imprimir."
            )
            return

        document = QTextDocument()
        document.setHtml(self._build_print_html())
        # Margen interno propio de QTextDocument (por defecto no es 0):
        # se suma al margen de página del printer, así que se anula aquí
        # para que el único margen efectivo sea el que se fija más abajo.
        document.setDocumentMargin(0)

        printer = QPrinter(QPrinter.HighResolution)

        print_dialog = QPrintDialog(printer, self)
        print_dialog.setWindowTitle(f"Imprimir historial — Finca {self._audinot_id}")
        if print_dialog.exec_() != QDialog.Accepted:
            return

        # Los márgenes se fijan AQUÍ, después de cerrar el diálogo de
        # impresión -- no antes (como estaba): al elegir impresora/papel
        # dentro del propio QPrintDialog, el driver puede reemplazar el
        # page-setup del QPrinter por su configuración por defecto (con
        # márgenes bastante más amplios de los que se piden aquí),
        # pisando cualquier setPageMargins() hecho antes de abrir el
        # diálogo. Fijándolos justo antes de imprimir, ya no hay nada
        # después que los pueda sobrescribir.
        printer.setFullPage(False)
        printer.setPageMargins(8, 8, 8, 8, QPrinter.Millimeter)

        document.print_(printer)

    def _build_print_html(self):
        """Documento HTML/CSS aparte del que muestra QTableWidget en
        pantalla: pensado para QTextDocument (no depende de QtWebEngine,
        es un módulo distinto y siempre disponible junto con
        QtPrintSupport), con aspecto de informe técnico -- cabecera,
        tabla con bordes y pie con metadatos de generación, para que se
        pueda entregar como justificante de trazabilidad.

        Cada entrada es UNA sola fila de la tabla exterior (no dos, como
        en un intento anterior): dentro de su única celda va una
        tablita interna de 2 filas (Fecha/Usuario/Rol/Evento arriba,
        Detalle a ancho completo debajo). Al ser una única fila/celda
        para la tabla EXTERIOR -que es la que decide dónde parte página
        al imprimir-, un comentario largo puede alargar esa celda, pero
        Qt nunca corta la cabecera (Fecha/Usuario/Rol/Evento) por un
        lado y el Detalle por otro en páginas distintas: quedan
        pegados como un solo bloque. 'page-break-inside:avoid' en la
        fila exterior es además una segunda red de seguridad para que,
        si cabe entera, la entrada completa salte de página en vez de
        partirse por la mitad.

        Los anchos (16% / 20% / 12% / 52%) se fijan en las columnas de
        CADA tablita interna Y en la cabecera exterior: al ser el mismo
        porcentaje del mismo ancho de página en todas, las columnas
        quedan alineadas visualmente entrada tras entrada aunque cada
        una viva en su propia tabla interna independiente.
        """
        import getpass
        import socket
        try:
            usuario = f"{getpass.getuser()}/{socket.gethostname()}"
        except Exception:
            usuario = "desconocido/desconocido"
        ahora = datetime.now().strftime("%d/%m/%Y %H:%M")

        # Orden cronológico ascendente (más antigua primero) para el
        # documento impreso: como relato de trazabilidad se lee mejor de
        # principio a fin, al contrario que la tabla en pantalla (más
        # reciente primero, pensada para consulta rápida del último
        # evento).
        entries_asc = list(reversed(self._entries))

        W_FECHA, W_USUARIO, W_ROL, W_EVENTO = "16%", "20%", "12%", "52%"

        rows_html = []
        for entry in entries_asc:
            rol = entry.get('rol') or ''
            origen = entry.get('origen') or ''
            detalle_html = self._format_detalle_html(origen, entry)
            rows_html.append(
                "<tr style=\"page-break-inside:avoid;\">"
                "<td colspan=\"4\" style=\"padding:0; border:1px solid #999999; "
                "border-bottom:2px solid #999999;\">"
                "<table style=\"width:100%; border-collapse:collapse;\">"
                "<tr>"
                f"<td style=\"width:{W_FECHA}; border:none; white-space:nowrap; "
                f"padding:3px 5px 1px 5px;\">{_html.escape(entry.get('fecha') or '')}</td>"
                f"<td style=\"width:{W_USUARIO}; border:none; padding:3px 5px 1px 5px;\">"
                f"{_html.escape(entry.get('usuario') or '')}</td>"
                f"<td style=\"width:{W_ROL}; border:none; padding:3px 5px 1px 5px;\">"
                f"{_html.escape(ROL_LABELS.get(rol, rol))}</td>"
                f"<td style=\"width:{W_EVENTO}; border:none; padding:3px 5px 1px 5px;\">"
                f"{_html.escape(ORIGEN_LABELS.get(origen, origen))}</td>"
                "</tr>"
                "<tr>"
                "<td colspan=\"4\" style=\"border:none; background-color:#fafafa; "
                "font-style:italic; color:#333333; padding:1px 5px 4px 5px; "
                "line-height:1.4;\">"
                f"{detalle_html}</td>"
                "</tr>"
                "</table>"
                "</td>"
                "</tr>"
            )

        return f"""
        <html>
        <head>
        <style>
            body {{ font-family: 'Segoe UI', Arial, sans-serif; color:#1a1a1a; margin:0; }}
            h1 {{ font-size: 16pt; margin-bottom: 2px; }}
            .subtitle {{ font-size: 10pt; color:#555; margin-top:0; margin-bottom: 16px; }}
            table {{ border-collapse: collapse; width: 100%; font-size: 9pt; }}
            th {{ border: 1px solid #999999; padding: 3px 5px; text-align: left; background-color: #e6e6e6; font-weight: bold; }}
            .footer {{ margin-top: 20px; font-size: 8pt; color: #777777; border-top: 1px solid #cccccc; padding-top: 6px; }}
        </style>
        </head>
        <body>
            <h1>AudiNOT — Historial de auditoría</h1>
            <p class="subtitle">Finca {_html.escape(str(self._audinot_id))}
                &nbsp;·&nbsp; {len(entries_asc)} entrada(s)
                &nbsp;·&nbsp; generado el {ahora}</p>
            <table>
                <tr>
                    <th style="width:{W_FECHA};">Fecha</th>
                    <th style="width:{W_USUARIO};">Usuario</th>
                    <th style="width:{W_ROL};">Rol</th>
                    <th style="width:{W_EVENTO};">Evento</th>
                </tr>
                {''.join(rows_html)}
            </table>
            <p class="footer">Documento generado con AudiNOT por {_html.escape(usuario)} el {ahora}.
                Uso interno / trazabilidad administrativa.</p>
        </body>
        </html>
        """

    @staticmethod
    def _split_raw_detalle(texto):
        """Divide en líneas el 'detalle' tal cual quedó guardado en
        AudiNOT_Historial para los orígenes que no se recomponen a
        partir de otros campos (recalculo_metricas/aparicion/
        desaparicion, ver _detalle_lines): usa saltos de línea reales
        si ya los tiene (formato actual, ver el "\n".join(...) de
        AuditService al construir el changelog de recalculo_metricas)
        y, si no, cae en un '; ' como separador heredado de versiones
        anteriores del plugin -- así el historial que ya estuviera
        guardado en el .gpkg de cada usuario ANTES de este cambio
        también se ve por líneas, sin tener que migrar nada."""
        texto = (texto or '').strip()
        if not texto:
            return []
        if '\n' in texto:
            return [linea.strip() for linea in texto.split('\n') if linea.strip()]
        if '; ' in texto:
            return [parte.strip() for parte in texto.split('; ') if parte.strip()]
        return [texto]

    @staticmethod
    def _detalle_lines(origen, entry):
        """Descompone el 'detalle' de una entrada en una lista de
        líneas lógicas -- una por apartado (transición de estado,
        observación, aviso...) -- en vez de una única cadena larga.
        _format_detalle (pantalla) y _format_detalle_html (impresión/
        PDF) parten de esta misma lista y solo cambian el separador
        con el que la unen."""
        if origen == 'migracion_inicial':
            # No hay "estado anterior" real que mostrar (el sistema
            # antiguo no guardaba una secuencia de cambios, solo el
            # último valor) -- mostrarlo como si lo hubiera habido
            # ("Sin revisar → ...") sería inventar un dato que no existe.
            estado_nuevo = entry.get('estado_nuevo') or ''
            lines = [f"Estado capturado: {ESTADO_LABELS.get(estado_nuevo, estado_nuevo)}"]
            obs_nueva = (entry.get('obs_nueva') or '').strip()
            if obs_nueva:
                lines.append(f"Obs.: {obs_nueva}")
            lines.append("(revisión de una versión anterior del plugin, sin más detalle disponible)")
            return lines
        if origen in _REVISION_HUMANA_ORIGENES:
            estado_anterior = entry.get('estado_anterior') or ''
            estado_nuevo = entry.get('estado_nuevo') or ''
            lines = [f"{ESTADO_LABELS.get(estado_anterior, estado_anterior)} → "
                     f"{ESTADO_LABELS.get(estado_nuevo, estado_nuevo)}"]
            obs_nueva = (entry.get('obs_nueva') or '').strip()
            if obs_nueva:
                lines.append(f"Obs.: {obs_nueva}")
            return lines
        return HistorialDialog._split_raw_detalle(entry.get('detalle'))

    @staticmethod
    def _format_detalle(origen, entry):
        """Texto plano para la celda 'Detalle' en pantalla
        (QTableWidgetItem, dentro de la ventana NO modal): una línea
        por apartado separada por saltos de línea reales. Con
        setWordWrap(True) activo en la tabla (ver __init__) y
        resizeRowsToContents() recalculado tras rellenarla y en cada
        resizeEvent, Qt respeta el \n como salto de línea forzado al
        dibujar la celda -- no hace falta nada más para que cada
        apartado quede en su propia línea."""
        return "\n".join(HistorialDialog._detalle_lines(origen, entry))

    @staticmethod
    def _format_detalle_html(origen, entry):
        """Misma descomposición en líneas que _format_detalle, pero
        para el HTML de impresión/PDF (_build_print_html): cada línea
        se escapa POR SEPARADO y se unen con <br>, en vez de escapar
        de una vez el bloque ya unido con \n -- un salto de línea real
        dentro de una cadena Python no se traduce solo, vía HTML/CSS,
        en un salto visual dentro de un <td> normal."""
        lines = HistorialDialog._detalle_lines(origen, entry)
        if not lines:
            return '—'
        return "<br>".join(_html.escape(linea) for linea in lines)
