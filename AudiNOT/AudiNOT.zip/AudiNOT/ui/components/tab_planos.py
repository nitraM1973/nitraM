# -*- coding: utf-8 -*-
"""
Pestaña "6: Planos" -- generación masiva de planos ANTES/DESPUÉS a partir
de una plantilla .qpt, una finca por plano, con encuadre y escala
normalizados. Ver `spec_pestana_7_planos.md` y `core/planos_service.py`
(docstring de cabecera) para el detalle de las decisiones tomadas en los
puntos que la spec dejaba abiertos.

--------------------------------------------------------------------
NOTA DE REDISEÑO UI/UX (respecto a la versión original secuencial)
--------------------------------------------------------------------
Objetivo: que un usuario que NO conoce el flujo interno pueda ver, de
un vistazo y sin necesidad de leer el código ni el manual, (a) qué es
obligatorio y qué es opcional, (b) cuántas fincas tiene seleccionadas
y (c) qué le falta para poder pulsar "Generar". Cambios concretos:

  1. 8 bloques secuenciales -> 4 secciones numeradas (Plantilla,
     Capas obligatorias [+ opcionales plegadas], Fincas, Escala/Salida).
  2. Los `QgsMapLayerComboBox` de capas ya NO se estiran al 100% del
     ancho del dock (esto es lo que hacía que la ficha se viera
     "apelotonada" con controles enormes para mostrar un nombre de
     capa corto). Se fija un ancho razonable y el espacio sobrante se
     usa para una etiqueta "auto" cuando la capa se ha detectado sola.
  3. Las capas opcionales (aditamentos, construcciones, capas
     adicionales) se agrupan en UNA sección plegable, colapsada por
     defecto: son la parte menos usada y no debe competir visualmente
     con lo obligatorio.
  4. La escala manual y el margen ya no conviven siempre visibles:
     solo se muestra el control del modo activo (antes solo se
     deshabilitaba el que no aplicaba, pero seguía ocupando espacio).
  5. Contador "X/Y fincas seleccionadas" en la cabecera de la tabla,
     actualizado en vivo al marcar/desmarcar checkboxes.
  6. Barra de estado + botón "Generar planos" FIJOS al pie de la
     ficha (fuera del área de scroll), con un resumen en una línea de
     qué falta (plantilla / capas / fincas / carpeta) y el botón
     deshabilitado hasta que todo esté listo -- así se elimina el
     ciclo de "pulsar -> leer aviso -> corregir -> repetir".

La lógica de negocio (servicios, generación, exportación) no se ha
tocado: todos los métodos públicos y el orden de las validaciones en
`on_generate` son los mismos que en la versión anterior.
--------------------------------------------------------------------
"""

import os
import time
import tempfile
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QPixmap
from qgis.PyQt.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QFormLayout, QLabel, QComboBox, QPushButton,
    QTableWidget, QTableWidgetItem, QHeaderView, QGroupBox, QCheckBox,
    QRadioButton, QButtonGroup, QSpinBox, QListWidget, QListWidgetItem,
    QAbstractItemView, QProgressDialog, QMessageBox, QApplication,
    QScrollArea, QFrame, QSizePolicy, QSplitter, QDialog,
)
from qgis.gui import QgsFileWidget, QgsMapLayerComboBox
from qgis.core import QgsProject, QgsLayoutItemMap, QgsExpressionContextUtils

from ...core.planos_service import PlanosService, STANDARD_SCALES


# ---------------------------------------------------------------------
# Paleta / estilos reutilizados de las demás fichas (mismo lenguaje
# visual que dock_manager.py y tab_audit.py: #2c3e50 título, #7f8c8d
# texto secundario, #2c8a4d ok, #c0392b aviso/error).
# ---------------------------------------------------------------------
SECTION_TITLE_STYLE = "font-size: 12px; font-weight: bold; color: #2c3e50;"
BADGE_AUTO_STYLE = (
    "color: #1e7e34; font-size: 10px; background: #eaf6ec; "
    "border-radius: 3px; padding: 1px 5px;"
)
COMBO_FIXED_WIDTH = 210  # ancho fijo de los selectores de capa (no estirar)
STATUS_OK_STYLE = "color: #1e7e34; font-size: 11px;"
STATUS_WARN_STYLE = "color: #c0392b; font-size: 11px; font-weight: bold;"

# Estilos del "Resumen del lote" convertido en leyenda clicable (ver
# _build_section_fincas / on_legend_clicked): cada línea es un QPushButton
# "plano" (sin borde ni relleno) que conserva el mismo color que tenía
# como QLabel, y gana un resaltado visual cuando es el filtro activo.
LEGEND_COMMON_STYLE = (
    "QPushButton { text-align: left; border: none; background: transparent; "
    "padding: 2px 5px; font-size: 11px; }"
    "QPushButton:hover { background: #f1f4f7; border-radius: 4px; }"
)
LEGEND_COLOR_BY_KEY = {
    'si': "color: #1e7e34;",
    'no': "color: #7f8c8d;",
    'rev': "color: #c0392b; font-weight: bold;",
    'sin': "color: #aaaaaa;",
}
LEGEND_ACTIVE_STYLE = "background: #eaf1fa; border: 1px solid #b7cbe6; border-radius: 4px;"


class CollapsibleGroup(QGroupBox):
    """Sección plegable, usada por TODOS los bloques de la ficha (no
    solo el opcional) para que el criterio visual sea el mismo en
    toda la pantalla: cualquier bloque se puede plegar igual.
    IMPORTANTE: NO usa el checkbox nativo de QGroupBox.setCheckable()
    como disparador, porque un checkbox en el título se lee como
    "activar/desactivar esta opción" y no como "desplegar/plegar" --
    ambigüedad real que confunde a quien no conoce el flujo (¿si lo
    desmarco, se ignoran las capas aunque estén rellenas?). En su
    lugar, el indicador nativo se oculta por CSS y el título muestra
    una flecha ▸/▾ que solo puede significar una cosa: expandir o
    contraer. TODOS los bloques (1, 2, 3, 4 y "Capas opcionales")
    empiezan plegados (`checked=False`), igual que las secciones
    equivalentes de las demás fichas (ver CollapsibleGroupBox en
    collapsible_group_box.py, usado con collapsed=True en tab_mapping,
    tab_thresholds y el filtro de tab_audit) -- así el criterio de
    "todo arranca colapsado" es uniforme en todo el plugin."""

    def __init__(self, title, checked=False, parent=None):
        self._base_title = title
        super().__init__(_collapsible_title(title, checked), parent)
        self.setCheckable(True)
        self.setChecked(checked)
        self.setStyleSheet(
            "QGroupBox::indicator { width: 0px; height: 0px; }"
            "QGroupBox { font-weight: bold; }")
        self._body = QWidget()
        outer = QVBoxLayout(self)
        outer.setContentsMargins(8, 6, 8, 8)
        outer.addWidget(self._body)
        self._body.setVisible(checked)
        self.toggled.connect(self._on_toggled)

    def _on_toggled(self, checked):
        self._body.setVisible(checked)
        self.setTitle(_collapsible_title(self._base_title, checked))

    def body_layout(self, layout):
        self._body.setLayout(layout)
        return layout


def _collapsible_title(text, expanded):
    return f"{'▾' if expanded else '▸'}  {text}"


class TabPlanos(QWidget):
    def __init__(self, iface):
        super().__init__()
        self.iface = iface
        self.log_callback = None

        self._output_dir_provider = None
        self._audit_service_provider = None
        self._mapping_provider = None  # -> TabMapping (para get_adit_mapping())

        self.service = PlanosService(log_callback=self._add_log_safe)
        self.layout_obj = None          # QgsPrintLayout de la plantilla cargada
        self.map_item = None            # QgsLayoutItemMap dentro de esa plantilla
        self.campos_info = []           # [{id, texto, editable, auto_sugerido}]
        self.parcels = []               # [{xid, fid, titular}]
        self.notificar = {}             # {xid: 'si'/'no'/'rev'/''}
        self._solo_notificar = False
        self._legend_filter = None      # None | 'si' | 'no' | 'rev' | 'sin' -- filtro por leyenda
        self._badge_signals_connected = False

        self.init_ui()
        self._update_readiness()

    # ------------------------------------------------------------------
    def set_log_callback(self, callback):
        self.log_callback = callback

    def _add_log_safe(self, msg):
        if self.log_callback:
            self.log_callback(msg)

    def set_output_dir_provider(self, fn):
        self._output_dir_provider = fn

    def set_audit_service_provider(self, fn):
        """Inyectado por AudiNOTDockManager: `fn()` debe devolver el
        `audit_service` YA ABIERTO por la Ficha "4: Auditoría" (misma
        instancia, nunca una segunda conexión al mismo .gpkg -- igual
        criterio que TabRevision)."""
        self._audit_service_provider = fn

    def set_mapping_provider(self, fn):
        """`fn()` debe devolver la instancia de TabMapping (Ficha 2), de
        donde se lee el campo de categorización de aditamentos
        (get_adit_mapping())."""
        self._mapping_provider = fn

    # ------------------------------------------------------------------
    # Construcción de la interfaz
    # ------------------------------------------------------------------
    def init_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # El contenido configurable va en un QScrollArea: en un dock de
        # ~420px de ancho, la ficha completa no cabe nunca en alto, y
        # antes eso obligaba a bajar hasta el fondo para encontrar el
        # botón "Generar". Ahora solo se desplaza esta parte; el pie
        # (estado + botón) queda siempre visible, fuera del scroll.
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QScrollArea.NoFrame)
        content = QWidget()
        body = QVBoxLayout(content)
        body.setContentsMargins(8, 8, 8, 8)
        body.setSpacing(12)
        scroll.setWidget(content)
        root.addWidget(scroll, 1)

        body.addWidget(self._build_section_plantilla())
        body.addWidget(self._build_section_capas_obligatorias())
        body.addWidget(self._build_section_capas_opcionales())
        body.addWidget(self._build_section_fincas())
        body.addWidget(self._build_section_escala_salida())
        body.addStretch()

        root.addWidget(self._build_footer())

        self._autodetect_layers()
        self._refresh_extra_layers_list()

    # -- 1. Plantilla y cajetín ----------------------------------------
    def _build_section_plantilla(self):
        box = CollapsibleGroup("1. Plantilla y cajetín", checked=False)
        v = QVBoxLayout()

        row_tpl = QHBoxLayout()
        row_tpl.addWidget(QLabel("Archivo .qpt:"))
        self.file_qpt = QgsFileWidget()
        self.file_qpt.setStorageMode(QgsFileWidget.GetFile)
        self.file_qpt.setFilter("Plantillas QGIS (*.qpt)")
        self.file_qpt.fileChanged.connect(self.on_template_changed)
        row_tpl.addWidget(self.file_qpt, 1)
        v.addLayout(row_tpl)

        v.addWidget(QLabel("Campos del cajetín:"))
        self.table_fields = QTableWidget(0, 3)
        self.table_fields.setHorizontalHeaderLabels(["Elemento", "Contenido", "🔁 Auto"])
        self.table_fields.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self.table_fields.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.table_fields.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeToContents)
        self.table_fields.setMaximumHeight(150)
        v.addWidget(self.table_fields)

        note = QLabel(
            "El valor de \"Contenido\" se usa igual para todos los planos del lote, "
            "salvo en las filas marcadas \"Auto\" (id/REC y, si procede, escala/fecha), "
            "que se recalculan por finca.")
        note.setWordWrap(True)
        note.setStyleSheet("color: #7f8c8d; font-size: 10px;")
        v.addWidget(note)
        box.body_layout(v)
        return box

    # -- 2. Capas obligatorias -------------------------------------------
    def _layer_row(self, form, label_text, allow_empty=True, autodetect_badge=False):
        combo = QgsMapLayerComboBox()
        combo.setAllowEmptyLayer(allow_empty)
        combo.setFixedWidth(COMBO_FIXED_WIDTH)
        if autodetect_badge:
            wrap = QHBoxLayout()
            wrap.addWidget(combo)
            badge = QLabel("auto")
            badge.setStyleSheet(BADGE_AUTO_STYLE)
            badge.setVisible(False)
            wrap.addWidget(badge)
            wrap.addStretch()
            form.addRow(label_text, wrap)
            return combo, badge
        form.addRow(label_text, combo)
        return combo, None

    def _build_section_capas_obligatorias(self):
        box = CollapsibleGroup("2. Capas de fincas (obligatorias)", checked=False)
        v = QVBoxLayout()

        row_hdr = QHBoxLayout()
        lbl_hint = QLabel(
            "Se detectan solas por nombre (ANTES_ok / DESPUÉS_ok); "
            "cámbialas aquí si hace falta.")
        lbl_hint.setWordWrap(True)
        lbl_hint.setStyleSheet("color: #7f8c8d; font-size: 10px;")
        row_hdr.addWidget(lbl_hint, 1)
        self.btn_refresh_layers = QPushButton("🔄 Actualizar")
        self.btn_refresh_layers.setToolTip(
            "Vuelve a leer las capas cargadas en el proyecto (por si se han "
            "añadido/quitado después de abrir esta pestaña).")
        self.btn_refresh_layers.clicked.connect(self._refresh_all_layer_widgets)
        row_hdr.addWidget(self.btn_refresh_layers)
        v.addLayout(row_hdr)

        form = QFormLayout()
        form.setFieldGrowthPolicy(QFormLayout.FieldsStayAtSizeHint)
        self.combo_antes, self.badge_antes = self._layer_row(form, "Antes:", autodetect_badge=True)
        self.combo_despues, self.badge_despues = self._layer_row(form, "Después:", autodetect_badge=True)
        v.addLayout(form)
        box.body_layout(v)
        return box

    # -- Capas opcionales (plegada) --------------------------------------
    def _build_section_capas_opcionales(self):
        section = CollapsibleGroup("Capas opcionales (aditamentos, construcciones, extra)", checked=False)
        v = QVBoxLayout()

        form = QFormLayout()
        form.setFieldGrowthPolicy(QFormLayout.FieldsStayAtSizeHint)
        self.combo_adit_antes, _ = self._layer_row(form, "Aditamentos antes:")
        self.combo_adit_despues, _ = self._layer_row(form, "Aditamentos después:")
        self.combo_construcciones, _ = self._layer_row(form, "Construcciones:")
        v.addLayout(form)

        self.chk_categorize_adit = QCheckBox(
            "Simbología automática de aditamentos por categoría\n(campo configurado en Ficha 2)")
        self.chk_categorize_adit.setChecked(True)
        v.addWidget(self.chk_categorize_adit)

        v.addWidget(QLabel("Capas adicionales (se muestran tal cual en ANTES y DESPUÉS):"))
        self.list_extra_layers = QListWidget()
        self.list_extra_layers.setSelectionMode(QAbstractItemView.NoSelection)
        self.list_extra_layers.setMaximumHeight(80)
        v.addWidget(self.list_extra_layers)

        section.body_layout(v)
        return section

    # -- 3. Fincas ---------------------------------------------------------
    def _build_section_fincas(self):
        box = CollapsibleGroup("3. Fincas", checked=False)
        v = QVBoxLayout()

        row_hdr = QHBoxLayout()
        self.btn_refresh_parcels = QPushButton("Cargar fincas")
        self.btn_refresh_parcels.clicked.connect(self.on_refresh_parcels)
        row_hdr.addWidget(self.btn_refresh_parcels)
        self.btn_filter_notify = QPushButton("Solo notificar")
        self.btn_filter_notify.setCheckable(True)
        self.btn_filter_notify.setEnabled(False)
        self.btn_filter_notify.toggled.connect(self.on_toggle_notify_filter)
        row_hdr.addWidget(self.btn_filter_notify)
        # Mejora UI/UX: con lotes grandes, marcar/desmarcar fila a fila es
        # tedioso -- un checkbox "Todas" en la cabecera actúa sobre las
        # filas actualmente visibles en la tabla (respeta el filtro
        # "Solo notificar" si está activo).
        self.chk_select_all = QCheckBox("Todas")
        self.chk_select_all.toggled.connect(self.on_toggle_select_all)
        row_hdr.addWidget(self.chk_select_all)
        row_hdr.addStretch()
        self.lbl_parcels_count = QLabel("0/0 seleccionadas")
        self.lbl_parcels_count.setStyleSheet("color: #7f8c8d; font-size: 11px;")
        row_hdr.addWidget(self.lbl_parcels_count)
        v.addLayout(row_hdr)

        # La tabla NO se estira a lo ancho del bloque: se limita a lo
        # que necesitan sus 3 columnas (checkbox + REC corto +
        # etiqueta de Notificar). El espacio que queda a la derecha se
        # usa para un resumen en vivo de cuántas fincas hay en cada
        # estado de notificación -- dato que antes solo se veía fila a
        # fila, sin ningún sitio que diera el cómputo global.
        # La tabla no se estira sola, pero el usuario puede ensancharla
        # a mano arrastrando el separador (útil si algún REC es largo o
        # simplemente prefiere verla más holgada). Se limita entre su
        # ancho por defecto (DEFAULT_TABLE_W) y el doble
        # (MAX_TABLE_W) para que no invada el panel de resumen.
        DEFAULT_TABLE_W = 230
        MAX_TABLE_W = DEFAULT_TABLE_W * 2

        self.table_parcels = QTableWidget(0, 3)
        self.table_parcels.setHorizontalHeaderLabels(["", "REC (xID)", "Notificar"])
        self.table_parcels.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self.table_parcels.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeToContents)
        self.table_parcels.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeToContents)
        self.table_parcels.setMinimumWidth(160)
        self.table_parcels.setMaximumWidth(MAX_TABLE_W)
        self.table_parcels.setMaximumHeight(200)
        self.table_parcels.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Preferred)
        self.table_parcels.itemChanged.connect(self._on_parcels_table_changed)

        resumen = QVBoxLayout()
        resumen.setSpacing(4)
        lbl_resumen_title = QLabel("Resumen del lote:")
        lbl_resumen_title.setStyleSheet("color: #2c3e50; font-size: 11px; font-weight: bold;")
        resumen.addWidget(lbl_resumen_title)
        lbl_resumen_hint = QLabel("(clic en un estado para filtrar)")
        lbl_resumen_hint.setStyleSheet("color: #adb5bd; font-size: 9px; font-style: italic;")
        resumen.addWidget(lbl_resumen_hint)

        # Mejora UI/UX: el resumen del lote (antes 4 QLabel de solo
        # lectura) ahora es una leyenda clicable -- pulsar un estado
        # filtra la tabla de fincas a ese estado; pulsarlo de nuevo quita
        # el filtro. Esto es ADITIVO al filtro "Solo notificar" ya
        # existente (que se deja tal cual): ambos se combinan (AND) si
        # están activos a la vez.
        self.lbl_resumen_si = QPushButton("✔ Sí: 0")
        self.lbl_resumen_no = QPushButton("✘ No: 0")
        self.lbl_resumen_rev = QPushButton("👁 Revisar: 0")
        self.lbl_resumen_sin = QPushButton("— Sin dato: 0")
        self._legend_buttons = {
            'si': self.lbl_resumen_si,
            'no': self.lbl_resumen_no,
            'rev': self.lbl_resumen_rev,
            'sin': self.lbl_resumen_sin,
        }
        for key, btn in self._legend_buttons.items():
            btn.setCursor(Qt.PointingHandCursor)
            btn.setToolTip("Clic para filtrar la tabla por este estado; clic de nuevo para quitar el filtro.")
            btn.clicked.connect(lambda _checked=False, k=key: self.on_legend_clicked(k))
            resumen.addWidget(btn)
        self._sync_legend_buttons()
        resumen.addStretch()
        resumen_widget = QWidget()
        resumen_widget.setLayout(resumen)

        splitter = QSplitter(Qt.Horizontal)
        splitter.setChildrenCollapsible(False)
        splitter.addWidget(self.table_parcels)
        splitter.addWidget(resumen_widget)
        splitter.setStretchFactor(0, 0)
        splitter.setStretchFactor(1, 1)
        splitter.setSizes([DEFAULT_TABLE_W, 140])

        v.addWidget(splitter)
        box.body_layout(v)
        return box

    # -- 4. Escala y salida --------------------------------------------
    def _build_section_escala_salida(self):
        box = CollapsibleGroup("4. Escala y salida", checked=False)
        v = QVBoxLayout()

        row_scale_mode = QHBoxLayout()
        self.radio_scale_auto = QRadioButton("Escala automática")
        self.radio_scale_manual = QRadioButton("Escala manual")
        self.radio_scale_auto.setChecked(True)
        grp = QButtonGroup(self)
        grp.addButton(self.radio_scale_auto)
        grp.addButton(self.radio_scale_manual)
        row_scale_mode.addWidget(self.radio_scale_auto)
        row_scale_mode.addWidget(self.radio_scale_manual)
        row_scale_mode.addStretch()
        v.addLayout(row_scale_mode)

        # Solo se muestra el control del modo activo (antes ambos
        # ocupaban espacio siempre, solo cambiaba si estaban grises).
        self.widget_scale_auto = QWidget()
        row_auto = QHBoxLayout(self.widget_scale_auto)
        row_auto.setContentsMargins(20, 0, 0, 0)
        row_auto.addWidget(QLabel("Margen sobre la finca más grande (%):"))
        self.spin_margin = QSpinBox()
        self.spin_margin.setRange(0, 100)
        self.spin_margin.setValue(15)
        row_auto.addWidget(self.spin_margin)
        row_auto.addStretch()
        v.addWidget(self.widget_scale_auto)

        self.widget_scale_manual = QWidget()
        row_manual = QHBoxLayout(self.widget_scale_manual)
        row_manual.setContentsMargins(20, 0, 0, 0)
        row_manual.addWidget(QLabel("Escala 1:"))
        self.combo_scale_manual = QComboBox()
        for s in STANDARD_SCALES:
            self.combo_scale_manual.addItem(str(s), s)
        self.combo_scale_manual.setFixedWidth(100)
        row_manual.addWidget(self.combo_scale_manual)
        row_manual.addStretch()
        v.addWidget(self.widget_scale_manual)
        self.widget_scale_manual.setVisible(False)

        self.radio_scale_auto.toggled.connect(self.widget_scale_auto.setVisible)
        self.radio_scale_manual.toggled.connect(self.widget_scale_manual.setVisible)

        line = QFrame()
        line.setFrameShape(QFrame.HLine)
        line.setStyleSheet("color: #eee;")
        v.addWidget(line)

        row_fmt = QHBoxLayout()
        row_fmt.addWidget(QLabel("Formato de salida:"))
        self.chk_pdf = QCheckBox("PDF")
        self.chk_pdf.setChecked(True)
        self.chk_png = QCheckBox("PNG")
        row_fmt.addWidget(self.chk_pdf)
        row_fmt.addWidget(self.chk_png)
        row_fmt.addStretch()
        v.addLayout(row_fmt)

        row_folder = QHBoxLayout()
        row_folder.addWidget(QLabel("Carpeta de destino:"))
        self.file_out_dir = QgsFileWidget()
        self.file_out_dir.setStorageMode(QgsFileWidget.GetDirectory)
        row_folder.addWidget(self.file_out_dir, 1)
        v.addLayout(row_folder)

        for w in (self.chk_pdf, self.chk_png):
            w.toggled.connect(self._update_readiness)
        self.file_out_dir.fileChanged.connect(lambda *_: self._update_readiness())
        box.body_layout(v)
        return box

    # -- Pie fijo: estado + botón Generar --------------------------------
    def _build_footer(self):
        footer = QWidget()
        footer.setStyleSheet("background: #f8f9fa; border-top: 1px solid #ddd;")
        v = QVBoxLayout(footer)
        v.setContentsMargins(10, 8, 10, 10)
        v.setSpacing(6)

        self.lbl_status = QLabel()
        self.lbl_status.setWordWrap(True)
        v.addWidget(self.lbl_status)

        row_btns = QHBoxLayout()
        self.btn_preview = QPushButton("👁 Vista previa")
        self.btn_preview.setToolTip(
            "Genera solo el ANTES+DESPUÉS de la PRIMERA finca seleccionada, "
            "para comprobar visualmente el encuadre/escala antes de lanzar "
            "el lote completo.")
        self.btn_preview.clicked.connect(self.on_preview)
        row_btns.addWidget(self.btn_preview)

        self.btn_generate = QPushButton("Generar planos")
        self.btn_generate.setStyleSheet(
            "background-color: #2c3e50; color: white; font-weight: bold; padding: 8px;")
        self.btn_generate.clicked.connect(self.on_generate)
        row_btns.addWidget(self.btn_generate, 1)
        v.addLayout(row_btns)
        return footer

    # ------------------------------------------------------------------
    # Estado global "¿está todo listo para generar?" -- se recalcula en
    # cada cambio relevante para que el botón y el mensaje del pie
    # reflejen siempre la situación real, sin esperar a pulsar Generar.
    # ------------------------------------------------------------------
    def _update_readiness(self):
        missing = []
        if self.layout_obj is None or self.map_item is None:
            missing.append("plantilla .qpt con un elemento de mapa")
        if self.combo_antes.currentLayer() is None or self.combo_despues.currentLayer() is None:
            missing.append("capas Antes/Después")
        if not self._selected_xids():
            missing.append("al menos una finca seleccionada")
        if not (self.chk_pdf.isChecked() or self.chk_png.isChecked()):
            missing.append("un formato de salida (PDF/PNG)")
        out_dir = self.file_out_dir.filePath()
        if not out_dir and not self._output_dir_provider:
            missing.append("carpeta de destino")

        if missing:
            self.lbl_status.setText("Falta: " + "; ".join(missing) + ".")
            self.lbl_status.setStyleSheet(STATUS_WARN_STYLE)
            self.btn_generate.setEnabled(False)
        else:
            n = len(self._selected_xids())
            self.lbl_status.setText(f"✔ Todo listo -- se generarán planos para {n} finca(s).")
            self.lbl_status.setStyleSheet(STATUS_OK_STYLE)
            self.btn_generate.setEnabled(True)

    def _on_parcels_table_changed(self, item):
        if item.column() == 0:
            self._update_parcels_count()
        self._update_readiness()

    def _update_parcels_count(self):
        total = self.table_parcels.rowCount()
        selected = len(self._selected_xids())
        self.lbl_parcels_count.setText(f"{selected}/{total} seleccionadas")

    # ------------------------------------------------------------------
    # Actualización de capas bajo demanda (al mostrar la pestaña / botón
    # manual) en vez de suscripción permanente a QgsProject.instance().
    # IMPORTANTE: QgsProject es un singleton que sobrevive a esta pestaña
    # (p.ej. al recargar el plugin en desarrollo, o si el dock se
    # reconstruye); conectar lambdas de esta instancia a sus señales
    # `layersAdded`/`layersRemoved` dejaba conexiones colgando que
    # disparaban sobre widgets Qt ya destruidos ("wrapped C/C++ object
    # ... has been deleted"). Refrescar solo cuando la pestaña se hace
    # visible evita ese problema de raíz sin perder la comodidad de la
    # autodetección.
    # ------------------------------------------------------------------
    def showEvent(self, event):
        self._refresh_all_layer_widgets()
        super().showEvent(event)

    def _refresh_all_layer_widgets(self):
        self._autodetect_layers()
        self._refresh_extra_layers_list()
        self._update_readiness()

    # ------------------------------------------------------------------
    # Autodetección de capas por nombre (ANTES_ok / DESPUES_ok), editable
    # ------------------------------------------------------------------
    def _autodetect_layers(self):
        if not self._badge_signals_connected:
            self.combo_antes.layerChanged.connect(lambda _l: self.badge_antes.setVisible(False))
            self.combo_despues.layerChanged.connect(lambda _l: self.badge_despues.setVisible(False))
            self.combo_antes.layerChanged.connect(lambda _l: self._update_readiness())
            self.combo_despues.layerChanged.connect(lambda _l: self._update_readiness())
            # Corrección de la falla nº4 detectada en revisión: cambiar de
            # capa Antes/Después DESPUÉS de haber pulsado "Cargar fincas"
            # dejaba la tabla mostrando xIDs de la capa anterior (solo se
            # ocultaba el badge "auto" y se recalculaba _update_readiness,
            # nunca se vaciaba self.parcels/table_parcels). Ahora cualquier
            # cambio de capa invalida el lote cargado y avisa al usuario en
            # vez de arrastrar un desajuste silencioso hasta "Generar".
            self.combo_antes.layerChanged.connect(self._on_source_layer_changed)
            self.combo_despues.layerChanged.connect(self._on_source_layer_changed)
            self._badge_signals_connected = True

        for combo, needle, badge in (
            (self.combo_antes, "antes_ok", self.badge_antes),
            (self.combo_despues, "despues_ok", self.badge_despues),
        ):
            if combo.currentLayer() is not None:
                continue
            for lyr in QgsProject.instance().mapLayers().values():
                if needle in lyr.name().lower().replace("é", "e"):
                    combo.setLayer(lyr)
                    if badge is not None:
                        badge.setVisible(True)
                    break

    def _refresh_extra_layers_list(self):
        checked_before = {
            self.list_extra_layers.item(i).data(Qt.UserRole)
            for i in range(self.list_extra_layers.count())
            if self.list_extra_layers.item(i).checkState() == Qt.Checked
        }
        self.list_extra_layers.clear()
        for lyr in QgsProject.instance().mapLayers().values():
            item = QListWidgetItem(lyr.name())
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            item.setCheckState(Qt.Checked if lyr.id() in checked_before else Qt.Unchecked)
            item.setData(Qt.UserRole, lyr.id())
            self.list_extra_layers.addItem(item)

    def _selected_extra_layers(self):
        ids = [self.list_extra_layers.item(i).data(Qt.UserRole)
               for i in range(self.list_extra_layers.count())
               if self.list_extra_layers.item(i).checkState() == Qt.Checked]
        return [QgsProject.instance().mapLayer(i) for i in ids if QgsProject.instance().mapLayer(i)]

    # ------------------------------------------------------------------
    # 3. Análisis de plantilla
    # ------------------------------------------------------------------
    def on_template_changed(self, path):
        if not path or not os.path.exists(path):
            return
        try:
            self.layout_obj, self.campos_info = self.service.analyze_template(path)
        except Exception as e:
            QMessageBox.critical(self, "AudiNOT", f"No se pudo analizar la plantilla:\n{e}")
            self._add_log_safe(f"<font color='red'>Planos: error analizando plantilla: {e}</font>")
            return

        self.map_item = None
        for it in self.layout_obj.items():
            if isinstance(it, QgsLayoutItemMap):
                self.map_item = it
                break

        self._populate_fields_table()
        self._update_readiness()

    def _populate_fields_table(self):
        self.table_fields.setRowCount(0)
        for row, campo in enumerate(self.campos_info):
            self.table_fields.insertRow(row)

            item_id = QTableWidgetItem(campo['id'])
            item_id.setFlags(item_id.flags() & ~Qt.ItemIsEditable)
            self.table_fields.setItem(row, 0, item_id)

            item_val = QTableWidgetItem(campo['texto'])
            if not campo['editable']:
                item_val.setFlags(item_val.flags() & ~Qt.ItemIsEditable)
                item_val.setBackground(Qt.lightGray)
            self.table_fields.setItem(row, 1, item_val)

            chk = QTableWidgetItem()
            chk.setFlags(Qt.ItemIsUserCheckable | Qt.ItemIsEnabled if campo['editable'] else Qt.NoItemFlags)
            if campo['editable']:
                chk.setCheckState(Qt.Checked if campo['auto_sugerido'] else Qt.Unchecked)
            self.table_fields.setItem(row, 2, chk)

    def _current_fields_config(self):
        cfg = []
        for row, campo in enumerate(self.campos_info):
            if not campo['editable']:
                continue
            val_item = self.table_fields.item(row, 1)
            chk_item = self.table_fields.item(row, 2)
            cfg.append({
                'id': campo['id'],
                'editable': True,
                'valor': val_item.text() if val_item else '',
                'auto': bool(chk_item and chk_item.checkState() == Qt.Checked),
            })
        return cfg

    # ------------------------------------------------------------------
    # 4/5. Listado de fincas + filtro NOTIFICAR
    # ------------------------------------------------------------------
    def on_refresh_parcels(self):
        layer_antes = self.combo_antes.currentLayer()
        if layer_antes is None:
            QMessageBox.warning(self, "AudiNOT", "Selecciona primero la capa ANTES (fincas).")
            return
        try:
            self.parcels = self.service.list_parcels(layer_antes)
        except Exception as e:
            QMessageBox.critical(self, "AudiNOT", str(e))
            return

        audit_service = self._audit_service_provider() if self._audit_service_provider else None
        self.notificar = self.service.notificar_map(audit_service)
        self.btn_filter_notify.setEnabled(bool(self.notificar))
        self._legend_filter = None
        self._sync_legend_buttons()

        self._populate_parcels_table()
        self._add_log_safe(f"Planos: {len(self.parcels)} finca(s) cargada(s) "
                            f"(excluidos elementos comunes por TIPO).")

    def _populate_parcels_table(self):
        # Las filas se insertan marcadas por defecto (ver más abajo), así
        # que el checkbox "Todas" de la cabecera arranca reflejando eso.
        self.chk_select_all.blockSignals(True)
        self.chk_select_all.setChecked(True)
        self.chk_select_all.blockSignals(False)
        self.table_parcels.blockSignals(True)
        self.table_parcels.setRowCount(0)
        for parcel in self.parcels:
            estado = self.notificar.get(parcel['xid'], '')
            if self._solo_notificar and estado != 'si':
                continue
            if not self._matches_legend_filter(estado):
                continue
            row = self.table_parcels.rowCount()
            self.table_parcels.insertRow(row)

            chk = QTableWidgetItem()
            chk.setFlags(Qt.ItemIsUserCheckable | Qt.ItemIsEnabled)
            chk.setCheckState(Qt.Checked)
            chk.setData(Qt.UserRole, parcel['xid'])
            self.table_parcels.setItem(row, 0, chk)

            item_xid = QTableWidgetItem(parcel['xid'])
            item_xid.setFlags(item_xid.flags() & ~Qt.ItemIsEditable)
            self.table_parcels.setItem(row, 1, item_xid)

            label = {'si': '✔ Sí', 'no': '✘ No', 'rev': '👁 Revisar'}.get(estado, '—')
            item_notif = QTableWidgetItem(label)
            item_notif.setFlags(item_notif.flags() & ~Qt.ItemIsEditable)
            self.table_parcels.setItem(row, 2, item_notif)
        self.table_parcels.blockSignals(False)
        self._update_parcels_count()
        self._update_notify_summary()
        self._update_readiness()

    def _update_notify_summary(self):
        """Cómputo global (sobre TODAS las fincas cargadas, no solo las
        visibles si algún filtro está activo) de cuántas hay en cada
        estado. Se ve de un vistazo en el hueco que deja la tabla al no
        estirarse a lo ancho, y ahora además sirve de leyenda clicable
        (ver on_legend_clicked) para filtrar la tabla por ese estado."""
        counts = {'si': 0, 'no': 0, 'rev': 0, '': 0}
        for parcel in self.parcels:
            estado = self.notificar.get(parcel['xid'], '')
            counts[estado if estado in counts else ''] += 1
        self.lbl_resumen_si.setText(f"✔ Sí: {counts['si']}")
        self.lbl_resumen_no.setText(f"✘ No: {counts['no']}")
        self.lbl_resumen_rev.setText(f"👁 Revisar: {counts['rev']}")
        self.lbl_resumen_sin.setText(f"— Sin dato: {counts['']}")

    # -- Leyenda "Resumen del lote" clicable ----------------------------
    def _matches_legend_filter(self, estado):
        if self._legend_filter is None:
            return True
        if self._legend_filter == 'sin':
            return estado not in ('si', 'no', 'rev')
        return estado == self._legend_filter

    def on_legend_clicked(self, key):
        """Clic en una línea del "Resumen del lote": filtra la tabla de
        fincas a ese estado. Un segundo clic sobre el MISMO estado quita
        el filtro (vuelve a mostrar todas). Es aditivo al filtro "Solo
        notificar" ya existente -- si ambos están activos se combinan
        (AND); ese botón no se toca."""
        self._legend_filter = None if self._legend_filter == key else key
        self._sync_legend_buttons()
        self._populate_parcels_table()

    def _sync_legend_buttons(self):
        for key, btn in self._legend_buttons.items():
            style = LEGEND_COMMON_STYLE + f"QPushButton {{ {LEGEND_COLOR_BY_KEY[key]} }}"
            if self._legend_filter == key:
                style += f"QPushButton {{ {LEGEND_ACTIVE_STYLE} }}"
            btn.setStyleSheet(style)

    def on_toggle_notify_filter(self, checked):
        self._solo_notificar = checked
        self.btn_filter_notify.setText("Mostrar todas" if checked else "Solo notificar")
        self._populate_parcels_table()
        # Mejora UI/UX: antes, si el filtro dejaba la tabla en 0 filas, no
        # había ningún mensaje explícito -- solo una tabla vacía y el botón
        # "Generar" deshabilitado sin explicación visible. self.notificar
        # SÍ tiene datos (si no, el botón "Solo notificar" ni se habilita,
        # ver on_refresh_parcels), así que un 0 aquí es "ninguna finca
        # cumple 'Notificar = Sí'", no "no hay datos de auditoría".
        if checked and self.parcels and self.table_parcels.rowCount() == 0:
            QMessageBox.information(
                self, "AudiNOT",
                "Ninguna finca del lote cargado tiene NOTIFICAR = 'Sí'. La tabla se queda "
                "vacía; pulsa 'Mostrar todas' para ver de nuevo el lote completo.")

    def on_toggle_select_all(self, checked):
        """Mejora UI/UX: checkbox 'Todas' en la cabecera de la tabla de
        fincas -- marca/desmarca todas las filas VISIBLES actualmente
        (respeta el filtro 'Solo notificar' si está activo), evitando
        tener que hacerlo fila a fila en lotes grandes."""
        self.table_parcels.blockSignals(True)
        for row in range(self.table_parcels.rowCount()):
            item = self.table_parcels.item(row, 0)
            if item is not None:
                item.setCheckState(Qt.Checked if checked else Qt.Unchecked)
        self.table_parcels.blockSignals(False)
        self._update_parcels_count()
        self._update_readiness()

    def _on_source_layer_changed(self, _layer=None):
        """Corrección de la falla nº4: invalida el lote de fincas cargado
        en cuanto cambia la capa Antes o Después, para no arrastrar xIDs
        de la capa anterior hasta "Generar" (donde antes podía acabar en
        errores silenciosos tipo "sin geometría en ANTES ni en DESPUÉS")."""
        if self.parcels:
            self.parcels = []
            self.notificar = {}
            self.table_parcels.setRowCount(0)
            self.chk_select_all.blockSignals(True)
            self.chk_select_all.setChecked(False)
            self.chk_select_all.blockSignals(False)
            self.btn_filter_notify.blockSignals(True)
            self.btn_filter_notify.setChecked(False)
            self.btn_filter_notify.setText("Solo notificar")
            self.btn_filter_notify.blockSignals(False)
            self._solo_notificar = False
            self.btn_filter_notify.setEnabled(False)
            self._update_parcels_count()
            self._update_notify_summary()
            self._add_log_safe(
                "<font color='orange'>Planos: se ha cambiado la capa Antes/Después -- el "
                "lote de fincas cargado ya no es válido. Pulsa 'Cargar fincas' de nuevo.</font>")
        self._update_readiness()

    def _selected_xids(self):
        xids = []
        for row in range(self.table_parcels.rowCount()):
            item = self.table_parcels.item(row, 0)
            if item and item.checkState() == Qt.Checked:
                xids.append(item.data(Qt.UserRole))
        return xids

    # ------------------------------------------------------------------
    # 6. Generación
    # ------------------------------------------------------------------
    def on_generate(self):
        if self.layout_obj is None or self.map_item is None:
            QMessageBox.warning(self, "AudiNOT", "Selecciona antes una plantilla .qpt válida "
                                                  "con un elemento de mapa.")
            return
        layer_antes = self.combo_antes.currentLayer()
        layer_despues = self.combo_despues.currentLayer()
        if layer_antes is None or layer_despues is None:
            QMessageBox.warning(self, "AudiNOT", "Selecciona las capas ANTES y DESPUÉS.")
            return

        xids = self._selected_xids()
        if not xids:
            QMessageBox.warning(self, "AudiNOT", "No hay ninguna finca seleccionada.")
            return

        out_dir = self.file_out_dir.filePath()
        if not out_dir:
            provider_dir = self._output_dir_provider() if self._output_dir_provider else None
            out_dir = os.path.join(provider_dir, "RESULTADO", "Planos") if provider_dir else None
        if not out_dir:
            QMessageBox.warning(self, "AudiNOT", "Indica una carpeta de destino.")
            return
        os.makedirs(out_dir, exist_ok=True)

        formats = []
        if self.chk_pdf.isChecked():
            formats.append('pdf')
        if self.chk_png.isChecked():
            formats.append('png')
        if not formats:
            QMessageBox.warning(self, "AudiNOT", "Selecciona al menos un formato de salida (PDF/PNG).")
            return

        if self.radio_scale_auto.isChecked():
            # Corrección de la falla nº1: se pasa también la capa DESPUÉS
            # para que la escala del lote tenga en cuenta el tamaño real
            # de la finca en AMBOS estados, no solo en ANTES.
            scale = self.service.compute_auto_scale(
                layer_antes, xids, self.map_item, layer_despues=layer_despues,
                margin_pct=self.spin_margin.value())
        else:
            scale = self.combo_scale_manual.currentData()
        self._add_log_safe(f"Planos: escala normalizada del lote = 1:{scale}")

        extra_layers = self._selected_extra_layers()
        adit_antes = self.combo_adit_antes.currentLayer()
        adit_despues = self.combo_adit_despues.currentLayer()
        construcciones = self.combo_construcciones.currentLayer()
        adit_field = 'layer'
        if self._mapping_provider:
            tab_mapping = self._mapping_provider()
            if tab_mapping is not None:
                adit_field = tab_mapping.get_adit_mapping() or 'layer'

        fields_cfg = self._current_fields_config()
        # Corrección del hueco entre nombre y relleno real: los campos
        # «Auto» de escala/fecha reciben ahora su valor real calculado
        # (no el xID) -- ver PlanosService.build_extra_auto_values. La
        # escala es la del lote completo (misma para todas las fincas),
        # así que se calcula una sola vez aquí, fuera del bucle de fincas.
        extra_auto_values = self.service.build_extra_auto_values(fields_cfg, scale)
        xid_field_antes = 'xID' if layer_antes.fields().indexOf('xID') != -1 else None
        xid_field_desp = 'xID' if layer_despues.fields().indexOf('xID') != -1 else None
        if xid_field_antes is None or xid_field_desp is None:
            QMessageBox.critical(self, "AudiNOT", "Las capas seleccionadas no tienen campo 'xID'.")
            return

        # Mejora UI/UX + corrección de la falla nº6: si la carpeta de
        # destino ya contiene ficheros con el mismo patrón de nombre que
        # se va a generar, se pisarían sin ningún aviso. Se comprueba
        # ANTES de arrancar el lote y se pide confirmación explícita.
        basenames = {xid: self.service.build_output_basename(xid) for xid in xids}
        existing = [
            os.path.join(out_dir, f"{basenames[xid]}_{suffix}.{fmt}")
            for xid in xids for fmt in formats for suffix in ("ANTES", "DESPUES")
            if os.path.exists(os.path.join(out_dir, f"{basenames[xid]}_{suffix}.{fmt}"))
        ]
        if existing:
            resp = QMessageBox.question(
                self, "AudiNOT",
                f"La carpeta de destino ya contiene {len(existing)} fichero(s) con el mismo "
                f"nombre que se van a generar (p.ej. '{os.path.basename(existing[0])}'). "
                "Se sobrescribirán.\n\n¿Continuar?",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if resp != QMessageBox.Yes:
                return

        # Simbología no destructiva: guardar renderers originales para
        # restaurarlos SIEMPRE al terminar (éxito, error o cancelación).
        restore_jobs = []
        progress = QProgressDialog("Generando planos...", "Cancelar", 0, len(xids), self)
        progress.setWindowModality(Qt.WindowModal)
        progress.setMinimumDuration(0)

        ok_count = 0
        errors = []
        start_time = time.time()
        try:
            restore_jobs.append((layer_antes, self.service.prepare_highlight_renderer(layer_antes, xid_field_antes)))
            restore_jobs.append((layer_despues, self.service.prepare_highlight_renderer(layer_despues, xid_field_desp)))
            if construcciones is not None:
                restore_jobs.append((construcciones, self.service.apply_construction_hatch(construcciones)))
            if self.chk_categorize_adit.isChecked():
                for adit_layer in (adit_antes, adit_despues):
                    if adit_layer is not None:
                        restore_jobs.append(
                            (adit_layer, self.service.apply_categorized_adit_renderer(adit_layer, adit_field)))

            idx_xid_antes = layer_antes.fields().indexOf('xID')
            idx_xid_desp = layer_despues.fields().indexOf('xID')
            geoms_antes = {str(f[idx_xid_antes]): f.geometry() for f in layer_antes.getFeatures()}
            geoms_desp = {str(f[idx_xid_desp]): f.geometry() for f in layer_despues.getFeatures()}

            base_layers_antes = [layer_antes] + ([adit_antes] if adit_antes else []) + extra_layers
            base_layers_desp = [layer_despues] + ([adit_despues] if adit_despues else []) + extra_layers
            if construcciones is not None:
                base_layers_antes.append(construcciones)
                base_layers_desp.append(construcciones)

            project = QgsProject.instance()

            for i, xid in enumerate(xids):
                if progress.wasCanceled():
                    self._add_log_safe("Planos: generación cancelada por el usuario.")
                    break
                progress.setValue(i)
                eta_txt = ""
                if i > 0:
                    # Mejora UI/UX: estimación de tiempo restante a partir
                    # del tiempo medio por finca ya generada (útil porque
                    # cada finca exporta hasta 4 ficheros -- 2 formatos x
                    # 2 estados -- y en lotes grandes puede tardar).
                    elapsed = time.time() - start_time
                    remaining = (elapsed / i) * (len(xids) - i)
                    eta_txt = f" -- restante aprox. {self._format_duration(remaining)}"
                progress.setLabelText(f"Finca {xid} ({i + 1}/{len(xids)}){eta_txt}")
                QApplication.processEvents()

                geom_antes = geoms_antes.get(xid)
                geom_desp = geoms_desp.get(xid)
                antes_vacia = geom_antes is None or geom_antes.isEmpty()
                desp_vacia = geom_desp is None or geom_desp.isEmpty()
                if antes_vacia and desp_vacia:
                    errors.append(f"{xid}: sin geometría en ANTES ni en DESPUÉS")
                    continue

                try:
                    QgsExpressionContextUtils.setProjectVariable(
                        project, 'planos_finca_actual', xid)

                    basename = basenames[xid]

                    # Corrección de la falla nº1: el encuadre se calcula UNA
                    # sola vez sobre la UNIÓN de la geometría en ANTES y en
                    # DESPUÉS (antes solo miraba ANTES), para que ninguno de
                    # los dos planos quede con la parcela recortada por el
                    # marco si la finca cambia de forma/posición entre
                    # estados. El mismo encuadre/escala se reutiliza para
                    # los dos planos, así siguen siendo comparables.
                    self.service.frame_map_item(self.map_item, geom_antes, geom_desp, scale)

                    # --- ANTES ---
                    self.map_item.setLayers(base_layers_antes)
                    self.service.fill_labels(self.layout_obj, fields_cfg, xid,
                                              extra_auto_values=extra_auto_values)
                    for fmt in formats:
                        out_path = os.path.join(out_dir, f"{basename}_ANTES.{fmt}")
                        if not self.service.export_layout(self.layout_obj, out_path, fmt):
                            errors.append(f"{xid}: fallo exportando ANTES ({fmt})")

                    # --- DESPUÉS (mismo encuadre/escala que ANTES) ---
                    self.map_item.setLayers(base_layers_desp)
                    self.service.fill_labels(self.layout_obj, fields_cfg, xid,
                                              extra_auto_values=extra_auto_values)
                    for fmt in formats:
                        # Corrección de la falla nº5 (typo): era "_DESPOIS".
                        out_path = os.path.join(out_dir, f"{basename}_DESPUES.{fmt}")
                        if not self.service.export_layout(self.layout_obj, out_path, fmt):
                            errors.append(f"{xid}: fallo exportando DESPUÉS ({fmt})")

                    ok_count += 1
                except Exception as e:
                    errors.append(f"{xid}: {e}")

            progress.setValue(len(xids))
        finally:
            for layer, original in restore_jobs:
                self.service.restore_renderer(layer, original)
            variables = QgsProject.instance().customVariables()
            if 'planos_finca_actual' in variables:
                del variables['planos_finca_actual']
                QgsProject.instance().setCustomVariables(variables)

        msg = f"Planos generados: {ok_count} finca(s) en:\n{out_dir}"
        if errors:
            msg += f"\n\n{len(errors)} error(es):\n" + "\n".join(errors[:20])
            if len(errors) > 20:
                msg += f"\n... y {len(errors) - 20} más."
        self._add_log_safe(f"Planos: generación finalizada -- {ok_count} finca(s), "
                            f"{len(errors)} error(es).")
        QMessageBox.information(self, "AudiNOT", msg)

    @staticmethod
    def _format_duration(seconds):
        seconds = max(0, int(seconds))
        if seconds < 60:
            return f"{seconds}s"
        m, s = divmod(seconds, 60)
        return f"{m}m {s}s"

    # ------------------------------------------------------------------
    # Mejora UI/UX: vista previa de un plano suelto (ANTES+DESPUÉS de la
    # PRIMERA finca seleccionada) antes de lanzar el lote completo -- así
    # se puede detectar visualmente el problema de recorte de la falla
    # nº1 sin tener que generar el lote entero para descubrirlo. No aplica
    # simbología de resaltado/aditamentos (solo capas base): es una
    # comprobación rápida de encuadre/escala, no un sustituto del plano
    # final.
    # ------------------------------------------------------------------
    def on_preview(self):
        if self.layout_obj is None or self.map_item is None:
            QMessageBox.warning(self, "AudiNOT", "Selecciona antes una plantilla .qpt válida "
                                                  "con un elemento de mapa.")
            return
        layer_antes = self.combo_antes.currentLayer()
        layer_despues = self.combo_despues.currentLayer()
        if layer_antes is None or layer_despues is None:
            QMessageBox.warning(self, "AudiNOT", "Selecciona las capas ANTES y DESPUÉS.")
            return

        xids = self._selected_xids()
        if not xids:
            QMessageBox.warning(self, "AudiNOT", "No hay ninguna finca seleccionada.")
            return
        xid = xids[0]

        idx_xid_antes = layer_antes.fields().indexOf('xID')
        idx_xid_desp = layer_despues.fields().indexOf('xID')
        if idx_xid_antes == -1 or idx_xid_desp == -1:
            QMessageBox.critical(self, "AudiNOT", "Las capas seleccionadas no tienen campo 'xID'.")
            return

        geom_antes = next((f.geometry() for f in layer_antes.getFeatures()
                            if str(f[idx_xid_antes]) == xid), None)
        geom_desp = next((f.geometry() for f in layer_despues.getFeatures()
                           if str(f[idx_xid_desp]) == xid), None)
        antes_vacia = geom_antes is None or geom_antes.isEmpty()
        desp_vacia = geom_desp is None or geom_desp.isEmpty()
        if antes_vacia and desp_vacia:
            QMessageBox.warning(self, "AudiNOT",
                                 f"La finca {xid} no tiene geometría en ANTES ni en DESPUÉS.")
            return

        if self.radio_scale_auto.isChecked():
            scale = self.service.compute_auto_scale(
                layer_antes, xids, self.map_item, layer_despues=layer_despues,
                margin_pct=self.spin_margin.value())
        else:
            scale = self.combo_scale_manual.currentData()

        adit_antes = self.combo_adit_antes.currentLayer()
        adit_despues = self.combo_adit_despues.currentLayer()
        construcciones = self.combo_construcciones.currentLayer()
        extra_layers = self._selected_extra_layers()
        base_layers_antes = [layer_antes] + ([adit_antes] if adit_antes else []) + extra_layers
        base_layers_desp = [layer_despues] + ([adit_despues] if adit_despues else []) + extra_layers
        if construcciones is not None:
            base_layers_antes.append(construcciones)
            base_layers_desp.append(construcciones)

        fields_cfg = self._current_fields_config()
        # Igual que en on_generate: la vista previa debe mostrar el mismo
        # texto que saldría en la generación real, no el xID en los
        # campos de escala/fecha.
        extra_auto_values = self.service.build_extra_auto_values(fields_cfg, scale)
        project = QgsProject.instance()
        tmp_dir = tempfile.mkdtemp(prefix="audinot_preview_")
        path_antes = os.path.join(tmp_dir, "preview_ANTES.png")
        path_desp = os.path.join(tmp_dir, "preview_DESPUES.png")
        try:
            QgsExpressionContextUtils.setProjectVariable(project, 'planos_finca_actual', xid)
            self.service.frame_map_item(self.map_item, geom_antes, geom_desp, scale)

            self.map_item.setLayers(base_layers_antes)
            self.service.fill_labels(self.layout_obj, fields_cfg, xid,
                                      extra_auto_values=extra_auto_values)
            if not self.service.export_layout(self.layout_obj, path_antes, 'png'):
                path_antes = None

            self.map_item.setLayers(base_layers_desp)
            self.service.fill_labels(self.layout_obj, fields_cfg, xid,
                                      extra_auto_values=extra_auto_values)
            if not self.service.export_layout(self.layout_obj, path_desp, 'png'):
                path_desp = None
        except Exception as e:
            QMessageBox.critical(self, "AudiNOT", f"No se pudo generar la vista previa:\n{e}")
            return
        finally:
            variables = project.customVariables()
            if 'planos_finca_actual' in variables:
                del variables['planos_finca_actual']
                project.setCustomVariables(variables)

        self._show_preview_dialog(xid, scale, path_antes, path_desp)

    def _show_preview_dialog(self, xid, scale, path_antes, path_desp):
        dlg = QDialog(self)
        dlg.setWindowTitle(f"Vista previa -- finca {xid} (1:{scale})")
        outer = QVBoxLayout(dlg)
        hint = QLabel(
            "Comprueba que la parcela no queda cortada por el marco en ninguno de los "
            "dos estados (mismo encuadre y escala en ambos, para que sean comparables).")
        hint.setWordWrap(True)
        hint.setStyleSheet("color: #7f8c8d; font-size: 10px;")
        outer.addWidget(hint)

        row = QHBoxLayout()
        for title, path in (("ANTES", path_antes), ("DESPUÉS", path_desp)):
            col = QVBoxLayout()
            lbl_title = QLabel(title)
            lbl_title.setStyleSheet("font-weight: bold;")
            lbl_title.setAlignment(Qt.AlignCenter)
            col.addWidget(lbl_title)
            img_lbl = QLabel()
            img_lbl.setAlignment(Qt.AlignCenter)
            pix = QPixmap(path) if path else QPixmap()
            if not pix.isNull():
                img_lbl.setPixmap(pix.scaled(420, 420, Qt.KeepAspectRatio, Qt.SmoothTransformation))
            else:
                img_lbl.setText("(no se pudo generar la imagen)")
            col.addWidget(img_lbl)
            wrap = QWidget()
            wrap.setLayout(col)
            row.addWidget(wrap)
        outer.addLayout(row)

        btn_close = QPushButton("Cerrar")
        btn_close.clicked.connect(dlg.accept)
        outer.addWidget(btn_close)
        dlg.exec_()

    # ------------------------------------------------------------------
    # Corrección de la falla nº2: esta ficha no se reseteaba al cerrar el
    # proyecto ni con el botón "Cerrar" de la cabecera -- a diferencia de
    # Ficha 1/4, que ya reciben este mismo tratamiento desde
    # AudiNOTDockManager._on_project_cleared / on_click_close. Sin esto,
    # tras cerrar el proyecto la plantilla, la tabla de fincas, la
    # carpeta de destino y las capas opcionales de la sesión anterior
    # seguían ahí.
    # ------------------------------------------------------------------
    def reset_to_empty(self):
        self.file_qpt.blockSignals(True)
        self.file_qpt.setFilePath("")
        self.file_qpt.blockSignals(False)
        self.layout_obj = None
        self.map_item = None
        self.campos_info = []
        self.table_fields.setRowCount(0)

        self.parcels = []
        self.notificar = {}
        self._solo_notificar = False
        self._legend_filter = None
        self._sync_legend_buttons()
        self.table_parcels.setRowCount(0)
        self.chk_select_all.blockSignals(True)
        self.chk_select_all.setChecked(False)
        self.chk_select_all.blockSignals(False)
        self.btn_filter_notify.blockSignals(True)
        self.btn_filter_notify.setChecked(False)
        self.btn_filter_notify.setText("Solo notificar")
        self.btn_filter_notify.setEnabled(False)
        self.btn_filter_notify.blockSignals(False)
        self._update_parcels_count()
        self._update_notify_summary()

        for combo in (self.combo_antes, self.combo_despues, self.combo_adit_antes,
                      self.combo_adit_despues, self.combo_construcciones):
            combo.setLayer(None)
        self.list_extra_layers.clear()

        self.file_out_dir.blockSignals(True)
        self.file_out_dir.setFilePath("")
        self.file_out_dir.blockSignals(False)

        self._update_readiness()

    # ------------------------------------------------------------------
    # Corrección de la falla nº3 + mejora UI/UX: incluir esta ficha en el
    # mecanismo de "Guardar/Cargar parámetros" (parametros.anot) ya
    # existente para las demás fichas, para que un lote de planos
    # configurado sea reproducible entre sesiones o entre compañeros de
    # equipo. NO se persisten los IDs de capa (no sobreviven entre
    # sesiones/proyectos): las capas obligatorias se siguen autodetectando
    # por nombre como hasta ahora, y las opcionales se intentan
    # reseleccionar por NOMBRE (mejor esfuerzo -- si no existen en el
    # proyecto actual, simplemente se quedan vacías).
    # ------------------------------------------------------------------
    def get_params_for_save(self):
        fields_overrides = {}
        for row, campo in enumerate(self.campos_info):
            if not campo['editable']:
                continue
            chk_item = self.table_fields.item(row, 2)
            if chk_item and chk_item.checkState() == Qt.Checked:
                continue  # "Auto": se recalcula por finca, no hace falta guardar valor
            val_item = self.table_fields.item(row, 1)
            fields_overrides[campo['id']] = val_item.text() if val_item else ''

        def _layer_name(combo):
            lyr = combo.currentLayer()
            return lyr.name() if lyr is not None else None

        extra_layer_names = [
            self.list_extra_layers.item(i).text()
            for i in range(self.list_extra_layers.count())
            if self.list_extra_layers.item(i).checkState() == Qt.Checked
        ]

        return {
            'qpt_path': self.file_qpt.filePath() or None,
            'fields_overrides': fields_overrides,
            'scale_mode': 'auto' if self.radio_scale_auto.isChecked() else 'manual',
            'margin_pct': self.spin_margin.value(),
            'manual_scale': self.combo_scale_manual.currentData(),
            'formats': [fmt for fmt, chk in (('pdf', self.chk_pdf), ('png', self.chk_png))
                        if chk.isChecked()],
            'out_dir': self.file_out_dir.filePath() or None,
            'categorize_adit': self.chk_categorize_adit.isChecked(),
            'layer_adit_antes': _layer_name(self.combo_adit_antes),
            'layer_adit_despues': _layer_name(self.combo_adit_despues),
            'layer_construcciones': _layer_name(self.combo_construcciones),
            'extra_layers': extra_layer_names,
        }

    def set_params(self, data):
        if not data:
            return

        qpt_path = data.get('qpt_path')
        if qpt_path and os.path.exists(qpt_path):
            # setFilePath dispara fileChanged -> on_template_changed, que
            # analiza la plantilla y rellena self.campos_info/table_fields
            # de forma síncrona, así que a continuación ya se pueden
            # aplicar los overrides de valor guardados.
            self.file_qpt.setFilePath(qpt_path)

        overrides = data.get('fields_overrides') or {}
        if overrides:
            for row, campo in enumerate(self.campos_info):
                if campo['id'] not in overrides:
                    continue
                val_item = self.table_fields.item(row, 1)
                if val_item:
                    val_item.setText(overrides[campo['id']])
                chk_item = self.table_fields.item(row, 2)
                if chk_item:
                    chk_item.setCheckState(Qt.Unchecked)

        scale_mode = data.get('scale_mode', 'auto')
        self.radio_scale_auto.setChecked(scale_mode != 'manual')
        self.radio_scale_manual.setChecked(scale_mode == 'manual')
        if 'margin_pct' in data:
            self.spin_margin.setValue(data['margin_pct'])
        if data.get('manual_scale') in STANDARD_SCALES:
            idx = self.combo_scale_manual.findData(data['manual_scale'])
            if idx != -1:
                self.combo_scale_manual.setCurrentIndex(idx)

        formats = data.get('formats', ['pdf'])
        self.chk_pdf.setChecked('pdf' in formats)
        self.chk_png.setChecked('png' in formats)

        if data.get('out_dir'):
            self.file_out_dir.setFilePath(data['out_dir'])

        self.chk_categorize_adit.setChecked(data.get('categorize_adit', True))

        # Refresca los combos/lista de capas con las que haya AHORA en el
        # proyecto antes de intentar reseleccionar por nombre.
        self._refresh_all_layer_widgets()

        def _select_by_name(combo, name):
            if not name:
                return
            for lyr in QgsProject.instance().mapLayers().values():
                if lyr.name() == name:
                    combo.setLayer(lyr)
                    return

        _select_by_name(self.combo_adit_antes, data.get('layer_adit_antes'))
        _select_by_name(self.combo_adit_despues, data.get('layer_adit_despues'))
        _select_by_name(self.combo_construcciones, data.get('layer_construcciones'))

        extra_names = set(data.get('extra_layers') or [])
        for i in range(self.list_extra_layers.count()):
            item = self.list_extra_layers.item(i)
            item.setCheckState(Qt.Checked if item.text() in extra_names else Qt.Unchecked)

        self._update_readiness()
