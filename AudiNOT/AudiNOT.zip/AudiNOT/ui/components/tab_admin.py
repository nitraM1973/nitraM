from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
                              QPushButton, QGroupBox, QRadioButton, QMessageBox)
from PyQt5.QtCore import pyqtSignal, Qt

from ...core.audit_service import AuditService, ROLE_DEFAULT
from ...core.access_control import generar_posiciones, verify_code_parcial, SEED_LENGTH
from ..busy_indicator import BusyCursor


class TabAdmin(QWidget):
    """Ficha "6: Administración". Abierta por cualquiera (no está
    restringida en sí misma); lo que hay DETRÁS del PIN sí lo está: solo
    tras validarlo se revela el selector de rol. No decide restricciones
    de ninguna otra ficha -- eso vive únicamente en
    AudiNOTDockManager.aplicar_restricciones_por_rol (ver roleChanged).

    El cambio de rol debe poder hacerse SIEMPRE, sea cual sea el estado de
    la Ficha "1: Datos Entrada" (con o sin carpeta de salida, con o sin
    GeoPackage de auditoría ya generado): si hay carpeta de salida, el
    cambio se escribe directamente en su GeoPackage (creando la tabla
    AudiNOT_Admin si hiciera falta, aunque todavía no se haya ejecutado
    ningún análisis en esa carpeta); si no la hay todavía, el cambio queda
    en memoria como `pending_role` y es AudiNOTDockManager quien lo
    traslada al GeoPackage en cuanto haya una carpeta de proyecto válida
    (ver AudiNOTDockManager._try_persist_pending_role)."""

    roleChanged = pyqtSignal(str)

    def __init__(self, iface):
        super().__init__()
        self.iface = iface
        self.audit_service = None
        self._output_dir_provider = None
        # Rol elegido en esta ficha mientras todavía no había carpeta de
        # salida (Ficha 1) donde persistirlo. None = no hay ningún cambio
        # pendiente (o ya se trasladó al GeoPackage). Ver pending_role /
        # clear_pending_role, más abajo.
        self._pending_role = None
        # Posiciones (1-indexadas, de 1 a SEED_LENGTH) pedidas en el
        # reto actual de "clave de coordenadas" -- se renueva en cada
        # intento (ver _nuevo_reto), nunca se repite el mismo reto dos
        # veces seguidas.
        self._posiciones_actuales = []
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)

        layout.addWidget(QLabel("<b>Administración</b>"))
        note = QLabel(
            "Introduce clave ADMIN:"
        )
        note.setWordWrap(True)
        note.setStyleSheet("color: #666; font-size: 10px;")
        layout.addWidget(note)

        # Rejilla de "clave de coordenadas": una columna por cada una de
        # las SEED_LENGTH posiciones. La etiqueta superior solo muestra
        # el número de posición si se pidió en el reto actual; si no,
        # muestra "*" y su casilla debajo queda deshabilitada. No hay
        # ninguna pista visual sobre qué representa cada posición.
        self._lbls_pos = []
        self._boxes_pos = []
        row_labels = QHBoxLayout()
        row_boxes = QHBoxLayout()
        for _ in range(SEED_LENGTH):
            lbl = QLabel("*")
            lbl.setAlignment(Qt.AlignCenter)
            lbl.setFixedWidth(22)
            row_labels.addWidget(lbl)
            self._lbls_pos.append(lbl)

            box = QLineEdit()
            box.setFixedWidth(22)
            box.setMaxLength(1)
            box.setAlignment(Qt.AlignCenter)
            box.setEnabled(False)
            box.returnPressed.connect(self.on_click_validar)
            row_boxes.addWidget(box)
            self._boxes_pos.append(box)
        layout.addLayout(row_labels)
        layout.addLayout(row_boxes)

        self.btn_validar = QPushButton("Validar")
        self.btn_validar.clicked.connect(self.on_click_validar)
        layout.addWidget(self.btn_validar)

        self.lbl_error = QLabel("")
        self.lbl_error.setStyleSheet("color: #c0392b; font-size: 10px;")
        layout.addWidget(self.lbl_error)

        self.group_rol = QGroupBox("Rol activo")
        group_layout = QVBoxLayout()
        self.rb_revisor1 = QRadioButton("REVISOR 1")
        self.rb_revisor2 = QRadioButton("REVISOR 2")
        group_layout.addWidget(self.rb_revisor1)
        group_layout.addWidget(self.rb_revisor2)
        self.btn_aplicar = QPushButton("Aplicar cambio de rol")
        self.btn_aplicar.clicked.connect(self.on_click_aplicar)
        group_layout.addWidget(self.btn_aplicar)
        self.group_rol.setLayout(group_layout)
        self.group_rol.setVisible(False)
        layout.addWidget(self.group_rol)

        layout.addStretch()

        self._nuevo_reto()

    def _nuevo_reto(self):
        """Genera un reto nuevo: elige SEED_LENGTH->POSITIONS_TO_ASK
        posiciones al azar, muestra su número solo en esas etiquetas
        (el resto queda en "*") y habilita solo esas casillas, vacías.
        Se llama al abrir la ficha y tras cada intento (acierto o
        fallo) para que nunca se repita el mismo reto."""
        self._posiciones_actuales = generar_posiciones()
        primera_caja = None
        for i in range(SEED_LENGTH):
            pos = i + 1
            pedir = pos in self._posiciones_actuales
            self._lbls_pos[i].setText(str(pos) if pedir else "*")
            self._boxes_pos[i].setEnabled(pedir)
            self._boxes_pos[i].clear()
            if pedir and primera_caja is None:
                primera_caja = self._boxes_pos[i]
        if primera_caja is not None:
            primera_caja.setFocus()

    def set_output_dir_provider(self, fn):
        """Inyectado por AudiNOTDockManager: `fn()` debe devolver la
        "Carpeta de Salida" (raíz de proyecto) ACTUAL de la Ficha "1:
        Datos Entrada" -- ahí vive el GeoPackage de auditoría, igual
        patrón que TabAudit.set_output_dir_provider."""
        self._output_dir_provider = fn

    @property
    def pending_role(self):
        """Rol elegido en esta ficha que todavía no se ha podido escribir
        en ningún GeoPackage por no haber carpeta de salida en la Ficha 1
        en el momento de aplicarlo. None si no hay ningún cambio
        pendiente. Solo lectura desde fuera -- ver clear_pending_role."""
        return self._pending_role

    def clear_pending_role(self):
        """Llamado por AudiNOTDockManager (_try_persist_pending_role) en
        cuanto el rol pendiente queda escrito en el GeoPackage de la
        carpeta de proyecto actual."""
        self._pending_role = None

    def _ensure_audit_service(self):
        output_dir = self._output_dir_provider() if self._output_dir_provider else None
        if not output_dir:
            return None
        # Se reconstruye en cada uso (barato: solo guarda una ruta) en vez
        # de cachear, para reflejar siempre la carpeta de proyecto vigente
        # en la Ficha 1 -- igual criterio que el resto de fichas que leen
        # el GeoPackage de auditoría bajo demanda.
        self.audit_service = AuditService(output_dir)
        return self.audit_service

    def on_click_validar(self):
        entradas = {
            pos: self._boxes_pos[pos - 1].text()
            for pos in self._posiciones_actuales
        }
        if not verify_code_parcial(entradas, self._posiciones_actuales):
            self.lbl_error.setText("Código incorrecto.")
            self.group_rol.setVisible(False)
            # Reto nuevo tras un fallo: no se reutiliza el mismo.
            self._nuevo_reto()
            return

        # El PIN habilita el selector de rol pase lo que pase en la Ficha
        # "1: Datos Entrada" -- el rol debe poder cambiarse aunque todavía
        # no haya carpeta de salida ni GeoPackage de auditoría (ver
        # docstring de la clase). El rol mostrado como "actual" es: el
        # cambio pendiente en memoria, si lo hay; si no, el leído del
        # GeoPackage de la carpeta actual; si tampoco hay carpeta o
        # GeoPackage, ROLE_DEFAULT.
        self.lbl_error.setText("")
        service = self._ensure_audit_service()
        if self._pending_role:
            rol_actual = self._pending_role
        elif service is not None:
            rol_actual = service.get_current_role()
        else:
            rol_actual = ROLE_DEFAULT
        self.rb_revisor1.setChecked(rol_actual != 'revisor2')
        self.rb_revisor2.setChecked(rol_actual == 'revisor2')
        self.group_rol.setVisible(True)

    def on_click_aplicar(self):
        service = self._ensure_audit_service()

        if self._pending_role:
            rol_anterior = self._pending_role
        elif service is not None:
            rol_anterior = service.get_current_role()
        else:
            rol_anterior = ROLE_DEFAULT

        nuevo_rol = 'revisor2' if self.rb_revisor2.isChecked() else 'revisor1'
        if nuevo_rol == rol_anterior:
            QMessageBox.information(self, "AudiNOT", "El rol activo ya era ese; no hay ningún cambio que aplicar.")
            return

        if service is not None:
            try:
                with BusyCursor():
                    service.set_current_role(nuevo_rol)
                    # Reutiliza add_historial_entry (ya existe en AuditService,
                    # ver save_review_with_history) en vez de reimplementar la
                    # escritura en AudiNOT_Historial -- este módulo sigue siendo
                    # el único que sabe escribir en el gpkg de auditoría.
                    service.add_historial_entry(
                        audinot_id='', origen='cambio_rol', report_id=None,
                        detalle=f"{rol_anterior} \u2192 {nuevo_rol}",
                    )
            except Exception as e:
                QMessageBox.critical(self, "AudiNOT", f"No se pudo cambiar el rol:\n{e}")
                return
            self._pending_role = None
            mensaje = f"Rol activo cambiado a {nuevo_rol.upper()}."
        else:
            # Todavía no hay carpeta de salida en la Ficha "1: Datos
            # Entrada" -- no hay dónde escribir el rol. Se guarda en
            # memoria; AudiNOTDockManager lo trasladará al GeoPackage de
            # auditoría en cuanto se seleccione una carpeta de proyecto
            # (ver _try_persist_pending_role).
            self._pending_role = nuevo_rol
            mensaje = (
                f"Rol cambiado a {nuevo_rol.upper()} para esta sesión. Como todavía no hay "
                "una \"Carpeta de Salida\" seleccionada en la Ficha \"1: Datos Entrada\", el "
                "cambio se guardará en el GeoPackage de auditoría en cuanto elijas una."
            )

        self._nuevo_reto()
        self.group_rol.setVisible(False)
        QMessageBox.information(self, "AudiNOT", mensaje)

        # Refresca la UI (indicador del dock + restricciones de las demás
        # fichas) sin recargar el gpkg -- ver
        # AudiNOTDockManager.aplicar_restricciones_por_rol, único sitio que
        # sabe qué se apaga y qué se enciende según el rol.
        self.roleChanged.emit(nuevo_rol)
