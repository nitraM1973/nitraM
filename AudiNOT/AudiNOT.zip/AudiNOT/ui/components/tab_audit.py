import json
import os
import re
import tempfile
from datetime import datetime

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QComboBox,
    QListWidget, QListWidgetItem, QSplitter, QGroupBox, QTextEdit,
    QButtonGroup, QRadioButton, QLineEdit, QScrollArea, QMessageBox,
    QCheckBox, QApplication, QProgressBar, QFileDialog
)
from PyQt5.QtCore import Qt, pyqtSignal, QRectF, QSize, QUrl
from PyQt5.QtGui import QPainter, QDesktopServices
from PyQt5.QtSvg import QSvgWidget

from qgis.core import QgsFeatureRequest, QgsProject, NULL as QGIS_NULL

from ...core.audit_service import AuditService, AUDIT_LAYER_NAME, HISTORIAL_LAYER_NAME
from ...core.report_service import ReportService
from ..busy_indicator import BusyCursor
from .historial_dialog import HistorialDialog


def _safe_bool_field(feat, name):
    """Lee un campo booleano de un feature sin reventar si el campo no
    existe todavía en la capa (p.ej. un .gpkg de una versión anterior del
    plugin cuya migración de esquema haya fallado por algún motivo -
    fichero de solo lectura, permisos... ver AuditService._migrate_schema,
    que ya se invoca en cada load_layer() precisamente para que esto no
    pase, pero esto es el cinturón de seguridad). Ausente o NULL -> False."""
    idx = feat.fields().indexFromName(name)
    if idx == -1:
        return False
    value = feat[name]
    if value is None or value == QGIS_NULL:
        return False
    return bool(value)


class AspectRatioSvgWidget(QSvgWidget):
    """QSvgWidget "de fábrica" ignora la proporción (ancho/alto) del
    <svg> y lo estira para rellenar todo el widget (su paintEvent llama
    a renderer().render(painter) sin pasarle un rectángulo destino, así
    que Qt usa directamente los bordes del widget). Eso es lo que
    deforma el croquis horizontalmente cada vez que el usuario cambia
    el ancho del dock.

    Aquí se sobreescribe paintEvent para calcular, a partir del
    viewBox del SVG, el rectángulo más grande que cabe en el widget
    manteniendo la proporción original (equivalente a
    Qt.KeepAspectRatio), centrado dejando marco en blanco a los lados
    o arriba/abajo según haga falta. Así el croquis se ve siempre
    proporcionado, sea cual sea el ancho que el usuario le dé al dock.

    Además se sobreescriben sizeHint/minimumSizeHint: QSvgWidget, por
    defecto, las calcula a partir del tamaño NATIVO del SVG (el
    croquis se genera a 560x380px, ver report_service.py), y ese ancho
    de 560px es justo lo que obligaba a la QScrollArea que envuelve
    este widget a ensancharse por encima del dock y mostrar un scroll
    horizontal en cuanto el dock bajaba de ese ancho. Como el
    paintEvent de aquí arriba ya sabe encajar el dibujo en cualquier
    tamaño (con su propio letterboxing), no hace falta ese mínimo: el
    widget puede anunciar un tamaño pequeño y dejar que el layout lo
    estire tanto como haya sitio."""

    def sizeHint(self):
        return QSize(320, 260)

    def minimumSizeHint(self):
        return QSize(120, self.minimumHeight() or 120)

    def paintEvent(self, event):
        renderer = self.renderer()
        if renderer is None or not renderer.isValid():
            return

        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        target = QRectF(self.rect())
        view_box = renderer.viewBoxF()
        if view_box.width() <= 0 or view_box.height() <= 0 or target.height() <= 0:
            renderer.render(painter, target)
            return

        svg_ratio = view_box.width() / view_box.height()
        target_ratio = target.width() / target.height()

        if target_ratio > svg_ratio:
            # El widget es proporcionalmente más ancho que el croquis:
            # se limita el ancho del dibujo y se centra horizontalmente.
            w = target.height() * svg_ratio
            draw_rect = QRectF(target.x() + (target.width() - w) / 2, target.y(), w, target.height())
        else:
            # El widget es proporcionalmente más alto: se limita la
            # altura del dibujo y se centra verticalmente.
            h = target.width() / svg_ratio
            draw_rect = QRectF(target.x(), target.y() + (target.height() - h) / 2, target.width(), h)

        renderer.render(painter, draw_rect)


class TabAudit(QWidget):
    """
    Ficha "4: Auditoría".

    Es un módulo NUEVO y AISLADO: solo depende de core/audit_service.py
    (que a su vez lee lo ya calculado por ReportService). No modifica
    ni depende de tab_inputs / tab_mapping / tab_thresholds, así que
    todo lo demás del plugin sigue funcionando exactamente igual si
    esta ficha no se usa.
    """

    layerReady = pyqtSignal()
    # Emitida cuando, al picar en el lienzo, se auto-selecciona un recinto
    # en esta ficha (ver on_canvas_selection_changed): el dock_manager la
    # usa para cambiar automáticamente a esta pestaña.
    requestActivateTab = pyqtSignal()

    def __init__(self, iface):
        super().__init__()
        self.iface = iface
        self.audit_service = None
        self.layer = None
        self.current_feature_id = None
        self._id_by_row = []
        # Función (inyectada desde fuera, ver set_output_dir_provider) que
        # devuelve la "Carpeta de Salida" ACTUAL de la Ficha "1: Datos
        # Entrada" en el momento de la consulta -- no un valor cacheado.
        # Se usa solo para que el botón "↻ Recargar" no haga nada si esa
        # carpeta está vacía; mantiene a esta ficha desacoplada de
        # TabInputs (nunca la importa ni la referencia directamente, es
        # AudiNOTDockManager quien conecta la función).
        self._output_dir_provider = None
        # Evita el bucle de señales cuando esta misma ficha selecciona una
        # feature en la capa (zoom_to_current, guardar revisión...): esa
        # selección programática no debe volver a auto-seleccionar nada.
        self._syncing_selection = False
        # True mientras otra ficha (p.ej. Ficha "5: Revisión", ver
        # TabRevision._zoom_to) selecciona programáticamente una feature en
        # ESTA MISMA capa compartida solo para hacer zoom/resaltar, sin que
        # eso deba traer el foco a esta ficha. A diferencia de
        # _syncing_selection (que evita el bucle de re-selección), este
        # flag sí deja pasar el resto de on_layer_selection_changed (resalta
        # la fila en la lista de esta ficha) pero suprime el
        # requestActivateTab.emit() final. Lo activa/desactiva
        # AudiNOTDockManager mediante set_suppress_activate.
        self._suppress_activate_signal = False
        # True solo cuando el recinto "actual" lo ha elegido el usuario a
        # propósito (clic en la lista, o picar en el lienzo). Se pone a
        # False al recargar la capa o al cambiar el filtro, porque en esos
        # casos Qt auto-selecciona la primera fila de la lista sin que eso
        # sea una elección real del usuario. Lo usa export_current_html
        # para distinguir "hay una finca elegida" de "hay una finca
        # resaltada porque es la primera de la lista".
        self._user_selected_row = False
        # Ventana no modal de historial (ver historial_dialog.py): se crea
        # perezosamente al pulsar "📜 Ver historial" y, mientras está
        # abierta, se mantiene sincronizada con la finca seleccionada
        # (ver _refresh_historial_dialog, llamado desde _render_detail).
        self._historial_dialog = None
        # Detalle del último recálculo de métricas de la finca actual,
        # cacheado en cada _render_detail para que _show_desact_warning
        # (icono ⚠ de la cabecera) no tenga que volver a consultarlo.
        self._desact_detalle = ''
        self.init_ui()

    # ------------------------------------------------------------------
    # UI
    # ------------------------------------------------------------------
    def init_ui(self):
        layout = QVBoxLayout(self)

        # --- Cabecera: progreso "de un vistazo" ---
        header = QHBoxLayout()
        self.lbl_progress = QLabel("Sin capa de auditoría cargada todavía.")
        self.lbl_progress.setStyleSheet("font-weight:bold; color:#2c3e50;")
        header.addWidget(self.lbl_progress)
        header.addStretch()

        # Barra de progreso para la exportación masiva de fichas HTML
        # (_export_bulk_html). Oculta el resto del tiempo: un widget
        # oculto no reserva espacio en el layout, así que su presencia
        # no cambia en nada la distribución habitual de la cabecera.
        # Ancho fijo y compacta para que, cuando aparece, sea discreta
        # y no empuje al resto de controles.
        self.progress_bar = QProgressBar()
        self.progress_bar.setFixedWidth(160)
        self.progress_bar.setFixedHeight(16)
        self.progress_bar.setTextVisible(True)
        self.progress_bar.setVisible(False)
        header.addWidget(self.progress_bar)

        self.btn_reload = QPushButton("↻ Recargar")
        self.btn_reload.setToolTip("Vuelve a leer el estado actual del GeoPackage de auditoría (por si se editó desde la tabla de atributos)")
        self.btn_reload.clicked.connect(self.on_click_reload)
        header.addWidget(self.btn_reload)
        layout.addLayout(header)

        # --- Filtro ---
        # Los mismos criterios que ya ofrecen las facetas del informe HTML
        # (sidebar "Filtros" del informe): Estado, Notificación, Titular,
        # Precisión T24 y Validación GML. Se reparten en dos filas para
        # que quepan sin abrumar.
        filter_group = QGroupBox("Filtro")
        filter_v = QVBoxLayout()

        # Los combos tienen listas de cadenas fijas (no dependen de los
        # datos cargados), así que se les da un ancho fijo en vez de
        # dejarlos crecer: eso permite meter más de un filtro por fila y
        # ganar espacio vertical. El texto completo de la opción elegida
        # sigue disponible en el tooltip y, sin recortar, en el desplegable.
        ANCHO_COMBO_CORTO = 110    # Revisión, Precisión T24
        ANCHO_COMBO_MEDIO = 130    # Estado, Validación GML
        ANCHO_COMBO_LARGO = 150    # Notificación (opciones más largas)
        ANCHO_BUSCAR = 110         # admite el ID (hasta 6 dígitos) o un trozo de titular

        row1 = QHBoxLayout()
        row1.addWidget(QLabel("Revisión:"))
        self.cmb_revision = QComboBox()
        self.cmb_revision.addItems(["Todas", "Sin revisar", "Revisar", "Notifica", "No notifica", "Desactualizadas"])
        self.cmb_revision.setToolTip("Estado de LA REVISIÓN HUMANA de esta ficha (equivalente a la faceta 'Usuario' del informe).")
        self.cmb_revision.setFixedWidth(ANCHO_COMBO_CORTO)
        self.cmb_revision.currentIndexChanged.connect(self.on_filter_changed)
        row1.addWidget(self.cmb_revision)

        row1.addWidget(QLabel("Estado:"))
        self.cmb_estado = QComboBox()
        self.cmb_estado.addItems(["Todos", "Nueva (ALTA)", "Desaparece (BAJA)", "Persistente"])
        self.cmb_estado.setToolTip("Equivalente a la faceta 'Estado' del informe HTML.")
        self.cmb_estado.setFixedWidth(ANCHO_COMBO_MEDIO)
        self.cmb_estado.currentIndexChanged.connect(self.on_filter_changed)
        row1.addWidget(self.cmb_estado)

        row1.addWidget(QLabel("Buscar:"))
        self.txt_search = QLineEdit()
        self.txt_search.setPlaceholderText("ID / titular…")
        self.txt_search.setToolTip("Busca por ID de finca (hasta 6 dígitos) o por parte del nombre del titular anterior o posterior.")
        self.txt_search.setFixedWidth(ANCHO_BUSCAR)
        self.txt_search.textChanged.connect(self.on_filter_changed)
        row1.addWidget(self.txt_search)
        row1.addStretch()
        filter_v.addLayout(row1)

        row2 = QHBoxLayout()
        row2.addWidget(QLabel("Notificación:"))
        self.cmb_notif = QComboBox()
        self.cmb_notif.addItems([
            "Todas",
            "Paramétrica: notifica", "Paramétrica: no notifica",
            "Alternativa: notifica", "Alternativa: no notifica",
            "Divergen (paramétrica ≠ alternativa)",
            "Coinciden en notificar",
        ])
        self.cmb_notif.setToolTip("Equivalente a la faceta 'Notificación' del informe HTML.")
        self.cmb_notif.setFixedWidth(ANCHO_COMBO_LARGO)
        self.cmb_notif.currentIndexChanged.connect(self.on_filter_changed)
        row2.addWidget(self.cmb_notif)

        self.chk_titular_cambia = QCheckBox("Cambia titular")
        self.chk_titular_cambia.setToolTip("Equivalente a la faceta 'Titular → Cambio de titular' del informe HTML.")
        self.chk_titular_cambia.stateChanged.connect(self.on_filter_changed)
        row2.addWidget(self.chk_titular_cambia)

        row2.addWidget(QLabel("Precisión T24:"))
        self.cmb_t24 = QComboBox()
        self.cmb_t24.addItems([
            "Todas", "Fuera de tolerancia", "Empeora la precisión",
            "Mejora la precisión", "Sin dato de referencia",
        ])
        self.cmb_t24.setToolTip(
            "Compara supfT24 vs. superficie GRÁFICA real (equivalente a la faceta "
            "'Precisión de superficie' del informe HTML)."
        )
        self.cmb_t24.setFixedWidth(ANCHO_COMBO_CORTO)
        self.cmb_t24.currentIndexChanged.connect(self.on_filter_changed)
        row2.addWidget(self.cmb_t24)
        row2.addStretch()
        filter_v.addLayout(row2)

        row3 = QHBoxLayout()
        row3.addWidget(QLabel("Validación GML:"))
        self.cmb_validacion = QComboBox()
        self.cmb_validacion.addItems([
            "Todas", "No valida en Después", "Antes validaba, después no",
            "Antes no validaba, después sí",
        ])
        self.cmb_validacion.setToolTip(
            "Combina supfT24 vs. GRÁFICA y vs. GML (equivalente a la faceta "
            "'Validación' del informe HTML): 'no valida' si falla cualquiera de las dos."
        )
        self.cmb_validacion.setFixedWidth(ANCHO_COMBO_MEDIO)
        self.cmb_validacion.currentIndexChanged.connect(self.on_filter_changed)
        row3.addWidget(self.cmb_validacion)
        row3.addStretch()
        filter_v.addLayout(row3)

        filter_group.setLayout(filter_v)
        layout.addWidget(filter_group)

        # --- Maestro-detalle ---
        splitter = QSplitter(Qt.Horizontal)

        list_container = QWidget()
        list_v = QVBoxLayout(list_container)
        list_v.setContentsMargins(0, 0, 0, 0)

        bulk_row = QHBoxLayout()
        self.btn_bulk_no_notificar = QPushButton("🚫")
        self.btn_bulk_no_notificar.setFixedWidth(34)
        self.btn_bulk_no_notificar.setToolTip(
            "Pendientes → NO NOTIFICAR\n\n"
            "Marca automáticamente como NO NOTIFICAR todas las fincas que\n"
            "todavía están 'Sin revisar'. No toca las que ya tengan una\n"
            "decisión tomada."
        )
        self.btn_bulk_no_notificar.clicked.connect(self.bulk_mark_pending_no_notificar)
        bulk_row.addWidget(self.btn_bulk_no_notificar)

        self.btn_bulk_reset = QPushButton("♻️")
        self.btn_bulk_reset.setFixedWidth(34)
        self.btn_bulk_reset.setToolTip(
            "Todo → Sin revisar\n\n"
            "Pone TODAS las fincas en estado 'Sin revisar', borrando\n"
            "también todas las observaciones guardadas."
        )
        self.btn_bulk_reset.clicked.connect(self.bulk_reset_all_to_sin_revisar)
        bulk_row.addWidget(self.btn_bulk_reset)

        self.btn_bulk_verify_desact = QPushButton("✅")
        self.btn_bulk_verify_desact.setFixedWidth(34)
        self.btn_bulk_verify_desact.setToolTip(
            "Desactualizadas → Verificadas\n\n"
            "Da por buenas TODAS las fincas marcadas como 'desactualizada'\n"
            "(ya revisadas, pero cuyos datos cambiaron después). Quita el\n"
            "aviso ⚠ sin tocar la decisión (NOTIFICAR / NO NOTIFICAR / A\n"
            "REVISAR) ni la observación ya guardadas."
        )
        self.btn_bulk_verify_desact.clicked.connect(self.bulk_verify_desactualizadas)
        bulk_row.addWidget(self.btn_bulk_verify_desact)
        bulk_row.addStretch()

        # Etiqueta con el nº de elementos que muestra la lista en cada
        # momento (cambia con los filtros y con cada recarga/refresco de
        # datos: se actualiza en _update_list_count, llamado al final de
        # apply_filter y tras vaciar la lista en reload_layer).
        self.lbl_list_count = QLabel("0 fincas")
        self.lbl_list_count.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.lbl_list_count.setStyleSheet("color:#666;")
        bulk_row.addWidget(self.lbl_list_count)
        list_v.addLayout(bulk_row)

        self.list_widget = QListWidget()
        self.list_widget.setMinimumWidth(180)
        self.list_widget.currentRowChanged.connect(self.on_select_row)
        self.list_widget.itemClicked.connect(self.on_click_zoom)
        self.list_widget.itemDoubleClicked.connect(self.on_double_click_toggle)
        list_v.addWidget(self.list_widget)

        splitter.addWidget(list_container)

        # Contenedor del detalle: el título va fijo arriba y, debajo, un
        # splitter VERTICAL en tres bloques:
        #   1) croquis + botones de exportar/zoom  → fijo, no hace scroll
        #   2) datos (métricas + conclusión)        → con su PROPIO scroll
        #   3) "Revisión de esta ficha"              → fijo, no hace scroll
        # Así, al revisar muchas fincas seguidas, el croquis de arriba y
        # los radiobuttons/observación/guardar de abajo quedan siempre a
        # la vista; solo se desplaza el bloque de datos del medio, que
        # es el que puede variar de longitud según la finca. Al ser un
        # QSplitter (no proporciones fijas), el usuario puede arrastrar
        # las barras divisoras para darle más alto al croquis o al
        # bloque de datos según le convenga en cada momento.
        detail_container = QWidget()
        detail_outer = QVBoxLayout(detail_container)
        detail_outer.setContentsMargins(0, 0, 0, 0)

        title_row = QHBoxLayout()
        self.lbl_detail_title = QLabel("Selecciona una finca de la lista")
        self.lbl_detail_title.setStyleSheet("font-size:14px; font-weight:bold; color:#2c3e50;")
        title_row.addWidget(self.lbl_detail_title, stretch=1)

        # Icono ⚠ arriba a la derecha, misma fila que "Finca X — estado":
        # sustituye al texto largo que antes vivía de forma permanente bajo
        # "Revisión de esta ficha" (ver _render_detail más abajo). Mismo
        # disparador (revision_desactualizada), pero aquí solo ocupa el
        # ancho de un icono; el mensaje completo aparece al pulsarlo
        # (_show_desact_warning), no fijo en pantalla como antes.
        self.btn_desact_warning = QPushButton("⚠")
        self.btn_desact_warning.setFlat(True)
        self.btn_desact_warning.setCursor(Qt.PointingHandCursor)
        self.btn_desact_warning.setFixedWidth(28)
        self.btn_desact_warning.setStyleSheet(
            "QPushButton { border:none; background:transparent; color:#b45309; "
            "font-size:18px; font-weight:bold; padding:0; }"
            "QPushButton:hover { color:#92400e; }"
        )
        self.btn_desact_warning.setToolTip(
            "Las métricas de esta finca han cambiado desde la última revisión.\n"
            "Pulsa para ver el detalle."
        )
        self.btn_desact_warning.setVisible(False)
        self.btn_desact_warning.clicked.connect(self._show_desact_warning)
        title_row.addWidget(self.btn_desact_warning, stretch=0)

        detail_outer.addLayout(title_row)

        detail_splitter = QSplitter(Qt.Vertical)

        # --- Bloque 1: croquis + botones (fijo) ---
        top_widget = QWidget()
        top_layout = QVBoxLayout(top_widget)
        top_layout.setContentsMargins(0, 0, 0, 0)

        self.svg_widget = AspectRatioSvgWidget()
        self.svg_widget.setMinimumHeight(160)
        self.svg_widget.setStyleSheet("background:white; border:1px solid #ddd;")
        top_layout.addWidget(self.svg_widget, stretch=1)

        # Los 4 botones bajo el croquis: solo el de "Ver en el lienzo" es
        # icono puro (misma convención que los iconos sueltos de bulk_row
        # más arriba: setFixedWidth ajustado + tooltip con el texto
        # completo). Los otros tres combinan icono + texto corto, para no
        # competir en anchura con el croquis; el detalle largo va siempre
        # en el tooltip, nunca en la etiqueta visible.
        btn_row_actions = QHBoxLayout()

        btn_zoom = QPushButton("🔍")
        btn_zoom.setFixedWidth(30)
        btn_zoom.setToolTip("Ver en el lienzo")
        btn_zoom.clicked.connect(self.zoom_to_current)
        btn_row_actions.addWidget(btn_zoom)

        self.btn_export_html = QPushButton("📤 HTML")
        self.btn_export_html.setToolTip(
            "Exportar ficha HTML\n\n"
            "Genera la ficha de este recinto en HTML, con el mismo aspecto que en el "
            "informe (croquis, aditamentos, conclusiones), y la guarda en la carpeta "
            "de RESULTADO."
        )
        self.btn_export_html.clicked.connect(self.export_current_html)
        btn_row_actions.addWidget(self.btn_export_html)

        self.btn_preview_metrics = QPushButton("🔢 Métricas")
        self.btn_preview_metrics.setToolTip(
            "Vista previa de métricas\n\n"
            "Genera una vista previa temporal (no se guarda en disco) con la sección de "
            "métricas de esta finca, tal y como aparece en el Informe HTML completo "
            "(incluye el croquis al final). Se abre directamente en el navegador."
        )
        self.btn_preview_metrics.clicked.connect(self.preview_current_metrics)
        btn_row_actions.addWidget(self.btn_preview_metrics)
        top_layout.addLayout(btn_row_actions)

        detail_splitter.addWidget(top_widget)

        # --- Bloque 2: datos (métricas + conclusión), con scroll propio ---
        mid_scroll = QScrollArea()
        mid_scroll.setWidgetResizable(True)
        mid_scroll.setFrameShape(QScrollArea.NoFrame)
        mid_content = QWidget()
        mid_layout = QVBoxLayout(mid_content)
        mid_layout.setContentsMargins(0, 4, 0, 4)

        self.lbl_metrics = QLabel("")
        self.lbl_metrics.setWordWrap(True)
        self.lbl_metrics.setStyleSheet("background:#f8f9fa; border:1px solid #eee; padding:8px; border-radius:4px;")
        mid_layout.addWidget(self.lbl_metrics)

        self.lbl_conclusion = QLabel("")
        self.lbl_conclusion.setWordWrap(True)
        self.lbl_conclusion.setStyleSheet("padding:6px;")
        mid_layout.addWidget(self.lbl_conclusion)
        mid_layout.addStretch()

        mid_scroll.setWidget(mid_content)
        detail_splitter.addWidget(mid_scroll)

        # --- Bloque 3: "Revisión de esta ficha" (fijo) ---
        review_group = QGroupBox("📝 Revisión de esta ficha")
        review_layout = QVBoxLayout()

        # El aviso de "métricas desactualizadas" ya no vive aquí como texto
        # fijo (ocupaba demasiado alto dentro de este bloque, que no hace
        # scroll): ahora es el icono ⚠ de la cabecera, junto a "Finca X —
        # estado" (ver btn_desact_warning en __init__ y _show_desact_warning
        # más abajo). El de "no_presente_ultimo_calculo" sí se queda aquí
        # tal cual (el usuario no ha pedido tocar este otro aviso).

        # Aviso equivalente para no_presente_ultimo_calculo (ver
        # diseno_historial_ficha4.md, punto 7): distinto del anterior,
        # esta finca ni siquiera entró en el último cálculo.
        self.lbl_no_presente_warning = QLabel("")
        self.lbl_no_presente_warning.setStyleSheet("color:#c0392b; font-weight:bold;")
        self.lbl_no_presente_warning.setWordWrap(True)
        self.lbl_no_presente_warning.setVisible(False)
        review_layout.addWidget(self.lbl_no_presente_warning)

        btn_row = QHBoxLayout()
        self.btn_group_decision = QButtonGroup(self)
        self.rb_sin_revisar = QRadioButton("Sin revisar")
        self.rb_revisar = QRadioButton("👁 Revisar")
        self.rb_revisar.setToolTip(
            "Marca esta ficha para que la revise específicamente otro técnico "
            "(todavía sin decisión de notificar / no notificar)."
        )
        self.rb_si = QRadioButton("✔ Notificar")
        self.rb_no = QRadioButton("✘ NO Notificar")
        for i, rb in enumerate([self.rb_sin_revisar, self.rb_revisar, self.rb_si, self.rb_no]):
            self.btn_group_decision.addButton(rb, i)
            btn_row.addWidget(rb)
        review_layout.addLayout(btn_row)

        self.txt_obs = QTextEdit()
        self.txt_obs.setPlaceholderText("Observación justificativa (sin límite de texto)…")
        self.txt_obs.setFixedHeight(80)
        review_layout.addWidget(self.txt_obs)

        btn_row_guardar = QHBoxLayout()
        self.btn_guardar = QPushButton("💾 Guardar revisión")
        self.btn_guardar.setStyleSheet("background-color:#2c3e50; color:white; font-weight:bold; padding:6px;")
        self.btn_guardar.clicked.connect(self.save_current_review)
        btn_row_guardar.addWidget(self.btn_guardar, stretch=1)

        self.btn_historial = QPushButton("📜 Ver historial")
        self.btn_historial.setToolTip(
            "Abre una ventana con todo el historial de revisiones y recálculos de "
            "esta finca. No es modal y queda sincronizada: si cambias de finca en "
            "la lista, se actualiza sola sin que tengas que volver a abrirla."
        )
        self.btn_historial.clicked.connect(self.toggle_historial_dialog)
        btn_row_guardar.addWidget(self.btn_historial)
        review_layout.addLayout(btn_row_guardar)

        review_group.setLayout(review_layout)
        detail_splitter.addWidget(review_group)

        # El bloque de datos (índice 1) es el que se lleva el espacio
        # sobrante; croquis y revisión piden solo lo que necesitan, pero
        # ninguno de los tres puede colapsarse del todo arrastrando el
        # divisor (así el croquis o la revisión no desaparecen sin querer).
        detail_splitter.setStretchFactor(0, 0)
        detail_splitter.setStretchFactor(1, 1)
        detail_splitter.setStretchFactor(2, 0)
        detail_splitter.setCollapsible(0, False)
        detail_splitter.setCollapsible(1, False)
        detail_splitter.setCollapsible(2, False)

        detail_outer.addWidget(detail_splitter, stretch=1)

        splitter.addWidget(detail_container)
        splitter.setStretchFactor(0, 1)
        splitter.setStretchFactor(1, 2)

        layout.addWidget(splitter, stretch=1)

    # ------------------------------------------------------------------
    # Carga / recarga de la capa
    # ------------------------------------------------------------------
    def close_and_release(self):
        """Desconecta esta ficha del GeoPackage de auditoría: cierra el
        diálogo de historial si está abierto, quita del proyecto QGIS la
        capa de auditoría, las capas de referencia (ANTES_ok/DESPUES_ok/
        ADIT_*) y la tabla de historial, y suelta las referencias Python
        (self.layer, self.audit_service) que mantienen sus datasources
        OGR abiertos -- para que el .gpkg quede libre en disco (mover,
        renombrar, borrar, copiar...) tras pulsar 'Cerrar'. Llamado por
        AudiNOTDockManager.on_click_close."""
        if self._historial_dialog is not None:
            try:
                self._historial_dialog.close()
            except Exception:
                pass
            self._historial_dialog = None

        if self.layer is not None:
            try:
                self.layer.selectionChanged.disconnect(self.on_layer_selection_changed)
            except (TypeError, RuntimeError):
                pass

        names = {AUDIT_LAYER_NAME, HISTORIAL_LAYER_NAME, "ANTES_ok", "DESPUES_ok"}
        to_remove = [
            lyr.id() for lyr in QgsProject.instance().mapLayers().values()
            if lyr.name() in names or lyr.name().startswith("ADIT_")
        ]
        if to_remove:
            QgsProject.instance().removeMapLayers(to_remove)

        self.layer = None
        self.audit_service = None
        self.current_feature_id = None
        self._id_by_row = []
        self._user_selected_row = False
        self._desact_detalle = ''
        self.list_widget.clear()
        self._update_list_count()
        self.lbl_progress.setText("Sin capa de auditoría cargada todavía.")

    def set_output_dir(self, output_dir, log_callback=None):
        """Llamado por el dock_manager tras EJECUTAR ANÁLISIS (o al
        detectar un GeoPackage de auditoría ya existente en esa
        carpeta al reabrir el proyecto)."""
        self.audit_service = AuditService(output_dir, log_callback)
        self.reload_layer()

    def set_output_dir_provider(self, fn):
        """Inyectado por AudiNOTDockManager: `fn()` debe devolver la
        "Carpeta de Salida" ACTUAL del campo de la Ficha "1: Datos
        Entrada" (una llamada, no un valor cacheado). Ver
        on_click_reload."""
        self._output_dir_provider = fn

    def on_click_reload(self):
        """Manejador del botón "↻ Recargar": antes de recargar nada,
        comprueba que la Ficha "1: Datos Entrada" tenga de verdad una
        "Carpeta de Salida" válida rellenada AHORA MISMO -- es ahí donde
        tiene que estar el GeoPackage de auditoría. Sin eso, el botón no
        hace nada (más allá de explicarlo), en vez de intentar recargar
        con lo que hubiera quedado cacheado de una sesión anterior."""
        output_dir = self._output_dir_provider() if self._output_dir_provider else None
        if not output_dir or not os.path.isdir(output_dir):
            QMessageBox.information(
                self, "AudiNOT",
                "Para recargar, primero indica una \"Carpeta de Salida\" válida en la "
                "Ficha \"1: Datos Entrada\" -- ahí es donde debe estar el GeoPackage de "
                "auditoría."
            )
            return
        self.reload_layer()

    def reload_layer(self):
        # Recarga completa: la fila que quede resaltada tras repoblar la
        # lista es la auto-seleccionada por Qt (primera fila), no una
        # elección real del usuario.
        self._user_selected_row = False

        if not self.audit_service:
            self.lbl_progress.setText("Sin capa de auditoría cargada todavía.")
            return

        with BusyCursor():
            self._reload_layer_body()

    def _reload_layer_body(self):
        # Si ya había una capa conectada (p.ej. recarga tras re-ejecutar el
        # análisis), se desconecta primero para no acumular conexiones
        # duplicadas de selectionChanged en la nueva capa.
        if self.layer is not None:
            try:
                self.layer.selectionChanged.disconnect(self.on_layer_selection_changed)
            except (TypeError, RuntimeError):
                pass

        self.layer = self.audit_service.load_layer(add_to_project=True)
        if not self.layer:
            self.lbl_progress.setText("No se encontró GeoPackage de auditoría en la carpeta de salida.")
            self.list_widget.clear()
            self._update_list_count()
            return

        # Capas de referencia complementarias (ANTES_ok, DESPUES_ok,
        # ADIT_*): viven en el MISMO GeoPackage que la capa de auditoría
        # (ver core/audit_service.py -> _write_reference_layers), así que
        # se cargan aquí también para que el usuario tenga todo el
        # contexto en el lienzo sin ir a buscar los shapefiles sueltos.
        # No aislado en su propio try/except aparte porque
        # load_reference_layers ya absorbe sus propios fallos por capa
        # (uno que falle no debe impedir ver el resto).
        self.audit_service.load_reference_layers(add_to_project=True)

        # Tabla de historial (AudiNOT_Historial): se añade también al
        # panel de Capas (como tabla, sin geometría) para que se pueda
        # consultar -y, si hace falta, editar a mano- desde QGIS, no
        # solo desde el diálogo "📜 Ver historial" del propio plugin.
        self.audit_service.load_historial_layer(add_to_project=True)

        # Al picar UN único recinto de esta capa en el lienzo de QGIS (con
        # la herramienta "Seleccionar features" y la capa de auditoría
        # activa), se auto-selecciona ese mismo recinto aquí y se carga su
        # ficha de detalle.
        self.layer.selectionChanged.connect(self.on_layer_selection_changed)

        self.apply_filter()
        self._update_progress_label()
        self.layerReady.emit()

    def on_layer_selection_changed(self, selected=None, deselected=None, clear_and_set=None):
        """Auto-selecciona en la lista de esta ficha el recinto picado en
        el lienzo, siempre que la selección sea de UN único recinto (con
        varios seleccionados no hay una ficha única que mostrar, así que
        se deja la selección de lista tal cual está)."""
        if self._syncing_selection or self.layer is None:
            return

        ids = self.layer.selectedFeatureIds()
        if len(ids) != 1:
            return

        fid = ids[0]
        if fid == self.current_feature_id:
            return

        try:
            row = self._id_by_row.index(fid)
        except ValueError:
            # El recinto picado no está en la lista con el filtro activo
            # actualmente (p.ej. es infraestructura fija, o no pasa algún
            # filtro puesto en esta ficha). No se cambia nada para no
            # confundir; el usuario puede quitar el filtro si quiere verlo.
            return

        self._syncing_selection = True
        try:
            self.list_widget.setCurrentRow(row)
        finally:
            self._syncing_selection = False

        # Picar un recinto en el lienzo es tan "elegirlo a propósito" como
        # hacer clic en la lista -- EXCEPTO cuando la selección la ha
        # disparado otra ficha (Ficha "5: Revisión" haciendo zoom desde su
        # propia lista, ver _suppress_activate_signal): ahí sí se resalta
        # la fila correspondiente en esta lista, pero no se debe robar el
        # foco a la Ficha "4: Auditoría".
        self._user_selected_row = True
        if not self._suppress_activate_signal:
            self.requestActivateTab.emit()

    def set_suppress_activate(self, value):
        """Inyectado por AudiNOTDockManager: permite a otra ficha (Ficha
        "5: Revisión") marcar que la selección que está a punto de hacer en
        la capa compartida es solo para zoom/resaltado, no una elección
        real del usuario en ESTA ficha -- así on_layer_selection_changed no
        dispara requestActivateTab mientras value sea True. Ver
        TabRevision._zoom_to."""
        self._suppress_activate_signal = bool(value)

    def on_filter_changed(self, *_args):
        """Wrapper al que se conectan los controles de filtro (en vez de
        conectarlos directamente a apply_filter): cambiar un filtro
        repuebla la lista y Qt auto-resalta su primera fila, pero eso no
        es una elección real del usuario, así que aquí se limpia
        _user_selected_row antes de refrescar (ver export_current_html)."""
        self._user_selected_row = False
        self.apply_filter()

    def _update_progress_label(self):
        if not self.layer:
            return
        c = AuditService.progress_counts(self.layer)
        self.lbl_progress.setText(
            f"Auditoría: {c['total']} fincas · "
            f"{c['pendientes']} sin revisar · "
            f"{c['si']} notifica · {c['no']} no notifica"
            + (f" · 👁 {c['revisar']} para revisar" if c['revisar'] else "")
            + (f" · ⚠ {c['desactualizadas']} desactualizadas" if c['desactualizadas'] else "")
        )

    # ------------------------------------------------------------------
    # Filtro y lista
    # ------------------------------------------------------------------
    def _build_expression(self):
        # Los recintos de infraestructura fija (VIALES/CURSOS AGUA/
        # EDIFICACIONES/EXCLUIDO, 'tipo_recinto' != 'PARCELA') están en el
        # GeoPackage/lienzo para que se vean, pero no son fincas a
        # revisar: no tienen titular, conclusión ni notificación, así que
        # se excluyen siempre de esta lista (NULL cubre una capa migrada
        # desde una versión anterior sin este campo, donde todo era
        # implícitamente 'PARCELA').
        parts = ["(tipo_recinto IS NULL OR tipo_recinto = 'PARCELA')"]

        rev = self.cmb_revision.currentText()
        if rev == "Sin revisar":
            parts.append("(revision_estado IS NULL OR revision_estado = '')")
        elif rev == "Revisar":
            parts.append("revision_estado = 'rev'")
        elif rev == "Notifica":
            parts.append("revision_estado = 'si'")
        elif rev == "No notifica":
            parts.append("revision_estado = 'no'")
        elif rev == "Desactualizadas":
            parts.append("revision_desactualizada = 1 AND revision_estado != ''")

        estado = self.cmb_estado.currentText()
        if estado == "Nueva (ALTA)":
            parts.append("estado = 'ALTA'")
        elif estado == "Desaparece (BAJA)":
            parts.append("estado = 'BAJA'")
        elif estado == "Persistente":
            parts.append("estado = 'PERSISTENTE'")

        notif = self.cmb_notif.currentText()
        if notif == "Paramétrica: notifica":
            parts.append("notifica_param = 1")
        elif notif == "Paramétrica: no notifica":
            parts.append("notifica_param = 0")
        elif notif == "Alternativa: notifica":
            parts.append("notifica_legal = 1")
        elif notif == "Alternativa: no notifica":
            parts.append("notifica_legal = 0")
        elif notif == "Divergen (paramétrica ≠ alternativa)":
            parts.append("notif_divergen = 1")
        elif notif == "Coinciden en notificar":
            parts.append("notifica_param = 1 AND notifica_legal = 1")

        if self.chk_titular_cambia.isChecked():
            parts.append("titular_cambia = 1")

        # --- Precisión T24 (supfT24 vs. superficie GRÁFICA real) ---
        # Misma lógica que ReportService._t24_filter_flags, expresada
        # como expresión QGIS sobre val_pct_a / val_pct_d / val_limite_pct
        # (ya calculados y guardados por finca).
        t24 = self.cmb_t24.currentText()
        valid_a_t24 = "(val_pct_a IS NOT NULL AND abs(val_pct_a) <= val_limite_pct)"
        invalid_a_t24 = "(val_pct_a IS NOT NULL AND abs(val_pct_a) > val_limite_pct)"
        valid_d_t24 = "(val_pct_d IS NOT NULL AND abs(val_pct_d) <= val_limite_pct)"
        invalid_d_t24 = "(val_pct_d IS NOT NULL AND abs(val_pct_d) > val_limite_pct)"
        unk_t24 = "(val_pct_a IS NULL OR val_pct_d IS NULL)"
        if t24 == "Fuera de tolerancia":
            parts.append(f"(NOT {unk_t24}) AND {invalid_d_t24}")
        elif t24 == "Empeora la precisión":
            parts.append(f"(NOT {unk_t24}) AND {valid_a_t24} AND {invalid_d_t24}")
        elif t24 == "Mejora la precisión":
            parts.append(f"(NOT {unk_t24}) AND {invalid_a_t24} AND {valid_d_t24}")
        elif t24 == "Sin dato de referencia":
            parts.append(unk_t24)

        # --- Validación GML (combina supfT24 vs. GRÁFICA y vs. GML) ---
        # Misma lógica que ReportService._validacion_filter_flags: "no
        # valida en Después" si falla cualquiera de los dos criterios.
        validacion = self.cmb_validacion.currentText()
        unk_val = "(val_pct_a IS NULL OR val_pct_d IS NULL OR val_pct_gml_d IS NULL)"
        valid_a_val = "(val_pct_a IS NOT NULL AND abs(val_pct_a) <= val_limite_pct)"
        invalid_after_val = "(val_gml_d_supera = 1 OR (val_pct_d IS NOT NULL AND abs(val_pct_d) > val_limite_pct))"
        valid_after_val = "(val_gml_d_supera = 0 AND val_pct_d IS NOT NULL AND abs(val_pct_d) <= val_limite_pct)"
        if validacion == "No valida en Después":
            parts.append(f"(NOT {unk_val}) AND {invalid_after_val}")
        elif validacion == "Antes validaba, después no":
            parts.append(f"(NOT {unk_val}) AND {valid_a_val} AND {invalid_after_val}")
        elif validacion == "Antes no validaba, después sí":
            parts.append(f"(NOT {unk_val}) AND (NOT {valid_a_val}) AND {valid_after_val}")

        text = self.txt_search.text().strip().replace("'", "''")
        if text:
            parts.append(f"(audinot_id ILIKE '%{text}%' OR titular_a ILIKE '%{text}%' OR titular_d ILIKE '%{text}%')")

        return " AND ".join(parts) if parts else ""

    def _is_filter_active(self):
        """True si algún control de filtro está en un valor distinto de
        su neutro ("Todas"/"Todos", casilla sin marcar, buscador vacío).
        No cuenta la exclusión fija de infraestructura (tipo_recinto),
        que siempre está aplicada de fondo y no es un filtro que el
        usuario haya elegido."""
        return (
            self.cmb_revision.currentText() != "Todas"
            or self.cmb_estado.currentText() != "Todos"
            or bool(self.txt_search.text().strip())
            or self.cmb_notif.currentText() != "Todas"
            or self.chk_titular_cambia.isChecked()
            or self.cmb_t24.currentText() != "Todas"
            or self.cmb_validacion.currentText() != "Todas"
        )

    @staticmethod
    def _audinot_id_sort_key(audinot_id):
        """Clave de ordenación NUMÉRICA y jerárquica para audinot_id
        (formato POL/MASA[-SUBMASA]/REC[-SUBREC], ver
        ShpService.enrich_layer): por Polígono, luego Masa, Submasa,
        Recinto y Subrecinto. Ordenar por el string tal cual (como
        hacía "addOrderBy('audinot_id')") trata "10" como anterior a
        "2"; aquí cada tramo se compara como número siempre que se
        pueda. Un recinto SIN submasa/subrecinto ordena inmediatamente
        antes que los que sí la tienen dentro de la misma masa/recinto
        (12/34/56 antes que 12/34/56-1), que es el orden lógico
        habitual en catastro."""
        def _num(token):
            try:
                return (0, float(token))
            except (TypeError, ValueError):
                return (1, token or '')

        aid = audinot_id or ''
        pol_part, _, rest = aid.partition('/')
        masa_part, _, rec_part = rest.partition('/')
        masa, _, submasa = masa_part.partition('-')
        rec, _, subrec = rec_part.partition('-')

        # "sin submasa/subrecinto" (0,) ordena SIEMPRE antes que
        # cualquier valor real (1, ...), sea cual sea ese valor.
        submasa_key = (0,) if submasa == '' else (1, _num(submasa))
        subrec_key = (0,) if subrec == '' else (1, _num(subrec))

        return (_num(pol_part), _num(masa), submasa_key, _num(rec), subrec_key)

    def apply_filter(self):
        if not self.layer:
            return
        self.list_widget.clear()
        self._id_by_row = []

        expr = self._build_expression()
        request = QgsFeatureRequest()
        if expr:
            request.setFilterExpression(expr)

        try:
            features = list(self.layer.getFeatures(request))
        except Exception:
            # Si ILIKE no está soportado por el proveedor, se reintenta sin filtro de texto
            features = list(self.layer.getFeatures())

        # Orden numérico lógico (Polígono/Masa-Submasa/Recinto-Subrecinto),
        # no alfabético: ver _audinot_id_sort_key.
        features.sort(key=lambda f: self._audinot_id_sort_key(f['audinot_id']))

        for f in features:
            estado = f['revision_estado'] or ''
            # Columna de iconos: 1) estado de revisión (semáforo
            # notificar/no notificar, o hueco en blanco si aún no hay
            # decisión final), 2) marca de observación (si tiene texto),
            # 3) hueco antes reservado en blanco, ahora usado para el
            # OJO que marca las fincas señaladas para que las revise
            # otro técnico ('rev'), y en blanco para el resto de
            # estados.
            icon_estado = "⬜" if estado in ('', 'rev') else ("🔴" if estado == 'si' else "🟢")
            icon_obs = "📝" if (f['revision_obs'] or '').strip() else "·"
            icon_reserved = "👁" if estado == 'rev' else "·"
            desact = " ⚠" if _safe_bool_field(f, 'revision_desactualizada') else ""
            no_presente = " ⛔" if _safe_bool_field(f, 'no_presente_ultimo_calculo') else ""
            item = QListWidgetItem(f"{icon_estado}{icon_obs}{icon_reserved} {f['audinot_id']}{desact}{no_presente}")
            estado_label = {
                '': 'Sin revisar', 'rev': 'Marcada para revisar',
                'si': 'Notifica', 'no': 'No notifica',
            }[estado]
            item.setToolTip(
                "Doble clic para alternar NOTIFICAR / NO NOTIFICAR.\n"
                f"Estado: {estado_label}"
                + ("\nTiene observación." if (f['revision_obs'] or '').strip() else "")
                + ("\n⛔ No apareció en el último cálculo." if _safe_bool_field(f, 'no_presente_ultimo_calculo') else "")
            )
            self.list_widget.addItem(item)
            self._id_by_row.append(f.id())

        self._update_progress_label()
        self._update_list_count()

    def _update_list_count(self):
        """Mantiene la etiqueta situada sobre la lista con el nº de
        elementos que muestra en cada momento (se llama al repoblar la
        lista en apply_filter, y también al vaciarla en reload_layer
        cuando no hay capa que cargar)."""
        n = self.list_widget.count()
        self.lbl_list_count.setText(f"{n} finca" if n == 1 else f"{n} fincas")

    # ------------------------------------------------------------------
    # Selección y detalle
    # ------------------------------------------------------------------
    def on_select_row(self, row):
        if row < 0 or row >= len(self._id_by_row):
            self.current_feature_id = None
            return
        self.current_feature_id = self._id_by_row[row]
        self._render_detail()

    def on_click_zoom(self, item):
        """Al hacer clic simple sobre un recinto de la lista (selección
        manual del usuario), hace zoom sobre él en el lienzo igual que el
        botón "Ver en el lienzo". Se conecta a itemClicked (no a
        currentRowChanged) porque esa señal solo se emite ante una
        interacción real del usuario con el ratón, y no cuando la fila
        actual cambia por otros motivos (recarga de la lista al aplicar
        un filtro, o sincronización al picar el recinto en el lienzo),
        evitando así zooms automáticos no deseados."""
        self._user_selected_row = True
        self.zoom_to_current()

    def _current_feature(self):
        if self.layer is None or self.current_feature_id is None:
            return None
        return self.layer.getFeature(self.current_feature_id)

    @staticmethod
    def _fmt_num(v):
        """Formatea un valor numérico de un campo de la capa, mostrando
        '?' cuando el campo es NULL. feat['campo'] devuelve el sentinel
        QVariant NULL de PyQGIS cuando el valor es nulo (p.ej. un recinto
        que ha desaparecido de ANTES a DESPUÉS y no tiene datos de
        "Después"), y ese objeto no es el None de Python, así que hay que
        comprobarlo explícitamente antes de formatear con ':g'."""
        if v is None or v == QGIS_NULL:
            return "?"
        try:
            return f"{v:g}"
        except (TypeError, ValueError):
            return str(v)

    @staticmethod
    def _render_t24_gml_line(feat):
        """Línea 'supfT24 / superficie GML / % validación' del panel de
        detalle, con el % de Después resaltado en naranja (error
        positivo: supfT24 > superficie GML) o morado (error negativo:
        supfT24 < superficie GML) cuando supera el umbral '% Validación'
        de la Ficha 3 (feat['val_gml_d_supera'], ya calculado); en verde
        cuando no lo supera; en gris si no hay dato."""
        _fmt = TabAudit._fmt_num

        def _pct_span(pct, supera, positivo):
            if pct is None or pct == QGIS_NULL:
                return '<span style="color:#888">?</span>'
            if not supera:
                color = "#27ae60"
            else:
                color = "#e67e22" if positivo else "#8e44ad"
            return f'<span style="color:{color}; font-weight:bold">{pct:+.2f}%</span>'

        val_pct_gml_d = feat['val_pct_gml_d']
        val_pct_gml_d = None if val_pct_gml_d == QGIS_NULL else val_pct_gml_d
        supera = bool(feat['val_gml_d_supera']) and feat['val_gml_d_supera'] != QGIS_NULL
        positivo = bool(val_pct_gml_d and val_pct_gml_d > 0)

        return (
            f"<b>supfT24:</b> {_fmt(feat['sup_t24_a'])} m² → {_fmt(feat['sup_t24_d'])} m² &nbsp;&nbsp; "
            f"<b>Superficie GML:</b> {_fmt(feat['sup_gml_a'])} m² → {_fmt(feat['sup_gml_d'])} m²<br>"
            f"<b>% Validación (T24 vs. gráfica):</b> {_pct_span(feat['val_pct_a'], False, False)} → "
            f"{_pct_span(feat['val_pct_d'], False, False)} &nbsp;&nbsp; "
            f"<b>% Validación GML (T24 vs. GML) Después:</b> {_pct_span(val_pct_gml_d, supera, positivo)}<br>"
        )

    # Traducción clase CSS → atributos de presentación SVG. Debe
    # mantenerse alineada con las reglas ".sketch-*" definidas en el
    # <style> del informe HTML (core/report_service.py, bloque de estilos
    # de _generate_report / búsqueda ".sketch-"), porque croquis_svg
    # reutiliza esas mismas clases. QSvgWidget (QtSvg) no interpreta hojas
    # de estilo CSS por clase de forma fiable, así que aquí se inyectan
    # como atributos fill/stroke/etc. directamente en cada elemento antes
    # de pasarlo al widget.
    _SKETCH_CSS = {
        'sketch-bg': 'fill="#fbfbfa" stroke="#dddddd" stroke-width="1"',
        'sketch-study-fill': 'fill="#f0f0f0" stroke="none"',
        'sketch-antes': 'fill="none" stroke="#2980b9" stroke-width="2" stroke-dasharray="6,4"',
        'sketch-despues': 'fill="none" stroke="#2c3e50" stroke-width="2.2"',
        'sketch-gained': 'fill="#0072B2" fill-opacity="0.45" stroke="#004C75" stroke-width="0.6"',
        'sketch-lost': 'fill="#E69F00" fill-opacity="0.45" stroke="#A66F00" stroke-width="0.6"',
        'sketch-context': 'fill="none" stroke="#bbbbbb" stroke-width="0.6"',
        # El patrón rayado real (edifHatch) puede no representarse en
        # QtSvg (igual que aditAlertHatch); se usa un relleno sólido
        # tenue como alternativa para distinguir igualmente las
        # EDIFICACIONES de contexto del resto de fincas/huecos.
        'sketch-context-edif': 'fill="#999999" fill-opacity="0.35" stroke="#777777" stroke-width="0.7"',
        'sketch-context-related': 'fill="none" stroke="#888888" stroke-width="1.1" stroke-dasharray="3,2"',
        'sketch-context-label': 'fill="#aaaaaa" font-size="8px" text-anchor="middle" dominant-baseline="middle"',
        'sketch-context-label-related': 'fill="#555555" font-size="8px" font-weight="bold" text-anchor="middle" dominant-baseline="middle"',
        'sketch-adit': 'fill="#4d4d4d" fill-opacity="0.30" stroke="#2b2b2b" stroke-width="0.8"',
        'sketch-adit-line': 'fill="none" stroke="#2b2b2b" stroke-width="1.4"',
        'sketch-adit-point': 'fill="#4d4d4d" stroke="#2b2b2b" stroke-width="0.6"',
        # El patrón rayado real (aditAlertHatch) puede no representarse en
        # QtSvg; se usa un relleno sólido aproximado como alternativa.
        'sketch-adit-alert': 'fill="#CC79A7" stroke="#000000" stroke-width="1.8"',
        'sketch-adit-line-alert': 'fill="none" stroke="#000000" stroke-width="2.4" stroke-dasharray="4,2"',
        'sketch-adit-point-alert': 'fill="#CC79A7" stroke="#000000" stroke-width="1.4"',
        'sketch-context-adit': 'fill="#bbbbbb" fill-opacity="0.25" stroke="#999999" stroke-width="0.5"',
        'sketch-context-adit-line': 'fill="none" stroke="#999999" stroke-width="0.9" stroke-dasharray="2,1.5"',
        'sketch-context-adit-point': 'fill="#bbbbbb" stroke="#999999" stroke-width="0.4"',
    }

    @classmethod
    def _extract_main_svg(cls, croquis_html):
        """croquis_svg (campo del GeoPackage) es en realidad el fragmento
        HTML completo que usa el informe: un <div class="sketch-section">
        con leyenda, escala gráfica y el <svg class="sketch-svg"> del
        dibujo propiamente dicho, todo ello coloreado por clases CSS que
        solo existen en el <style> del informe HTML. Aquí se extrae solo
        ese <svg> interior (el dibujo) y se le insertan como atributos de
        presentación los mismos colores/trazos que ya usa el informe,
        para poder mostrarlo en QSvgWidget sin depender de CSS externo."""
        if not croquis_html:
            return None
        m = re.search(r'<svg\b[^>]*class="sketch-svg".*?</svg>', croquis_html, re.DOTALL)
        if not m:
            return None
        svg = m.group(0)

        def _repl(match):
            cls_name = match.group(1)
            attrs = TabAudit._SKETCH_CSS.get(cls_name)
            return match.group(0) if not attrs else f'{match.group(0)} {attrs}'

        return re.sub(r'class="([\w-]+)"', _repl, svg)

    def _load_croquis(self, croquis_html):
        main_svg = self._extract_main_svg(croquis_html)
        if main_svg:
            self.svg_widget.load(bytearray(main_svg, encoding='utf-8'))
        else:
            self.svg_widget.load(bytearray('<svg xmlns="http://www.w3.org/2000/svg"></svg>', encoding='utf-8'))

    def _render_detail(self):
        feat = self._current_feature()
        if feat is None:
            return

        self.lbl_detail_title.setText(
            f"Finca {feat['audinot_id']}  —  {feat['estado']}"
        )

        self._load_croquis(feat['croquis_svg'] or '')

        param_txt = "SÍ" if feat['notifica_param'] else "NO"
        legal_txt = "SÍ" if feat['notifica_legal'] else "NO"
        diverge = " ⚠ (las dos interpretaciones no coinciden)" if feat['notif_divergen'] else ""

        _fmt = self._fmt_num
        titular_a = feat['titular_a'] if feat['titular_a'] not in (None, QGIS_NULL) else "?"
        titular_d = feat['titular_d'] if feat['titular_d'] not in (None, QGIS_NULL) else "?"

        self.lbl_metrics.setText(
            f"<b>Titular:</b> {titular_a} → {titular_d}<br>"
            f"<b>Superficie:</b> {_fmt(feat['sup_a'])} m² → {_fmt(feat['sup_d'])} m² "
            f"(Δ {_fmt(feat['var_sup'])} m², {_fmt(feat['var_sup_pct'])}%)<br>"
            f"<b>Perímetro Δ:</b> {_fmt(feat['var_perim'])} m<br>"
            f"<b>Partes:</b> {_fmt(feat['n_partes_a'])} → {_fmt(feat['n_partes_d'])}<br>"
            f"{self._render_t24_gml_line(feat)}"
            f"<b>Notifica (paramétrico):</b> {param_txt} &nbsp;&nbsp; "
            f"<b>Notifica (alternativo):</b> {legal_txt}{diverge}"
        )

        conclusion_html = ""
        if feat['conclusion_param']:
            conclusion_html += f"<p><b>⚠ Conclusión paramétrica:</b> {feat['conclusion_param']}</p>"
        if feat['conclusion_legal']:
            conclusion_html += f"<p><b>⚖ Conclusión alternativa:</b> {feat['conclusion_legal']}</p>"
        self.lbl_conclusion.setText(conclusion_html)

        # Estado de revisión actual
        estado = feat['revision_estado'] or ''
        self.rb_sin_revisar.setChecked(estado == '')
        self.rb_revisar.setChecked(estado == 'rev')
        self.rb_si.setChecked(estado == 'si')
        self.rb_no.setChecked(estado == 'no')
        self.txt_obs.setPlainText(feat['revision_obs'] or '')

        if _safe_bool_field(feat, 'revision_desactualizada'):
            detalle = ''
            if self.audit_service is not None:
                try:
                    detalle = self.audit_service.get_last_recalculo_detalle(feat['audinot_id'])
                except Exception:
                    detalle = ''

            # El mensaje completo ya no se imprime de forma permanente en
            # pantalla (antes lbl_desact_warning, con altura variable según
            # cuántos campos hubieran cambiado, empujaba a los
            # radiobuttons/observación/guardar fuera de la vista dentro del
            # mismo QSplitter). Ahora solo se guarda para _show_desact_warning
            # y se muestra bajo demanda al pulsar el icono ⚠ de la cabecera;
            # el detalle completo, sin límite de espacio, sigue disponible
            # también en "📜 Ver historial" (evento 'recalculo_metricas').
            self._desact_detalle = detalle
            self.btn_desact_warning.setVisible(True)
        else:
            self._desact_detalle = ''
            self.btn_desact_warning.setVisible(False)

        if _safe_bool_field(feat, 'no_presente_ultimo_calculo'):
            self.lbl_no_presente_warning.setText("⛔ Esta finca no apareció en el último cálculo.")
            self.lbl_no_presente_warning.setVisible(True)
        else:
            self.lbl_no_presente_warning.setVisible(False)

        self._refresh_historial_dialog()

    def _show_desact_warning(self):
        """Handler del icono ⚠ de la cabecera (ver __init__ y
        _render_detail): el mensaje completo aparece bajo demanda al
        pulsarlo, en vez de ocupar sitio fijo bajo "Revisión de esta
        ficha" como hacía antes lbl_desact_warning."""
        detalle = (self._desact_detalle or '').strip()
        mensaje = (
            "Las métricas de esta finca han cambiado desde la última revisión.\n"
            "Comprueba si tu decisión anterior sigue siendo válida."
        )
        if detalle:
            mensaje += f"\n\n{detalle}"
        mensaje += "\n\n(historial completo en \"📜 Ver historial\")."
        QMessageBox.warning(self, "AudiNOT", mensaje)

    # ------------------------------------------------------------------
    # Historial (AudiNOT_Historial) -- ventana no modal, sincronizada
    # ------------------------------------------------------------------
    def toggle_historial_dialog(self):
        """Abre la ventana de historial (o, si ya está abierta, la trae
        al frente) y la carga con la finca actualmente seleccionada. No
        modal a propósito: se puede dejar abierta en una esquina y seguir
        trabajando con el resto de la Ficha 4 -- cada cambio de selección
        la refresca sola (ver _render_detail -> _refresh_historial_dialog)."""
        if self._historial_dialog is None:
            self._historial_dialog = HistorialDialog(self)
        self._historial_dialog.show()
        self._historial_dialog.raise_()
        self._historial_dialog.activateWindow()
        self._refresh_historial_dialog()

    def _refresh_historial_dialog(self):
        """Si la ventana de historial está abierta, la actualiza con la
        finca actualmente seleccionada. Sin efecto si está cerrada (no
        se crea la ventana solo para refrescarla)."""
        if self._historial_dialog is None or not self._historial_dialog.isVisible():
            return

        feat = self._current_feature()
        if feat is None or self.audit_service is None:
            self._historial_dialog.show_empty()
            return

        try:
            entries = self.audit_service.get_historial_for_finca(feat['audinot_id'])
        except Exception as e:
            self._historial_dialog.show_error(str(e))
            return

        self._historial_dialog.set_entries(feat['audinot_id'], entries)

    # ------------------------------------------------------------------
    # Guardar revisión
    # ------------------------------------------------------------------
    def save_current_review(self):
        if self.current_feature_id is None or self.layer is None:
            QMessageBox.warning(self, "AudiNOT", "Selecciona primero una finca de la lista.")
            return

        if self.rb_si.isChecked():
            estado = 'si'
        elif self.rb_no.isChecked():
            estado = 'no'
        elif self.rb_revisar.isChecked():
            estado = 'rev'
        else:
            estado = ''

        observacion = self.txt_obs.toPlainText()

        # Regla de negocio: una OBSERVACIÓN por sí sola, sin que el
        # usuario haya marcado alguna decisión (NOTIFICAR / NO
        # NOTIFICAR / REVISAR), no se puede grabar (dejaría una finca
        # con anotación pero sin decisión trazable). Si en cambio SÍ se
        # marca alguna de las tres, la observación puede ir en blanco
        # perfectamente.
        if estado == '' and observacion.strip():
            QMessageBox.warning(
                self, "AudiNOT",
                "Has escrito una observación pero no has marcado NOTIFICAR, NO NOTIFICAR ni REVISAR.\n\n"
                "Indica una de esas decisiones para poder guardar (o borra la observación "
                "si de verdad quieres dejar esta finca sin revisar)."
            )
            return

        try:
            self.audit_service.save_review_with_history(
                self.layer, self.current_feature_id, estado, observacion, origen='panel'
            )
        except Exception as e:
            QMessageBox.critical(self, "AudiNOT", f"No se pudo guardar la revisión:\n{e}")
            return

        self.apply_filter()
        # Re-seleccionar la misma finca tras refrescar la lista
        try:
            row = self._id_by_row.index(self.current_feature_id)
            self.list_widget.setCurrentRow(row)
        except ValueError:
            pass

    # ------------------------------------------------------------------
    # Doble clic en la lista: alterna NOTIFICAR <-> NO NOTIFICAR
    # ------------------------------------------------------------------
    def on_double_click_toggle(self, item):
        """Doble clic sobre una finca de la lista:
          - Sin revisar / Revisar -> pasa a NOTIFICAR.
          - Marcada (si/no)       -> se invierte (si -> no, no -> si).
        En cualquiera de los dos casos que SÍ cambian el estado (es
        decir, siempre, porque "sin revisar" también es un cambio), se
        borra la observación existente: una observación escrita para
        justificar una decisión concreta deja de tener sentido en cuanto
        esa decisión se invierte o se sustituye sin que el usuario la
        haya revisado a propósito desde el panel de la derecha."""
        row = self.list_widget.row(item)
        if row < 0 or row >= len(self._id_by_row):
            return
        fid = self._id_by_row[row]
        if self.layer is None:
            return

        feat = self.layer.getFeature(fid)
        estado_actual = feat['revision_estado'] or ''
        estado_nuevo = 'si' if estado_actual != 'si' else 'no'
        etiqueta_actual = {
            'si': 'NOTIFICAR', 'no': 'NO NOTIFICAR',
            'rev': '👁 Revisar', '': 'Sin revisar',
        }[estado_actual]
        etiqueta_nueva = {'si': 'NOTIFICAR', 'no': 'NO NOTIFICAR'}[estado_nuevo]

        tenia_obs = bool((feat['revision_obs'] or '').strip())
        aviso_obs = "\n\nSe borrará la observación actual." if tenia_obs else ""

        resp = QMessageBox.question(
            self, "AudiNOT",
            f"Finca {feat['audinot_id']}\n\n"
            f"Estado actual: {etiqueta_actual}\n"
            f"¿Cambiar a: {etiqueta_nueva}?{aviso_obs}",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes
        )
        if resp != QMessageBox.Yes:
            return

        try:
            self.audit_service.save_review_with_history(self.layer, fid, estado_nuevo, '', origen='doble_clic')
        except Exception as e:
            QMessageBox.critical(self, "AudiNOT", f"No se pudo guardar el cambio:\n{e}")
            return

        self.apply_filter()
        try:
            new_row = self._id_by_row.index(fid)
            self.list_widget.setCurrentRow(new_row)
        except ValueError:
            pass

    # ------------------------------------------------------------------
    # Exportar ficha HTML del recinto seleccionado
    # ------------------------------------------------------------------
    def _choose_export_dir(self):
        """Pide al usuario la carpeta de destino para las fichas HTML
        (exportación individual o en bloque). Devuelve la ruta elegida,
        o None si el usuario cancela el diálogo o la ruta no resulta
        válida -- en ambos casos, quien llame a esto debe abortar toda
        la exportación sin generar ninguna ficha."""
        default_dir = self.audit_service.output_dir if self.audit_service else ""
        if not default_dir or not os.path.isdir(default_dir):
            default_dir = os.path.expanduser("~")

        out_dir = QFileDialog.getExistingDirectory(
            self, "Selecciona la carpeta de destino para las fichas", default_dir
        )
        if not out_dir:
            return None  # el usuario ha cancelado el diálogo

        if not os.path.isdir(out_dir) or not os.access(out_dir, os.W_OK):
            QMessageBox.critical(
                self, "AudiNOT",
                f"No se puede escribir en la carpeta elegida:\n{out_dir}\n\n"
                "Se cancela la exportación."
            )
            return None

        return out_dir

    def export_current_html(self):
        """Botón "📤 HTML". Comportamiento:

        - Sin filtro aplicado: exporta únicamente la finca elegida a
          propósito por el usuario (clic en la lista o pick en el
          lienzo); si no ha elegido ninguna, avisa y no hace nada.
        - Con filtro aplicado y una finca elegida: pregunta si se quiere
          exportar solo esa finca o el bloque entero de fincas que pasa
          el filtro actual.
        - Con filtro aplicado y ninguna finca elegida a propósito:
          avisa de cuántas fichas (N = resultado del filtro) se van a
          generar y pide confirmación antes de procesar el bloque.

        Así, aplicar un filtro y pulsar el botón directamente (sin tocar
        la lista) permite procesar de golpe todas las fichas de ese
        filtro."""
        if self.layer is None or self.audit_service is None:
            QMessageBox.warning(self, "AudiNOT", "No hay ninguna capa de auditoría cargada.")
            return

        out_dir = self._choose_export_dir()
        if out_dir is None:
            return  # cancelado o ruta inválida: no se genera ninguna ficha

        total_filtrados = len(self._id_by_row)
        filtro_activo = self._is_filter_active()
        hay_seleccion = self._user_selected_row and self.current_feature_id is not None

        if not filtro_activo:
            if not hay_seleccion:
                QMessageBox.warning(
                    self, "AudiNOT",
                    "Selecciona primero una finca de la lista (con un clic) para exportar su ficha."
                )
                return
            self._export_single_html(self.current_feature_id, out_dir, offer_open=True)
            return

        if hay_seleccion:
            box = QMessageBox(self)
            box.setWindowTitle("AudiNOT")
            box.setIcon(QMessageBox.Question)
            box.setText(
                f"Hay un filtro aplicado ({total_filtrados} recintos) y una finca seleccionada.\n\n"
                "¿Qué quieres exportar?"
            )
            btn_todas = box.addButton(f"Las {total_filtrados} del filtro", QMessageBox.AcceptRole)
            btn_sel = box.addButton("Solo la seleccionada", QMessageBox.AcceptRole)
            box.addButton("Cancelar", QMessageBox.RejectRole)
            box.setDefaultButton(btn_sel)
            box.exec_()
            clicked = box.clickedButton()
            if clicked is btn_todas:
                self._export_bulk_html(list(self._id_by_row), out_dir)
            elif clicked is btn_sel:
                self._export_single_html(self.current_feature_id, out_dir, offer_open=True)
            return

        # Filtro aplicado, sin finca elegida a propósito: exportar el bloque.
        if total_filtrados == 0:
            QMessageBox.information(self, "AudiNOT", "El filtro actual no tiene ningún recinto.")
            return
        resp = QMessageBox.question(
            self, "AudiNOT",
            f"Se van a generar {total_filtrados} fichas, correspondientes al resultado "
            "del filtro actual.\n\n¿Continuar?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        if resp == QMessageBox.Yes:
            self._export_bulk_html(list(self._id_by_row), out_dir)

    def _write_parcel_html(self, feat, out_dir):
        """Genera y guarda en disco la ficha HTML de UNA finca. Devuelve
        (ok, out_path, error)."""
        raw_json = feat['audinot_json'] or '{}'
        try:
            audinot_json = json.loads(raw_json) if raw_json else {}
        except (TypeError, ValueError):
            audinot_json = {}

        attrs = {name: feat[name] for name in self.layer.fields().names() if name.lower() != 'fid'}

        report_service = ReportService(self.audit_service.output_dir)
        try:
            html = report_service.generate_parcel_card_html(attrs, audinot_json)
        except Exception as e:
            return False, None, str(e)

        filename = ReportService.parcel_export_filename(feat['audinot_id'])
        out_path = os.path.join(out_dir, filename)
        try:
            with open(out_path, 'w', encoding='utf-8') as f:
                f.write(html)
        except Exception as e:
            return False, None, str(e)

        return True, out_path, None

    def _export_single_html(self, fid, out_dir, offer_open=False):
        feat = self.layer.getFeature(fid)
        if feat is None:
            return
        with BusyCursor():
            ok, out_path, err = self._write_parcel_html(feat, out_dir)
        if not ok:
            QMessageBox.critical(self, "AudiNOT", f"No se pudo generar la ficha HTML:\n{err}")
            return

        if offer_open:
            resp = QMessageBox.information(
                self, "AudiNOT",
                f"Ficha guardada en:\n{out_path}\n\n¿Abrirla ahora?",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes
            )
            if resp == QMessageBox.Yes:
                QDesktopServices.openUrl(QUrl.fromLocalFile(out_path))

    def _export_bulk_html(self, fids, out_dir):
        """Genera la ficha HTML de cada finca de `fids` (bloque
        completo, p.ej. el resultado de un filtro)."""
        if not fids:
            return

        total = len(fids)
        self.progress_bar.setRange(0, total)
        self.progress_bar.setValue(0)
        self.progress_bar.setFormat("Exportando %v/%m")
        self.progress_bar.setVisible(True)
        QApplication.setOverrideCursor(Qt.WaitCursor)
        ok_count = 0
        errores = []
        try:
            for i, fid in enumerate(fids, start=1):
                feat = self.layer.getFeature(fid)
                if feat is not None:
                    ok, _out_path, err = self._write_parcel_html(feat, out_dir)
                    if ok:
                        ok_count += 1
                    else:
                        errores.append(f"{feat['audinot_id']}: {err}")
                self.progress_bar.setValue(i)
                # Refresca la UI (barra + resto del dock) en cada
                # iteración para que la barra avance de verdad y la
                # ventana no parezca congelada durante el bloque.
                QApplication.processEvents()
        finally:
            QApplication.restoreOverrideCursor()
            self.progress_bar.setVisible(False)

        msg = f"Se han exportado {ok_count} de {len(fids)} fichas en:\n{out_dir}"
        if errores:
            detalle = "\n".join(errores[:10])
            if len(errores) > 10:
                detalle += f"\n… y {len(errores) - 10} más."
            msg += f"\n\n⚠ Hubo {len(errores)} error(es):\n{detalle}"

        resp = QMessageBox.information(
            self, "AudiNOT", msg + "\n\n¿Abrir la carpeta de resultados?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes
        )
        if resp == QMessageBox.Yes:
            QDesktopServices.openUrl(QUrl.fromLocalFile(out_dir))

    # ------------------------------------------------------------------
    # Vista previa de métricas (botón "📊 Vista previa de métricas").
    #
    # A diferencia de "Exportar ficha HTML" (📤 HTML), opera
    # SOLO sobre la finca seleccionada en pantalla (sin modo masivo/
    # filtro, sin diálogo para elegir carpeta): genera un HTML temporal
    # con la sección de métricas (MÉTRICAS GEOMÉTRICAS, FACHADAS, HUECOS/
    # ISLAS, DINÁMICA TERRITORIAL, ADITAMENTOS y conclusiones -- ver
    # ReportService.render_parcel_metrics_preview) y lo abre directamente
    # en el navegador del sistema. Nada se guarda en la carpeta de
    # RESULTADO: el fichero vive solo en la carpeta temporal del sistema.
    # ------------------------------------------------------------------
    def preview_current_metrics(self):
        if self.layer is None or self.audit_service is None:
            QMessageBox.warning(self, "AudiNOT", "No hay ninguna capa de auditoría cargada.")
            return

        hay_seleccion = self._user_selected_row and self.current_feature_id is not None
        if not hay_seleccion:
            QMessageBox.warning(
                self, "AudiNOT",
                "Selecciona primero una finca de la lista (con un clic) para generar su vista previa."
            )
            return

        feat = self._current_feature()
        if feat is None:
            return

        raw_json = feat['audinot_json'] or '{}'
        try:
            audinot_json = json.loads(raw_json) if raw_json else {}
        except (TypeError, ValueError):
            audinot_json = {}

        attrs = {name: feat[name] for name in self.layer.fields().names() if name.lower() != 'fid'}

        try:
            params = self.audit_service.read_parameters() or {}
            thresholds = params.get('thresholds')
            special_ranges = params.get('ranges')
            special_owners = params.get('special_owners')

            with BusyCursor():
                report_service = ReportService(self.audit_service.output_dir)
                html = report_service.render_parcel_metrics_preview(
                    attrs, audinot_json, croquis_html=feat['croquis_svg'] or '',
                    thresholds=thresholds, special_ranges=special_ranges, special_owners=special_owners
                )
                safe_id = re.sub(r'[^A-Za-z0-9_-]+', '_', str(feat['audinot_id']))
                fd, tmp_path = tempfile.mkstemp(
                    prefix=f"audinot_metricas_{safe_id}_", suffix=".html"
                )
                with os.fdopen(fd, 'w', encoding='utf-8') as f:
                    f.write(html)

            QDesktopServices.openUrl(QUrl.fromLocalFile(tmp_path))
        except Exception as e:
            QMessageBox.critical(self, "AudiNOT", f"No se pudo generar la vista previa de métricas:\n{e}")

    # ------------------------------------------------------------------
    # Zoom al lienzo
    # ------------------------------------------------------------------
    def zoom_to_current(self):
        feat = self._current_feature()
        if feat is None or self.layer is None:
            return
        geom = feat.geometry()
        if geom is None or geom.isEmpty():
            QMessageBox.information(self, "AudiNOT", "Esta finca no tiene geometría para hacer zoom.")
            return
        canvas = self.iface.mapCanvas()
        rect = geom.boundingBox()
        rect.scale(1.3)
        canvas.setExtent(rect)
        canvas.refresh()

        self._syncing_selection = True
        try:
            self.layer.removeSelection()
            self.layer.select(feat.id())
        finally:
            self._syncing_selection = False
        try:
            canvas.flashFeatureIds(self.layer, [feat.id()])
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Acciones masivas sobre TODAS las fincas de la lista
    # ------------------------------------------------------------------
    def _refresh_after_bulk_change(self):
        """Refresca lista, contador de cabecera y (si sigue existiendo)
        el panel de detalle de la finca seleccionada, tras una acción
        masiva que puede haber cambiado el estado de muchas fincas a la
        vez."""
        fid = self.current_feature_id
        self.apply_filter()
        self._update_progress_label()
        if fid is not None:
            try:
                row = self._id_by_row.index(fid)
                self.list_widget.setCurrentRow(row)
            except ValueError:
                pass

    def bulk_mark_pending_no_notificar(self):
        if self.layer is None:
            QMessageBox.warning(self, "AudiNOT", "No hay ninguna capa de auditoría cargada.")
            return

        pendientes = AuditService.progress_counts(self.layer)['pendientes']
        if pendientes == 0:
            QMessageBox.information(self, "AudiNOT", "No queda ninguna finca 'Sin revisar'.")
            return

        resp1 = QMessageBox.question(
            self, "AudiNOT",
            f"Hay {pendientes} finca(s) todavía 'Sin revisar'.\n\n"
            "¿Quieres marcarlas TODAS como NO NOTIFICAR? Se les añadirá "
            "automáticamente una observación indicando que la revisión fue "
            "automática. Las fincas que ya tengan una decisión tomada NO se "
            "tocan.",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        if resp1 != QMessageBox.Yes:
            return

        resp2 = QMessageBox.warning(
            self, "AudiNOT",
            "Este cambio es irreversible. ¿Continuamos?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        if resp2 != QMessageBox.Yes:
            return

        observacion = (
            f"Revisado automáticamente como NO NOTIFICAR el "
            f"{datetime.now().strftime('%d/%m/%Y %H:%M')} (acción masiva sobre "
            f"fincas pendientes)."
        )
        try:
            n = self.audit_service.bulk_mark_pending_no_notificar(self.layer, observacion)
        except Exception as e:
            QMessageBox.critical(self, "AudiNOT", f"No se pudo completar la acción:\n{e}")
            return

        self._refresh_after_bulk_change()
        QMessageBox.information(self, "AudiNOT", f"Se han marcado {n} finca(s) como NO NOTIFICAR.")

    def bulk_reset_all_to_sin_revisar(self):
        if self.layer is None:
            QMessageBox.warning(self, "AudiNOT", "No hay ninguna capa de auditoría cargada.")
            return

        resp1 = QMessageBox.question(
            self, "AudiNOT",
            "¿Quieres poner TODAS las fincas en estado 'Sin revisar'?\n\n"
            "Esto borrará TODAS las decisiones (NOTIFICAR / NO NOTIFICAR) y "
            "TODAS las observaciones guardadas hasta ahora, en todas las "
            "fincas de la lista.",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        if resp1 != QMessageBox.Yes:
            return

        resp2 = QMessageBox.warning(
            self, "AudiNOT",
            "Este cambio es irreversible. ¿Continuamos?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        if resp2 != QMessageBox.Yes:
            return

        try:
            n = self.audit_service.bulk_reset_all_to_sin_revisar(self.layer)
        except Exception as e:
            QMessageBox.critical(self, "AudiNOT", f"No se pudo completar la acción:\n{e}")
            return

        self._refresh_after_bulk_change()
        QMessageBox.information(self, "AudiNOT", f"Se han puesto {n} finca(s) en estado 'Sin revisar'.")

    def bulk_verify_desactualizadas(self):
        if self.layer is None:
            QMessageBox.warning(self, "AudiNOT", "No hay ninguna capa de auditoría cargada.")
            return

        desact = AuditService.progress_counts(self.layer)['desactualizadas']
        if desact == 0:
            QMessageBox.information(self, "AudiNOT", "No hay ninguna finca marcada como 'desactualizada'.")
            return

        resp = QMessageBox.question(
            self, "AudiNOT",
            f"Hay {desact} finca(s) marcadas como 'desactualizada' (su decisión "
            "ya tomada no se corresponde con los datos actuales tras un "
            "recálculo).\n\n"
            "¿Quieres darlas TODAS por verificadas? Se retirará el aviso ⚠ "
            "de 'desactualizada' SIN tocar la decisión (NOTIFICAR / NO "
            "NOTIFICAR / A REVISAR) ni la observación ya guardadas en cada "
            "una.",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        if resp != QMessageBox.Yes:
            return

        try:
            n = self.audit_service.bulk_verify_desactualizadas(self.layer)
        except Exception as e:
            QMessageBox.critical(self, "AudiNOT", f"No se pudo completar la acción:\n{e}")
            return

        self._refresh_after_bulk_change()
        QMessageBox.information(self, "AudiNOT", f"Se han verificado {n} finca(s) (aviso de 'desactualizada' retirado).")
