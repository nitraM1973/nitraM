import json
import os
import re
from datetime import datetime

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QComboBox,
    QListWidget, QListWidgetItem, QSplitter, QGroupBox, QTextEdit,
    QButtonGroup, QRadioButton, QLineEdit, QScrollArea, QMessageBox,
    QCheckBox
)
from PyQt5.QtCore import Qt, pyqtSignal, QRectF, QSize, QUrl
from PyQt5.QtGui import QPainter, QDesktopServices
from PyQt5.QtSvg import QSvgWidget

from qgis.core import QgsFeatureRequest, NULL as QGIS_NULL

from ...core.audit_service import AuditService
from ...core.report_service import ReportService


class AspectRatioSvgWidget(QSvgWidget):
    """QSvgWidget "de fábrica" ignora la proporción (ancho/alto) del
    <svg> y lo estira para rellenar todo el widget (su paintEvent llama
    a renderer().render(painter) sin pasarle un rectángulo destino, así
    que Qt usa directamente los bordes del widget). Eso es lo que
    deforma el croquis horizontalmente cada vez que el usuario cambia
    el ancho del dock.

    Aquí se sobreescribe paintEvent para calcular, a partir del
    viewBox del SVG, el rectángulo más grande que cabe en el widget
    manteniendo la proporción original (equivalente a
    Qt.KeepAspectRatio), centrado dejando marco en blanco a los lados
    o arriba/abajo según haga falta. Así el croquis se ve siempre
    proporcionado, sea cual sea el ancho que el usuario le dé al dock.

    Además se sobreescriben sizeHint/minimumSizeHint: QSvgWidget, por
    defecto, las calcula a partir del tamaño NATIVO del SVG (el
    croquis se genera a 560x380px, ver report_service.py), y ese ancho
    de 560px es justo lo que obligaba a la QScrollArea que envuelve
    este widget a ensancharse por encima del dock y mostrar un scroll
    horizontal en cuanto el dock bajaba de ese ancho. Como el
    paintEvent de aquí arriba ya sabe encajar el dibujo en cualquier
    tamaño (con su propio letterboxing), no hace falta ese mínimo: el
    widget puede anunciar un tamaño pequeño y dejar que el layout lo
    estire tanto como haya sitio."""

    def sizeHint(self):
        return QSize(320, 260)

    def minimumSizeHint(self):
        return QSize(120, self.minimumHeight() or 120)

    def paintEvent(self, event):
        renderer = self.renderer()
        if renderer is None or not renderer.isValid():
            return

        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        target = QRectF(self.rect())
        view_box = renderer.viewBoxF()
        if view_box.width() <= 0 or view_box.height() <= 0 or target.height() <= 0:
            renderer.render(painter, target)
            return

        svg_ratio = view_box.width() / view_box.height()
        target_ratio = target.width() / target.height()

        if target_ratio > svg_ratio:
            # El widget es proporcionalmente más ancho que el croquis:
            # se limita el ancho del dibujo y se centra horizontalmente.
            w = target.height() * svg_ratio
            draw_rect = QRectF(target.x() + (target.width() - w) / 2, target.y(), w, target.height())
        else:
            # El widget es proporcionalmente más alto: se limita la
            # altura del dibujo y se centra verticalmente.
            h = target.width() / svg_ratio
            draw_rect = QRectF(target.x(), target.y() + (target.height() - h) / 2, target.width(), h)

        renderer.render(painter, draw_rect)


class TabAudit(QWidget):
    """
    Ficha "4: Auditoría".

    Es un módulo NUEVO y AISLADO: solo depende de core/audit_service.py
    (que a su vez lee lo ya calculado por ReportService). No modifica
    ni depende de tab_inputs / tab_mapping / tab_thresholds, así que
    todo lo demás del plugin sigue funcionando exactamente igual si
    esta ficha no se usa.
    """

    layerReady = pyqtSignal()
    # Emitida cuando, al picar en el lienzo, se auto-selecciona un recinto
    # en esta ficha (ver on_canvas_selection_changed): el dock_manager la
    # usa para cambiar automáticamente a esta pestaña.
    requestActivateTab = pyqtSignal()

    def __init__(self, iface):
        super().__init__()
        self.iface = iface
        self.audit_service = None
        self.layer = None
        self.current_feature_id = None
        self._id_by_row = []
        # Evita el bucle de señales cuando esta misma ficha selecciona una
        # feature en la capa (zoom_to_current, guardar revisión...): esa
        # selección programática no debe volver a auto-seleccionar nada.
        self._syncing_selection = False
        self.init_ui()

    # ------------------------------------------------------------------
    # UI
    # ------------------------------------------------------------------
    def init_ui(self):
        layout = QVBoxLayout(self)

        # --- Cabecera: progreso "de un vistazo" ---
        header = QHBoxLayout()
        self.lbl_progress = QLabel("Sin capa de auditoría cargada todavía.")
        self.lbl_progress.setStyleSheet("font-weight:bold; color:#2c3e50;")
        header.addWidget(self.lbl_progress)
        header.addStretch()
        self.btn_reload = QPushButton("↻ Recargar")
        self.btn_reload.setToolTip("Vuelve a leer el estado actual del GeoPackage de auditoría (por si se editó desde la tabla de atributos)")
        self.btn_reload.clicked.connect(self.reload_layer)
        header.addWidget(self.btn_reload)
        layout.addLayout(header)

        # --- Filtro ---
        # Los mismos criterios que ya ofrecen las facetas del informe HTML
        # (sidebar "Filtros" del informe): Estado, Notificación, Titular,
        # Precisión T24 y Validación GML. Se reparten en dos filas para
        # que quepan sin abrumar.
        filter_group = QGroupBox("Filtro")
        filter_v = QVBoxLayout()

        row1 = QHBoxLayout()
        row1.addWidget(QLabel("Revisión:"))
        self.cmb_revision = QComboBox()
        self.cmb_revision.addItems(["Todas", "Sin revisar", "Notifica", "No notifica", "Desactualizadas"])
        self.cmb_revision.setToolTip("Estado de LA REVISIÓN HUMANA de esta ficha (equivalente a la faceta 'Usuario' del informe).")
        self.cmb_revision.currentIndexChanged.connect(self.apply_filter)
        row1.addWidget(self.cmb_revision)

        row1.addWidget(QLabel("Estado:"))
        self.cmb_estado = QComboBox()
        self.cmb_estado.addItems(["Todos", "Nueva (ALTA)", "Desaparece (BAJA)", "Persistente"])
        self.cmb_estado.setToolTip("Equivalente a la faceta 'Estado' del informe HTML.")
        self.cmb_estado.currentIndexChanged.connect(self.apply_filter)
        row1.addWidget(self.cmb_estado)

        row1.addWidget(QLabel("Buscar:"))
        self.txt_search = QLineEdit()
        self.txt_search.setPlaceholderText("ID de finca o titular…")
        self.txt_search.textChanged.connect(self.apply_filter)
        row1.addWidget(self.txt_search)
        filter_v.addLayout(row1)

        row2 = QHBoxLayout()
        row2.addWidget(QLabel("Notificación:"))
        self.cmb_notif = QComboBox()
        self.cmb_notif.addItems([
            "Todas",
            "Paramétrica: notifica", "Paramétrica: no notifica",
            "Alternativa: notifica", "Alternativa: no notifica",
            "Divergen (paramétrica ≠ alternativa)",
            "Coinciden en notificar",
        ])
        self.cmb_notif.setToolTip("Equivalente a la faceta 'Notificación' del informe HTML.")
        self.cmb_notif.currentIndexChanged.connect(self.apply_filter)
        row2.addWidget(self.cmb_notif)

        self.chk_titular_cambia = QCheckBox("Cambia titular")
        self.chk_titular_cambia.setToolTip("Equivalente a la faceta 'Titular → Cambio de titular' del informe HTML.")
        self.chk_titular_cambia.stateChanged.connect(self.apply_filter)
        row2.addWidget(self.chk_titular_cambia)
        filter_v.addLayout(row2)

        row3 = QHBoxLayout()
        row3.addWidget(QLabel("Precisión T24:"))
        self.cmb_t24 = QComboBox()
        self.cmb_t24.addItems([
            "Todas", "Fuera de tolerancia", "Empeora la precisión",
            "Mejora la precisión", "Sin dato de referencia",
        ])
        self.cmb_t24.setToolTip(
            "Compara supfT24 vs. superficie GRÁFICA real (equivalente a la faceta "
            "'Precisión de superficie' del informe HTML)."
        )
        self.cmb_t24.currentIndexChanged.connect(self.apply_filter)
        row3.addWidget(self.cmb_t24)

        row3.addWidget(QLabel("Validación GML:"))
        self.cmb_validacion = QComboBox()
        self.cmb_validacion.addItems([
            "Todas", "No valida en Después", "Antes validaba, después no",
            "Antes no validaba, después sí",
        ])
        self.cmb_validacion.setToolTip(
            "Combina supfT24 vs. GRÁFICA y vs. GML (equivalente a la faceta "
            "'Validación' del informe HTML): 'no valida' si falla cualquiera de las dos."
        )
        self.cmb_validacion.currentIndexChanged.connect(self.apply_filter)
        row3.addWidget(self.cmb_validacion)
        filter_v.addLayout(row3)

        filter_group.setLayout(filter_v)
        layout.addWidget(filter_group)

        # --- Maestro-detalle ---
        splitter = QSplitter(Qt.Horizontal)

        list_container = QWidget()
        list_v = QVBoxLayout(list_container)
        list_v.setContentsMargins(0, 0, 0, 0)

        bulk_row = QHBoxLayout()
        self.btn_bulk_no_notificar = QPushButton("🚫")
        self.btn_bulk_no_notificar.setFixedWidth(34)
        self.btn_bulk_no_notificar.setToolTip(
            "Pendientes → NO NOTIFICAR\n\n"
            "Marca automáticamente como NO NOTIFICAR todas las fincas que\n"
            "todavía están 'Sin revisar'. No toca las que ya tengan una\n"
            "decisión tomada."
        )
        self.btn_bulk_no_notificar.clicked.connect(self.bulk_mark_pending_no_notificar)
        bulk_row.addWidget(self.btn_bulk_no_notificar)

        self.btn_bulk_reset = QPushButton("♻️")
        self.btn_bulk_reset.setFixedWidth(34)
        self.btn_bulk_reset.setToolTip(
            "Todo → Sin revisar\n\n"
            "Pone TODAS las fincas en estado 'Sin revisar', borrando\n"
            "también todas las observaciones guardadas."
        )
        self.btn_bulk_reset.clicked.connect(self.bulk_reset_all_to_sin_revisar)
        bulk_row.addWidget(self.btn_bulk_reset)
        bulk_row.addStretch()
        list_v.addLayout(bulk_row)

        self.list_widget = QListWidget()
        self.list_widget.setMinimumWidth(180)
        self.list_widget.currentRowChanged.connect(self.on_select_row)
        self.list_widget.itemDoubleClicked.connect(self.on_double_click_toggle)
        list_v.addWidget(self.list_widget)

        splitter.addWidget(list_container)

        detail_scroll = QScrollArea()
        detail_scroll.setWidgetResizable(True)
        detail_content = QWidget()
        detail_layout = QVBoxLayout(detail_content)

        self.lbl_detail_title = QLabel("Selecciona una finca de la lista")
        self.lbl_detail_title.setStyleSheet("font-size:14px; font-weight:bold; color:#2c3e50;")
        detail_layout.addWidget(self.lbl_detail_title)

        self.svg_widget = AspectRatioSvgWidget()
        self.svg_widget.setMinimumHeight(260)
        self.svg_widget.setStyleSheet("background:white; border:1px solid #ddd;")
        detail_layout.addWidget(self.svg_widget)

        btn_row_actions = QHBoxLayout()
        btn_zoom = QPushButton("🔍 Ver en el lienzo")
        btn_zoom.clicked.connect(self.zoom_to_current)
        btn_row_actions.addWidget(btn_zoom)

        self.btn_export_html = QPushButton("🖨 Exportar ficha HTML")
        self.btn_export_html.setToolTip(
            "Genera la ficha de este recinto en HTML, con el mismo aspecto que en el "
            "informe (croquis, aditamentos, conclusiones), y la guarda en la carpeta "
            "de RESULTADO."
        )
        self.btn_export_html.clicked.connect(self.export_current_html)
        btn_row_actions.addWidget(self.btn_export_html)
        detail_layout.addLayout(btn_row_actions)

        self.lbl_metrics = QLabel("")
        self.lbl_metrics.setWordWrap(True)
        self.lbl_metrics.setStyleSheet("background:#f8f9fa; border:1px solid #eee; padding:8px; border-radius:4px;")
        detail_layout.addWidget(self.lbl_metrics)

        self.lbl_conclusion = QLabel("")
        self.lbl_conclusion.setWordWrap(True)
        self.lbl_conclusion.setStyleSheet("padding:6px;")
        detail_layout.addWidget(self.lbl_conclusion)

        # Panel de revisión
        review_group = QGroupBox("📝 Revisión de esta ficha")
        review_layout = QVBoxLayout()

        self.lbl_desact_warning = QLabel("")
        self.lbl_desact_warning.setStyleSheet("color:#b45309; font-weight:bold;")
        self.lbl_desact_warning.setVisible(False)
        review_layout.addWidget(self.lbl_desact_warning)

        btn_row = QHBoxLayout()
        self.btn_group_decision = QButtonGroup(self)
        self.rb_sin_revisar = QRadioButton("Sin revisar")
        self.rb_si = QRadioButton("✔ Notificar")
        self.rb_no = QRadioButton("✘ NO Notificar")
        for i, rb in enumerate([self.rb_sin_revisar, self.rb_si, self.rb_no]):
            self.btn_group_decision.addButton(rb, i)
            btn_row.addWidget(rb)
        review_layout.addLayout(btn_row)

        self.txt_obs = QTextEdit()
        self.txt_obs.setPlaceholderText("Observación justificativa (sin límite de texto)…")
        self.txt_obs.setFixedHeight(80)
        review_layout.addWidget(self.txt_obs)

        self.btn_guardar = QPushButton("💾 Guardar revisión")
        self.btn_guardar.setStyleSheet("background-color:#2c3e50; color:white; font-weight:bold; padding:6px;")
        self.btn_guardar.clicked.connect(self.save_current_review)
        review_layout.addWidget(self.btn_guardar)

        review_group.setLayout(review_layout)
        detail_layout.addWidget(review_group)

        detail_layout.addStretch()
        detail_scroll.setWidget(detail_content)
        splitter.addWidget(detail_scroll)
        splitter.setStretchFactor(0, 1)
        splitter.setStretchFactor(1, 2)

        layout.addWidget(splitter, stretch=1)

    # ------------------------------------------------------------------
    # Carga / recarga de la capa
    # ------------------------------------------------------------------
    def set_output_dir(self, output_dir, log_callback=None):
        """Llamado por el dock_manager tras EJECUTAR ANÁLISIS (o al
        detectar un GeoPackage de auditoría ya existente en esa
        carpeta al reabrir el proyecto)."""
        self.audit_service = AuditService(output_dir, log_callback)
        self.reload_layer()

    def reload_layer(self):
        if not self.audit_service:
            self.lbl_progress.setText("Sin capa de auditoría cargada todavía.")
            return

        # Si ya había una capa conectada (p.ej. recarga tras re-ejecutar el
        # análisis), se desconecta primero para no acumular conexiones
        # duplicadas de selectionChanged en la nueva capa.
        if self.layer is not None:
            try:
                self.layer.selectionChanged.disconnect(self.on_layer_selection_changed)
            except (TypeError, RuntimeError):
                pass

        self.layer = self.audit_service.load_layer(add_to_project=True)
        if not self.layer:
            self.lbl_progress.setText("No se encontró GeoPackage de auditoría en la carpeta de salida.")
            self.list_widget.clear()
            return

        # Al picar UN único recinto de esta capa en el lienzo de QGIS (con
        # la herramienta "Seleccionar features" y la capa de auditoría
        # activa), se auto-selecciona ese mismo recinto aquí y se carga su
        # ficha de detalle.
        self.layer.selectionChanged.connect(self.on_layer_selection_changed)

        self.apply_filter()
        self._update_progress_label()
        self.layerReady.emit()

    def on_layer_selection_changed(self, selected=None, deselected=None, clear_and_set=None):
        """Auto-selecciona en la lista de esta ficha el recinto picado en
        el lienzo, siempre que la selección sea de UN único recinto (con
        varios seleccionados no hay una ficha única que mostrar, así que
        se deja la selección de lista tal cual está)."""
        if self._syncing_selection or self.layer is None:
            return

        ids = self.layer.selectedFeatureIds()
        if len(ids) != 1:
            return

        fid = ids[0]
        if fid == self.current_feature_id:
            return

        try:
            row = self._id_by_row.index(fid)
        except ValueError:
            # El recinto picado no está en la lista con el filtro activo
            # actualmente (p.ej. es infraestructura fija, o no pasa algún
            # filtro puesto en esta ficha). No se cambia nada para no
            # confundir; el usuario puede quitar el filtro si quiere verlo.
            return

        self._syncing_selection = True
        try:
            self.list_widget.setCurrentRow(row)
        finally:
            self._syncing_selection = False

        self.requestActivateTab.emit()

    def _update_progress_label(self):
        if not self.layer:
            return
        c = AuditService.progress_counts(self.layer)
        self.lbl_progress.setText(
            f"Auditoría: {c['total']} fincas · "
            f"{c['pendientes']} sin revisar · "
            f"{c['si']} notifica · {c['no']} no notifica"
            + (f" · ⚠ {c['desactualizadas']} desactualizadas" if c['desactualizadas'] else "")
        )

    # ------------------------------------------------------------------
    # Filtro y lista
    # ------------------------------------------------------------------
    def _build_expression(self):
        # Los recintos de infraestructura fija (VIALES/CURSOS AGUA/
        # EDIFICACIONES/EXCLUIDO, 'tipo_recinto' != 'PARCELA') están en el
        # GeoPackage/lienzo para que se vean, pero no son fincas a
        # revisar: no tienen titular, conclusión ni notificación, así que
        # se excluyen siempre de esta lista (NULL cubre una capa migrada
        # desde una versión anterior sin este campo, donde todo era
        # implícitamente 'PARCELA').
        parts = ["(tipo_recinto IS NULL OR tipo_recinto = 'PARCELA')"]

        rev = self.cmb_revision.currentText()
        if rev == "Sin revisar":
            parts.append("(revision_estado IS NULL OR revision_estado = '')")
        elif rev == "Notifica":
            parts.append("revision_estado = 'si'")
        elif rev == "No notifica":
            parts.append("revision_estado = 'no'")
        elif rev == "Desactualizadas":
            parts.append("revision_desactualizada = 1 AND revision_estado != ''")

        estado = self.cmb_estado.currentText()
        if estado == "Nueva (ALTA)":
            parts.append("estado = 'ALTA'")
        elif estado == "Desaparece (BAJA)":
            parts.append("estado = 'BAJA'")
        elif estado == "Persistente":
            parts.append("estado = 'PERSISTENTE'")

        notif = self.cmb_notif.currentText()
        if notif == "Paramétrica: notifica":
            parts.append("notifica_param = 1")
        elif notif == "Paramétrica: no notifica":
            parts.append("notifica_param = 0")
        elif notif == "Alternativa: notifica":
            parts.append("notifica_legal = 1")
        elif notif == "Alternativa: no notifica":
            parts.append("notifica_legal = 0")
        elif notif == "Divergen (paramétrica ≠ alternativa)":
            parts.append("notif_divergen = 1")
        elif notif == "Coinciden en notificar":
            parts.append("notifica_param = 1 AND notifica_legal = 1")

        if self.chk_titular_cambia.isChecked():
            parts.append("titular_cambia = 1")

        # --- Precisión T24 (supfT24 vs. superficie GRÁFICA real) ---
        # Misma lógica que ReportService._t24_filter_flags, expresada
        # como expresión QGIS sobre val_pct_a / val_pct_d / val_limite_pct
        # (ya calculados y guardados por finca).
        t24 = self.cmb_t24.currentText()
        valid_a_t24 = "(val_pct_a IS NOT NULL AND abs(val_pct_a) <= val_limite_pct)"
        invalid_a_t24 = "(val_pct_a IS NOT NULL AND abs(val_pct_a) > val_limite_pct)"
        valid_d_t24 = "(val_pct_d IS NOT NULL AND abs(val_pct_d) <= val_limite_pct)"
        invalid_d_t24 = "(val_pct_d IS NOT NULL AND abs(val_pct_d) > val_limite_pct)"
        unk_t24 = "(val_pct_a IS NULL OR val_pct_d IS NULL)"
        if t24 == "Fuera de tolerancia":
            parts.append(f"(NOT {unk_t24}) AND {invalid_d_t24}")
        elif t24 == "Empeora la precisión":
            parts.append(f"(NOT {unk_t24}) AND {valid_a_t24} AND {invalid_d_t24}")
        elif t24 == "Mejora la precisión":
            parts.append(f"(NOT {unk_t24}) AND {invalid_a_t24} AND {valid_d_t24}")
        elif t24 == "Sin dato de referencia":
            parts.append(unk_t24)

        # --- Validación GML (combina supfT24 vs. GRÁFICA y vs. GML) ---
        # Misma lógica que ReportService._validacion_filter_flags: "no
        # valida en Después" si falla cualquiera de los dos criterios.
        validacion = self.cmb_validacion.currentText()
        unk_val = "(val_pct_a IS NULL OR val_pct_d IS NULL OR val_pct_gml_d IS NULL)"
        valid_a_val = "(val_pct_a IS NOT NULL AND abs(val_pct_a) <= val_limite_pct)"
        invalid_after_val = "(val_gml_d_supera = 1 OR (val_pct_d IS NOT NULL AND abs(val_pct_d) > val_limite_pct))"
        valid_after_val = "(val_gml_d_supera = 0 AND val_pct_d IS NOT NULL AND abs(val_pct_d) <= val_limite_pct)"
        if validacion == "No valida en Después":
            parts.append(f"(NOT {unk_val}) AND {invalid_after_val}")
        elif validacion == "Antes validaba, después no":
            parts.append(f"(NOT {unk_val}) AND {valid_a_val} AND {invalid_after_val}")
        elif validacion == "Antes no validaba, después sí":
            parts.append(f"(NOT {unk_val}) AND (NOT {valid_a_val}) AND {valid_after_val}")

        text = self.txt_search.text().strip().replace("'", "''")
        if text:
            parts.append(f"(audinot_id ILIKE '%{text}%' OR titular_a ILIKE '%{text}%' OR titular_d ILIKE '%{text}%')")

        return " AND ".join(parts) if parts else ""

    @staticmethod
    def _audinot_id_sort_key(audinot_id):
        """Clave de ordenación NUMÉRICA y jerárquica para audinot_id
        (formato POL/MASA[-SUBMASA]/REC[-SUBREC], ver
        ShpService.enrich_layer): por Polígono, luego Masa, Submasa,
        Recinto y Subrecinto. Ordenar por el string tal cual (como
        hacía "addOrderBy('audinot_id')") trata "10" como anterior a
        "2"; aquí cada tramo se compara como número siempre que se
        pueda. Un recinto SIN submasa/subrecinto ordena inmediatamente
        antes que los que sí la tienen dentro de la misma masa/recinto
        (12/34/56 antes que 12/34/56-1), que es el orden lógico
        habitual en catastro."""
        def _num(token):
            try:
                return (0, float(token))
            except (TypeError, ValueError):
                return (1, token or '')

        aid = audinot_id or ''
        pol_part, _, rest = aid.partition('/')
        masa_part, _, rec_part = rest.partition('/')
        masa, _, submasa = masa_part.partition('-')
        rec, _, subrec = rec_part.partition('-')

        # "sin submasa/subrecinto" (0,) ordena SIEMPRE antes que
        # cualquier valor real (1, ...), sea cual sea ese valor.
        submasa_key = (0,) if submasa == '' else (1, _num(submasa))
        subrec_key = (0,) if subrec == '' else (1, _num(subrec))

        return (_num(pol_part), _num(masa), submasa_key, _num(rec), subrec_key)

    def apply_filter(self):
        if not self.layer:
            return
        self.list_widget.clear()
        self._id_by_row = []

        expr = self._build_expression()
        request = QgsFeatureRequest()
        if expr:
            request.setFilterExpression(expr)

        try:
            features = list(self.layer.getFeatures(request))
        except Exception:
            # Si ILIKE no está soportado por el proveedor, se reintenta sin filtro de texto
            features = list(self.layer.getFeatures())

        # Orden numérico lógico (Polígono/Masa-Submasa/Recinto-Subrecinto),
        # no alfabético: ver _audinot_id_sort_key.
        features.sort(key=lambda f: self._audinot_id_sort_key(f['audinot_id']))

        for f in features:
            estado = f['revision_estado'] or ''
            # Columna de iconos: 1) estado de revisión, 2) marca de
            # observación (si tiene texto), 3) hueco reservado en blanco
            # (por si en el futuro se añade algún estado más, para que la
            # lista no se "recoloque" cuando se añada).
            icon_estado = "⬜" if estado == '' else ("🔴" if estado == 'si' else "🟢")
            icon_obs = "📝" if (f['revision_obs'] or '').strip() else "·"
            icon_reserved = "·"
            desact = " ⚠" if f['revision_desactualizada'] else ""
            item = QListWidgetItem(f"{icon_estado}{icon_obs}{icon_reserved} {f['audinot_id']}{desact}")
            item.setToolTip(
                "Doble clic para alternar NOTIFICAR / NO NOTIFICAR.\n"
                f"Estado: {'Sin revisar' if estado == '' else ('Notifica' if estado == 'si' else 'No notifica')}"
                + ("\nTiene observación." if (f['revision_obs'] or '').strip() else "")
            )
            self.list_widget.addItem(item)
            self._id_by_row.append(f.id())

        self._update_progress_label()

    # ------------------------------------------------------------------
    # Selección y detalle
    # ------------------------------------------------------------------
    def on_select_row(self, row):
        if row < 0 or row >= len(self._id_by_row):
            self.current_feature_id = None
            return
        self.current_feature_id = self._id_by_row[row]
        self._render_detail()

    def _current_feature(self):
        if self.layer is None or self.current_feature_id is None:
            return None
        return self.layer.getFeature(self.current_feature_id)

    @staticmethod
    def _fmt_num(v):
        """Formatea un valor numérico de un campo de la capa, mostrando
        '?' cuando el campo es NULL. feat['campo'] devuelve el sentinel
        QVariant NULL de PyQGIS cuando el valor es nulo (p.ej. un recinto
        que ha desaparecido de ANTES a DESPUÉS y no tiene datos de
        "Después"), y ese objeto no es el None de Python, así que hay que
        comprobarlo explícitamente antes de formatear con ':g'."""
        if v is None or v == QGIS_NULL:
            return "?"
        try:
            return f"{v:g}"
        except (TypeError, ValueError):
            return str(v)

    @staticmethod
    def _render_t24_gml_line(feat):
        """Línea 'supfT24 / superficie GML / % validación' del panel de
        detalle, con el % de Después resaltado en naranja (error
        positivo: supfT24 > superficie GML) o morado (error negativo:
        supfT24 < superficie GML) cuando supera el umbral '% Validación'
        de la Ficha 3 (feat['val_gml_d_supera'], ya calculado); en verde
        cuando no lo supera; en gris si no hay dato."""
        _fmt = TabAudit._fmt_num

        def _pct_span(pct, supera, positivo):
            if pct is None or pct == QGIS_NULL:
                return '<span style="color:#888">?</span>'
            if not supera:
                color = "#27ae60"
            else:
                color = "#e67e22" if positivo else "#8e44ad"
            return f'<span style="color:{color}; font-weight:bold">{pct:+.2f}%</span>'

        val_pct_gml_d = feat['val_pct_gml_d']
        val_pct_gml_d = None if val_pct_gml_d == QGIS_NULL else val_pct_gml_d
        supera = bool(feat['val_gml_d_supera']) and feat['val_gml_d_supera'] != QGIS_NULL
        positivo = bool(val_pct_gml_d and val_pct_gml_d > 0)

        return (
            f"<b>supfT24:</b> {_fmt(feat['sup_t24_a'])} m² → {_fmt(feat['sup_t24_d'])} m² &nbsp;&nbsp; "
            f"<b>Superficie GML:</b> {_fmt(feat['sup_gml_a'])} m² → {_fmt(feat['sup_gml_d'])} m²<br>"
            f"<b>% Validación (T24 vs. gráfica):</b> {_pct_span(feat['val_pct_a'], False, False)} → "
            f"{_pct_span(feat['val_pct_d'], False, False)} &nbsp;&nbsp; "
            f"<b>% Validación GML (T24 vs. GML) Después:</b> {_pct_span(val_pct_gml_d, supera, positivo)}<br>"
        )

    # Traducción clase CSS → atributos de presentación SVG. Debe
    # mantenerse alineada con las reglas ".sketch-*" definidas en el
    # <style> del informe HTML (core/report_service.py, bloque de estilos
    # de _generate_report / búsqueda ".sketch-"), porque croquis_svg
    # reutiliza esas mismas clases. QSvgWidget (QtSvg) no interpreta hojas
    # de estilo CSS por clase de forma fiable, así que aquí se inyectan
    # como atributos fill/stroke/etc. directamente en cada elemento antes
    # de pasarlo al widget.
    _SKETCH_CSS = {
        'sketch-bg': 'fill="#fbfbfa" stroke="#dddddd" stroke-width="1"',
        'sketch-study-fill': 'fill="#f0f0f0" stroke="none"',
        'sketch-antes': 'fill="none" stroke="#2980b9" stroke-width="2" stroke-dasharray="6,4"',
        'sketch-despues': 'fill="none" stroke="#2c3e50" stroke-width="2.2"',
        'sketch-gained': 'fill="#0072B2" fill-opacity="0.45" stroke="#004C75" stroke-width="0.6"',
        'sketch-lost': 'fill="#E69F00" fill-opacity="0.45" stroke="#A66F00" stroke-width="0.6"',
        'sketch-context': 'fill="none" stroke="#bbbbbb" stroke-width="0.6"',
        'sketch-context-related': 'fill="none" stroke="#888888" stroke-width="1.1" stroke-dasharray="3,2"',
        'sketch-context-label': 'fill="#aaaaaa" font-size="8px" text-anchor="middle" dominant-baseline="middle"',
        'sketch-context-label-related': 'fill="#555555" font-size="8px" font-weight="bold" text-anchor="middle" dominant-baseline="middle"',
        'sketch-adit': 'fill="#4d4d4d" fill-opacity="0.30" stroke="#2b2b2b" stroke-width="0.8"',
        'sketch-adit-line': 'fill="none" stroke="#2b2b2b" stroke-width="1.4"',
        'sketch-adit-point': 'fill="#4d4d4d" stroke="#2b2b2b" stroke-width="0.6"',
        # El patrón rayado real (aditAlertHatch) puede no representarse en
        # QtSvg; se usa un relleno sólido aproximado como alternativa.
        'sketch-adit-alert': 'fill="#CC79A7" stroke="#000000" stroke-width="1.8"',
        'sketch-adit-line-alert': 'fill="none" stroke="#000000" stroke-width="2.4" stroke-dasharray="4,2"',
        'sketch-adit-point-alert': 'fill="#CC79A7" stroke="#000000" stroke-width="1.4"',
        'sketch-context-adit': 'fill="#bbbbbb" fill-opacity="0.25" stroke="#999999" stroke-width="0.5"',
        'sketch-context-adit-line': 'fill="none" stroke="#999999" stroke-width="0.9" stroke-dasharray="2,1.5"',
        'sketch-context-adit-point': 'fill="#bbbbbb" stroke="#999999" stroke-width="0.4"',
    }

    @classmethod
    def _extract_main_svg(cls, croquis_html):
        """croquis_svg (campo del GeoPackage) es en realidad el fragmento
        HTML completo que usa el informe: un <div class="sketch-section">
        con leyenda, escala gráfica y el <svg class="sketch-svg"> del
        dibujo propiamente dicho, todo ello coloreado por clases CSS que
        solo existen en el <style> del informe HTML. Aquí se extrae solo
        ese <svg> interior (el dibujo) y se le insertan como atributos de
        presentación los mismos colores/trazos que ya usa el informe,
        para poder mostrarlo en QSvgWidget sin depender de CSS externo."""
        if not croquis_html:
            return None
        m = re.search(r'<svg\b[^>]*class="sketch-svg".*?</svg>', croquis_html, re.DOTALL)
        if not m:
            return None
        svg = m.group(0)

        def _repl(match):
            cls_name = match.group(1)
            attrs = TabAudit._SKETCH_CSS.get(cls_name)
            return match.group(0) if not attrs else f'{match.group(0)} {attrs}'

        return re.sub(r'class="([\w-]+)"', _repl, svg)

    def _load_croquis(self, croquis_html):
        main_svg = self._extract_main_svg(croquis_html)
        if main_svg:
            self.svg_widget.load(bytearray(main_svg, encoding='utf-8'))
        else:
            self.svg_widget.load(bytearray('<svg xmlns="http://www.w3.org/2000/svg"></svg>', encoding='utf-8'))

    def _render_detail(self):
        feat = self._current_feature()
        if feat is None:
            return

        self.lbl_detail_title.setText(
            f"Finca {feat['audinot_id']}  —  {feat['estado']}"
        )

        self._load_croquis(feat['croquis_svg'] or '')

        param_txt = "SÍ" if feat['notifica_param'] else "NO"
        legal_txt = "SÍ" if feat['notifica_legal'] else "NO"
        diverge = " ⚠ (las dos interpretaciones no coinciden)" if feat['notif_divergen'] else ""

        _fmt = self._fmt_num
        titular_a = feat['titular_a'] if feat['titular_a'] not in (None, QGIS_NULL) else "?"
        titular_d = feat['titular_d'] if feat['titular_d'] not in (None, QGIS_NULL) else "?"

        self.lbl_metrics.setText(
            f"<b>Titular:</b> {titular_a} → {titular_d}<br>"
            f"<b>Superficie:</b> {_fmt(feat['sup_a'])} m² → {_fmt(feat['sup_d'])} m² "
            f"(Δ {_fmt(feat['var_sup'])} m², {_fmt(feat['var_sup_pct'])}%)<br>"
            f"<b>Perímetro Δ:</b> {_fmt(feat['var_perim'])} m<br>"
            f"<b>Partes:</b> {_fmt(feat['n_partes_a'])} → {_fmt(feat['n_partes_d'])}<br>"
            f"{self._render_t24_gml_line(feat)}"
            f"<b>Notifica (paramétrico):</b> {param_txt} &nbsp;&nbsp; "
            f"<b>Notifica (alternativo):</b> {legal_txt}{diverge}"
        )

        conclusion_html = ""
        if feat['conclusion_param']:
            conclusion_html += f"<p><b>⚠ Conclusión paramétrica:</b> {feat['conclusion_param']}</p>"
        if feat['conclusion_legal']:
            conclusion_html += f"<p><b>⚖ Conclusión alternativa:</b> {feat['conclusion_legal']}</p>"
        self.lbl_conclusion.setText(conclusion_html)

        # Estado de revisión actual
        estado = feat['revision_estado'] or ''
        self.rb_sin_revisar.setChecked(estado == '')
        self.rb_si.setChecked(estado == 'si')
        self.rb_no.setChecked(estado == 'no')
        self.txt_obs.setPlainText(feat['revision_obs'] or '')

        if feat['revision_desactualizada']:
            self.lbl_desact_warning.setText(
                "⚠ Las métricas de esta finca han cambiado desde la última revisión. "
                "Comprueba si tu decisión anterior sigue siendo válida."
            )
            self.lbl_desact_warning.setVisible(True)
        else:
            self.lbl_desact_warning.setVisible(False)

    # ------------------------------------------------------------------
    # Guardar revisión
    # ------------------------------------------------------------------
    def save_current_review(self):
        if self.current_feature_id is None or self.layer is None:
            QMessageBox.warning(self, "AudiNOT", "Selecciona primero una finca de la lista.")
            return

        if self.rb_si.isChecked():
            estado = 'si'
        elif self.rb_no.isChecked():
            estado = 'no'
        else:
            estado = ''

        observacion = self.txt_obs.toPlainText()

        # Regla de negocio: una OBSERVACIÓN por sí sola, sin que el
        # usuario haya marcado NOTIFICAR o NO NOTIFICAR, no se puede
        # grabar (dejaría una finca con anotación pero sin decisión
        # trazable). Si en cambio SÍ se marca NOTIFICAR/NO NOTIFICAR, la
        # observación puede ir en blanco perfectamente.
        if estado == '' and observacion.strip():
            QMessageBox.warning(
                self, "AudiNOT",
                "Has escrito una observación pero no has marcado NOTIFICAR ni NO NOTIFICAR.\n\n"
                "Indica una de las dos decisiones para poder guardar (o borra la observación "
                "si de verdad quieres dejar esta finca sin revisar)."
            )
            return

        try:
            AuditService.save_review(self.layer, self.current_feature_id, estado, observacion)
        except Exception as e:
            QMessageBox.critical(self, "AudiNOT", f"No se pudo guardar la revisión:\n{e}")
            return

        self.apply_filter()
        # Re-seleccionar la misma finca tras refrescar la lista
        try:
            row = self._id_by_row.index(self.current_feature_id)
            self.list_widget.setCurrentRow(row)
        except ValueError:
            pass

    # ------------------------------------------------------------------
    # Doble clic en la lista: alterna NOTIFICAR <-> NO NOTIFICAR
    # ------------------------------------------------------------------
    def on_double_click_toggle(self, item):
        """Doble clic sobre una finca de la lista:
          - Sin revisar         -> pasa a NOTIFICAR.
          - Marcada (si/no)     -> se invierte (si -> no, no -> si).
        En cualquiera de los dos casos que SÍ cambian el estado (es
        decir, siempre, porque "sin revisar" también es un cambio), se
        borra la observación existente: una observación escrita para
        justificar una decisión concreta deja de tener sentido en cuanto
        esa decisión se invierte o se sustituye sin que el usuario la
        haya revisado a propósito desde el panel de la derecha."""
        row = self.list_widget.row(item)
        if row < 0 or row >= len(self._id_by_row):
            return
        fid = self._id_by_row[row]
        if self.layer is None:
            return

        feat = self.layer.getFeature(fid)
        estado_actual = feat['revision_estado'] or ''
        estado_nuevo = 'si' if estado_actual != 'si' else 'no'
        etiqueta_actual = {'si': 'NOTIFICAR', 'no': 'NO NOTIFICAR', '': 'Sin revisar'}[estado_actual]
        etiqueta_nueva = {'si': 'NOTIFICAR', 'no': 'NO NOTIFICAR'}[estado_nuevo]

        tenia_obs = bool((feat['revision_obs'] or '').strip())
        aviso_obs = "\n\nSe borrará la observación actual." if tenia_obs else ""

        resp = QMessageBox.question(
            self, "AudiNOT",
            f"Finca {feat['audinot_id']}\n\n"
            f"Estado actual: {etiqueta_actual}\n"
            f"¿Cambiar a: {etiqueta_nueva}?{aviso_obs}",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes
        )
        if resp != QMessageBox.Yes:
            return

        try:
            AuditService.save_review(self.layer, fid, estado_nuevo, '')
        except Exception as e:
            QMessageBox.critical(self, "AudiNOT", f"No se pudo guardar el cambio:\n{e}")
            return

        self.apply_filter()
        try:
            new_row = self._id_by_row.index(fid)
            self.list_widget.setCurrentRow(new_row)
        except ValueError:
            pass

    # ------------------------------------------------------------------
    # Exportar ficha HTML del recinto seleccionado
    # ------------------------------------------------------------------
    def export_current_html(self):
        feat = self._current_feature()
        if feat is None or self.audit_service is None:
            QMessageBox.warning(self, "AudiNOT", "Selecciona primero una finca de la lista.")
            return

        raw_json = feat['audinot_json'] or '{}'
        try:
            audinot_json = json.loads(raw_json) if raw_json else {}
        except (TypeError, ValueError):
            audinot_json = {}

        attrs = {name: feat[name] for name in self.layer.fields().names() if name.lower() != 'fid'}

        report_service = ReportService(self.audit_service.output_dir)
        try:
            html = report_service.generate_parcel_card_html(attrs, audinot_json)
        except Exception as e:
            QMessageBox.critical(self, "AudiNOT", f"No se pudo generar la ficha HTML:\n{e}")
            return

        filename = ReportService.parcel_export_filename(feat['audinot_id'])
        out_path = os.path.join(self.audit_service.output_dir, filename)
        try:
            with open(out_path, 'w', encoding='utf-8') as f:
                f.write(html)
        except Exception as e:
            QMessageBox.critical(self, "AudiNOT", f"No se pudo guardar el fichero:\n{e}")
            return

        resp = QMessageBox.information(
            self, "AudiNOT",
            f"Ficha guardada en:\n{out_path}\n\n¿Abrirla ahora?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes
        )
        if resp == QMessageBox.Yes:
            QDesktopServices.openUrl(QUrl.fromLocalFile(out_path))

    # ------------------------------------------------------------------
    # Zoom al lienzo
    # ------------------------------------------------------------------
    def zoom_to_current(self):
        feat = self._current_feature()
        if feat is None or self.layer is None:
            return
        geom = feat.geometry()
        if geom is None or geom.isEmpty():
            QMessageBox.information(self, "AudiNOT", "Esta finca no tiene geometría para hacer zoom.")
            return
        canvas = self.iface.mapCanvas()
        rect = geom.boundingBox()
        rect.scale(1.3)
        canvas.setExtent(rect)
        canvas.refresh()

        self._syncing_selection = True
        try:
            self.layer.removeSelection()
            self.layer.select(feat.id())
        finally:
            self._syncing_selection = False
        try:
            canvas.flashFeatureIds(self.layer, [feat.id()])
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Acciones masivas sobre TODAS las fincas de la lista
    # ------------------------------------------------------------------
    def _refresh_after_bulk_change(self):
        """Refresca lista, contador de cabecera y (si sigue existiendo)
        el panel de detalle de la finca seleccionada, tras una acción
        masiva que puede haber cambiado el estado de muchas fincas a la
        vez."""
        fid = self.current_feature_id
        self.apply_filter()
        self._update_progress_label()
        if fid is not None:
            try:
                row = self._id_by_row.index(fid)
                self.list_widget.setCurrentRow(row)
            except ValueError:
                pass

    def bulk_mark_pending_no_notificar(self):
        if self.layer is None:
            QMessageBox.warning(self, "AudiNOT", "No hay ninguna capa de auditoría cargada.")
            return

        pendientes = AuditService.progress_counts(self.layer)['pendientes']
        if pendientes == 0:
            QMessageBox.information(self, "AudiNOT", "No queda ninguna finca 'Sin revisar'.")
            return

        resp1 = QMessageBox.question(
            self, "AudiNOT",
            f"Hay {pendientes} finca(s) todavía 'Sin revisar'.\n\n"
            "¿Quieres marcarlas TODAS como NO NOTIFICAR? Se les añadirá "
            "automáticamente una observación indicando que la revisión fue "
            "automática. Las fincas que ya tengan una decisión tomada NO se "
            "tocan.",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        if resp1 != QMessageBox.Yes:
            return

        resp2 = QMessageBox.warning(
            self, "AudiNOT",
            "Este cambio es irreversible. ¿Continuamos?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        if resp2 != QMessageBox.Yes:
            return

        observacion = (
            f"Revisado automáticamente como NO NOTIFICAR el "
            f"{datetime.now().strftime('%d/%m/%Y %H:%M')} (acción masiva sobre "
            f"fincas pendientes)."
        )
        try:
            n = AuditService.bulk_mark_pending_no_notificar(self.layer, observacion)
        except Exception as e:
            QMessageBox.critical(self, "AudiNOT", f"No se pudo completar la acción:\n{e}")
            return

        self._refresh_after_bulk_change()
        QMessageBox.information(self, "AudiNOT", f"Se han marcado {n} finca(s) como NO NOTIFICAR.")

    def bulk_reset_all_to_sin_revisar(self):
        if self.layer is None:
            QMessageBox.warning(self, "AudiNOT", "No hay ninguna capa de auditoría cargada.")
            return

        resp1 = QMessageBox.question(
            self, "AudiNOT",
            "¿Quieres poner TODAS las fincas en estado 'Sin revisar'?\n\n"
            "Esto borrará TODAS las decisiones (NOTIFICAR / NO NOTIFICAR) y "
            "TODAS las observaciones guardadas hasta ahora, en todas las "
            "fincas de la lista.",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        if resp1 != QMessageBox.Yes:
            return

        resp2 = QMessageBox.warning(
            self, "AudiNOT",
            "Este cambio es irreversible. ¿Continuamos?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        if resp2 != QMessageBox.Yes:
            return

        try:
            n = AuditService.bulk_reset_all_to_sin_revisar(self.layer)
        except Exception as e:
            QMessageBox.critical(self, "AudiNOT", f"No se pudo completar la acción:\n{e}")
            return

        self._refresh_after_bulk_change()
        QMessageBox.information(self, "AudiNOT", f"Se han puesto {n} finca(s) en estado 'Sin revisar'.")
