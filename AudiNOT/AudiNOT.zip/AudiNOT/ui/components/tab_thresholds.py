from PyQt5.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QDoubleSpinBox, QGroupBox, QScrollArea

class TabThresholds(QWidget):
    def __init__(self, iface):
        super().__init__()
        self.iface = iface
        self.init_ui()

    def init_ui(self):
        # Usar ScrollArea porque los umbrales ahora son numerosos
        main_layout = QVBoxLayout(self)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll_content = QWidget()
        layout = QVBoxLayout(scroll_content)
        
        # 1. Umbrales de Geometría
        group_geo = QGroupBox("Métricas Geométricas y Perímetro")
        geo_layout = QVBoxLayout()
        
        row_gravelius, self.spin_gravelius = self._create_spin_row("Coef. Gravelius (K):", 1.0, 10.0, 1.5)
        geo_layout.addLayout(row_gravelius)
        
        row_desp, self.spin_desp = self._create_spin_row("Desplazamiento Máx (m):", 0, 1000, 5.0)
        geo_layout.addLayout(row_desp)
        
        row_invasion, self.spin_invasion = self._create_spin_row("Invasión de Huecos (%):", 0, 100, 10.0)
        geo_layout.addLayout(row_invasion)

        row_long = self._create_double_spin_row("Variación Perímetro:", "m", " %", 1.0, 2.0)
        self.spin_long_abs, self.spin_long_pct = row_long[1], row_long[2]
        geo_layout.addLayout(row_long[0])
        
        group_geo.setLayout(geo_layout)
        layout.addWidget(group_geo)
        
        # 2. Umbrales de Superficie
        group_sup = QGroupBox("Variación de Superficie")
        sup_layout = QVBoxLayout()
        row_sup = self._create_double_spin_row("Diferencia de Área:", "m²", " %", 10.0, 5.0)
        self.spin_sup_abs, self.spin_sup_pct = row_sup[1], row_sup[2]
        sup_layout.addLayout(row_sup[0])
        group_sup.setLayout(sup_layout)
        layout.addWidget(group_sup)
        
        # 3. Umbrales de Fachadas (Accesos)
        group_facades = QGroupBox("Variación en Fachadas (Accesos)")
        facades_layout = QVBoxLayout()
        
        # Viales
        row_viales = self._create_double_spin_row("Fachada VIALES:", "m", " %", 1.0, 5.0)
        self.spin_viales_abs, self.spin_viales_pct = row_viales[1], row_viales[2]
        facades_layout.addLayout(row_viales[0])
        
        # Agua
        row_agua = self._create_double_spin_row("Fachada AGUA:", "m", " %", 1.0, 5.0)
        self.spin_agua_abs, self.spin_agua_pct = row_agua[1], row_agua[2]
        facades_layout.addLayout(row_agua[0])
        
        # Edificios
        row_edificios = self._create_double_spin_row("Fachada EDIFICIOS:", "m", " %", 1.0, 5.0)
        self.spin_edif_abs, self.spin_edif_pct = row_edificios[1], row_edificios[2]
        facades_layout.addLayout(row_edificios[0])
        
        # Excluido
        row_excluido = self._create_double_spin_row("Fachada EXCLUIDO:", "m", " %", 1.0, 5.0)
        self.spin_excl_abs, self.spin_excl_pct = row_excluido[1], row_excluido[2]
        facades_layout.addLayout(row_excluido[0])
        
        group_facades.setLayout(facades_layout)
        layout.addWidget(group_facades)
        
        # 4. Umbrales de Aditamentos (Elementos Técnicos)
        group_aditamentos = QGroupBox("Variación en Aditamentos (Elementos Técnicos)")
        adit_layout = QVBoxLayout()
        
        # Elementos Lineales (cables, tuberías, etc.)
        row_adit_linear = self._create_double_spin_row("Elementos Lineales:", "m", " %", 1.0, 5.0)
        self.spin_adit_linear_abs, self.spin_adit_linear_pct = row_adit_linear[1], row_adit_linear[2]
        adit_layout.addLayout(row_adit_linear[0])
        
        # Elementos Poligonales (muros, pavimentos, etc.)
        row_adit_poly = self._create_double_spin_row("Elementos Poligonales:", "m²", " %", 1.0, 5.0)
        self.spin_adit_poly_abs, self.spin_adit_poly_pct = row_adit_poly[1], row_adit_poly[2]
        adit_layout.addLayout(row_adit_poly[0])
        
        # Nota informativa
        note_label = QLabel("<i>Nota: Elementos puntuales (postes, arquetas) siempre alertan ante cualquier cambio.</i>")
        note_label.setStyleSheet("color: #666; font-size: 10px;")
        adit_layout.addWidget(note_label)
        
        group_aditamentos.setLayout(adit_layout)
        layout.addWidget(group_aditamentos)
        
        layout.addStretch()
        scroll.setWidget(scroll_content)
        main_layout.addWidget(scroll)

    def _create_spin_row(self, label_text, min_v, max_v, default):
        row = QHBoxLayout()
        row.addWidget(QLabel(label_text))
        spin = QDoubleSpinBox()
        spin.setRange(min_v, max_v)
        spin.setValue(default)
        row.addWidget(spin)
        return row, spin

    def _create_double_spin_row(self, label_text, suffix1, suffix2, def1, def2):
        row = QHBoxLayout()
        
        # SpinBox 1 (Valor absoluto)
        s1 = QDoubleSpinBox()
        s1.setRange(0, 1000000)
        s1.setValue(def1)
        s1.setSuffix(f" {suffix1}")
        
        # SpinBox 2 (Porcentaje)
        s2 = QDoubleSpinBox()
        s2.setRange(0, 100)
        s2.setValue(def2)
        s2.setSuffix(suffix2)
        
        row.addWidget(s1)
        row.addWidget(s2)
        
        v_layout = QVBoxLayout()
        v_layout.addWidget(QLabel(f"<b>{label_text}</b>"))
        v_layout.addLayout(row)
        
        return v_layout, s1, s2

    def get_thresholds(self):
        """Devuelve un diccionario con todos los umbrales configurados."""
        return {
            'gravelius': self.spin_gravelius.value(),
            'desp_max': self.spin_desp.value(),
            'invasion_pct': self.spin_invasion.value(),
            'perim_abs': self.spin_long_abs.value(),
            'perim_pct': self.spin_long_pct.value(),
            'area_abs': self.spin_sup_abs.value(),
            'area_pct': self.spin_sup_pct.value(),
            'facades': {
                'VIAL': {'abs': self.spin_viales_abs.value(), 'pct': self.spin_viales_pct.value()},
                'AGUA': {'abs': self.spin_agua_abs.value(), 'pct': self.spin_agua_pct.value()},
                'EDIF': {'abs': self.spin_edif_abs.value(), 'pct': self.spin_edif_pct.value()},
                'EXCL': {'abs': self.spin_excl_abs.value(), 'pct': self.spin_excl_pct.value()}
            },
            'aditamentos': {
                'linear': {'abs': self.spin_adit_linear_abs.value(), 'pct': self.spin_adit_linear_pct.value()},
                'poly': {'abs': self.spin_adit_poly_abs.value(), 'pct': self.spin_adit_poly_pct.value()},
                'point': {'abs': 0, 'pct': 0}  # Cualquier cambio en puntos es alerta
            }
        }
