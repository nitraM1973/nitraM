from PyQt5.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QDoubleSpinBox, QScrollArea
from .collapsible_group_box import CollapsibleGroupBox


class TabThresholds(QWidget):
    def __init__(self, iface):
        super().__init__()
        self.iface = iface
        self.init_ui()

    def init_ui(self):
        # Usar ScrollArea porque los umbrales ahora son numerosos
        main_layout = QVBoxLayout(self)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll_content = QWidget()
        layout = QVBoxLayout(scroll_content)
        
        # 1. Umbrales de Geometría
        group_geo = CollapsibleGroupBox("Métricas Geométricas y Perímetro", collapsed=True)
        geo_layout = QVBoxLayout()
        
        row_gravelius, self.spin_gravelius = self._create_spin_row("Coef. Gravelius/Convex. (K):", 1.0, 10.0, 0.20)
        geo_layout.addLayout(row_gravelius)
        
        row_desp, self.spin_desp = self._create_spin_row("Desplazamiento Máx (m):", 0, 1000, 5.0)
        geo_layout.addLayout(row_desp)
        
        row_invasion, self.spin_invasion = self._create_spin_row("Invasión de Huecos (%):", 0, 100, 10.0)
        geo_layout.addLayout(row_invasion)

        row_stability, self.spin_stability = self._create_spin_row("Mínima Estabilidad Lindes (%):", 0, 100, 90.0)
        geo_layout.addLayout(row_stability)

        row_long = self._create_double_spin_row("Variación Perímetro:", "m", " %", 1.0, 2.0)
        self.spin_long_abs, self.spin_long_pct = row_long[1], row_long[2]
        geo_layout.addLayout(row_long[0])
        
        group_geo.set_content_layout(geo_layout)
        layout.addWidget(group_geo)
        
        # 2. Umbrales de Superficie
        group_sup = CollapsibleGroupBox("Variación de Superficie", collapsed=True)
        sup_layout = QVBoxLayout()
        row_sup = self._create_double_spin_row("Diferencia de Área:", "m²", " %", 10.0, 5.0)
        self.spin_sup_abs, self.spin_sup_pct = row_sup[1], row_sup[2]
        sup_layout.addLayout(row_sup[0])
        group_sup.set_content_layout(sup_layout)
        layout.addWidget(group_sup)

        # 2b. Validación de Superficie T24 (comprobación informativa)
        group_t24 = CollapsibleGroupBox("Validación Superficie T24 (informativa)", collapsed=True)
        t24_layout = QVBoxLayout()
        row_t24 = self._create_spin_row("% Validación:", 0.0, 100.0, 10.0)
        self.spin_validacion_pct = row_t24[1]
        self.spin_validacion_pct.setDecimals(2)
        self.spin_validacion_pct.setSuffix(" %")
        t24_layout.addLayout(row_t24[0])
        note_t24 = QLabel(
            "<i>Nota: umbral para sombrear en rojo (supera) o verde (no supera) la "
            "desviación entre 'supfT24' y la superficie real (GML) de cada recinto. "
            "No condiciona ninguna alerta de notificación.</i>"
        )
        note_t24.setWordWrap(True)
        note_t24.setStyleSheet("color: #666; font-size: 10px;")
        t24_layout.addWidget(note_t24)
        group_t24.set_content_layout(t24_layout)
        layout.addWidget(group_t24)
        
        # 3. Umbrales de Fachadas (Accesos)
        group_facades = CollapsibleGroupBox("Variación en Fachadas (Accesos)", collapsed=True)
        facades_layout = QVBoxLayout()
        
        # Viales
        row_viales = self._create_double_spin_row("Fachada VIALES:", "m", " %", 1.0, 5.0)
        self.spin_viales_abs, self.spin_viales_pct = row_viales[1], row_viales[2]
        facades_layout.addLayout(row_viales[0])
        
        # Agua
        row_agua = self._create_double_spin_row("Fachada AGUA:", "m", " %", 1.0, 5.0)
        self.spin_agua_abs, self.spin_agua_pct = row_agua[1], row_agua[2]
        facades_layout.addLayout(row_agua[0])
        
        # Edificios
        row_edificios = self._create_double_spin_row("Fachada EDIFICIOS:", "m", " %", 1.0, 5.0)
        self.spin_edif_abs, self.spin_edif_pct = row_edificios[1], row_edificios[2]
        facades_layout.addLayout(row_edificios[0])
        
        # Excluido
        row_excluido = self._create_double_spin_row("Fachada EXCLUIDO:", "m", " %", 1.0, 5.0)
        self.spin_excl_abs, self.spin_excl_pct = row_excluido[1], row_excluido[2]
        facades_layout.addLayout(row_excluido[0])
        
        group_facades.set_content_layout(facades_layout)
        layout.addWidget(group_facades)
        
        # 4. Umbrales de Aditamentos (Elementos Técnicos)
        group_aditamentos = CollapsibleGroupBox("Variación en Aditamentos (Elementos Técnicos)", collapsed=True)
        adit_layout = QVBoxLayout()
        
        # Elementos Lineales (cables, tuberías, etc.)
        row_adit_linear = self._create_double_spin_row("Elementos Lineales:", "m", " %", 1.0, 5.0)
        self.spin_adit_linear_abs, self.spin_adit_linear_pct = row_adit_linear[1], row_adit_linear[2]
        adit_layout.addLayout(row_adit_linear[0])
        
        # Elementos Poligonales (muros, pavimentos, etc.)
        row_adit_poly = self._create_double_spin_row("Elementos Poligonales:", "m²", " %", 1.0, 5.0)
        self.spin_adit_poly_abs, self.spin_adit_poly_pct = row_adit_poly[1], row_adit_poly[2]
        adit_layout.addLayout(row_adit_poly[0])
        
        # Nota informativa
        note_label = QLabel("<i>Nota: Elementos puntuales (postes, arquetas) siempre alertan ante cualquier cambio.</i>")
        note_label.setStyleSheet("color: #666; font-size: 10px;")
        adit_layout.addWidget(note_label)
        
        group_aditamentos.set_content_layout(adit_layout)
        layout.addWidget(group_aditamentos)
        
        layout.addStretch()
        scroll.setWidget(scroll_content)
        main_layout.addWidget(scroll)

    def _create_spin_row(self, label_text, min_v, max_v, default):
        row = QHBoxLayout()
        row.addWidget(QLabel(label_text))
        spin = QDoubleSpinBox()
        spin.setRange(min_v, max_v)
        spin.setValue(default)
        row.addWidget(spin)
        return row, spin

    def _create_double_spin_row(self, label_text, suffix1, suffix2, def1, def2):
        row = QHBoxLayout()
        
        # SpinBox 1 (Valor absoluto)
        s1 = QDoubleSpinBox()
        s1.setRange(0, 1000000)
        s1.setValue(def1)
        s1.setSuffix(f" {suffix1}")
        
        # SpinBox 2 (Porcentaje)
        s2 = QDoubleSpinBox()
        s2.setRange(0, 100)
        s2.setValue(def2)
        s2.setSuffix(suffix2)
        
        row.addWidget(s1)
        row.addWidget(s2)
        
        v_layout = QVBoxLayout()
        v_layout.addWidget(QLabel(f"<b>{label_text}</b>"))
        v_layout.addLayout(row)
        
        return v_layout, s1, s2

    def set_thresholds(self, data):
        """Rellena los spinboxes a partir de un diccionario generado por get_thresholds()."""
        if not data:
            return

        def _set(spin, value):
            if value is not None:
                try:
                    spin.setValue(float(value))
                except (TypeError, ValueError):
                    pass

        _set(self.spin_gravelius, data.get('gravelius'))
        _set(self.spin_desp, data.get('desp_max'))
        _set(self.spin_invasion, data.get('invasion_pct'))
        _set(self.spin_long_abs, data.get('perim_abs'))
        _set(self.spin_long_pct, data.get('perim_pct'))
        _set(self.spin_sup_abs, data.get('area_abs'))
        _set(self.spin_sup_pct, data.get('area_pct'))
        _set(self.spin_stability, data.get('stability_pct'))
        _set(self.spin_validacion_pct, data.get('validacion_pct'))

        facades = data.get('facades', {})
        if 'VIAL' in facades:
            _set(self.spin_viales_abs, facades['VIAL'].get('abs'))
            _set(self.spin_viales_pct, facades['VIAL'].get('pct'))
        if 'AGUA' in facades:
            _set(self.spin_agua_abs, facades['AGUA'].get('abs'))
            _set(self.spin_agua_pct, facades['AGUA'].get('pct'))
        if 'EDIF' in facades:
            _set(self.spin_edif_abs, facades['EDIF'].get('abs'))
            _set(self.spin_edif_pct, facades['EDIF'].get('pct'))
        if 'EXCL' in facades:
            _set(self.spin_excl_abs, facades['EXCL'].get('abs'))
            _set(self.spin_excl_pct, facades['EXCL'].get('pct'))

        aditamentos = data.get('aditamentos', {})
        if 'linear' in aditamentos:
            _set(self.spin_adit_linear_abs, aditamentos['linear'].get('abs'))
            _set(self.spin_adit_linear_pct, aditamentos['linear'].get('pct'))
        if 'poly' in aditamentos:
            _set(self.spin_adit_poly_abs, aditamentos['poly'].get('abs'))
            _set(self.spin_adit_poly_pct, aditamentos['poly'].get('pct'))

    def get_thresholds(self):
        """Devuelve un diccionario con todos los umbrales configurados."""
        return {
            'gravelius': self.spin_gravelius.value(),
            'desp_max': self.spin_desp.value(),
            'invasion_pct': self.spin_invasion.value(),
            'perim_abs': self.spin_long_abs.value(),
            'perim_pct': self.spin_long_pct.value(),
            'area_abs': self.spin_sup_abs.value(),
            'area_pct': self.spin_sup_pct.value(),
            'stability_pct': self.spin_stability.value(),
            'validacion_pct': self.spin_validacion_pct.value(),
            'facades': {
                'VIAL': {'abs': self.spin_viales_abs.value(), 'pct': self.spin_viales_pct.value()},
                'AGUA': {'abs': self.spin_agua_abs.value(), 'pct': self.spin_agua_pct.value()},
                'EDIF': {'abs': self.spin_edif_abs.value(), 'pct': self.spin_edif_pct.value()},
                'EXCL': {'abs': self.spin_excl_abs.value(), 'pct': self.spin_excl_pct.value()}
            },
            'aditamentos': {
                'linear': {'abs': self.spin_adit_linear_abs.value(), 'pct': self.spin_adit_linear_pct.value()},
                'poly': {'abs': self.spin_adit_poly_abs.value(), 'pct': self.spin_adit_poly_pct.value()},
                'point': {'abs': 0, 'pct': 0}  # Cualquier cambio en puntos es alerta
            }
        }

    def get_restricted_widgets(self):
        """Widgets de edición de esta ficha que pasan a solo lectura en rol
        Revisor 2 (ver AudiNOTDockManager.aplicar_restricciones_por_rol):
        la ficha sigue siendo visible/legible entera, solo dejan de poder
        editarse los valores."""
        return [
            self.spin_gravelius, self.spin_desp, self.spin_invasion, self.spin_stability,
            self.spin_long_abs, self.spin_long_pct,
            self.spin_sup_abs, self.spin_sup_pct,
            self.spin_validacion_pct,
            self.spin_viales_abs, self.spin_viales_pct,
            self.spin_agua_abs, self.spin_agua_pct,
            self.spin_edif_abs, self.spin_edif_pct,
            self.spin_excl_abs, self.spin_excl_pct,
            self.spin_adit_linear_abs, self.spin_adit_linear_pct,
            self.spin_adit_poly_abs, self.spin_adit_poly_pct,
        ]
