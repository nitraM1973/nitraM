from PyQt5.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QComboBox, QTableWidget, QTableWidgetItem, QHeaderView, QGroupBox, QSpinBox, QSizePolicy
from PyQt5.QtCore import Qt
from qgis.core import QgsProject, QgsMapLayer

class TabMapping(QWidget):
    def __init__(self, iface):
        super().__init__()
        self.iface = iface
        self.log_callback = None
        
        # Almacenes de widgets para acceso directo y ultra-robusto
        self.combos_antes = []
        self.combos_desp = []
        
        self.init_ui()

    def set_log_callback(self, callback):
        self.log_callback = callback

    def add_log(self, message):
        if self.log_callback:
            self.log_callback(message)

    def init_ui(self):
        layout = QVBoxLayout(self)
        
        # 1. Tabla de Mapeo de Campos (3 COLUMNAS)
        layout.addWidget(QLabel("<b>Mapeo de Atributos Críticos:</b>"))
        self.table_fields = QTableWidget(6, 3)
        self.table_fields.setHorizontalHeaderLabels(["Propiedad", "Capa ANTES", "Capa DESPUÉS"])
        self.table_fields.verticalHeader().setVisible(False)
        self.table_fields.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self.table_fields.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.table_fields.horizontalHeader().setSectionResizeMode(2, QHeaderView.Stretch)
        # Tamaño vertical: que la tabla pida prioridad sobre el resto de secciones
        # para que sus 6 filas se vean siempre completas sin necesidad de hacer scroll.
        self.table_fields.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        
        # Conceptos y campos estándar
        self.concept_to_standard = {
            "PROPIETARIO": "PROP",
            "POLIGONO": "POL",
            "MASA": "MASA",
            "SUBMASA": "SUBMASA",
            "RECINTO": "REC",
            "SUBRECINTO": "SUBREC"
        }
        self.concepts = list(self.concept_to_standard.keys())
        
        for i, concept in enumerate(self.concepts):
            # Columna 0: Concepto
            item_concept = QTableWidgetItem(concept)
            item_concept.setFlags(item_concept.flags() & ~Qt.ItemIsEditable) 
            self.table_fields.setItem(i, 0, item_concept)
            
            # Columna 1: Combo ANTES
            combo_antes = QComboBox()
            combo_antes.currentIndexChanged.connect(lambda idx, row=i: self.on_antes_field_changed(row, idx))
            self.table_fields.setCellWidget(i, 1, combo_antes)
            self.combos_antes.append(combo_antes)
            
            # Columna 2: Combo DESPUÉS
            combo_desp = QComboBox()
            self.table_fields.setCellWidget(i, 2, combo_desp)
            self.combos_desp.append(combo_desp)
            
        # Asegurar una altura mínima suficiente para ver las 6 filas completas
        # (cabecera + filas), independientemente del tamaño del dock.
        self.table_fields.resizeRowsToContents()
        header_h = self.table_fields.horizontalHeader().sizeHint().height()
        rows_h = sum(self.table_fields.rowHeight(r) for r in range(self.table_fields.rowCount()))
        self.table_fields.setMinimumHeight(header_h + rows_h + 8)
            
        # Factor de estiramiento alto: la tabla tiene prioridad para crecer,
        # el resto de secciones (propietarios, rangos, aditamentos) se quedan
        # con su tamaño natural y bajan en el layout.
        layout.addWidget(self.table_fields, 1)
        
        layout.addSpacing(10)
        
        # 2. Propietarios Especiales (IDs)
        layout.addWidget(QLabel("<b>Propietarios Especiales (IDs):</b>"))
        row_owners = QHBoxLayout()
        vbox_agader = QVBoxLayout(); vbox_agader.addWidget(QLabel("AGADER:")); self.txt_agader = QLineEdit(); vbox_agader.addWidget(self.txt_agader); row_owners.addLayout(vbox_agader)
        vbox_masas = QVBoxLayout(); vbox_masas.addWidget(QLabel("MASA COMÚN:")); self.txt_masas = QLineEdit(); vbox_masas.addWidget(self.txt_masas); row_owners.addLayout(vbox_masas)
        vbox_descon = QVBoxLayout(); vbox_descon.addWidget(QLabel("DESCONOCIDOS:")); self.txt_desconocidos = QLineEdit(); vbox_descon.addWidget(self.txt_desconocidos); row_owners.addLayout(vbox_descon)
        layout.addLayout(row_owners)
        
        layout.addSpacing(10)
        
        # 3. Rangos de Recintos Especiales
        group_ranges = QGroupBox("Identificación por REC (Rangos)")
        ranges_data = [
            ("VIALES", 9000, 9099),
            ("CURSOS AGUA", 9300, 9399),
            ("EDIFICACIONES", 9100, 9199),
            ("EXCLUIDO", 9200, 9299)
        ]
        self.range_widgets = {}
        
        grid_ranges = QVBoxLayout()
        for label, min_val, max_val in ranges_data:
            row = QHBoxLayout()
            row.addWidget(QLabel(f"<b>{label}:</b>"))
            spin_min = QSpinBox(); spin_min.setRange(0, 99999); spin_min.setValue(min_val)
            spin_max = QSpinBox(); spin_max.setRange(0, 99999); spin_max.setValue(max_val)
            row.addWidget(spin_min); row.addWidget(QLabel("-")); row.addWidget(spin_max)
            grid_ranges.addLayout(row)
            self.range_widgets[label] = (spin_min, spin_max)
        
        group_ranges.setLayout(grid_ranges)
        layout.addWidget(group_ranges)
        
        layout.addSpacing(10)
        
        # 4. Mapeo de Aditamentos
        group_adit = QGroupBox("Mapeo de Aditamentos (Opcional)")
        adit_layout = QHBoxLayout()
        adit_layout.addWidget(QLabel("Campo Identificador (ELEMENTO):"))
        self.txt_adit_field = QLineEdit("layer")
        adit_layout.addWidget(self.txt_adit_field, 1)
        group_adit.setLayout(adit_layout)
        layout.addWidget(group_adit)
        
        layout.addStretch()

    def update_fields(self, layer: QgsMapLayer, column: int):
        """Actualiza los combos de una columna (1=Antes, 2=Después)"""
        if not layer: 
            return
        
        fields = [""] + [f.name() for f in layer.fields()]
        col_list = self.combos_antes if column == 1 else self.combos_desp
        col_name = "ANTES" if column == 1 else "DESPUÉS"
        
        self.add_log(f"Mapeo: Sincronizando {len(fields)-1} campos para {col_name}...")
        
        for i, combo in enumerate(col_list):
            combo.blockSignals(True)
            combo.clear()
            combo.addItems(fields)
            
            # Auto-mapeo inteligente por nombre estándar
            std_name = self.concept_to_standard[self.concepts[i]]
            idx = -1
            for j in range(combo.count()):
                if combo.itemText(j).upper() == std_name.upper():
                    idx = j
                    break
            
            if idx != -1:
                combo.setCurrentIndex(idx)
            combo.blockSignals(False)
            
        self.add_log(f"Mapeo: {col_name} actualizado correctamente.")

    def on_antes_field_changed(self, row, idx):
        """Sincronización automática: si el campo de ANTES existe en DESPUÉS, se marca."""
        if row >= len(self.combos_antes) or row >= len(self.combos_desp):
            return
            
        combo_antes = self.combos_antes[row]
        combo_desp = self.combos_desp[row]
        
        field_name = combo_antes.currentText()
        if not field_name: return
        
        idx_desp = combo_desp.findText(field_name, Qt.MatchExactly)
        if idx_desp == -1:
            # Reintento insensible a mayúsculas
            for j in range(combo_desp.count()):
                if combo_desp.itemText(j).upper() == field_name.upper():
                    idx_desp = j
                    break
                    
        if idx_desp != -1:
            combo_desp.setCurrentIndex(idx_desp)

    def get_defined_ranges(self):
        """Devuelve un diccionario con los rangos definidos por el usuario."""
        ranges = {}
        for label, (spin_min, spin_max) in self.range_widgets.items():
            vmin = spin_min.value()
            vmax = spin_max.value()
            # Mapear nombres de UI a nombres internos de MetricsCalculator
            key = label
            if "VIALE" in label: key = "VIAL"
            elif "AGUA" in label: key = "AGUA"
            elif "EDIF" in label: key = "EDIF" 
            elif "EXCLUIDO" in label: key = "EXCLUIDO"
            
            ranges[key] = range(vmin, vmax + 1)
        return ranges
    def get_ranges_for_save(self):
        """Devuelve los rangos REC en formato simple {label: {min, max}} para persistir."""
        ranges = {}
        for label, (spin_min, spin_max) in self.range_widgets.items():
            ranges[label] = {'min': spin_min.value(), 'max': spin_max.value()}
        return ranges

    def set_ranges(self, data):
        """Restaura los rangos REC a partir de un diccionario generado por get_ranges_for_save()."""
        if not data:
            return
        for label, (spin_min, spin_max) in self.range_widgets.items():
            values = data.get(label)
            if not values:
                continue
            vmin = values.get('min')
            vmax = values.get('max')
            if vmin is not None:
                spin_min.setValue(int(vmin))
            if vmax is not None:
                spin_max.setValue(int(vmax))

    def get_adit_mapping(self):
        """Devuelve el nombre del campo mapeado para aditamentos."""
        return self.txt_adit_field.text().strip()

    def get_field_mappings(self):
        """Devuelve los mapeos de campos configurados en la UI."""
        mapping = {'antes': {}, 'desp': {}}
        for i, concept in enumerate(self.concepts):
            std_key = self.concept_to_standard[concept]
            mapping['antes'][std_key] = self.combos_antes[i].currentText()
            mapping['desp'][std_key] = self.combos_desp[i].currentText()
        return mapping

    def get_special_owners(self):
        """Devuelve los propietarios especiales configurados con sus símbolos asignados."""
        special_owners = {}
        
        def validate_owner_id(value):
            """Valida que el ID sea numérico, no vacío, no nulo y diferente de 0."""
            if not value or value.strip() == '':
                return None
            try:
                num_val = int(value.strip())
                if num_val == 0:
                    return None
                return num_val
            except (ValueError, AttributeError):
                return None
        
        agader = validate_owner_id(self.txt_agader.text())
        masas = validate_owner_id(self.txt_masas.text())
        desconocidos = validate_owner_id(self.txt_desconocidos.text())
        
        # Asignar símbolos numéricos (se renderizarán como superíndices en el informe)
        if agader is not None:
            special_owners[agader] = {'name': 'AGADER', 'symbol': '1'}
        if masas is not None:
            special_owners[masas] = {'name': 'MASA COMÚN', 'symbol': '2'}
        if desconocidos is not None:
            special_owners[desconocidos] = {'name': 'DESCONOCIDOS', 'symbol': '3'}
        
        # Debug logging
        if self.log_callback:
            self.log_callback(f"<b>Propietarios Especiales Configurados:</b>")
            self.log_callback(f"  AGADER: {agader if agader is not None else 'NO CONFIGURADO'}")
            self.log_callback(f"  MASA COMÚN: {masas if masas is not None else 'NO CONFIGURADO'}")
            self.log_callback(f"  DESCONOCIDOS: {desconocidos if desconocidos is not None else 'NO CONFIGURADO'}")
            self.log_callback(f"  Diccionario final: {special_owners}")
            
        return special_owners

    def get_special_owners_for_save(self):
        """Devuelve los IDs de Propietarios Especiales tal cual estan
        escritos en la UI (sin validar), en formato simple para
        persistir en el fichero .anot."""
        return {
            'agader': self.txt_agader.text().strip(),
            'masas': self.txt_masas.text().strip(),
            'desconocidos': self.txt_desconocidos.text().strip()
        }

    def set_special_owners(self, data):
        """Restaura los campos de Propietarios Especiales (ficha 2) a
        partir de un diccionario generado por
        get_special_owners_for_save()."""
        if not data:
            return
        self.txt_agader.setText(str(data.get('agader', '') or ''))
        self.txt_masas.setText(str(data.get('masas', '') or ''))
        self.txt_desconocidos.setText(str(data.get('desconocidos', '') or ''))
