from PyQt5.QtWidgets import (QDockWidget, QTabWidget, QVBoxLayout, QHBoxLayout, QWidget, QPushButton,
                              QMessageBox, QLabel, QFileDialog, QStyle, QProgressBar, QApplication)
from PyQt5.QtCore import Qt, QUrl
from PyQt5.QtGui import QDesktopServices
import os
import json
from qgis.core import QgsProject
from qgis.gui import QgisInterface
from .components.tab_inputs import TabInputs
from .components.tab_mapping import TabMapping
from .components.tab_thresholds import TabThresholds
from .components.tab_audit import TabAudit
from ..core.analysis_engine import AnalysisEngine
from ..core.audit_service import AuditService

class AudiNOTDockManager:
    def __init__(self, iface: QgisInterface):
        self.iface = iface
        self.dock = None
        self.tabs = None
        
        self.tab_inputs = None
        self.tab_mapping = None
        self.tab_thresholds = None
        self.tab_audit = None

    def setup_ui(self):
        self.dock = QDockWidget("AudiNOT - Análisis de Variaciones", self.iface.mainWindow())
        self.dock.setObjectName("AudiNOTDockWidget")
        
        main_widget = QWidget()
        layout = QVBoxLayout(main_widget)

        header_layout = QHBoxLayout()
        lbl_title = QLabel("<b>AudiNOT</b>")
        lbl_title.setStyleSheet("font-size: 14px; color: #2c3e50;")
        
        btn_help = QPushButton("?")
        btn_help.setFixedSize(24, 24)
        btn_help.setToolTip("Abrir Manual de Ayuda")
        btn_help.setStyleSheet("""
            QPushButton {
                background-color: #3498db; 
                color: white; 
                border-radius: 12px; 
                font-weight: bold;
                border: none;
            }
            QPushButton:hover {
                background-color: #2980b9;
            }
        """)
        btn_help.clicked.connect(self.open_help)

        btn_close = QPushButton("Cerrar")
        btn_close.setToolTip(
            "Desconecta el plugin del GeoPackage y de los shapes/DXF referenciados "
            "(los quita del proyecto QGIS) y vacía las rutas de la Ficha 1, para "
            "poder mover, copiar o borrar esos ficheros en disco sin que queden "
            "bloqueados."
        )
        btn_close.setFixedHeight(24)
        btn_close.setStyleSheet("""
            QPushButton {
                background-color: #e74c3c;
                color: white;
                border-radius: 4px;
                font-weight: bold;
                border: none;
                padding: 0 10px;
            }
            QPushButton:hover {
                background-color: #c0392b;
            }
        """)
        btn_close.clicked.connect(self.on_click_close)

        header_layout.addWidget(lbl_title)
        header_layout.addStretch()
        header_layout.addWidget(btn_close)
        header_layout.addWidget(btn_help)
        
        layout.addLayout(header_layout)
        
        self.tabs = QTabWidget()
        
        self.tab_inputs = TabInputs(self.iface)
        self.tab_mapping = TabMapping(self.iface)
        self.tab_thresholds = TabThresholds(self.iface)
        self.tab_audit = TabAudit(self.iface)
        
        self.tab_mapping.set_log_callback(self.tab_inputs.add_log)
        self.tab_inputs.layerLoaded.connect(self.on_layer_loaded)
        self.tab_audit.requestActivateTab.connect(lambda: self.tabs.setCurrentWidget(self.tab_audit))

        # El botón "↻ Recargar" de la Ficha 4 no debe hacer nada si la
        # Ficha 1 no tiene todavía una carpeta de proyecto válida (ahí,
        # en su raíz -no en "RESULTADO"-, está el GeoPackage de
        # auditoría). Se deja deshabilitado mientras tanto (mejor UX que
        # dejarlo pulsable sin efecto), y además on_click_reload vuelve a
        # comprobarlo por su cuenta en el momento del clic como cinturón
        # de seguridad.
        self.tab_audit.set_output_dir_provider(lambda: self.tab_inputs.project_root_path)

        def _update_reload_button(_path=None):
            root = self.tab_inputs.project_root_path
            self.tab_audit.btn_reload.setEnabled(bool(root) and os.path.isdir(root))

        self.tab_inputs.file_output.fileChanged.connect(_update_reload_button)
        _update_reload_button()

        # Auto-carga de parametros.anot: si al configurar la carpeta de
        # proyecto (ver TabInputs.on_output_folder_changed) ya existe un
        # "parametros.anot" en su raíz -de una sesión anterior-, se carga
        # solo, sin que el usuario tenga que pulsar el botón de cargar.
        # Se lee project_root_path directamente (en vez del argumento del
        # signal) porque TabInputs puede reescribir el campo con
        # blockSignals al añadir "RESULTADO", así que el argumento no es
        # fiable para saber cuál es la raíz ya resuelta.
        def _auto_load_params(_path):
            root = self.tab_inputs.project_root_path
            if not root:
                return
            candidate = os.path.join(root, "parametros.anot")
            if os.path.exists(candidate):
                self._load_parameters_from_path(candidate, silent=True)
                return

            # No hay .anot propio todavía en la raíz del proyecto: si el
            # GeoPackage de auditoría de esta carpeta ya trae un snapshot
            # de los parámetros del último cálculo (ver
            # AuditService._write_parameters_table), se recuperan de ahí
            # -típico al abrir en OTRO equipo un GeoPackage recibido sin
            # el .anot al lado- y se deja creado parametros.anot en la
            # raíz para que quede como nuevo valor por defecto en
            # adelante. El GeoPackage vive en la propia raíz del
            # proyecto (no en "RESULTADO"), así que se usa 'root' aquí
            # directamente.
            if not os.path.isdir(root):
                return
            try:
                audit_service = AuditService(root, self.tab_inputs.add_log)
                parametros = audit_service.read_parameters()
            except Exception as e:
                self.tab_inputs.add_log(
                    f"<font color='orange'>AVISO: no se pudo leer parámetros del GeoPackage: {e}</font>")
                return
            if not parametros:
                return

            self.tab_thresholds.set_thresholds(parametros.get("thresholds"))
            self.tab_mapping.set_ranges(parametros.get("ranges"))
            self.tab_mapping.set_special_owners(parametros.get("special_owners"))

            try:
                self._save_parameters_to_path(candidate)
                self.tab_inputs.add_log(
                    f"<font color='green'>✓ Parámetros recuperados del GeoPackage de auditoría y "
                    f"guardados como valor por defecto en: {candidate}</font>"
                )
            except Exception as e:
                self.tab_inputs.add_log(
                    f"<font color='orange'>AVISO: no se pudo crear {candidate} a partir del "
                    f"GeoPackage: {e}</font>")

        self.tab_inputs.file_output.fileChanged.connect(_auto_load_params)

        # Botones de guardar/cargar parámetros: antes vivían aquí arriba,
        # junto a la ayuda; ahora se crean igual (misma lógica, en
        # save_parameters/load_parameters más abajo) pero se alojan
        # dentro de "1: Datos Entrada" -ver TabInputs.add_param_buttons-
        # por ser más coherente con el resto de configuración previa al
        # análisis.
        btn_save_params = QPushButton()
        btn_save_params.setIcon(self.dock.style().standardIcon(QStyle.SP_DialogSaveButton))
        btn_save_params.setFixedSize(28, 28)
        btn_save_params.setToolTip("Guardar parámetros (Umbrales, Rangos REC y Propietarios Especiales) en parametros.anot (por defecto, en la carpeta de proyecto)")
        btn_save_params.clicked.connect(self.save_parameters)

        btn_load_params = QPushButton()
        btn_load_params.setIcon(self.dock.style().standardIcon(QStyle.SP_DialogOpenButton))
        btn_load_params.setFixedSize(28, 28)
        btn_load_params.setToolTip("Cargar parámetros desde un fichero parametros.anot (se auto-carga al elegir la carpeta de proyecto, si ya existe)")
        btn_load_params.clicked.connect(self.load_parameters)

        self.tab_inputs.add_param_buttons(btn_save_params, btn_load_params)
        
        self.tabs.addTab(self.tab_inputs, "1: Datos Entrada")
        self.tabs.addTab(self.tab_mapping, "2: Mapeo Campos")
        self.tabs.addTab(self.tab_thresholds, "3: Umbrales")
        self.tabs.addTab(self.tab_audit, "4: Auditoría")

        # Si ya existe una carpeta de salida seleccionada (p.ej. al
        # reabrir el proyecto) y en ella hay un GeoPackage de auditoría
        # de una sesión anterior, se carga solo -- sin recalcular nada
        # -- para poder "volver a la Ficha 4 en cualquier momento".
        self.tabs.currentChanged.connect(self._on_tab_changed)
        
        layout.addWidget(self.tabs)
        
        btn_run = QPushButton("EJECUTAR ANÁLISIS")
        btn_run.setStyleSheet("background-color: #2c3e50; color: white; font-weight: bold; padding: 10px;")
        btn_run.clicked.connect(self.on_run_analysis)
        self.btn_run = btn_run

        # Barra de progreso + estado discretos, para que se vea que el
        # plugin está trabajando durante el análisis (que puede tardar) y
        # no dé sensación de estar colgado. Oculta en reposo.
        progress_container = QWidget()
        progress_layout = QVBoxLayout(progress_container)
        progress_layout.setContentsMargins(0, 4, 0, 0)
        progress_layout.setSpacing(2)

        self.lbl_progress = QLabel("")
        self.lbl_progress.setStyleSheet("color: #7f8c8d; font-size: 11px;")
        self.lbl_progress.setVisible(False)

        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.progress_bar.setFixedHeight(8)
        self.progress_bar.setTextVisible(False)
        self.progress_bar.setStyleSheet("""
            QProgressBar { background-color: #ecf0f1; border: none; border-radius: 4px; }
            QProgressBar::chunk { background-color: #3498db; border-radius: 4px; }
        """)
        self.progress_bar.setVisible(False)

        progress_layout.addWidget(self.lbl_progress)
        progress_layout.addWidget(self.progress_bar)

        # El botón y la barra de progreso viven DENTRO de la Ficha "1:
        # Datos Entrada" (a petición expresa), no debajo de las pestañas
        # como antes: así solo se ven mientras esa ficha está activa.
        self.tab_inputs.add_run_controls(btn_run, [progress_container])
        
        self.dock.setWidget(main_widget)
        # Ancho mínimo del dock: por debajo de este valor, el contenido de
        # la Ficha "4: Auditoría" (croquis + datos de interpretación) no
        # cabe sin recurrir a un scroll horizontal, que resulta muy
        # incómodo de usar. Al fijar un mínimo razonable, QGIS impide que
        # el usuario estreche el dock más de la cuenta, y así el resto del
        # layout (ver AspectRatioSvgWidget en tab_audit.py, que además ya
        # no exige el ancho nativo del SVG) siempre tiene sitio de sobra.
        self.dock.setMinimumWidth(420)
        self.iface.addDockWidget(Qt.RightDockWidgetArea, self.dock)
        self.dock.hide()

    def show(self):
        if self.dock:
            self.dock.show()

    def _on_tab_changed(self, index):
        """Carga perezosa de la Ficha 4: solo se intenta leer el
        GeoPackage de auditoría la primera vez que el usuario entra en
        esa pestaña (o tras un análisis nuevo), nunca al arrancar el
        plugin."""
        if self.tabs.widget(index) is not self.tab_audit:
            return
        if self.tab_audit.audit_service is not None:
            return  # ya está enlazada a una carpeta de salida
        output_dir = self.tab_inputs.project_root_path
        if output_dir and os.path.isdir(output_dir):
            self.tab_audit.set_output_dir(output_dir, self.tab_inputs.add_log)

    def on_layer_loaded(self, label, layer):
        self.tab_inputs.add_log(f"Gestor: Detectada carga de {label} - {layer.name()}")
        
        lbl = str(label).upper()
        if "ANTE" in lbl:
            self.tab_mapping.update_fields(layer, 1)
        elif "DESP" in lbl:
            self.tab_mapping.update_fields(layer, 2)
        else:
            self.tab_inputs.add_log(f"AVISO: Etiqueta {label} no reconocida para mapeo")

    def _progress_start(self):
        self.lbl_progress.setText("Preparando análisis...")
        self.lbl_progress.setVisible(True)
        self.progress_bar.setValue(0)
        self.progress_bar.setVisible(True)
        self.btn_run.setEnabled(False)
        self.btn_run.setText("Analizando…")
        QApplication.processEvents()

    def _progress_update(self, pct, text=""):
        try:
            pct = max(0, min(100, int(pct)))
        except (TypeError, ValueError):
            pct = self.progress_bar.value()
        self.progress_bar.setValue(pct)
        if text:
            self.lbl_progress.setText(text)
        # El análisis corre de forma síncrona en el hilo de UI: forzamos el
        # repintado para que la barra y el texto se vean actualizarse en
        # tiempo real en vez de quedar "congelados" hasta el final.
        QApplication.processEvents()

    def _progress_end(self):
        self.progress_bar.setVisible(False)
        self.lbl_progress.setVisible(False)
        self.btn_run.setEnabled(True)
        self.btn_run.setText("EJECUTAR ANÁLISIS")
        QApplication.processEvents()

    def _confirm_dialog(self, question):
        """confirm_callback para AnalysisEngine: única pieza de este dock
        que sabe abrir un QMessageBox, para que el motor (analysis_engine.py)
        siga sin depender de Qt más allá de log/progreso. Se usa hoy para
        la comprobación de continuidad de fincas antes de fusionar con
        AudiNOT_Auditoria/AudiNOT_Historial (ver AuditService.check_survival)."""
        reply = QMessageBox.question(
            self.dock,
            "AudiNOT — Comprobación de continuidad",
            question,
            QMessageBox.Yes | QMessageBox.No
        )
        return reply == QMessageBox.Yes

    def on_run_analysis(self):
        self.tab_inputs.clear_log()
        self.tab_inputs.add_log("<b>=== INICIANDO PROCESO DE ANÁLISIS ===</b>")
        
        # 1. Validar carpeta de salida
        output_dir = self.tab_inputs.file_output.filePath()
        self.tab_inputs.add_log(f"Carpeta de salida: {output_dir}")
        
        if not output_dir:
            self.tab_inputs.add_log("<font color='red'>ERROR: Debe seleccionar una carpeta de salida.</font>")
            return

        # 1b. Si la carpeta de proyecto no tiene todavía su propio
        # parametros.anot, se crea por defecto con los valores actuales.
        self._ensure_default_params_file()

        # 2. Recuperar capas desde QgsProject por ID (robusto frente a eliminaciones)
        layer_antes = None
        layer_desp = None

        if self.tab_inputs.layer_antes_id:
            layer_antes = QgsProject.instance().mapLayer(self.tab_inputs.layer_antes_id)
            self.tab_inputs.layer_antes = layer_antes

        if self.tab_inputs.layer_desp_id:
            layer_desp = QgsProject.instance().mapLayer(self.tab_inputs.layer_desp_id)
            self.tab_inputs.layer_desp = layer_desp

        self.tab_inputs.add_log(f"Capa ANTES: {layer_antes.name() if layer_antes else 'NO CARGADA'}")
        self.tab_inputs.add_log(f"Capa DESPUÉS: {layer_desp.name() if layer_desp else 'NO CARGADA'}")

        if not layer_antes or not layer_desp or not layer_antes.isValid() or not layer_desp.isValid():
            self.tab_inputs.add_log(
                "<font color='red'>ERROR: Las capas no están disponibles. "
                "Vuelva a seleccionar los archivos en la pestaña de entrada.</font>"
            )
            self.tab_inputs.layer_antes_id = None
            self.tab_inputs.layer_desp_id = None
            return

        # 3. Recolectar settings de filtrado
        filter_settings = self.tab_inputs.get_filter_settings()
        
        # 4. Construir settings completos
        settings = {
            'output_dir': output_dir,
            'project_root': self.tab_inputs.project_root_path,
            'restart_all': True,
            'layer_antes': layer_antes,
            'layer_desp': layer_desp,
            'dxf_antes_path': self.tab_inputs.dxf_antes_path,
            'dxf_desp_path': self.tab_inputs.dxf_desp_path,
            'owner_filter': filter_settings,
            'thresholds': self.tab_thresholds.get_thresholds(),
            'special_ranges': self.tab_mapping.get_defined_ranges(),
            'mapping': self.tab_mapping.get_field_mappings(),
            'adit_paths': self.tab_inputs.get_adit_paths(),
            'adit_mapping_field': self.tab_mapping.get_adit_mapping(),
            'special_owners': self.tab_mapping.get_special_owners(),
            # Snapshot para adjuntar al GeoPackage de auditoría (mismo
            # formato que el .anot) -- ver AuditService._write_parameters_table.
            'parametros_anot': self._current_parameters_dict()
        }
        
        # 5. Verificar selección activa en capa ANTES
        if layer_antes.selectedFeatureCount() > 0:
            reply = QMessageBox.question(
                self.dock,
                "Fincas Seleccionadas",
                f"Hay {layer_antes.selectedFeatureCount()} fincas seleccionadas en la capa ANTES.\n\n"
                "¿Desea restringir el análisis SOLAMENTE a esta selección?",
                QMessageBox.Yes | QMessageBox.No | QMessageBox.Cancel
            )
            
            if reply == QMessageBox.Cancel:
                self.tab_inputs.add_log("Proceso detenido por el usuario.")
                return
            
            if reply == QMessageBox.Yes:
                settings['only_selected'] = True
                self.tab_inputs.add_log(
                    f"Modo Selección: Procesando solo las {layer_antes.selectedFeatureCount()} fincas seleccionadas."
                )
            else:
                settings['only_selected'] = False
                self.tab_inputs.add_log("Modo Completo: Se analizará la capa entera ignorando la selección.")
        else:
            settings['only_selected'] = False

        # 6. Instanciar y ejecutar motor
        self.tab_inputs.add_log("Instanciando motor de análisis...")
        self._progress_start()
        try:
            engine = AnalysisEngine(
                self.iface, settings, self.tab_inputs.add_log, self._progress_update,
                confirm_callback=self._confirm_dialog
            )
            self.tab_inputs.add_log("Motor creado. Ejecutando...")
            engine.run()
            self.tab_inputs.add_log("<b>=== PROCESO COMPLETADO ===</b>")

            # Refrescar la Ficha "4: Auditoría" con el GeoPackage recién
            # actualizado por el motor (bloque aislado y aditivo: si el
            # motor no llegó a generar capa de auditoría por lo que sea,
            # last_output_dir queda a None y aquí simplemente no se hace
            # nada -- el resto del plugin sigue funcionando igual).
            if getattr(engine, 'last_output_dir', None):
                self.tab_audit.set_output_dir(engine.last_output_dir, self.tab_inputs.add_log)
        except Exception as e:
            self.tab_inputs.add_log(f"<font color='red'>ERROR CRÍTICO: {str(e)}</font>")
            import traceback
            self.tab_inputs.add_log(f"<font color='red'>{traceback.format_exc()}</font>")
        finally:
            # Pase lo que pase (éxito, error, o un return anticipado dentro
            # del motor), la barra de progreso debe volver a su estado de
            # reposo para no dejar la UI con aspecto de "colgada".
            self._progress_end()

    def _default_params_path(self):
        # Preferimos la raíz del proyecto (donde el usuario ya tiene sus
        # shapes/DXF y, ahora, "RESULTADO") como ubicación por defecto de
        # parametros.anot; si aún no hay carpeta de proyecto configurada,
        # caemos al directorio del propio plugin como antes.
        root = self.tab_inputs.project_root_path
        if root:
            return os.path.join(root, "parametros.anot")
        plugin_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        return os.path.join(plugin_dir, "parametros.anot")

    def _current_parameters_dict(self):
        """Umbrales/Rangos REC/Propietarios Especiales tal como están
        ahora mismo en la UI, en el mismo formato que usa el fichero
        .anot. Reutilizado por el guardado a .anot y por el snapshot que
        se adjunta al GeoPackage de auditoría (AuditService.export_or_update)."""
        return {
            "thresholds": self.tab_thresholds.get_thresholds(),
            "ranges": self.tab_mapping.get_ranges_for_save(),
            "special_owners": self.tab_mapping.get_special_owners_for_save()
        }

    def _save_parameters_to_path(self, path):
        """Vuelca Umbrales/Rangos REC/Propietarios Especiales a `path` en JSON. Lanza excepción si falla; no toca la UI."""
        data = self._current_parameters_dict()
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4, ensure_ascii=False)

    def _load_parameters_from_path(self, path, silent=False):
        """Lee `path` y rellena Umbrales/Rangos REC/Propietarios Especiales.
        silent=True: pensado para la auto-carga al configurar la carpeta de
        proyecto -solo deja constancia en el log, sin QMessageBox, para no
        interrumpir al usuario con un aviso en cada selección de carpeta."""
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception as e:
            msg = f"No se pudo leer el fichero:\n{str(e)}"
            if silent:
                self.tab_inputs.add_log(f"<font color='orange'>AVISO: no se pudo auto-cargar {path}: {e}</font>")
            else:
                QMessageBox.critical(self.dock, "Error al cargar", msg)
            return False

        self.tab_thresholds.set_thresholds(data.get("thresholds"))
        self.tab_mapping.set_ranges(data.get("ranges"))
        self.tab_mapping.set_special_owners(data.get("special_owners"))

        self.tab_inputs.add_log(f"Parámetros cargados correctamente desde: {path}")

        # Además de rellenar la UI, si ya existe un GeoPackage de auditoría
        # (de un cálculo anterior) en la carpeta de proyecto actual, se
        # actualiza también su tabla 'AudiNOT_Parametros' con estos mismos
        # parámetros recién cargados -si no, el .gpkg seguiría enseñando el
        # snapshot del último cálculo hasta el próximo "Ejecutar Análisis"
        # (ver AuditService.update_parameters_snapshot).
        self._sync_parameters_to_gpkg(data)

        if not silent:
            QMessageBox.information(self.dock, "Parámetros cargados", f"Parámetros cargados desde:\n{path}")
        return True

    def _sync_parameters_to_gpkg(self, parametros):
        """Si el GeoPackage de auditoría de la carpeta de proyecto actual ya
        existe (de un cálculo anterior), actualiza también su tabla
        'AudiNOT_Parametros' con `parametros` (mismo formato que el .anot:
        thresholds/ranges/special_owners), para que no se quede
        desactualizada al cargar un .anot distinto. Si el GeoPackage
        todavía no existe (no ha habido ningún cálculo en esta carpeta),
        no hace nada -se creará ya con los parámetros correctos en el
        primer "Ejecutar Análisis"."""
        root = self.tab_inputs.project_root_path
        if not root:
            return
        try:
            audit_service = AuditService(root, self.tab_inputs.add_log)
            if os.path.exists(audit_service.gpkg_path):
                audit_service.update_parameters_snapshot(parametros)
                self.tab_inputs.add_log(
                    "<font color='green'>✓ Tabla de parámetros del GeoPackage de auditoría "
                    "actualizada con los valores recién cargados.</font>"
                )
        except Exception as e:
            self.tab_inputs.add_log(
                f"<font color='orange'>AVISO: no se pudo actualizar la tabla de parámetros en el "
                f"GeoPackage de auditoría: {e}</font>")

    def save_parameters(self):
        """Guarda los Umbrales (ficha 3), los Rangos REC y los Propietarios Especiales (ficha 2) en un fichero JSON .anot"""
        default_path = self._default_params_path()
        path, _ = QFileDialog.getSaveFileName(
            self.dock,
            "Guardar parámetros",
            default_path,
            "Parámetros AudiNOT (*.anot)"
        )
        if not path:
            return
        if not path.lower().endswith(".anot"):
            path += ".anot"

        try:
            self._save_parameters_to_path(path)
            self.tab_inputs.add_log(f"Parámetros guardados correctamente en: {path}")
            QMessageBox.information(self.dock, "Parámetros guardados", f"Parámetros guardados en:\n{path}")
        except Exception as e:
            QMessageBox.critical(self.dock, "Error al guardar", f"No se pudo guardar el fichero:\n{str(e)}")

    def load_parameters(self):
        """Carga los Umbrales, Rangos REC y Propietarios Especiales desde un fichero JSON .anot y rellena las casillas."""
        default_path = self._default_params_path()
        start_path = default_path if os.path.exists(default_path) else ""
        path, _ = QFileDialog.getOpenFileName(
            self.dock,
            "Cargar parámetros",
            start_path,
            "Parámetros AudiNOT (*.anot)"
        )
        if not path:
            return

        self._load_parameters_from_path(path, silent=False)

    def _ensure_default_params_file(self):
        """Si al inicializar el análisis la carpeta de proyecto todavía no
        tiene un parametros.anot propio, se crea con los valores actuales
        de la UI -así queda disponible para auto-cargarse en la próxima
        sesión sin que el usuario tenga que acordarse de pulsar 'Guardar'."""
        root = self.tab_inputs.project_root_path
        if not root:
            return
        candidate = os.path.join(root, "parametros.anot")
        if os.path.exists(candidate):
            return
        try:
            self._save_parameters_to_path(candidate)
            self.tab_inputs.add_log(f"Creado parametros.anot por defecto en: {candidate}")
        except Exception as e:
            self.tab_inputs.add_log(f"<font color='orange'>AVISO: no se pudo crear parametros.anot por defecto: {e}</font>")

    def open_help(self):
        plugin_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        help_path = os.path.join(plugin_dir, 'ayuda.html')
        url = QUrl.fromLocalFile(help_path)
        QDesktopServices.openUrl(url)

    def on_click_close(self):
        """Botón 'Cerrar' (junto al de ayuda, arriba a la derecha del
        dock): desconecta completamente el plugin del GeoPackage de
        auditoría y de los shapes/DXF referenciados, para que el usuario
        pueda modificarlos, moverlos, copiarlos o borrarlos en disco sin
        que QGIS/AudiNOT los tenga bloqueados. También vacía los campos
        de la Ficha 1 que no tienen un valor por defecto (rutas de
        carpeta/ficheros, filtro de propietario); Umbrales, Rangos REC
        y Propietarios Especiales -que sí tienen valores por defecto- no
        se tocan."""
        resp = QMessageBox.question(
            self.dock, "Cerrar proyecto AudiNOT",
            "Esto desconectará el plugin del GeoPackage de auditoría y de los "
            "shapes/DXF cargados (se quitan del proyecto QGIS) y vaciará las rutas "
            "de la Ficha 1, para que puedas modificar, mover, copiar o borrar esos "
            "ficheros en disco sin que queden bloqueados.\n\n"
            "Los Umbrales, Rangos REC y Propietarios Especiales no se pierden.\n\n"
            "¿Continuar?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        if resp != QMessageBox.Yes:
            return

        # 1. Ficha 4: suelta self.layer/self.audit_service y quita del
        # proyecto la capa de auditoría, las de referencia y la de
        # historial (ver TabAudit.close_and_release).
        self.tab_audit.close_and_release()

        # 2. Ficha 1: quita ANTES/DESPUÉS del proyecto y vacía las rutas
        # (ver TabInputs.reset_to_empty).
        self.tab_inputs.reset_to_empty()

        # 3. Barrido de capas intermedias que el motor de análisis pudo
        # dejar en el proyecto durante un cálculo (ANTES-ok/DESPUES-ok,
        # DXF corregidos, uniones, aditamentos temporales...) y que no
        # quedan referenciadas desde ningún sitio una vez cerradas las
        # Fichas 1 y 4 -- se identifican por el patrón de nombre que les
        # ponen shp_service/dxf_service/adit_service, no por su origen,
        # así que este barrido es intencionadamente más amplio que el de
        # los dos pasos anteriores.
        stray_prefixes = ("ANTES-ok", "DESPUES-ok", "ANTES_temp", "DESPUES_temp",
                           "UNION_ANALISIS", "UNION", "ADIT_TEMP_")
        stray_ids = [
            lyr.id() for lyr in QgsProject.instance().mapLayers().values()
            if lyr.name().startswith(stray_prefixes)
        ]
        if stray_ids:
            QgsProject.instance().removeMapLayers(stray_ids)

        # 4. Fuerza la liberación de los datasources OGR/GDAL de las capas
        # recién quitadas del proyecto: removeMapLayers() basta casi
        # siempre, pero un gc.collect() explícito evita que una
        # referencia colgante retrase el cierre real del fichero en
        # disco (relevante sobre todo en Windows, donde un fichero .gpkg
        # con el handle todavía abierto no se puede mover/borrar/copiar).
        import gc
        gc.collect()

        self.tab_inputs.add_log(
            "<font color='green'>✓ Plugin desconectado del GeoPackage y de los ficheros "
            "referenciados. Ya puedes modificarlos libremente en disco.</font>"
        )