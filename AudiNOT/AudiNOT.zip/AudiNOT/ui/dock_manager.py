from PyQt5.QtWidgets import QDockWidget, QTabWidget, QVBoxLayout, QHBoxLayout, QWidget, QPushButton, QMessageBox, QLabel
from PyQt5.QtCore import Qt, QUrl
from PyQt5.QtGui import QDesktopServices
import os
from qgis.gui import QgisInterface
from .components.tab_inputs import TabInputs
from .components.tab_mapping import TabMapping
from .components.tab_thresholds import TabThresholds
from ..core.analysis_engine import AnalysisEngine

class AudiNOTDockManager:
    def __init__(self, iface: QgisInterface):
        self.iface = iface
        self.dock = None
        self.tabs = None
        
        # Componentes de pestañas
        self.tab_inputs = None
        self.tab_mapping = None
        self.tab_thresholds = None

    def setup_ui(self):
        """
        Configura el Dock Widget y las pestañas.
        """
        self.dock = QDockWidget("AudiNOT - Análisis de Variaciones", self.iface.mainWindow())
        self.dock.setObjectName("AudiNOTDockWidget")
        
        main_widget = QWidget()
        layout = QVBoxLayout(main_widget)

        # Header con Título y Botón de Ayuda
        header_layout = QHBoxLayout()
        lbl_title = QLabel("<b>AudiNOT</b>")
        lbl_title.setStyleSheet("font-size: 14px; color: #2c3e50;")
        
        btn_help = QPushButton("?")
        btn_help.setFixedSize(24, 24)
        btn_help.setToolTip("Abrir Manual de Ayuda")
        btn_help.setStyleSheet("""
            QPushButton {
                background-color: #3498db; 
                color: white; 
                border-radius: 12px; 
                font-weight: bold;
                border: none;
            }
            QPushButton:hover {
                background-color: #2980b9;
            }
        """)
        btn_help.clicked.connect(self.open_help)
        
        header_layout.addWidget(lbl_title)
        header_layout.addStretch()
        header_layout.addWidget(btn_help)
        
        layout.addLayout(header_layout)
        
        self.tabs = QTabWidget()
        
        # Inicializar pestañas
        self.tab_inputs = TabInputs(self.iface)
        self.tab_mapping = TabMapping(self.iface)
        self.tab_thresholds = TabThresholds(self.iface)
        
        # Establecer el callback de log para TabMapping
        self.tab_mapping.set_log_callback(self.tab_inputs.add_log)
        
        # Conectar señales para comunicación robusta
        self.tab_inputs.layerLoaded.connect(self.on_layer_loaded)
        
        self.tabs.addTab(self.tab_inputs, "1: Datos Entrada")
        self.tabs.addTab(self.tab_mapping, "2: Mapeo Campos")
        self.tabs.addTab(self.tab_thresholds, "3: Umbrales")
        
        layout.addWidget(self.tabs)
        
        # Botón principal de ejecución
        btn_run = QPushButton("EJECUTAR ANÁLISIS")
        btn_run.setStyleSheet("background-color: #2c3e50; color: white; font-weight: bold; padding: 10px;")
        btn_run.clicked.connect(self.on_run_analysis)
        layout.addWidget(btn_run)
        
        self.dock.setWidget(main_widget)
        self.iface.addDockWidget(Qt.RightDockWidgetArea, self.dock)
        self.dock.hide()

    def show(self):
        if self.dock:
            self.dock.show()

    def on_layer_loaded(self, label, layer):
        """
        Llamado desde TabInputs cuando se carga un archivo.
        """
        self.tab_inputs.add_log(f"Gestor: Detectada carga de {label} - {layer.name()}")
        
        # Normalizar label para evitar problemas de acentos o mayúsculas
        lbl = str(label).upper()
        if "ANTE" in lbl:
            self.tab_mapping.update_fields(layer, 1)
        elif "DESP" in lbl:
            self.tab_mapping.update_fields(layer, 2)
        else:
            # Los aditamentos no requieren sincronización de campos (es un textbox estático)
            pass
            self.tab_inputs.add_log(f"AVISO: Etiqueta {label} no reconocida para mapeo")

    def on_run_analysis(self):
        """
        Orquestador del proceso principal con confirmación de reinicio.
        """
        # Limpiar log al inicio de cada análisis
        self.tab_inputs.clear_log()
        
        self.tab_inputs.add_log("<b>=== INICIANDO PROCESO DE ANÁLISIS ===</b>")
        
        # 1. Validaciones básicas
        output_dir = self.tab_inputs.file_output.filePath()
        self.tab_inputs.add_log(f"Carpeta de salida: {output_dir}")
        
        if not output_dir:
            self.tab_inputs.add_log("<font color='red'>ERROR: Debe seleccionar una carpeta de salida.</font>")
            return

        layer_antes = self.tab_inputs.layer_antes
        layer_desp = self.tab_inputs.layer_desp
        
        self.tab_inputs.add_log(f"Capa ANTES: {layer_antes.name() if layer_antes else 'NO CARGADA'}")
        self.tab_inputs.add_log(f"Capa DESPUÉS: {layer_desp.name() if layer_desp else 'NO CARGADA'}")
        
        if not layer_antes or not layer_desp or not layer_antes.isValid() or not layer_desp.isValid():
            self.tab_inputs.add_log("<font color='red'>ERROR: Las capas de entrada no son válidas. Asegúrese de cargar ANTES y DESPUÉS.</font>")
            return

        # Recolectar settings de filtrado
        filter_settings = self.tab_inputs.get_filter_settings()
        
        # 2. Recolectar settings (siempre REINICIAR TODO)
        settings = {
            'output_dir': output_dir,
            'restart_all': True,  # Siempre reiniciar
            'layer_antes': layer_antes,  # Capa original
            'layer_desp': layer_desp,    # Capa original
            'dxf_antes_path': self.tab_inputs.dxf_antes_path,
            'dxf_desp_path': self.tab_inputs.dxf_desp_path,
            'owner_filter': filter_settings,
            'thresholds': self.tab_thresholds.get_thresholds(), # Mapear umbrales de la UI
        # Recolectar rangos definidos por usuario
            'special_ranges': self.tab_mapping.get_defined_ranges(),
        # Recolectar mapeo de campos (CRÍTICO)
            'mapping': self.tab_mapping.get_field_mappings(),
        # Aditamentos (Rutas y Mapeo)
            'adit_paths': self.tab_inputs.get_adit_paths(),
            'adit_mapping_field': self.tab_mapping.get_adit_mapping(),
        # Propietarios Especiales
            'special_owners': self.tab_mapping.get_special_owners()
        }
        
        # Verificar selección en capa ANTES
        if layer_antes.selectedFeatureCount() > 0:
            reply = QMessageBox.question(
                self.dock,
                "Fincas Seleccionadas",
                f"Hay {layer_antes.selectedFeatureCount()} fincas seleccionadas en la capa ANTES.\n\n"
                "¿Desea restringir el análisis SOLAMENTE a esta selección?",
                QMessageBox.Yes | QMessageBox.No | QMessageBox.Cancel
            )
            
            if reply == QMessageBox.Cancel:
                self.tab_inputs.add_log("Proceso detenido por el usuario.")
                return
            
            if reply == QMessageBox.Yes:
                settings['only_selected'] = True
                self.tab_inputs.add_log(f"Modo Selección: Procesando solo las {layer_antes.selectedFeatureCount()} fincas seleccionadas.")
            else:
                settings['only_selected'] = False
                self.tab_inputs.add_log("Modo Completo: Se analizará la capa entera ignorando la selección.")
        else:
             settings['only_selected'] = False

        # 3. Instanciar y ejecutar motor
        self.tab_inputs.add_log("Instanciando motor de análisis...")
        try:
            engine = AnalysisEngine(self.iface, settings, self.tab_inputs.add_log)
            self.tab_inputs.add_log("Motor creado. Ejecutando...")
            engine.run()
            self.tab_inputs.add_log("<b>=== PROCESO COMPLETADO ===</b>")
        except Exception as e:
            self.tab_inputs.add_log(f"<font color='red'>ERROR CRÍTICO: {str(e)}</font>")
            import traceback
            self.tab_inputs.add_log(f"<font color='red'>{traceback.format_exc()}</font>")

    def open_help(self):
        """Abre el archivo de ayuda HTML en el navegador por defecto."""
        # Ruta base del plugin (subiendo desde ui/)
        plugin_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        help_path = os.path.join(plugin_dir, 'ayuda.html')
        
        url = QUrl.fromLocalFile(help_path)
        QDesktopServices.openUrl(url)
