from PyQt5.QtWidgets import (QDockWidget, QTabWidget, QVBoxLayout, QHBoxLayout, QWidget, QPushButton,
                              QMessageBox, QLabel, QFileDialog, QStyle, QProgressBar, QApplication)
from PyQt5.QtCore import Qt, QUrl
from PyQt5.QtGui import QDesktopServices
import os
import json
from qgis.core import QgsProject
from qgis.gui import QgisInterface
from .components.tab_inputs import TabInputs
from .components.tab_mapping import TabMapping
from .components.tab_thresholds import TabThresholds
from ..core.analysis_engine import AnalysisEngine

class AudiNOTDockManager:
    def __init__(self, iface: QgisInterface):
        self.iface = iface
        self.dock = None
        self.tabs = None
        
        self.tab_inputs = None
        self.tab_mapping = None
        self.tab_thresholds = None

    def setup_ui(self):
        self.dock = QDockWidget("AudiNOT - Análisis de Variaciones", self.iface.mainWindow())
        self.dock.setObjectName("AudiNOTDockWidget")
        
        main_widget = QWidget()
        layout = QVBoxLayout(main_widget)

        header_layout = QHBoxLayout()
        lbl_title = QLabel("<b>AudiNOT</b>")
        lbl_title.setStyleSheet("font-size: 14px; color: #2c3e50;")
        
        btn_help = QPushButton("?")
        btn_help.setFixedSize(24, 24)
        btn_help.setToolTip("Abrir Manual de Ayuda")
        btn_help.setStyleSheet("""
            QPushButton {
                background-color: #3498db; 
                color: white; 
                border-radius: 12px; 
                font-weight: bold;
                border: none;
            }
            QPushButton:hover {
                background-color: #2980b9;
            }
        """)
        btn_help.clicked.connect(self.open_help)
        
        btn_save_params = QPushButton()
        btn_save_params.setIcon(self.dock.style().standardIcon(QStyle.SP_DialogSaveButton))
        btn_save_params.setFixedSize(28, 28)
        btn_save_params.setToolTip("Guardar parámetros (Umbrales, Rangos REC y Propietarios Especiales) en parametros.anot")
        btn_save_params.clicked.connect(self.save_parameters)

        btn_load_params = QPushButton()
        btn_load_params.setIcon(self.dock.style().standardIcon(QStyle.SP_DialogOpenButton))
        btn_load_params.setFixedSize(28, 28)
        btn_load_params.setToolTip("Cargar parámetros desde un fichero parametros.anot")
        btn_load_params.clicked.connect(self.load_parameters)

        header_layout.addWidget(lbl_title)
        header_layout.addStretch()
        header_layout.addWidget(btn_save_params)
        header_layout.addWidget(btn_load_params)
        header_layout.addWidget(btn_help)
        
        layout.addLayout(header_layout)
        
        self.tabs = QTabWidget()
        
        self.tab_inputs = TabInputs(self.iface)
        self.tab_mapping = TabMapping(self.iface)
        self.tab_thresholds = TabThresholds(self.iface)
        
        self.tab_mapping.set_log_callback(self.tab_inputs.add_log)
        self.tab_inputs.layerLoaded.connect(self.on_layer_loaded)
        
        self.tabs.addTab(self.tab_inputs, "1: Datos Entrada")
        self.tabs.addTab(self.tab_mapping, "2: Mapeo Campos")
        self.tabs.addTab(self.tab_thresholds, "3: Umbrales")
        
        layout.addWidget(self.tabs)
        
        btn_run = QPushButton("EJECUTAR ANÁLISIS")
        btn_run.setStyleSheet("background-color: #2c3e50; color: white; font-weight: bold; padding: 10px;")
        btn_run.clicked.connect(self.on_run_analysis)
        layout.addWidget(btn_run)
        self.btn_run = btn_run

        # Barra de progreso + estado discretos, para que se vea que el
        # plugin está trabajando durante el análisis (que puede tardar) y
        # no dé sensación de estar colgado. Oculta en reposo.
        progress_layout = QVBoxLayout()
        progress_layout.setContentsMargins(0, 4, 0, 0)
        progress_layout.setSpacing(2)

        self.lbl_progress = QLabel("")
        self.lbl_progress.setStyleSheet("color: #7f8c8d; font-size: 11px;")
        self.lbl_progress.setVisible(False)

        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.progress_bar.setFixedHeight(8)
        self.progress_bar.setTextVisible(False)
        self.progress_bar.setStyleSheet("""
            QProgressBar { background-color: #ecf0f1; border: none; border-radius: 4px; }
            QProgressBar::chunk { background-color: #3498db; border-radius: 4px; }
        """)
        self.progress_bar.setVisible(False)

        progress_layout.addWidget(self.lbl_progress)
        progress_layout.addWidget(self.progress_bar)
        layout.addLayout(progress_layout)
        
        self.dock.setWidget(main_widget)
        self.iface.addDockWidget(Qt.RightDockWidgetArea, self.dock)
        self.dock.hide()

    def show(self):
        if self.dock:
            self.dock.show()

    def on_layer_loaded(self, label, layer):
        self.tab_inputs.add_log(f"Gestor: Detectada carga de {label} - {layer.name()}")
        
        lbl = str(label).upper()
        if "ANTE" in lbl:
            self.tab_mapping.update_fields(layer, 1)
        elif "DESP" in lbl:
            self.tab_mapping.update_fields(layer, 2)
        else:
            self.tab_inputs.add_log(f"AVISO: Etiqueta {label} no reconocida para mapeo")

    def _progress_start(self):
        self.lbl_progress.setText("Preparando análisis...")
        self.lbl_progress.setVisible(True)
        self.progress_bar.setValue(0)
        self.progress_bar.setVisible(True)
        self.btn_run.setEnabled(False)
        self.btn_run.setText("Analizando…")
        QApplication.processEvents()

    def _progress_update(self, pct, text=""):
        try:
            pct = max(0, min(100, int(pct)))
        except (TypeError, ValueError):
            pct = self.progress_bar.value()
        self.progress_bar.setValue(pct)
        if text:
            self.lbl_progress.setText(text)
        # El análisis corre de forma síncrona en el hilo de UI: forzamos el
        # repintado para que la barra y el texto se vean actualizarse en
        # tiempo real en vez de quedar "congelados" hasta el final.
        QApplication.processEvents()

    def _progress_end(self):
        self.progress_bar.setVisible(False)
        self.lbl_progress.setVisible(False)
        self.btn_run.setEnabled(True)
        self.btn_run.setText("EJECUTAR ANÁLISIS")
        QApplication.processEvents()

    def on_run_analysis(self):
        self.tab_inputs.clear_log()
        self.tab_inputs.add_log("<b>=== INICIANDO PROCESO DE ANÁLISIS ===</b>")
        
        # 1. Validar carpeta de salida
        output_dir = self.tab_inputs.file_output.filePath()
        self.tab_inputs.add_log(f"Carpeta de salida: {output_dir}")
        
        if not output_dir:
            self.tab_inputs.add_log("<font color='red'>ERROR: Debe seleccionar una carpeta de salida.</font>")
            return

        # 2. Recuperar capas desde QgsProject por ID (robusto frente a eliminaciones)
        layer_antes = None
        layer_desp = None

        if self.tab_inputs.layer_antes_id:
            layer_antes = QgsProject.instance().mapLayer(self.tab_inputs.layer_antes_id)
            self.tab_inputs.layer_antes = layer_antes

        if self.tab_inputs.layer_desp_id:
            layer_desp = QgsProject.instance().mapLayer(self.tab_inputs.layer_desp_id)
            self.tab_inputs.layer_desp = layer_desp

        self.tab_inputs.add_log(f"Capa ANTES: {layer_antes.name() if layer_antes else 'NO CARGADA'}")
        self.tab_inputs.add_log(f"Capa DESPUÉS: {layer_desp.name() if layer_desp else 'NO CARGADA'}")

        if not layer_antes or not layer_desp or not layer_antes.isValid() or not layer_desp.isValid():
            self.tab_inputs.add_log(
                "<font color='red'>ERROR: Las capas no están disponibles. "
                "Vuelva a seleccionar los archivos en la pestaña de entrada.</font>"
            )
            self.tab_inputs.layer_antes_id = None
            self.tab_inputs.layer_desp_id = None
            return

        # 3. Recolectar settings de filtrado
        filter_settings = self.tab_inputs.get_filter_settings()
        
        # 4. Construir settings completos
        settings = {
            'output_dir': output_dir,
            'restart_all': True,
            'layer_antes': layer_antes,
            'layer_desp': layer_desp,
            'dxf_antes_path': self.tab_inputs.dxf_antes_path,
            'dxf_desp_path': self.tab_inputs.dxf_desp_path,
            'owner_filter': filter_settings,
            'thresholds': self.tab_thresholds.get_thresholds(),
            'special_ranges': self.tab_mapping.get_defined_ranges(),
            'mapping': self.tab_mapping.get_field_mappings(),
            'adit_paths': self.tab_inputs.get_adit_paths(),
            'adit_mapping_field': self.tab_mapping.get_adit_mapping(),
            'special_owners': self.tab_mapping.get_special_owners()
        }
        
        # 5. Verificar selección activa en capa ANTES
        if layer_antes.selectedFeatureCount() > 0:
            reply = QMessageBox.question(
                self.dock,
                "Fincas Seleccionadas",
                f"Hay {layer_antes.selectedFeatureCount()} fincas seleccionadas en la capa ANTES.\n\n"
                "¿Desea restringir el análisis SOLAMENTE a esta selección?",
                QMessageBox.Yes | QMessageBox.No | QMessageBox.Cancel
            )
            
            if reply == QMessageBox.Cancel:
                self.tab_inputs.add_log("Proceso detenido por el usuario.")
                return
            
            if reply == QMessageBox.Yes:
                settings['only_selected'] = True
                self.tab_inputs.add_log(
                    f"Modo Selección: Procesando solo las {layer_antes.selectedFeatureCount()} fincas seleccionadas."
                )
            else:
                settings['only_selected'] = False
                self.tab_inputs.add_log("Modo Completo: Se analizará la capa entera ignorando la selección.")
        else:
            settings['only_selected'] = False

        # 6. Instanciar y ejecutar motor
        self.tab_inputs.add_log("Instanciando motor de análisis...")
        self._progress_start()
        try:
            engine = AnalysisEngine(self.iface, settings, self.tab_inputs.add_log, self._progress_update)
            self.tab_inputs.add_log("Motor creado. Ejecutando...")
            engine.run()
            self.tab_inputs.add_log("<b>=== PROCESO COMPLETADO ===</b>")
        except Exception as e:
            self.tab_inputs.add_log(f"<font color='red'>ERROR CRÍTICO: {str(e)}</font>")
            import traceback
            self.tab_inputs.add_log(f"<font color='red'>{traceback.format_exc()}</font>")
        finally:
            # Pase lo que pase (éxito, error, o un return anticipado dentro
            # del motor), la barra de progreso debe volver a su estado de
            # reposo para no dejar la UI con aspecto de "colgada".
            self._progress_end()

    def _default_params_path(self):
        plugin_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        return os.path.join(plugin_dir, "parametros.anot")

    def save_parameters(self):
        """Guarda los Umbrales (ficha 3), los Rangos REC y los Propietarios Especiales (ficha 2) en un fichero JSON .anot"""
        default_path = self._default_params_path()
        path, _ = QFileDialog.getSaveFileName(
            self.dock,
            "Guardar parámetros",
            default_path,
            "Parámetros AudiNOT (*.anot)"
        )
        if not path:
            return
        if not path.lower().endswith(".anot"):
            path += ".anot"

        data = {
            "thresholds": self.tab_thresholds.get_thresholds(),
            "ranges": self.tab_mapping.get_ranges_for_save(),
            "special_owners": self.tab_mapping.get_special_owners_for_save()
        }

        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=4, ensure_ascii=False)
            self.tab_inputs.add_log(f"Parámetros guardados correctamente en: {path}")
            QMessageBox.information(self.dock, "Parámetros guardados", f"Parámetros guardados en:\n{path}")
        except Exception as e:
            QMessageBox.critical(self.dock, "Error al guardar", f"No se pudo guardar el fichero:\n{str(e)}")

    def load_parameters(self):
        """Carga los Umbrales, Rangos REC y Propietarios Especiales desde un fichero JSON .anot y rellena las casillas."""
        default_path = self._default_params_path()
        start_path = default_path if os.path.exists(default_path) else ""
        path, _ = QFileDialog.getOpenFileName(
            self.dock,
            "Cargar parámetros",
            start_path,
            "Parámetros AudiNOT (*.anot)"
        )
        if not path:
            return

        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception as e:
            QMessageBox.critical(self.dock, "Error al cargar", f"No se pudo leer el fichero:\n{str(e)}")
            return

        self.tab_thresholds.set_thresholds(data.get("thresholds"))
        self.tab_mapping.set_ranges(data.get("ranges"))
        self.tab_mapping.set_special_owners(data.get("special_owners"))

        self.tab_inputs.add_log(f"Parámetros cargados correctamente desde: {path}")
        QMessageBox.information(self.dock, "Parámetros cargados", f"Parámetros cargados desde:\n{path}")

    def open_help(self):
        plugin_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        help_path = os.path.join(plugin_dir, 'ayuda.html')
        url = QUrl.fromLocalFile(help_path)
        QDesktopServices.openUrl(url)