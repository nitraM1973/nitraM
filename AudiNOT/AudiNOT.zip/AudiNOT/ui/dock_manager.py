from PyQt5.QtWidgets import (QDockWidget, QTabWidget, QVBoxLayout, QHBoxLayout, QWidget, QPushButton,
                              QMessageBox, QLabel, QFileDialog, QStyle, QProgressBar, QApplication)
from PyQt5.QtCore import Qt, QUrl
from PyQt5.QtGui import QDesktopServices
import os
import json
from qgis.core import QgsProject
from qgis.gui import QgisInterface
from .components.tab_inputs import TabInputs
from .components.tab_mapping import TabMapping
from .components.tab_thresholds import TabThresholds
from .components.tab_audit import TabAudit
from .components.tab_revision import TabRevision
from .components.tab_admin import TabAdmin
from ..core.analysis_engine import AnalysisEngine
from ..core.audit_service import (
    AuditService, ROLE_DEFAULT,
    HISTORIAL_LAYER_NAME, ADMIN_LAYER_NAME, CHECKPOINTS_LAYER_NAME,
)

class AudiNOTDockManager:
    # Único mapa de "qué se apaga y qué se enciende" cuando el rol activo
    # es Revisor 2 (ver aplicar_restricciones_por_rol, más abajo -- ese
    # método es el ÚNICO sitio del plugin que consulta esta tabla; ninguna
    # pestaña decide nada de restricciones por su cuenta).
    #   'widgets'  -> pide layout.get_restricted_widgets() y los deshabilita
    #   'readonly' -> pide layout.get_restricted_widgets() y los pone en
    #                 solo lectura (setReadOnly), sin ocultar la ficha
    #   'pestana'  -> deshabilita la pestaña entera (QTabWidget)
    #   'widget'   -> deshabilita directamente el propio objeto
    #   None       -> sin restricción de acceso
    RESTRICCIONES_REVISOR2 = {
        'tab_inputs': 'widgets',
        'tab_mapping': 'pestana',
        'tab_thresholds': 'readonly',
        'tab_audit': None,
        # Ficha "5: Revisión" (Fase 2): sin restricción de acceso para
        # ningún rol -- puramente de lectura/agregación.
        'tab_revision': None,
        'btn_run': 'widget',
    }

    TOOLTIP_REVISOR2 = (
        "No disponible en rol Revisor 2. Cambia de rol en la pestaña 6: "
        "Administración si tienes permiso."
    )

    # Tablas "internas" del GeoPackage de auditoría (histórico de
    # cambios, rol activo, checkpoints de revisión) que NUNCA se cargan
    # por defecto en el panel de Capas por iniciativa de su propia
    # ficha -- es este dock, y solo este dock, quien decide si se
    # añaden o no, según el rol activo (ver
    # _sync_tablas_internas_por_rol, llamado desde
    # aplicar_restricciones_por_rol). Revisor 1 (el titular del
    # expediente) las ve siempre que haya capa de auditoría cargada;
    # Revisor 2 (revisor externo, p.ej. el técnico provincial) nunca --
    # si ya estaban en el proyecto (por ejemplo, el .gpkg se abrió antes
    # con rol Revisor 1), se retiran sin ningún aviso al pasar a
    # Revisor 2. Cada tupla es (nombre_de_la_tabla_en_el_gpkg,
    # metodo_de_AuditService_que_la_abre).
    TABLAS_INTERNAS_SOLO_REVISOR1 = (
        (HISTORIAL_LAYER_NAME, 'load_historial_layer'),
        (ADMIN_LAYER_NAME, 'load_admin_layer'),
        (CHECKPOINTS_LAYER_NAME, 'load_checkpoints_layer'),
    )

    def __init__(self, iface: QgisInterface):
        self.iface = iface
        self.dock = None
        self.tabs = None
        
        self.tab_inputs = None
        self.tab_mapping = None
        self.tab_thresholds = None
        self.tab_audit = None
        self.tab_revision = None
        self.tab_admin = None
        self.lbl_role = None
        self.btn_run = None

    def setup_ui(self):
        self.dock = QDockWidget("AudiNOT - Análisis de Variaciones", self.iface.mainWindow())
        self.dock.setObjectName("AudiNOTDockWidget")
        
        main_widget = QWidget()
        layout = QVBoxLayout(main_widget)

        header_layout = QHBoxLayout()
        lbl_title = QLabel("<b>AudiNOT</b>")
        lbl_title.setStyleSheet("font-size: 14px; color: #2c3e50;")

        # Indicador del rol activo (REVISOR 1 / REVISOR 2), leído de
        # AudiNOT_Admin dentro del propio GeoPackage de auditoría. Solo se
        # actualiza desde aplicar_restricciones_por_rol -- nunca de forma
        # independiente -- para que nunca pueda quedar desincronizado de
        # las restricciones que ese mismo método aplica al resto de la UI.
        self.lbl_role = QLabel("REVISOR 2")
        self.lbl_role.setStyleSheet(
            "font-size: 11px; font-weight: bold; color: white; "
            "background-color: #e67e22; padding: 2px 6px; border-radius: 3px;"
        )

        btn_help = QPushButton("?")
        btn_help.setFixedSize(24, 24)
        btn_help.setToolTip("Abrir Manual de Ayuda")
        btn_help.setStyleSheet("""
            QPushButton {
                background-color: #3498db; 
                color: white; 
                border-radius: 12px; 
                font-weight: bold;
                border: none;
            }
            QPushButton:hover {
                background-color: #2980b9;
            }
        """)
        btn_help.clicked.connect(self.open_help)

        btn_close = QPushButton("Cerrar")
        btn_close.setToolTip(
            "Desconecta el plugin del GeoPackage y de los shapes/DXF referenciados "
            "(los quita del proyecto QGIS) y vacía las rutas de la Ficha 1, para "
            "poder mover, copiar o borrar esos ficheros en disco sin que queden "
            "bloqueados."
        )
        btn_close.setFixedHeight(24)
        btn_close.setStyleSheet("""
            QPushButton {
                background-color: #e74c3c;
                color: white;
                border-radius: 4px;
                font-weight: bold;
                border: none;
                padding: 0 10px;
            }
            QPushButton:hover {
                background-color: #c0392b;
            }
        """)
        btn_close.clicked.connect(self.on_click_close)

        header_layout.addWidget(lbl_title)
        header_layout.addWidget(self.lbl_role)
        header_layout.addStretch()
        header_layout.addWidget(btn_close)
        header_layout.addWidget(btn_help)
        
        layout.addLayout(header_layout)
        
        self.tabs = QTabWidget()
        
        self.tab_inputs = TabInputs(self.iface)
        self.tab_mapping = TabMapping(self.iface)
        self.tab_thresholds = TabThresholds(self.iface)
        self.tab_audit = TabAudit(self.iface)
        self.tab_revision = TabRevision(self.iface)
        self.tab_admin = TabAdmin(self.iface)
        
        self.tab_mapping.set_log_callback(self.tab_inputs.add_log)
        self.tab_inputs.layerLoaded.connect(self.on_layer_loaded)
        self.tab_audit.requestActivateTab.connect(lambda: self.tabs.setCurrentWidget(self.tab_audit))

        # Ficha 5: reutiliza el AuditService y la capa AUDIT_LAYER_NAME ya
        # abiertos por la Ficha 4 (nunca una segunda conexión al mismo
        # .gpkg, ver docstring de TabRevision) y el mismo cálculo de rol
        # activo que usa aplicar_restricciones_por_rol.
        self.tab_revision.set_audit_service_provider(lambda: self.tab_audit.audit_service)
        self.tab_revision.set_audit_layer_provider(lambda: self.tab_audit.layer)
        self.tab_revision.set_role_provider(self._current_role)
        # Evita que el zoom-a-finca de la Ficha 5 (que selecciona en la
        # capa compartida solo para centrar el lienzo) dispare el salto
        # automático a la Ficha "4: Auditoría" -- ver
        # TabRevision._zoom_to / TabAudit.set_suppress_activate.
        self.tab_revision.set_suppress_activate_provider(self.tab_audit.set_suppress_activate)

        # Ficha 6: igual patrón que set_output_dir_provider de la Ficha 4
        # -- el GeoPackage de auditoría vive en la raíz de proyecto de la
        # Ficha 1, no en "RESULTADO". roleChanged: único punto de entrada
        # (b) de aplicar_restricciones_por_rol (el (a) es la carga/recarga
        # del gpkg, más abajo).
        self.tab_admin.set_output_dir_provider(lambda: self.tab_inputs.project_root_path)
        self.tab_admin.roleChanged.connect(lambda _rol: self.aplicar_restricciones_por_rol())

        # El botón "↻ Recargar" de la Ficha 4 no debe hacer nada si la
        # Ficha 1 no tiene todavía una carpeta de proyecto válida (ahí,
        # en su raíz -no en "RESULTADO"-, está el GeoPackage de
        # auditoría). Se deja deshabilitado mientras tanto (mejor UX que
        # dejarlo pulsable sin efecto), y además on_click_reload vuelve a
        # comprobarlo por su cuenta en el momento del clic como cinturón
        # de seguridad.
        self.tab_audit.set_output_dir_provider(lambda: self.tab_inputs.project_root_path)

        def _update_reload_button(_path=None):
            root = self.tab_inputs.project_root_path
            self.tab_audit.btn_reload.setEnabled(bool(root) and os.path.isdir(root))
            # Punto (b) de aplicar_restricciones_por_rol: la carpeta de
            # salida de la Ficha 1 acaba de cambiar -- si había un cambio
            # de rol pendiente de la Ficha 6 (sin carpeta todavía), es el
            # momento de intentar trasladarlo al GeoPackage de la nueva
            # carpeta.
            self.aplicar_restricciones_por_rol()

        self.tab_inputs.file_output.fileChanged.connect(_update_reload_button)
        _update_reload_button()

        # Auto-carga de parametros.anot: si al configurar la carpeta de
        # proyecto (ver TabInputs.on_output_folder_changed) ya existe un
        # "parametros.anot" en su raíz -de una sesión anterior-, se carga
        # solo, sin que el usuario tenga que pulsar el botón de cargar.
        # Se lee project_root_path directamente (en vez del argumento del
        # signal) porque TabInputs puede reescribir el campo con
        # blockSignals al añadir "RESULTADO", así que el argumento no es
        # fiable para saber cuál es la raíz ya resuelta.
        def _auto_load_params(_path):
            root = self.tab_inputs.project_root_path
            if not root:
                return
            candidate = os.path.join(root, "parametros.anot")
            if os.path.exists(candidate):
                self._load_parameters_from_path(candidate, silent=True)
                return

            # No hay .anot propio todavía en la raíz del proyecto: si el
            # GeoPackage de auditoría de esta carpeta ya trae un snapshot
            # de los parámetros del último cálculo (ver
            # AuditService._write_parameters_table), se recuperan de ahí
            # -típico al abrir en OTRO equipo un GeoPackage recibido sin
            # el .anot al lado- y se deja creado parametros.anot en la
            # raíz para que quede como nuevo valor por defecto en
            # adelante. El GeoPackage vive en la propia raíz del
            # proyecto (no en "RESULTADO"), así que se usa 'root' aquí
            # directamente.
            if not os.path.isdir(root):
                return
            try:
                audit_service = AuditService(root, self.tab_inputs.add_log)
                parametros = audit_service.read_parameters()
            except Exception as e:
                self.tab_inputs.add_log(
                    f"<font color='orange'>AVISO: no se pudo leer parámetros del GeoPackage: {e}</font>")
                return
            if not parametros:
                return

            self.tab_thresholds.set_thresholds(parametros.get("thresholds"))
            self.tab_mapping.set_ranges(parametros.get("ranges"))
            self.tab_mapping.set_special_owners(parametros.get("special_owners"))

            try:
                self._save_parameters_to_path(candidate)
                self.tab_inputs.add_log(
                    f"<font color='green'>✓ Parámetros recuperados del GeoPackage de auditoría y "
                    f"guardados como valor por defecto en: {candidate}</font>"
                )
            except Exception as e:
                self.tab_inputs.add_log(
                    f"<font color='orange'>AVISO: no se pudo crear {candidate} a partir del "
                    f"GeoPackage: {e}</font>")

        self.tab_inputs.file_output.fileChanged.connect(_auto_load_params)

        # Botones de guardar/cargar parámetros: antes vivían aquí arriba,
        # junto a la ayuda; ahora se crean igual (misma lógica, en
        # save_parameters/load_parameters más abajo) pero se alojan
        # dentro de "1: Datos Entrada" -ver TabInputs.add_param_buttons-
        # por ser más coherente con el resto de configuración previa al
        # análisis.
        btn_save_params = QPushButton()
        btn_save_params.setIcon(self.dock.style().standardIcon(QStyle.SP_DialogSaveButton))
        btn_save_params.setFixedSize(28, 28)
        btn_save_params.setToolTip("Guardar parámetros (Umbrales, Rangos REC y Propietarios Especiales) en parametros.anot (por defecto, en la carpeta de proyecto)")
        btn_save_params.clicked.connect(self.save_parameters)

        btn_load_params = QPushButton()
        btn_load_params.setIcon(self.dock.style().standardIcon(QStyle.SP_DialogOpenButton))
        btn_load_params.setFixedSize(28, 28)
        btn_load_params.setToolTip("Cargar parámetros desde un fichero parametros.anot (se auto-carga al elegir la carpeta de proyecto, si ya existe)")
        btn_load_params.clicked.connect(self.load_parameters)

        self.tab_inputs.add_param_buttons(btn_save_params, btn_load_params)
        
        self.tabs.addTab(self.tab_inputs, "1: Datos Entrada")
        self.tabs.addTab(self.tab_mapping, "2: Mapeo Campos")
        self.tabs.addTab(self.tab_thresholds, "3: Umbrales")
        self.tabs.addTab(self.tab_audit, "4: Auditoría")
        self.tabs.addTab(self.tab_revision, "5: Revisión")
        # Esta pestaña la puede abrir cualquiera -- lo que hay detrás del
        # PIN es lo único restringido (ver TabAdmin).
        self.tabs.addTab(self.tab_admin, "6: Administración")

        # Si ya existe una carpeta de salida seleccionada (p.ej. al
        # reabrir el proyecto) y en ella hay un GeoPackage de auditoría
        # de una sesión anterior, se carga solo -- sin recalcular nada
        # -- para poder "volver a la Ficha 4 en cualquier momento".
        self.tabs.currentChanged.connect(self._on_tab_changed)
        # Ficha 5 (Fase 2): refresco perezoso al entrar en la pestaña,
        # mismo patrón que _on_tab_changed de la Ficha 4 (ver más abajo),
        # como conexión SEPARADA para no tocar ese método ya existente.
        self.tabs.currentChanged.connect(self._on_tab_changed_revision)
        
        layout.addWidget(self.tabs)
        
        btn_run = QPushButton("EJECUTAR ANÁLISIS")
        btn_run.setStyleSheet("background-color: #2c3e50; color: white; font-weight: bold; padding: 10px;")
        btn_run.clicked.connect(self.on_run_analysis)
        self.btn_run = btn_run

        # Barra de progreso + estado discretos, para que se vea que el
        # plugin está trabajando durante el análisis (que puede tardar) y
        # no dé sensación de estar colgado. Oculta en reposo.
        progress_container = QWidget()
        progress_layout = QVBoxLayout(progress_container)
        progress_layout.setContentsMargins(0, 4, 0, 0)
        progress_layout.setSpacing(2)

        self.lbl_progress = QLabel("")
        self.lbl_progress.setStyleSheet("color: #7f8c8d; font-size: 11px;")
        self.lbl_progress.setVisible(False)

        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.progress_bar.setFixedHeight(8)
        self.progress_bar.setTextVisible(False)
        self.progress_bar.setStyleSheet("""
            QProgressBar { background-color: #ecf0f1; border: none; border-radius: 4px; }
            QProgressBar::chunk { background-color: #3498db; border-radius: 4px; }
        """)
        self.progress_bar.setVisible(False)

        progress_layout.addWidget(self.lbl_progress)
        progress_layout.addWidget(self.progress_bar)

        # El botón y la barra de progreso viven DENTRO de la Ficha "1:
        # Datos Entrada" (a petición expresa), no debajo de las pestañas
        # como antes: así solo se ven mientras esa ficha está activa.
        self.tab_inputs.add_run_controls(btn_run, [progress_container])
        
        self.dock.setWidget(main_widget)
        # Ancho mínimo del dock: por debajo de este valor, el contenido de
        # la Ficha "4: Auditoría" (croquis + datos de interpretación) no
        # cabe sin recurrir a un scroll horizontal, que resulta muy
        # incómodo de usar. Al fijar un mínimo razonable, QGIS impide que
        # el usuario estreche el dock más de la cuenta, y así el resto del
        # layout (ver AspectRatioSvgWidget en tab_audit.py, que además ya
        # no exige el ancho nativo del SVG) siempre tiene sitio de sobra.
        self.dock.setMinimumWidth(420)
        self.iface.addDockWidget(Qt.RightDockWidgetArea, self.dock)
        self.dock.hide()

        # Punto (a) de aplicar_restricciones_por_rol: la UI ya está
        # completamente construida (tabs y btn_run incluidos) -- se aplica
        # el rol de inicio (REVISOR 2 si no hay todavía ningún rol
        # persistido en ningún GeoPackage) desde ya, para que el plugin se
        # COMPORTE como ese rol desde el primer instante y no se limite a
        # mostrarlo en el indicador de la cabecera.
        self.aplicar_restricciones_por_rol()

    def show(self):
        if self.dock:
            self.dock.show()

    def _on_tab_changed(self, index):
        """Carga perezosa de la Ficha 4: solo se intenta leer el
        GeoPackage de auditoría la primera vez que el usuario entra en
        esa pestaña (o tras un análisis nuevo), nunca al arrancar el
        plugin."""
        if self.tabs.widget(index) is not self.tab_audit:
            return
        if self.tab_audit.audit_service is not None:
            return  # ya está enlazada a una carpeta de salida
        output_dir = self.tab_inputs.project_root_path
        if output_dir and os.path.isdir(output_dir):
            self.tab_audit.set_output_dir(output_dir, self.tab_inputs.add_log)
            # Punto (a) de aplicar_restricciones_por_rol: se acaba de
            # cargar/enlazar el GeoPackage de auditoría de esta carpeta.
            self.aplicar_restricciones_por_rol()

    def _on_tab_changed_revision(self, index):
        """Refresco perezoso de la Ficha "5: Revisión": se recalcula
        cada vez que se entra en esa pestaña (nunca en segundo plano).
        Si la Ficha 4 todavía no ha enlazado su GeoPackage de auditoría
        en esta sesión (p.ej. el usuario entra primero en la Ficha 5),
        se fuerza aquí esa misma carga -- la Ficha 5 lee la MISMA capa
        que la Ficha 4, nunca abre su propia conexión (ver
        TabRevision)."""
        if self.tabs.widget(index) is not self.tab_revision:
            return
        if self.tab_audit.audit_service is None:
            output_dir = self.tab_inputs.project_root_path
            if output_dir and os.path.isdir(output_dir):
                self.tab_audit.set_output_dir(output_dir, self.tab_inputs.add_log)
                self.aplicar_restricciones_por_rol()
        self.tab_revision.refresh()

    def on_layer_loaded(self, label, layer):
        self.tab_inputs.add_log(f"Gestor: Detectada carga de {label} - {layer.name()}")
        
        lbl = str(label).upper()
        if "ANTE" in lbl:
            self.tab_mapping.update_fields(layer, 1)
        elif "DESP" in lbl:
            self.tab_mapping.update_fields(layer, 2)
        else:
            self.tab_inputs.add_log(f"AVISO: Etiqueta {label} no reconocida para mapeo")

    def _progress_start(self):
        self.lbl_progress.setText("Preparando análisis...")
        self.lbl_progress.setVisible(True)
        self.progress_bar.setValue(0)
        self.progress_bar.setVisible(True)
        self.btn_run.setEnabled(False)
        self.btn_run.setText("Analizando…")
        QApplication.processEvents()

    def _progress_update(self, pct, text=""):
        try:
            pct = max(0, min(100, int(pct)))
        except (TypeError, ValueError):
            pct = self.progress_bar.value()
        self.progress_bar.setValue(pct)
        if text:
            self.lbl_progress.setText(text)
        # El análisis corre de forma síncrona en el hilo de UI: forzamos el
        # repintado para que la barra y el texto se vean actualizarse en
        # tiempo real en vez de quedar "congelados" hasta el final.
        QApplication.processEvents()

    def _progress_end(self):
        self.progress_bar.setVisible(False)
        self.lbl_progress.setVisible(False)
        self.btn_run.setEnabled(True)
        self.btn_run.setText("EJECUTAR ANÁLISIS")
        QApplication.processEvents()

    def _current_role(self):
        """Rol activo. Prioridad:
        1) Cambio de rol pendiente en la Ficha "6: Administración" (elegido
           mientras la Ficha 1 todavía no tenía carpeta de salida y por
           tanto no se pudo persistir en ningún GeoPackage -- ver
           TabAdmin.pending_role / _try_persist_pending_role).
        2) Rol leído de AudiNOT_Admin, dentro del GeoPackage de auditoría
           de la carpeta de proyecto actual.
        3) Sin carpeta de proyecto todavía (o sin gpkg/tabla aún) ->
           ROLE_DEFAULT ('revisor2', restringido), igual criterio que
           AuditService.get_current_role."""
        if self.tab_admin.pending_role:
            return self.tab_admin.pending_role
        root = self.tab_inputs.project_root_path
        if not root or not os.path.isdir(root):
            return ROLE_DEFAULT
        try:
            return AuditService(root).get_current_role()
        except Exception:
            return ROLE_DEFAULT

    def _refresh_role_indicator(self, rol):
        """Actualiza el QLabel de la cabecera del dock. Se llama SOLO
        desde aplicar_restricciones_por_rol -- nunca de forma
        independiente (ver punto 4 de la Fase)."""
        if rol == 'revisor2':
            self.lbl_role.setText("REVISOR 2")
            color = "#e67e22"
        else:
            self.lbl_role.setText("REVISOR 1")
            color = "#34495e"
        self.lbl_role.setStyleSheet(
            f"font-size: 11px; font-weight: bold; color: white; "
            f"background-color: {color}; padding: 2px 6px; border-radius: 3px;"
        )

    def _try_persist_pending_role(self):
        """Si la Ficha "6: Administración" dejó un cambio de rol
        pendiente -elegido mientras la Ficha "1: Datos Entrada" todavía no
        tenía carpeta de salida, y por tanto no había ningún GeoPackage
        (ni siquiera solo con AudiNOT_Admin) donde escribirlo-, lo
        traslada ahora al GeoPackage de auditoría de la carpeta de
        proyecto actual en cuanto esta exista. No hace falta que ya se
        haya ejecutado ningún análisis: AuditService.set_current_role crea
        el .gpkg (con solo la tabla AudiNOT_Admin) si todavía no existe --
        el resto de tablas se añadirán más tarde, al primer "Ejecutar
        Análisis" en esa carpeta, sin pisar esta (ver AuditService.
        _create_gpkg). Si sigue sin haber carpeta de salida, no hace
        nada y el rol pendiente se mantiene en memoria."""
        pendiente = self.tab_admin.pending_role
        if not pendiente:
            return
        root = self.tab_inputs.project_root_path
        if not root or not os.path.isdir(root):
            return
        try:
            service = AuditService(root, self.tab_inputs.add_log)
            rol_anterior = service.get_current_role()
            if rol_anterior != pendiente:
                service.set_current_role(pendiente)
                service.add_historial_entry(
                    audinot_id='', origen='cambio_rol', report_id=None,
                    detalle=f"{rol_anterior} \u2192 {pendiente}",
                )
            self.tab_admin.clear_pending_role()
            self.tab_inputs.add_log(
                f"<font color='green'>✓ Cambio de rol pendiente aplicado al GeoPackage de "
                f"auditoría de esta carpeta ({pendiente.upper()}).</font>"
            )
        except Exception as e:
            self.tab_inputs.add_log(
                f"<font color='orange'>AVISO: no se pudo trasladar el cambio de rol pendiente "
                f"al GeoPackage de auditoría: {e}</font>")

    def _forzar_revisor2_si_equipo_distinto(self, rol):
        """Segunda (y única otra) vía por la que el rol activo puede
        cambiar sin que lo decida conscientemente el administrador desde
        la Ficha "6": si el rol leído del GeoPackage es 'revisor1' pero
        el equipo/usuario que lo abre AHORA no coincide con el último
        registrado en AudiNOT_Historial/AudiNOT_Checkpoints/AudiNOT_Admin
        (ver AuditService.get_last_known_actor), se fuerza y persiste el
        rol a 'revisor2' de inmediato, se deja constancia en el propio
        historial (origen='cambio_rol_auto', distinguible del cambio
        consciente 'cambio_rol') y se avisa en el log. Es una medida de
        seguridad (equipo/usuario distinto al último movimiento
        conocido), no una decisión editorial -- por eso nunca actúa al
        revés: no eleva de revisor2 a revisor1 aunque coincida el
        equipo, eso sigue siendo solo cosa del administrador.

        No hace nada (devuelve `rol` tal cual) si: ya es 'revisor2' (no
        hay nada que restringir más), no hay carpeta de proyecto válida
        todavía, el .gpkg no existe todavía, o get_last_known_actor() no
        tiene ningún registro previo con el que comparar (proyecto sin
        historial todavía, p.ej. justo tras _try_persist_pending_role en
        un .gpkg que antes solo tenía AudiNOT_Admin)."""
        if rol != 'revisor1':
            return rol
        root = self.tab_inputs.project_root_path
        if not root or not os.path.isdir(root):
            return rol
        try:
            service = AuditService(root)
            ultimo_actor = service.get_last_known_actor()
            actor_actual = service._current_user()
            if not ultimo_actor or ultimo_actor == actor_actual:
                return rol

            service.set_current_role('revisor2')
            service.add_historial_entry(
                audinot_id='', origen='cambio_rol_auto', report_id=None,
                detalle=(f"revisor1 \u2192 revisor2 (autom\u00e1tico: abierto desde "
                          f"{actor_actual}, distinto del \u00faltimo registro conocido "
                          f"en este GeoPackage, {ultimo_actor})"),
            )
            self.tab_inputs.add_log(
                f"<font color='orange'>AVISO: este GeoPackage de auditoría se tocó por "
                f"última vez desde <b>{ultimo_actor}</b>; como ahora se abre desde "
                f"<b>{actor_actual}</b>, el rol se ha puesto automáticamente en "
                f"REVISOR 2 por seguridad. Puedes volver a Revisor 1 desde la Ficha "
                f"\"6: Administración\" si corresponde.</font>"
            )
            return 'revisor2'
        except Exception as e:
            self.tab_inputs.add_log(
                f"<font color='orange'>AVISO: no se pudo comprobar el último equipo/usuario "
                f"que tocó el GeoPackage de auditoría: {e}</font>")
            return rol

    def aplicar_restricciones_por_rol(self):
        """ÚNICO método del plugin que sabe "qué se apaga y qué se
        enciende" según el rol activo (ver RESTRICCIONES_REVISOR2, más
        arriba). Ninguna pestaña decide nada de restricciones por su
        cuenta: cada tab_*.py solo expone get_restricted_widgets() con sus
        propios widgets restringibles; este método es quien interpreta esa
        lista según el modo declarado en la tabla.

        Se llama desde: (a) al arrancar la UI del plugin (final de
        setup_ui, para que el rol de inicio -REVISOR 2 si no hay nada
        persistido todavía- se aplique desde el primer momento, no solo
        se muestre); (b) al cargar/recargar el GeoPackage de auditoría
        (_on_tab_changed / on_run_analysis / al cambiar la carpeta de la
        Ficha 1); y (c) al aplicar un cambio de rol desde la Ficha "6:
        Administración" (TabAdmin.roleChanged). No debe llamarse ni
        reimplementarse desde ningún otro sitio.

        Antes de leer el rol activo, intenta trasladar cualquier cambio
        pendiente de la Ficha 6 al GeoPackage de la carpeta actual (ver
        _try_persist_pending_role) -- así, en cuanto haya carpeta de
        salida, el rol elegido queda persistido y no solo vigente en esta
        sesión. Después de leerlo, comprueba también si hay que forzarlo
        a Revisor 2 por equipo/usuario distinto al último que tocó este
        GeoPackage (ver _forzar_revisor2_si_equipo_distinto) -- la única
        otra vía, junto con la Ficha 6, por la que el rol puede cambiar
        sin que lo decida el administrador en el momento."""
        self._try_persist_pending_role()
        rol = self._current_role()
        rol = self._forzar_revisor2_si_equipo_distinto(rol)
        restringir = (rol == 'revisor2')
        tooltip = self.TOOLTIP_REVISOR2 if restringir else ""

        objetivos = {
            'tab_inputs': self.tab_inputs,
            'tab_mapping': self.tab_mapping,
            'tab_thresholds': self.tab_thresholds,
            'tab_audit': self.tab_audit,
            'btn_run': self.btn_run,
        }

        for clave, modo in self.RESTRICCIONES_REVISOR2.items():
            objetivo = objetivos.get(clave)
            if objetivo is None or modo is None:
                continue

            if modo == 'pestana':
                idx = self.tabs.indexOf(objetivo)
                if idx != -1:
                    self.tabs.setTabEnabled(idx, not restringir)
                    self.tabs.setTabToolTip(idx, tooltip)

            elif modo == 'widget':
                objetivo.setEnabled(not restringir)
                objetivo.setToolTip(tooltip)

            elif modo in ('widgets', 'readonly'):
                for widget in objetivo.get_restricted_widgets():
                    if modo == 'readonly' and hasattr(widget, 'setReadOnly'):
                        widget.setReadOnly(restringir)
                    else:
                        widget.setEnabled(not restringir)
                    widget.setToolTip(tooltip)

        self._refresh_role_indicator(rol)
        self._sync_tablas_internas_por_rol(rol)

    def _sync_tablas_internas_por_rol(self, rol):
        """Añade o quita del panel de Capas las tablas "internas" del
        GeoPackage de auditoría (ver TABLAS_INTERNAS_SOLO_REVISOR1, más
        arriba) según el rol activo. Llamado SIEMPRE desde el final de
        aplicar_restricciones_por_rol -- mismo criterio que el resto de
        este método: ninguna ficha decide esto por su cuenta.

        Con Revisor 1 activo: si hay una capa de auditoría cargada
        (self.tab_audit.audit_service ya existe) y la tabla en cuestión
        no está ya en el proyecto, se añade. Con Revisor 2: si la tabla
        está en el proyecto (por ejemplo, quedó cargada de una sesión
        anterior con Revisor 1), se retira sin ningún QMessageBox ni
        aviso -- no es un error, es una restricción de visibilidad
        deliberada."""
        mostrar = (rol == 'revisor1')
        audit_service = self.tab_audit.audit_service if self.tab_audit else None

        for nombre_capa, metodo in self.TABLAS_INTERNAS_SOLO_REVISOR1:
            if mostrar:
                if audit_service is not None and not QgsProject.instance().mapLayersByName(nombre_capa):
                    getattr(audit_service, metodo)(add_to_project=True)
            else:
                existentes = QgsProject.instance().mapLayersByName(nombre_capa)
                if existentes:
                    QgsProject.instance().removeMapLayers([lyr.id() for lyr in existentes])

    def _confirm_dialog(self, question):
        """confirm_callback para AnalysisEngine: única pieza de este dock
        que sabe abrir un QMessageBox, para que el motor (analysis_engine.py)
        siga sin depender de Qt más allá de log/progreso. Se usa hoy para
        la comprobación de continuidad de fincas antes de fusionar con
        AudiNOT_Auditoria/AudiNOT_Historial (ver AuditService.check_survival)."""
        reply = QMessageBox.question(
            self.dock,
            "AudiNOT — Comprobación de continuidad",
            question,
            QMessageBox.Yes | QMessageBox.No
        )
        return reply == QMessageBox.Yes

    def on_run_analysis(self):
        self.tab_inputs.clear_log()
        self.tab_inputs.add_log("<b>=== INICIANDO PROCESO DE ANÁLISIS ===</b>")
        
        # 1. Validar carpeta de salida
        output_dir = self.tab_inputs.file_output.filePath()
        self.tab_inputs.add_log(f"Carpeta de salida: {output_dir}")
        
        if not output_dir:
            self.tab_inputs.add_log("<font color='red'>ERROR: Debe seleccionar una carpeta de salida.</font>")
            return

        # 1b. Si la carpeta de proyecto no tiene todavía su propio
        # parametros.anot, se crea por defecto con los valores actuales.
        self._ensure_default_params_file()

        # 2. Recuperar capas desde QgsProject por ID (robusto frente a eliminaciones)
        layer_antes = None
        layer_desp = None

        if self.tab_inputs.layer_antes_id:
            layer_antes = QgsProject.instance().mapLayer(self.tab_inputs.layer_antes_id)
            self.tab_inputs.layer_antes = layer_antes

        if self.tab_inputs.layer_desp_id:
            layer_desp = QgsProject.instance().mapLayer(self.tab_inputs.layer_desp_id)
            self.tab_inputs.layer_desp = layer_desp

        self.tab_inputs.add_log(f"Capa ANTES: {layer_antes.name() if layer_antes else 'NO CARGADA'}")
        self.tab_inputs.add_log(f"Capa DESPUÉS: {layer_desp.name() if layer_desp else 'NO CARGADA'}")

        if not layer_antes or not layer_desp or not layer_antes.isValid() or not layer_desp.isValid():
            self.tab_inputs.add_log(
                "<font color='red'>ERROR: Las capas no están disponibles. "
                "Vuelva a seleccionar los archivos en la pestaña de entrada.</font>"
            )
            self.tab_inputs.layer_antes_id = None
            self.tab_inputs.layer_desp_id = None
            return

        # 3. Recolectar settings de filtrado
        filter_settings = self.tab_inputs.get_filter_settings()
        
        # 4. Construir settings completos
        settings = {
            'output_dir': output_dir,
            'project_root': self.tab_inputs.project_root_path,
            'restart_all': True,
            'layer_antes': layer_antes,
            'layer_desp': layer_desp,
            'dxf_antes_path': self.tab_inputs.dxf_antes_path,
            'dxf_desp_path': self.tab_inputs.dxf_desp_path,
            'owner_filter': filter_settings,
            'thresholds': self.tab_thresholds.get_thresholds(),
            'special_ranges': self.tab_mapping.get_defined_ranges(),
            'mapping': self.tab_mapping.get_field_mappings(),
            'adit_paths': self.tab_inputs.get_adit_paths(),
            'adit_mapping_field': self.tab_mapping.get_adit_mapping(),
            'special_owners': self.tab_mapping.get_special_owners(),
            # Snapshot para adjuntar al GeoPackage de auditoría (mismo
            # formato que el .anot) -- ver AuditService._write_parameters_table.
            'parametros_anot': self._current_parameters_dict()
        }
        
        # 5. Verificar selección activa en capa ANTES
        if layer_antes.selectedFeatureCount() > 0:
            reply = QMessageBox.question(
                self.dock,
                "Fincas Seleccionadas",
                f"Hay {layer_antes.selectedFeatureCount()} fincas seleccionadas en la capa ANTES.\n\n"
                "¿Desea restringir el análisis SOLAMENTE a esta selección?",
                QMessageBox.Yes | QMessageBox.No | QMessageBox.Cancel
            )
            
            if reply == QMessageBox.Cancel:
                self.tab_inputs.add_log("Proceso detenido por el usuario.")
                return
            
            if reply == QMessageBox.Yes:
                settings['only_selected'] = True
                self.tab_inputs.add_log(
                    f"Modo Selección: Procesando solo las {layer_antes.selectedFeatureCount()} fincas seleccionadas."
                )
            else:
                settings['only_selected'] = False
                self.tab_inputs.add_log("Modo Completo: Se analizará la capa entera ignorando la selección.")
        else:
            settings['only_selected'] = False

        # 6. Instanciar y ejecutar motor
        self.tab_inputs.add_log("Instanciando motor de análisis...")
        self._progress_start()
        try:
            engine = AnalysisEngine(
                self.iface, settings, self.tab_inputs.add_log, self._progress_update,
                confirm_callback=self._confirm_dialog
            )
            self.tab_inputs.add_log("Motor creado. Ejecutando...")
            engine.run()
            self.tab_inputs.add_log("<b>=== PROCESO COMPLETADO ===</b>")

            # Refrescar la Ficha "4: Auditoría" con el GeoPackage recién
            # actualizado por el motor (bloque aislado y aditivo: si el
            # motor no llegó a generar capa de auditoría por lo que sea,
            # last_output_dir queda a None y aquí simplemente no se hace
            # nada -- el resto del plugin sigue funcionando igual).
            if getattr(engine, 'last_output_dir', None):
                self.tab_audit.set_output_dir(engine.last_output_dir, self.tab_inputs.add_log)
                # Punto (a) de aplicar_restricciones_por_rol: nuevo cálculo,
                # gpkg de auditoría recién (re)cargado en la Ficha 4.
                self.aplicar_restricciones_por_rol()
        except Exception as e:
            self.tab_inputs.add_log(f"<font color='red'>ERROR CRÍTICO: {str(e)}</font>")
            import traceback
            self.tab_inputs.add_log(f"<font color='red'>{traceback.format_exc()}</font>")
        finally:
            # Pase lo que pase (éxito, error, o un return anticipado dentro
            # del motor), la barra de progreso debe volver a su estado de
            # reposo para no dejar la UI con aspecto de "colgada".
            self._progress_end()

    def _default_params_path(self):
        # Preferimos la raíz del proyecto (donde el usuario ya tiene sus
        # shapes/DXF y, ahora, "RESULTADO") como ubicación por defecto de
        # parametros.anot; si aún no hay carpeta de proyecto configurada,
        # caemos al directorio del propio plugin como antes.
        root = self.tab_inputs.project_root_path
        if root:
            return os.path.join(root, "parametros.anot")
        plugin_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        return os.path.join(plugin_dir, "parametros.anot")

    def _current_parameters_dict(self):
        """Umbrales/Rangos REC/Propietarios Especiales tal como están
        ahora mismo en la UI, en el mismo formato que usa el fichero
        .anot. Reutilizado por el guardado a .anot y por el snapshot que
        se adjunta al GeoPackage de auditoría (AuditService.export_or_update)."""
        return {
            "thresholds": self.tab_thresholds.get_thresholds(),
            "ranges": self.tab_mapping.get_ranges_for_save(),
            "special_owners": self.tab_mapping.get_special_owners_for_save()
        }

    def _save_parameters_to_path(self, path):
        """Vuelca Umbrales/Rangos REC/Propietarios Especiales a `path` en JSON. Lanza excepción si falla; no toca la UI."""
        data = self._current_parameters_dict()
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4, ensure_ascii=False)

    def _load_parameters_from_path(self, path, silent=False):
        """Lee `path` y rellena Umbrales/Rangos REC/Propietarios Especiales.
        silent=True: pensado para la auto-carga al configurar la carpeta de
        proyecto -solo deja constancia en el log, sin QMessageBox, para no
        interrumpir al usuario con un aviso en cada selección de carpeta."""
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception as e:
            msg = f"No se pudo leer el fichero:\n{str(e)}"
            if silent:
                self.tab_inputs.add_log(f"<font color='orange'>AVISO: no se pudo auto-cargar {path}: {e}</font>")
            else:
                QMessageBox.critical(self.dock, "Error al cargar", msg)
            return False

        self.tab_thresholds.set_thresholds(data.get("thresholds"))
        self.tab_mapping.set_ranges(data.get("ranges"))
        self.tab_mapping.set_special_owners(data.get("special_owners"))

        self.tab_inputs.add_log(f"Parámetros cargados correctamente desde: {path}")

        # Además de rellenar la UI, si ya existe un GeoPackage de auditoría
        # (de un cálculo anterior) en la carpeta de proyecto actual, se
        # actualiza también su tabla 'AudiNOT_Parametros' con estos mismos
        # parámetros recién cargados -si no, el .gpkg seguiría enseñando el
        # snapshot del último cálculo hasta el próximo "Ejecutar Análisis"
        # (ver AuditService.update_parameters_snapshot).
        self._sync_parameters_to_gpkg(data)

        if not silent:
            QMessageBox.information(self.dock, "Parámetros cargados", f"Parámetros cargados desde:\n{path}")
        return True

    def _sync_parameters_to_gpkg(self, parametros):
        """Si el GeoPackage de auditoría de la carpeta de proyecto actual ya
        existe (de un cálculo anterior), actualiza también su tabla
        'AudiNOT_Parametros' con `parametros` (mismo formato que el .anot:
        thresholds/ranges/special_owners), para que no se quede
        desactualizada al cargar un .anot distinto. Si el GeoPackage
        todavía no existe (no ha habido ningún cálculo en esta carpeta),
        no hace nada -se creará ya con los parámetros correctos en el
        primer "Ejecutar Análisis"."""
        root = self.tab_inputs.project_root_path
        if not root:
            return
        try:
            audit_service = AuditService(root, self.tab_inputs.add_log)
            if os.path.exists(audit_service.gpkg_path):
                audit_service.update_parameters_snapshot(parametros)
                self.tab_inputs.add_log(
                    "<font color='green'>✓ Tabla de parámetros del GeoPackage de auditoría "
                    "actualizada con los valores recién cargados.</font>"
                )
        except Exception as e:
            self.tab_inputs.add_log(
                f"<font color='orange'>AVISO: no se pudo actualizar la tabla de parámetros en el "
                f"GeoPackage de auditoría: {e}</font>")

    def save_parameters(self):
        """Guarda los Umbrales (ficha 3), los Rangos REC y los Propietarios Especiales (ficha 2) en un fichero JSON .anot"""
        default_path = self._default_params_path()
        path, _ = QFileDialog.getSaveFileName(
            self.dock,
            "Guardar parámetros",
            default_path,
            "Parámetros AudiNOT (*.anot)"
        )
        if not path:
            return
        if not path.lower().endswith(".anot"):
            path += ".anot"

        try:
            self._save_parameters_to_path(path)
            self.tab_inputs.add_log(f"Parámetros guardados correctamente en: {path}")
            QMessageBox.information(self.dock, "Parámetros guardados", f"Parámetros guardados en:\n{path}")
        except Exception as e:
            QMessageBox.critical(self.dock, "Error al guardar", f"No se pudo guardar el fichero:\n{str(e)}")

    def load_parameters(self):
        """Carga los Umbrales, Rangos REC y Propietarios Especiales desde un fichero JSON .anot y rellena las casillas."""
        default_path = self._default_params_path()
        start_path = default_path if os.path.exists(default_path) else ""
        path, _ = QFileDialog.getOpenFileName(
            self.dock,
            "Cargar parámetros",
            start_path,
            "Parámetros AudiNOT (*.anot)"
        )
        if not path:
            return

        self._load_parameters_from_path(path, silent=False)

    def _ensure_default_params_file(self):
        """Si al inicializar el análisis la carpeta de proyecto todavía no
        tiene un parametros.anot propio, se crea con los valores actuales
        de la UI -así queda disponible para auto-cargarse en la próxima
        sesión sin que el usuario tenga que acordarse de pulsar 'Guardar'."""
        root = self.tab_inputs.project_root_path
        if not root:
            return
        candidate = os.path.join(root, "parametros.anot")
        if os.path.exists(candidate):
            return
        try:
            self._save_parameters_to_path(candidate)
            self.tab_inputs.add_log(f"Creado parametros.anot por defecto en: {candidate}")
        except Exception as e:
            self.tab_inputs.add_log(f"<font color='orange'>AVISO: no se pudo crear parametros.anot por defecto: {e}</font>")

    def open_help(self):
        plugin_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        help_path = os.path.join(plugin_dir, 'ayuda.html')
        url = QUrl.fromLocalFile(help_path)
        QDesktopServices.openUrl(url)

    def on_click_close(self):
        """Botón 'Cerrar' (junto al de ayuda, arriba a la derecha del
        dock): desconecta completamente el plugin del GeoPackage de
        auditoría y de los shapes/DXF referenciados, para que el usuario
        pueda modificarlos, moverlos, copiarlos o borrarlos en disco sin
        que QGIS/AudiNOT los tenga bloqueados. También vacía los campos
        de la Ficha 1 que no tienen un valor por defecto (rutas de
        carpeta/ficheros, filtro de propietario); Umbrales, Rangos REC
        y Propietarios Especiales -que sí tienen valores por defecto- no
        se tocan."""
        resp = QMessageBox.question(
            self.dock, "Cerrar proyecto AudiNOT",
            "Esto desconectará el plugin del GeoPackage de auditoría y de los "
            "shapes/DXF cargados (se quitan del proyecto QGIS) y vaciará las rutas "
            "de la Ficha 1, para que puedas modificar, mover, copiar o borrar esos "
            "ficheros en disco sin que queden bloqueados.\n\n"
            "Los Umbrales, Rangos REC y Propietarios Especiales no se pierden.\n\n"
            "¿Continuar?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        if resp != QMessageBox.Yes:
            return

        # Capturamos la ruta del GeoPackage de auditoría ANTES de que
        # close_and_release() suelte self.audit_service (paso 1): la
        # necesitamos para el barrido por datasource del paso 3b, que
        # solo consulta esta ruta -no toca ni abre el .gpkg-, así que
        # no afecta a su contenido.
        gpkg_path = (
            self.tab_audit.audit_service.gpkg_path
            if self.tab_audit.audit_service is not None else None
        )

        # 1. Ficha 4: suelta self.layer/self.audit_service y quita del
        # proyecto la capa de auditoría, las de referencia y la de
        # historial (ver TabAudit.close_and_release).
        self.tab_audit.close_and_release()
        # La Ficha 5 lee esos mismos self.layer/self.audit_service (ver
        # TabRevision) -- se refresca para que no se quede enseñando una
        # lista obsoleta tras cerrar el proyecto.
        self.tab_revision.refresh()

        # 2. Ficha 1: quita ANTES/DESPUÉS del proyecto y vacía las rutas
        # (ver TabInputs.reset_to_empty).
        self.tab_inputs.reset_to_empty()

        # 3. Barrido de capas intermedias que el motor de análisis pudo
        # dejar en el proyecto durante un cálculo (ANTES-ok/DESPUES-ok,
        # DXF corregidos, uniones, aditamentos temporales...) y que no
        # quedan referenciadas desde ningún sitio una vez cerradas las
        # Fichas 1 y 4 -- se identifican por el patrón de nombre que les
        # ponen shp_service/dxf_service/adit_service, no por su origen,
        # así que este barrido es intencionadamente más amplio que el de
        # los dos pasos anteriores.
        stray_prefixes = ("ANTES-ok", "DESPUES-ok", "ANTES_temp", "DESPUES_temp",
                           "UNION_ANALISIS", "UNION", "ADIT_TEMP_")
        stray_ids = [
            lyr.id() for lyr in QgsProject.instance().mapLayers().values()
            if lyr.name().startswith(stray_prefixes)
        ]
        if stray_ids:
            QgsProject.instance().removeMapLayers(stray_ids)

        # 3b. Barrido por DATASOURCE (no por nombre): cualquier capa que
        # siga en el proyecto y cuya fuente apunte al GeoPackage de
        # auditoría se retira también, sea cual sea su nombre. Esto es
        # lo que de verdad garantiza que el .gpkg quede libre, en vez de
        # depender de mantener actualizada a mano la lista de nombres
        # "conocidos" del paso 3 -- cubre por ejemplo AudiNOT_Admin y
        # AudiNOT_Checkpoints (que _sync_tablas_internas_por_rol añade
        # al proyecto con rol Revisor 1 y que close_and_release() no
        # conocía por nombre) y cualquier tabla que se añada al
        # GeoPackage en el futuro. Solo lee lyr.source() -no abre ni
        # modifica el .gpkg-, así que no toca su contenido.
        if gpkg_path:
            gpkg_norm = os.path.normcase(os.path.normpath(gpkg_path))
            stray_gpkg_ids = [
                lyr.id() for lyr in QgsProject.instance().mapLayers().values()
                if os.path.normcase(os.path.normpath(lyr.source().split('|')[0])) == gpkg_norm
            ]
            if stray_gpkg_ids:
                QgsProject.instance().removeMapLayers(stray_gpkg_ids)

        # 4. Fuerza la liberación de los datasources OGR/GDAL de las capas
        # recién quitadas del proyecto: removeMapLayers() basta casi
        # siempre, pero un gc.collect() explícito evita que una
        # referencia colgante retrase el cierre real del fichero en
        # disco (relevante sobre todo en Windows, donde un fichero .gpkg
        # con el handle todavía abierto no se puede mover/borrar/copiar).
        import gc
        gc.collect()

        self.tab_inputs.add_log(
            "<font color='green'>✓ Plugin desconectado del GeoPackage y de los ficheros "
            "referenciados. Ya puedes modificarlos libremente en disco.</font>"
        )