"""
busy_indicator
==============

Ayuda visual mínima y reutilizable para las acciones del plugin que
pueden tardar un momento perceptible (recargar la capa, cambiar de
rol, generar una ficha suelta, refrescar la Ficha "5"...): mientras
duran, el cursor cambia a "reloj de arena" y -si se le pasa una
etiqueta- se muestra un texto genérico tipo "Procesando…" en vez de
dejar la ventana con aspecto de estar colgada sin ninguna señal.

Deliberadamente NO menciona aquí (ni en el texto que se muestra al
usuario) qué operación concreta está en marcha por dentro -- ver
BusyCursor.__enter__/mensaje por defecto: es solo "dar señales de
vida", no explicar las tripas del plugin. Cualquier pantalla que
quiera un texto más específico debe pasar uno igual de genérico
("Cargando…", "Aplicando…"), nunca nombres de tablas, servicios o
pasos internos.

Uso típico:

    with BusyCursor():
        ... operación que tarda ...

o, si además hay una etiqueta de estado visible que se pueda
aprovechar un momento:

    with BusyCursor(status_label=self.lbl_progress, text="Cargando…"):
        ... operación que tarda ...

Se apoya en QApplication.set/restoreOverrideCursor (igual mecanismo
que ya usan las acciones masivas de la Ficha "4: Auditoría") más un
processEvents() para que el cursor y el texto lleguen a pintarse de
verdad antes de que arranque el trabajo síncrono -- el plugin entero
corre en el hilo de UI, así que sin este processEvents() inicial
Qt podría quedarse con el cursor normal hasta que la operación
terminase por sí sola."""

from qgis.PyQt.QtWidgets import QApplication
from qgis.PyQt.QtCore import Qt


class BusyCursor:
    """Gestor de contexto: cursor de espera (y, opcionalmente, un
    texto de estado genérico) mientras dura el bloque `with`. Restaura
    siempre el cursor y el texto anterior al salir, también si el
    bloque lanza una excepción."""

    def __init__(self, status_label=None, text="Procesando…"):
        self._status_label = status_label
        self._text = text
        self._previous_text = None

    def __enter__(self):
        if self._status_label is not None:
            self._previous_text = self._status_label.text()
            self._status_label.setText(self._text)
        QApplication.setOverrideCursor(Qt.WaitCursor)
        # Fuerza el repintado AHORA: si no, con todo corriendo en el
        # hilo de UI, el cursor/texto nuevos podrían no llegar a
        # mostrarse hasta que la propia operación ya haya terminado.
        QApplication.processEvents()
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        QApplication.restoreOverrideCursor()
        if self._status_label is not None and self._previous_text is not None:
            self._status_label.setText(self._previous_text)
        QApplication.processEvents()
        return False  # nunca silencia la excepción
