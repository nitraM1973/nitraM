import os

def classFactory(iface):
    # Antes de cargar la clase, aseguramos que el entorno está limpio
    # aunque la limpieza profunda se hace en el arranque del plugin
    from .plugin import AudiNOTPlugin
    return AudiNOTPlugin(iface)

# Limpieza de caché opcional al importar el paquete
def clear_plugin_cache():
    import shutil
    import tempfile
    plugin_dir = os.path.dirname(__file__)
    # Lógica de limpieza específica si fuera necesario antes de la instancia
    pass
