import random
from datetime import date

# Longitud de la cadena semilla diaria: YYYYMMDD (8) + día ISO de la
# semana (1 dígito, 1=lunes .. 7=domingo) = 9 caracteres.
SEED_LENGTH = 9
# Cuántas posiciones de esas 9 se piden en cada reto.
POSITIONS_TO_ASK = 5


def _seed_full(today=None):
    """Cadena de 9 dígitos del día: YYYYMMDD + ordinal ISO del día de
    la semana. Nunca se expone al usuario tal cual -- solo se compara
    dígito a dígito contra lo que introduce en las posiciones pedidas."""
    d = today or date.today()
    return d.strftime('%Y%m%d') + str(d.isoweekday())


def generar_posiciones(k=POSITIONS_TO_ASK, n=SEED_LENGTH):
    """Elige al azar k posiciones (1-indexadas) de entre 1..n, sin
    repetición. Se llama una vez por intento -- un reto nuevo cada vez
    que se abre el diálogo o falla la validación, para que no sirva
    memorizar siempre las mismas posiciones."""
    return sorted(random.sample(range(1, n + 1), k))


def verify_code_parcial(entradas, posiciones, today=None):
    """Valida un reto de "clave de coordenadas".

    entradas: dict {posicion (1-indexada): caracter introducido}.
    posiciones: lista de posiciones (1-indexadas) que se pidieron --
    debe ser exactamente la misma lista devuelta por
    generar_posiciones() para este intento.

    Devuelve True solo si TODAS las posiciones pedidas coinciden con
    el dígito real de la cadena semilla de hoy en esa posición. No se
    reconstruye ni se expone la cadena completa en ningún mensaje de
    error -- una posición incorrecta da el mismo resultado que varias."""
    if not posiciones:
        return False
    seed = _seed_full(today)
    for pos in posiciones:
        esperado = seed[pos - 1]
        introducido = (entradas.get(pos) or '').strip()
        if introducido != esperado:
            return False
    return True
