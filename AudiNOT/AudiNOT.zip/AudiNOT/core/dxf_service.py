import os
from qgis.core import (
    QgsVectorLayer, 
    QgsProject, 
    QgsMessageLog, 
    Qgis,
    QgsWkbTypes,
    QgsFeature,
    QgsVectorFileWriter,
    QgsFields,
    QgsField,
    QgsGeometry
)
from PyQt5.QtCore import QVariant
import processing

class DxfService:
    def __init__(self, iface, log_callback=None):
        self.iface = iface
        self.log = log_callback
        self.loaded_layers = {}  # Diccionario para rastrear capas cargadas por DXF

    def add_log(self, message):
        if self.log:
            self.log(message)
        else:
            print(f"AudiNOT: {message}")

    def process_dxf(self, dxf_path, label):
        """
        Procesa un archivo DXF:
        1. Detecta tipos de geometría presentes
        2. Crea un shape para cada tipo
        3. Corrige geometrías
        4. Incorpora al proyecto con SRC del proyecto
        """
        if not dxf_path or not os.path.exists(dxf_path):
            self.add_log(f"<font color='red'>ERROR: El archivo DXF no existe: {dxf_path}</font>")
            return []

        filename = os.path.basename(dxf_path)
        self.add_log(f"<b>Procesando DXF: {filename} ({label})</b>")

        # Limpiar capas previas de este label si existen
        self.remove_layers_by_label(label)
        
        # Determinar el SRC del proyecto
        project_crs = QgsProject.instance().crs()
        self.add_log(f"SRC del proyecto: {project_crs.authid()}")

        # Cargar DXF completo primero
        dxf_layer = QgsVectorLayer(dxf_path, f"{label}_temp", "ogr")
        
        if not dxf_layer.isValid():
            self.add_log(f"<font color='red'>ERROR: No se pudo abrir el DXF.</font>")
            return []
        
        self.add_log(f"DXF cargado: {dxf_layer.featureCount()} entidades totales")
        
        # Asignar SRC del proyecto
        dxf_layer.setCrs(project_crs)

        # Separar geometrías por tipo manualmente
        geometry_data = self.separate_geometries_by_type(dxf_layer)
        
        if not geometry_data:
            self.add_log(f"<font color='orange'>AVISO: No se detectaron geometrías válidas en el DXF</font>")
            return []

        loaded_layers = []

        # Procesar cada tipo de geometría
        for geom_type, features in geometry_data.items():
            if not features:
                continue
                
            self.add_log(f"Procesando {len(features)} geometrías tipo: {geom_type}...")
            
            # Crear capa en memoria para este tipo
            layer = self.create_memory_layer(geom_type, features, dxf_layer.fields(), project_crs, f"{label}_{geom_type}")
            
            if layer and layer.featureCount() > 0:
                self.add_log(f"  Capa creada con {layer.featureCount()} elementos")
                
                # Corregir geometrías
                corrected = self.fix_geometry(layer, f"{label}_{geom_type}_ok")
                
                if corrected:
                    # Asegurar SRC del proyecto
                    corrected.setCrs(project_crs)
                    
                    # Añadir al proyecto
                    QgsProject.instance().addMapLayer(corrected)
                    loaded_layers.append(corrected)
                    self.add_log(f"<font color='green'>✓ {label}_{geom_type}_ok cargado ({corrected.featureCount()} elementos)</font>")

        # Guardar referencia de las capas cargadas
        self.loaded_layers[label] = loaded_layers

        if not loaded_layers:
            self.add_log(f"<font color='orange'>AVISO: No se cargaron capas desde {filename}</font>")
        
        return loaded_layers

    def separate_geometries_by_type(self, layer):
        """
        Separa las geometrías de una capa por tipo.
        Retorna un diccionario con listas de features por tipo.
        """
        geometry_data = {
            'Point': [],
            'LineString': [],
            'Polygon': []
        }
        
        for feature in layer.getFeatures():
            geom = feature.geometry()
            if geom and not geom.isNull():
                geom_type_base = QgsWkbTypes.geometryType(geom.wkbType())
                
                if geom_type_base == QgsWkbTypes.PointGeometry:
                    geometry_data['Point'].append(feature)
                elif geom_type_base == QgsWkbTypes.LineGeometry:
                    geometry_data['LineString'].append(feature)
                elif geom_type_base == QgsWkbTypes.PolygonGeometry:
                    geometry_data['Polygon'].append(feature)
        
        # Informar de lo encontrado
        for gtype, feats in geometry_data.items():
            if feats:
                self.add_log(f"  Detectadas {len(feats)} geometrías {gtype}")
        
        return geometry_data

    def create_memory_layer(self, geom_type, features, fields, crs, name):
        """
        Crea una capa en memoria con las features del tipo especificado.
        """
        try:
            # Mapeo de tipos a URIs de QGIS
            type_map = {
                'Point': 'Point',
                'LineString': 'LineString',
                'Polygon': 'Polygon'
            }
            
            uri = f"{type_map[geom_type]}?crs={crs.authid()}"
            layer = QgsVectorLayer(uri, name, "memory")
            
            if not layer.isValid():
                self.add_log(f"<font color='red'>Error creando capa en memoria para {geom_type}</font>")
                return None
            
            # Añadir campos
            layer.dataProvider().addAttributes(fields.toList())
            layer.updateFields()
            
            # Añadir features
            layer.startEditing()
            for feat in features:
                new_feat = QgsFeature(layer.fields())
                new_feat.setGeometry(feat.geometry())
                new_feat.setAttributes(feat.attributes())
                layer.addFeature(new_feat)
            layer.commitChanges()
            
            return layer
            
        except Exception as e:
            self.add_log(f"<font color='red'>Error creando capa {geom_type}: {str(e)}</font>")
            import traceback
            self.add_log(f"<font color='red'>{traceback.format_exc()}</font>")
            return None

    def fix_geometry(self, layer, name):
        """
        Ejecuta el algoritmo de corrección de geometrías.
        """
        try:
            params = {
                'INPUT': layer,
                'OUTPUT': 'memory:'
            }
            result = processing.run("native:fixgeometries", params)
            output_layer = result['OUTPUT']
            output_layer.setName(name)
            return output_layer
        except Exception as e:
            self.add_log(f"<font color='orange'>Aviso: No se pudo corregir geometría, usando original</font>")
            layer.setName(name)
            return layer  # Devolver original si falla

    def remove_layers_by_label(self, label):
        """
        Elimina del proyecto todas las capas asociadas a un label específico.
        """
        if label not in self.loaded_layers:
            return
            
        layers_to_remove = []
        for layer in self.loaded_layers[label]:
            if layer and layer.id() in QgsProject.instance().mapLayers():
                layers_to_remove.append(layer.id())
        
        if layers_to_remove:
            QgsProject.instance().removeMapLayers(layers_to_remove)
            self.add_log(f"Capas DXF de {label} eliminadas del proyecto.")
        
        del self.loaded_layers[label]
