import os
import time
import uuid
import base64
import math
import json
import re
import html as html_lib
from datetime import datetime
from qgis.core import QgsGeometry, QgsRectangle, QgsWkbTypes, QgsProject, QgsSpatialIndex, QgsFeature

class ReportService:
    # Cache a nivel de clase (no de instancia): el logo es un asset
    # estático del plugin, se lee y codifica en base64 una sola vez por
    # sesión de QGIS aunque se creen varias instancias de ReportService
    # (una por cada ficha/informe generado). None = aún no calculado;
    # '' = se intentó y no se pudo leer (para no reintentar en cada
    # llamada).
    _TRAGSATEC_LOGO_DATA_URI = None

    def __init__(self, output_dir, log_callback=None):
        self.output_dir = output_dir
        self.informes_dir = os.path.join(output_dir, "informes")
        os.makedirs(self.informes_dir, exist_ok=True)
        self.log_callback = log_callback
        self._sketch_log_count = 0
        self._context_geoms_despues = {}
        self._context_adits = {}
        self._gauss_area_cache = {}

    @classmethod
    def _tragsatec_logo_data_uri(cls):
        """Devuelve el logotipo de Tragsatec (resources/tragsatec.png)
        como data URI base64 ('data:image/png;base64,...'), listo para
        insertar en un <img src="..."> de un HTML autocontenido.

        Se embebe en base64 en vez de referenciarlo por ruta relativa a
        propósito: estas fichas/informes se generan como HTML sueltos
        que el usuario puede copiar, enviar por correo o abrir en otro
        equipo -- si el logo viajara como archivo aparte, se perdería en
        cuanto el HTML se moviera fuera de la carpeta de RESULTADO. El
        PNG de origen ya viene reducido y cuantizado a una paleta
        pequeña (~14 KB) para que el peso extra en el HTML sea mínimo.
        """
        if cls._TRAGSATEC_LOGO_DATA_URI is None:
            try:
                logo_path = os.path.join(os.path.dirname(__file__), "..", "resources", "tragsatec.png")
                with open(logo_path, "rb") as f:
                    b64 = base64.b64encode(f.read()).decode("ascii")
                cls._TRAGSATEC_LOGO_DATA_URI = f"data:image/png;base64,{b64}"
            except OSError:
                cls._TRAGSATEC_LOGO_DATA_URI = ""
        return cls._TRAGSATEC_LOGO_DATA_URI

    def _log(self, msg):
        if self.log_callback:
            try:
                self.log_callback(msg)
            except Exception:
                pass

    def generate_html(self, metrics_data, filename="informe_auditoria.html", thresholds=None, summary_mode=False, report_id=None):
        path = os.path.join(self.informes_dir, filename)
        
        # Si no pasan umbrales, usar diccionario vacío para evitar errores
        if thresholds is None:
            thresholds = {}

        t0 = time.time()
        html_content = self._build_html(metrics_data, thresholds, summary_mode=summary_mode, filename=filename, report_id=report_id)
        t1 = time.time()

        with open(path, 'w', encoding='utf-8') as f:
            f.write(html_content)
        t2 = time.time()

        n_recintos = len(metrics_data.get('parcel_details', []))
        self._log(
            f"TIEMPOS [{filename}]: construcción HTML = {t1 - t0:.1f}s, "
            f"escritura a disco = {t2 - t1:.1f}s ({len(html_content) / 1_000_000:.1f} MB, "
            f"{n_recintos} recintos)."
        )

        return path

    def generate_html_summary(self, metrics_data, filename="informe_auditoria_resumen.html", thresholds=None, report_id=None):
        """
        Genera el informe "resumen" (de presentación): misma información
        identificativa y de croquis que el informe ampliado, pero sin la
        sección de métricas detalladas, y con el croquis + su leyenda a la
        izquierda y las dos interpretaciones (paramétrica / alternativa)
        apiladas a la derecha, en una rejilla de 2 columnas x 2 filas.
        """
        return self.generate_html(metrics_data, filename=filename, thresholds=thresholds, summary_mode=True, report_id=report_id)

    def _polygons_from_geom(self, geom):
        """Normaliza una QgsGeometry (simple o multi) a una lista de polígonos,
        donde cada polígono es una lista de anillos [exterior, interior...]."""
        if not geom or geom.isNull() or geom.isEmpty():
            return []
        try:
            if geom.isMultipart():
                return geom.asMultiPolygon()
            poly = geom.asPolygon()
            return [poly] if poly else []
        except Exception:
            return []

    def _trunc2(self, val):
        """Trunca (NO redondea) un valor a 2 decimales. Antes de truncar
        se redondea a 6 decimales para eliminar el ruido de precisión de
        coma flotante (p.ej. un valor conceptualmente 123.46 que Python
        representa internamente como 123.45999999999998, que si se
        truncase en crudo daría 123.45 en vez de 123.46)."""
        return math.trunc(round(val, 6) * 100) / 100.0

    def _shoelace_ring_area(self, ring):
        """Área de un anillo (lista de vértices con .x()/.y()) mediante la
        fórmula de Gauss / algoritmo de la lazada (shoelace), truncando
        cada coordenada a 2 decimales antes de operar -- replica el área
        que resultaría de un GML cuyas coordenadas se exportan con esa
        precisión. Válido tanto si el anillo viene cerrado (primer punto
        == último) como abierto: el término de cierre se anula solo."""
        if not ring or len(ring) < 3:
            return 0.0
        pts = [(self._trunc2(p.x()), self._trunc2(p.y())) for p in ring]
        n = len(pts)
        acc = 0.0
        for i in range(n):
            x1, y1 = pts[i]
            x2, y2 = pts[(i + 1) % n]
            acc += x1 * y2 - x2 * y1
        return abs(acc) / 2.0

    def _gauss_area_truncated(self, geom):
        """Área total de una geometría (simple o multiparte) mediante la
        fórmula de Gauss / algoritmo de la lazada, con las coordenadas de
        cada vértice truncadas a 2 decimales (ver _trunc2).

        Islas (partes independientes, geometría multiparte): cada parte
        aporta su propio anillo exterior con área propia; se suman sin
        más, el shoelace de cada parte ya da su área neta por separado.

        Huecos (anillos interiores de un mismo polígono): el shoelace por
        sí solo no distingue anillo exterior de interior -- solo calcula
        el área que encierra un anillo dado. Hay que restar
        explícitamente el área de cada anillo interior (rings[1:]) del
        área del anillo exterior (rings[0]), igual que hace QGIS/GEOS
        internamente al calcular geom.area() de un polígono con huecos.

        La superficie resultante se devuelve redondeada SIN decimales
        (entero): así es como exige expresarla la especificación GML de
        parcela catastral (la que usará posteriormente el registrador), y
        es sobre ese valor entero -- no sobre el resultado en coma
        flotante del shoelace -- sobre el que se calcula después el % de
        error frente a supfT24 (ver _supft24_pct / _render_supft24_row).

        RENDIMIENTO: esta misma geometría (geom_a/geom_d de un recinto)
        pasa por aquí varias veces dentro de una sola pasada del informe
        (fila informativa supfT24, filtro de "Validación" del TOC, y
        cápsula de datos de anotaciones), y la pasada se repite además
        para el informe ampliado y el resumen -- hasta 6 recálculos del
        mismo shoelace por recinto. Como estas geometrías (ya disueltas
        en metrics_calculation) no cambian durante la generación del
        informe, se memoiza el resultado por identidad de objeto.
        """
        if not geom or geom.isNull() or geom.isEmpty():
            return 0
        cache = self._gauss_area_cache
        key = id(geom)
        cached = cache.get(key)
        if cached is not None:
            return cached
        total = 0.0
        for poly in self._polygons_from_geom(geom):
            if not poly:
                continue
            exterior_area = self._shoelace_ring_area(poly[0])
            holes_area = sum(self._shoelace_ring_area(r) for r in poly[1:])
            total += exterior_area - holes_area
        result = round(total)
        cache[key] = result
        return result

    def _build_svg_path(self, geom, transform):
        """Construye un atributo 'd' de <path> SVG (con regla evenodd) a partir
        de una QgsGeometry, aplicando la función transform(x,y) -> (sx,sy)."""
        polygons = self._polygons_from_geom(geom)
        if not polygons:
            return ""
        d_parts = []
        for poly in polygons:
            for ring in poly:
                if not ring or len(ring) < 2:
                    continue
                pts = [transform(p.x(), p.y()) for p in ring]
                d_parts.append("M " + " L ".join(f"{x:.2f},{y:.2f}" for x, y in pts) + " Z")
        return " ".join(d_parts)

    def _generate_sketch_svg(self, d, thresholds=None, summary_mode=False):
        """
        Genera un croquis de alteración tipo Catastro: superpone la situación
        ANTES (línea discontinua azul) y DESPUÉS (línea continua negra) del
        recinto, sombreando en azul (Okabe-Ito #0072B2) la superficie ganada
        y en naranja (Okabe-Ito #E69F00) la superficie perdida entre ambas
        situaciones, paleta segura para personas con daltonismo
        (deuteranopia/protanopia/tritanopia), para que se vea de un vistazo
        qué ha cambiado.
        """
        geom_a = d.get('geom_a')
        geom_d = d.get('geom_d')
        full_id = d.get('id', '???')

        has_a = geom_a and not geom_a.isNull() and not geom_a.isEmpty()
        has_d = geom_d and not geom_d.isNull() and not geom_d.isEmpty()

        if not has_a and not has_d:
            self._sketch_log_count += 1
            self._log(
                f"<font color='red'>CROQUIS: sin geom_a NI geom_d para xID '{full_id}' "
                f"(estado={d.get('state')}). No se encontró esta finca en ANTES-ok ni en "
                f"DESPUES-ok con ese identificador exacto: revisa si el xID difiere en "
                f"formato entre capas (mayúsculas, ceros, decimales, espacios).</font>"
            )
            return (
                f'<div class="sketch-section sketch-error">'
                f'<div class="panel-title">CROQUIS DE ALTERACIÓN (ANTES / DESPUÉS)</div>'
                f'<div style="font-size:0.8em; color:#c0392b">'
                f'No se ha podido generar el croquis: no se ha encontrado geometría para el '
                f'identificador <code>{full_id}</code> ni en ANTES-ok ni en DESPUES-ok. '
                f'Revise el log del proceso para más detalle (posible discrepancia de formato en xID).'
                f'</div></div>'
            )

        try:
            return self._render_sketch_svg(d, geom_a if has_a else None, geom_d if has_d else None, thresholds, summary_mode=summary_mode)
        except Exception as e:
            import traceback
            self._log(f"<font color='red'>CROQUIS: excepción al renderizar xID '{full_id}': {e}</font>")
            self._log(f"<pre style='font-size:0.7em'>{traceback.format_exc()}</pre>")
            return (
                f'<div class="sketch-section sketch-error">'
                f'<div class="panel-title">CROQUIS DE ALTERACIÓN (ANTES / DESPUÉS)</div>'
                f'<div style="font-size:0.8em; color:#999">No se ha podido generar el croquis para este recinto ({str(e)}).</div>'
                f'</div>'
            )

    def _fix_geom(self, geom):
        """Repara topología (auto-intersecciones, anillos degenerados, etc.) que
        son habituales en shapefiles catastrales y que de otro modo hacen
        fallar silenciosamente las operaciones de diferencia geométrica."""
        if geom is None:
            return None
        g = geom
        try:
            if hasattr(g, 'isGeosValid') and not g.isGeosValid():
                if hasattr(g, 'makeValid'):
                    fixed = g.makeValid()
                    if fixed and not fixed.isNull() and not fixed.isEmpty():
                        g = fixed
        except Exception:
            pass
        if g is None or g.isNull() or g.isEmpty():
            return geom
        return g

    def _dissolve_for_sketch(self, geoms):
        """Fusiona en una sola geometría la lista de fragmentos UNION (ya
        recortados/validados) que componen la superficie ganada o perdida de
        un flujo. No recalcula ninguna intersección: solo une piezas que ya
        vienen calculadas correctamente desde la capa UNION."""
        geoms = [g for g in geoms if g and not g.isNull() and not g.isEmpty()]
        if not geoms:
            return None
        if len(geoms) == 1:
            return geoms[0]
        try:
            merged = QgsGeometry.unaryUnion(geoms)
            if merged and not merged.isNull() and not merged.isEmpty():
                return merged
        except Exception:
            pass
        try:
            result = geoms[0]
            for g in geoms[1:]:
                result = result.combine(g)
            return result
        except Exception:
            return geoms[0]

    def _build_svg_path_lines(self, geom, transform):
        """Construye un atributo 'd' de <path> SVG (solo trazo, sin cierre ni
        relleno) a partir de una QgsGeometry de tipo línea (simple o multi)."""
        if not geom or geom.isNull() or geom.isEmpty():
            return ""
        try:
            lines = geom.asMultiPolyline() if geom.isMultipart() else None
            if lines is None:
                line = geom.asPolyline()
                lines = [line] if line else []
        except Exception:
            return ""
        d_parts = []
        for line in lines:
            if not line or len(line) < 2:
                continue
            pts = [transform(p.x(), p.y()) for p in line]
            d_parts.append("M " + " L ".join(f"{x:.2f},{y:.2f}" for x, y in pts))
        return " ".join(d_parts)

    def _points_from_geoms(self, geoms, transform):
        """Extrae una lista de coordenadas SVG (x, y) a partir de una lista de
        QgsGeometry de tipo punto (simple o multi)."""
        pts = []
        for g in geoms or []:
            if not g or g.isNull() or g.isEmpty():
                continue
            try:
                if g.isMultipart():
                    for p in g.asMultiPoint():
                        pts.append(transform(p.x(), p.y()))
                else:
                    p = g.asPoint()
                    pts.append(transform(p.x(), p.y()))
            except Exception:
                continue
        return pts

    def _adit_alert_flags(self, adits, thresholds=None):
        """Devuelve el conjunto de nombres de elemento de 'aditamentos' que
        superan los umbrales configurados (longitud, superficie o nº de
        elementos) — es decir, los mismos que disparan la notificación en
        _collect_adit_alert_reasons. Se usa para resaltarlos en el croquis."""
        if not adits:
            return set()
        TOL = 0.001
        t_linear_abs = 1.0; t_linear_pct = 5.0
        t_poly_abs = 1.0; t_poly_pct = 5.0
        if thresholds and 'aditamentos' in thresholds:
            t_linear_abs = thresholds['aditamentos'].get('linear', {}).get('abs', 1.0)
            t_linear_pct = thresholds['aditamentos'].get('linear', {}).get('pct', 5.0)
            t_poly_abs = thresholds['aditamentos'].get('poly', {}).get('abs', 1.0)
            t_poly_pct = thresholds['aditamentos'].get('poly', {}).get('pct', 5.0)

        flagged = set()
        for el_name, data in adits.items():
            a = data.get('a', {'len': 0, 'area': 0, 'count': 0})
            dv = data.get('d', {'len': 0, 'area': 0, 'count': 0})

            if a.get('len', 0) >= TOL or dv.get('len', 0) >= TOL:
                delta = dv.get('len', 0) - a.get('len', 0)
                pct = self._get_pct(a.get('len', 0), dv.get('len', 0))
                if self._chk(delta, t_linear_abs) or self._chk(pct, t_linear_pct):
                    flagged.add(el_name)

            if a.get('area', 0) >= TOL or dv.get('area', 0) >= TOL:
                delta = dv.get('area', 0) - a.get('area', 0)
                pct = self._get_pct(a.get('area', 0), dv.get('area', 0))
                if self._chk(delta, t_poly_abs) or self._chk(pct, t_poly_pct):
                    flagged.add(el_name)

            if a.get('count', 0) != dv.get('count', 0):
                flagged.add(el_name)

        return flagged

    def _pick_scale_length(self, max_meters):
        """Elige una longitud 'redonda' en metros (1-2-5-10-20-50-100-200-500...)
        que quepa dentro de max_meters, para la barra de escala gráfica."""
        if max_meters <= 0:
            return 1
        steps = [1, 2, 5]
        magnitude = 1
        best = 1
        while True:
            for s in steps:
                candidate = s * magnitude
                if candidate <= max_meters:
                    best = candidate
                else:
                    return best
            magnitude *= 10

    def _format_owner_label(self, owner_val, special_owners):
        """Si owner_val coincide con uno de los propietarios especiales
        mapeados (AGADER / MASA COMÚN / DESCONOCIDOS), le añade la
        denominación entre paréntesis junto al número. Si no coincide (o
        no hay mapeo válido), devuelve el valor tal cual."""
        if not special_owners or owner_val in (None, '', 'N/A'):
            return owner_val
        try:
            owner_num = int(str(owner_val).strip())
        except (ValueError, TypeError):
            return owner_val
        info = special_owners.get(owner_num)
        if info:
            return f"{owner_val} ({info['name']})"
        return owner_val

    def _sketch_diag_div(self, d, reason):
        full_id = d.get('id', '???')
        return (
            f'<div class="sketch-section sketch-error">'
            f'<div class="panel-title">CROQUIS DE ALTERACIÓN (ANTES / DESPUÉS)</div>'
            f'<div style="font-size:0.8em; color:#c0392b">'
            f'No se ha podido dibujar el croquis de <code>{full_id}</code>: {reason}'
            f'</div></div>'
        )

    def _build_context_geom_index(self, geoms_dict):
        """Construye un QgsSpatialIndex (por bounding box) sobre TODAS las
        geometrías de contexto DESPUÉS, para poder consultar por recuadro de
        croquis (`view_rect`) en O(log N) en lugar de recorrer el
        diccionario completo por cada recinto del informe. Devuelve el
        índice y un mapeo id-entero -> pid (QgsSpatialIndex solo admite
        ids enteros, no las claves de texto xID)."""
        index = QgsSpatialIndex()
        id_to_pid = {}
        if not geoms_dict:
            return index, id_to_pid
        fid = 0
        for pid, geom in geoms_dict.items():
            if geom is None or geom.isNull() or geom.isEmpty():
                continue
            feat = QgsFeature(fid)
            feat.setGeometry(geom)
            index.insertFeature(feat)
            id_to_pid[fid] = pid
            fid += 1
        return index, id_to_pid

    def _build_context_adits_index(self, context_adits):
        """Igual que `_build_context_geom_index` pero para los aditamentos
        de fincas vecinas: se indexa, por xID, el bounding box combinado de
        TODAS las geometrías 'd' (DESPUÉS) de ese recinto, sea cual sea el
        elemento técnico (vallado, piscina, porche...). Con esto, la
        consulta por recuadro de croquis descarta de un vistazo los
        recintos cuyos aditamentos no pueden ser visibles, sin tener que
        recorrer el diccionario completo de aditamentos por cada ficha."""
        index = QgsSpatialIndex()
        id_to_pid = {}
        if not context_adits:
            return index, id_to_pid
        fid = 0
        for pid, el_map in context_adits.items():
            if not el_map:
                continue
            bbox = None
            for adata in el_map.values():
                for g in adata.get('d', {}).get('geoms', []):
                    if not g or g.isNull() or g.isEmpty():
                        continue
                    try:
                        bb = g.boundingBox()
                    except Exception:
                        continue
                    if bbox is None:
                        bbox = QgsRectangle(bb)
                    else:
                        bbox.combineExtentWith(bb)
            if bbox is None:
                continue
            feat = QgsFeature(fid)
            feat.setGeometry(QgsGeometry.fromRect(bbox))
            index.insertFeature(feat)
            id_to_pid[fid] = pid
            fid += 1
        return index, id_to_pid

    def _render_sketch_svg(self, d, geom_a, geom_d, thresholds=None, summary_mode=False):
        """Construye el SVG del croquis. geom_a/geom_d ya vienen validados como
        no nulos/no vacíos (o None si esa situación no existe para el recinto)."""
        has_a = geom_a is not None
        has_d = geom_d is not None

        geom_a_fixed = self._fix_geom(geom_a) if has_a else None
        geom_d_fixed = self._fix_geom(geom_d) if has_d else None

        # Bounding box combinado de ambas geometrías. OJO: QgsRectangle.combineExtentWith()
        # modifica el rectángulo EN SITIO y no devuelve nada (None) — reasignar su
        # resultado (como se hacía antes) borraba el bbox ya calculado en cuanto había
        # una segunda geometría que combinar, que es justo el caso de toda finca
        # PERSISTENTE (tiene ANTES y DESPUÉS a la vez). Por eso el croquis nunca salía
        # salvo en ALTA/BAJA, donde solo hay una geometría y el bug no se disparaba.
        bbox = None
        for g in (geom_a_fixed, geom_d_fixed):
            if g is not None:
                bb = g.boundingBox()
                if bbox is None:
                    bbox = bb
                else:
                    bbox.combineExtentWith(bb)

        if bbox is None or bbox.width() < 0 or bbox.height() < 0:
            self._log(f"<font color='red'>CROQUIS: bbox inválido para xID '{d.get('id')}' "
                       f"(bbox={bbox}). has_a={has_a} has_d={has_d}.</font>")
            return self._sketch_diag_div(d, "no se pudo calcular el rectángulo envolvente de la geometría (bbox inválido).")

        svg_w, svg_h = 560, 380
        w = bbox.width() if bbox.width() > 0.001 else 1.0
        h = bbox.height() if bbox.height() > 0.001 else 1.0

        # Margen del 10% alrededor de la geometría
        pad_x = w * 0.10
        pad_y = h * 0.10
        minx = bbox.xMinimum() - pad_x
        miny = bbox.yMinimum() - pad_y
        ext_w = w + 2 * pad_x
        ext_h = h + 2 * pad_y

        scale = min(svg_w / ext_w, svg_h / ext_h)
        used_w = ext_w * scale
        used_h = ext_h * scale
        offset_x = (svg_w - used_w) / 2.0
        offset_y = (svg_h - used_h) / 2.0

        def transform(x, y):
            sx = (x - minx) * scale + offset_x
            sy = svg_h - ((y - miny) * scale + offset_y)  # Y invertido (SVG crece hacia abajo)
            return sx, sy

        path_a = self._build_svg_path(geom_a_fixed, transform) if has_a else ""
        path_d = self._build_svg_path(geom_d_fixed, transform) if has_d else ""

        # Contexto de entorno: contorno tenue de TODOS los demás recintos
        # DESPUÉS cuyo bounding box toque el área dibujada (aunque salgan
        # cortados por el borde, igual que pasaría con un croquis catastral
        # real). Es solo orientativo, así que basta un filtro rápido por
        # bounding box (sin necesidad de recortar/interseccionar la
        # geometría) y se dibuja SIEMPRE por debajo de todo lo demás.
        context_path = ""
        context_path_related = ""
        context_labels_svg = ""
        own_id = d.get('id')

        # Fincas relacionadas en la DINÁMICA TERRITORIAL (los mismos 'source'
        # de los inputs y 'target' de los outputs que se listan en esa
        # sección de la ficha). Estas son las que de verdad interesa poder
        # identificar en el croquis, así que se etiquetan siempre (salvo que
        # sean realmente minúsculas) y con un estilo más marcado que el
        # resto de fincas de contexto, meramente orientativas.
        related_pids = set()
        for fl in d.get('inputs', []):
            src = fl.get('source')
            if src and src != own_id:
                related_pids.add(src)
        for fl in d.get('outputs', []):
            tgt = fl.get('target')
            if tgt and tgt != own_id:
                related_pids.add(tgt)

        view_rect = QgsRectangle(minx, miny, minx + ext_w, miny + ext_h)

        context_geoms = getattr(self, '_context_geoms_despues', None)
        geom_index = getattr(self, '_context_geoms_index', None)
        geom_ids = getattr(self, '_context_geoms_ids', None)
        special_ranges = getattr(self, '_special_ranges', None) or {}
        context_path_edif = ""
        if context_geoms and geom_index is not None:
            ctx_d_parts = []
            ctx_d_parts_related = []
            ctx_d_parts_edif = []
            # Consulta por bbox contra el índice espacial (O(log N)) en vez
            # de recorrer TODO el diccionario de contexto (O(N)) para cada
            # uno de los recintos del informe.
            for cand_fid in geom_index.intersects(view_rect):
                pid = geom_ids.get(cand_fid)
                if pid is None or pid == own_id:
                    continue
                g = context_geoms.get(pid)
                if g is None or g.isNull() or g.isEmpty():
                    continue
                is_related = pid in related_pids
                # Recintos de contexto cuyo nº de REC cae dentro del rango
                # parametrizado como EDIFICACIONES (Ficha 2: Mapeo de
                # Campos): se dibujan con un relleno rayado propio (más
                # abajo, capa aparte) en vez del contorno hueco habitual,
                # para poder distinguirlos de un vistazo del resto de
                # fincas de contexto y de los huecos/islas del propio
                # recinto de estudio. Una finca relacionada con la
                # dinámica territorial (inputs/outputs) conserva siempre
                # su estilo "related", aunque su REC también caiga en ese
                # rango, por ser la distinción más relevante en ese caso.
                is_edif = False
                if not is_related and special_ranges:
                    kind, ref = self._category_or_id(pid, special_ranges)
                    is_edif = (kind == 'categoria' and ref == 'EDIFICACIONES')
                p = self._build_svg_path(g, transform)
                if p:
                    if is_related:
                        ctx_d_parts_related.append(p)
                    elif is_edif:
                        ctx_d_parts_edif.append(p)
                    else:
                        ctx_d_parts.append(p)

                # Etiqueta FINCA-SUBFINCA (mismo criterio que rec_label más
                # abajo: último tramo del id, "REC" o "REC-SUBREC" si el
                # subrecinto es distinto de cero). Se omite si la parcela
                # se ve demasiado pequeña en el croquis para que el texto
                # quepa de forma legible, salvo que sea una finca relacionada
                # con la dinámica territorial (inputs/outputs), en cuyo caso
                # se baja mucho el umbral para asegurarse de que casi
                # siempre salga, ya que es justo la que el lector necesita
                # poder identificar.
                try:
                    bb = g.boundingBox()
                    x0, y0 = transform(bb.xMinimum(), bb.yMinimum())
                    x1, y1 = transform(bb.xMaximum(), bb.yMaximum())
                    px_w, px_h = abs(x1 - x0), abs(y1 - y0)
                    min_w, min_h = (10, 7) if is_related else (26, 12)
                    if px_w >= min_w and px_h >= min_h:
                        ctx_label = str(pid).split('/')[-1]
                        anchor = g.pointOnSurface()
                        if anchor and not anchor.isNull() and not anchor.isEmpty():
                            ax, ay = anchor.asPoint().x(), anchor.asPoint().y()
                            lx, ly = transform(ax, ay)
                            label_cls = "sketch-context-label-related" if is_related else "sketch-context-label"
                            context_labels_svg += (
                                f'<text x="{lx:.1f}" y="{ly:.1f}" '
                                f'class="{label_cls}">{ctx_label}</text>'
                            )
                except Exception:
                    pass

            if ctx_d_parts:
                context_path = " ".join(ctx_d_parts)
            context_path_related = " ".join(ctx_d_parts_related) if ctx_d_parts_related else ""
            context_path_edif = " ".join(ctx_d_parts_edif) if ctx_d_parts_edif else ""

        # Aditamentos de fincas VECINAS (contexto): igual que se dibuja el
        # contorno de los demás recintos DESPUÉS como referencia del
        # entorno, también se dibujan -con un estilo tenue propio, para no
        # confundirlos con los del recinto de estudio- los vallados,
        # piscinas, porches, etc. de esas mismas fincas de contexto que
        # caigan dentro del recuadro del croquis. Sin esto, la "instantánea"
        # solo mostraba los aditamentos de la finca objeto de la ficha y
        # "se comía" los del resto del área visible, aunque existan en el
        # GIS. Se usa siempre la situación DESPUÉS (vigente), igual que el
        # contorno de contexto.
        context_adits_svg = ""
        context_adits = getattr(self, '_context_adits', None)
        adits_index = getattr(self, '_context_adits_index', None)
        adits_ids = getattr(self, '_context_adits_ids', None)
        if context_adits and adits_index is not None:
            # El índice ya descarta por bbox combinado los recintos cuyos
            # aditamentos no pueden tocar el recuadro del croquis, así que
            # solo iteramos los candidatos reales en lugar de TODO el
            # diccionario de aditamentos por cada ficha del informe.
            for cand_fid in adits_index.intersects(view_rect):
                pid = adits_ids.get(cand_fid)
                if pid is None:
                    continue
                el_map = context_adits.get(pid)
                if pid == own_id or not el_map:
                    continue
                for el_name, adata in el_map.items():
                    geoms = adata.get('d', {}).get('geoms', [])
                    if not geoms:
                        continue
                    try:
                        wkb_t = QgsWkbTypes.geometryType(geoms[0].wkbType())
                    except Exception:
                        continue
                    # Filtro fino por bbox individual: el índice solo
                    # garantiza que el bbox COMBINADO del recinto toca el
                    # recuadro; puede haber elementos concretos de ese
                    # mismo recinto que queden fuera.
                    visible = False
                    for g in geoms:
                        if not g or g.isNull() or g.isEmpty():
                            continue
                        try:
                            if g.boundingBox().intersects(view_rect):
                                visible = True
                                break
                        except Exception:
                            continue
                    if not visible:
                        continue

                    if wkb_t == QgsWkbTypes.PolygonGeometry:
                        merged = self._dissolve_for_sketch(geoms)
                        p = self._build_svg_path(merged, transform) if merged else ""
                        if p:
                            context_adits_svg += (
                                f'<path d="{p}" class="sketch-context-adit" fill-rule="evenodd">'
                                f'<title>{el_name} ({pid})</title></path>'
                            )
                    elif wkb_t == QgsWkbTypes.LineGeometry:
                        for g in geoms:
                            lp = self._build_svg_path_lines(g, transform)
                            if lp:
                                context_adits_svg += (
                                    f'<path d="{lp}" class="sketch-context-adit-line">'
                                    f'<title>{el_name} ({pid})</title></path>'
                                )
                    elif wkb_t == QgsWkbTypes.PointGeometry:
                        for (px, py) in self._points_from_geoms(geoms, transform):
                            context_adits_svg += (
                                f'<circle cx="{px:.2f}" cy="{py:.2f}" r="2.0" '
                                f'class="sketch-context-adit-point"><title>{el_name} ({pid})</title></circle>'
                            )

        # Superficie ganada/perdida: NO se recalcula con difference() entre
        # geom_a/geom_d (eso reintersecaba dos capas de origen distinto y
        # generaba "slivers" de ruido por todo el contorno allí donde ANTES
        # y DESPUÉS no encajaban vértice a vértice). En su lugar reutilizamos
        # los fragmentos de la capa UNION ya calculados y limpiados: cada
        # 'output' es el trozo exacto que esta finca cede a otra finca
        # distinta, y cada 'input' el trozo exacto que recibe de otra finca
        # distinta (se excluye el flujo consigo misma, que es el núcleo
        # estable y no representa cambio).
        own_id = d.get('id')
        lost_geoms = [fl['geom'] for fl in d.get('outputs', [])
                      if fl.get('geom') and fl.get('target') != own_id]
        gained_geoms = [fl['geom'] for fl in d.get('inputs', [])
                        if fl.get('geom') and fl.get('source') != own_id]

        gained_path = self._build_svg_path(self._dissolve_for_sketch(gained_geoms), transform) if gained_geoms else ""
        lost_path = self._build_svg_path(self._dissolve_for_sketch(lost_geoms), transform) if lost_geoms else ""

        # Aditamentos (elementos técnicos: vallados, piscinas, porches...)
        # en su situación DESPUÉS, dibujados sobre el croquis para que se
        # vea dónde están dentro de la finca. Los que superan los umbrales
        # configurados (los mismos que disparan la notificación) se
        # resaltan con un estilo de alerta distinto, para diferenciar de un
        # vistazo cuál de ellos es el que ha motivado la notificación.
        adits_svg = ""
        adit_legend_normal = False
        adit_legend_alert = False
        adits = d.get('aditamentos', {})
        if adits:
            alert_names = self._adit_alert_flags(adits, thresholds)
            for el_name, data in sorted(adits.items()):
                geoms = data.get('d', {}).get('geoms', [])
                if not geoms:
                    continue
                is_alert = el_name in alert_names
                cls_poly = "sketch-adit-alert" if is_alert else "sketch-adit"
                cls_line = "sketch-adit-line-alert" if is_alert else "sketch-adit-line"
                cls_pt = "sketch-adit-point-alert" if is_alert else "sketch-adit-point"

                try:
                    wkb_t = QgsWkbTypes.geometryType(geoms[0].wkbType())
                except Exception:
                    wkb_t = None

                if wkb_t == QgsWkbTypes.PolygonGeometry:
                    merged = self._dissolve_for_sketch(geoms)
                    p = self._build_svg_path(merged, transform) if merged else ""
                    if p:
                        adits_svg += f'<path d="{p}" class="{cls_poly}" fill-rule="evenodd"><title>{el_name}</title></path>'
                        adit_legend_alert = adit_legend_alert or is_alert
                        adit_legend_normal = adit_legend_normal or not is_alert
                elif wkb_t == QgsWkbTypes.LineGeometry:
                    any_drawn = False
                    for g in geoms:
                        lp = self._build_svg_path_lines(g, transform)
                        if lp:
                            adits_svg += f'<path d="{lp}" class="{cls_line}"><title>{el_name}</title></path>'
                            any_drawn = True
                    if any_drawn:
                        adit_legend_alert = adit_legend_alert or is_alert
                        adit_legend_normal = adit_legend_normal or not is_alert
                elif wkb_t == QgsWkbTypes.PointGeometry:
                    pt_r = 3.0 if is_alert else 2.4
                    for (px, py) in self._points_from_geoms(geoms, transform):
                        if is_alert:
                            # Rombo (en vez de círculo) para que la alerta se
                            # distinga también por la FORMA, no solo por el
                            # color (más robusto para daltonismo).
                            adits_svg += (
                                f'<rect x="{px - pt_r:.2f}" y="{py - pt_r:.2f}" '
                                f'width="{pt_r * 2:.2f}" height="{pt_r * 2:.2f}" '
                                f'transform="rotate(45 {px:.2f} {py:.2f})" '
                                f'class="{cls_pt}"><title>{el_name}</title></rect>'
                            )
                        else:
                            adits_svg += f'<circle cx="{px:.2f}" cy="{py:.2f}" r="{pt_r}" class="{cls_pt}"><title>{el_name}</title></circle>'
                    if geoms:
                        adit_legend_alert = adit_legend_alert or is_alert
                        adit_legend_normal = adit_legend_normal or not is_alert

        if not path_a and not path_d:
            self._log(
                f"<font color='red'>CROQUIS: paths SVG vacíos para xID '{d.get('id')}'. "
                f"has_a={has_a} has_d={has_d}. "
                f"Tipo geom_a={geom_a_fixed.wkbType() if geom_a_fixed else None} "
                f"({geom_a_fixed.asWkt()[:120] if geom_a_fixed else ''}). "
                f"Tipo geom_d={geom_d_fixed.wkbType() if geom_d_fixed else None} "
                f"({geom_d_fixed.asWkt()[:120] if geom_d_fixed else ''}).</font>"
            )
            return self._sketch_diag_div(
                d, "la geometría existe pero no se ha podido convertir a un polígono dibujable "
                   "(revise el log: probablemente es un tipo de geometría no soportado tras la "
                   "reparación de topología, p.ej. GeometryCollection en vez de Polygon)."
            )

        # Sombreado sólido del recinto de estudio (gris clarito), para que
        # destaque de un vistazo sobre el resto de recintos de contexto
        # (dibujados sin relleno, solo contorno). Se usa la geometría
        # DESPUÉS como referencia principal por ser la situación vigente;
        # si el recinto no tiene DESPUÉS (p.ej. una BAJA, que solo existe en
        # ANTES) se usa ésta como alternativa. Se dibuja antes que las capas
        # de superficie ganada/perdida y los contornos ANTES/DESPUÉS, para
        # que ese sombreado quede como fondo del recinto y no tape esas
        # capas informativas que se pintan por encima.
        study_path = path_d if path_d else path_a
        layers_svg = ""
        if context_path:
            layers_svg += f'<path d="{context_path}" class="sketch-context" fill-rule="evenodd" />'
        if context_path_edif:
            layers_svg += f'<path d="{context_path_edif}" class="sketch-context-edif" fill-rule="evenodd" />'
        if context_path_related:
            layers_svg += f'<path d="{context_path_related}" class="sketch-context-related" fill-rule="evenodd" />'
        if context_labels_svg:
            layers_svg += context_labels_svg
        if context_adits_svg:
            layers_svg += context_adits_svg
        if study_path:
            layers_svg += f'<path d="{study_path}" class="sketch-study-fill" fill-rule="evenodd" />'
        if lost_path:
            layers_svg += f'<path d="{lost_path}" class="sketch-lost" fill-rule="evenodd" />'
        if gained_path:
            layers_svg += f'<path d="{gained_path}" class="sketch-gained" fill-rule="evenodd" />'
        if path_a:
            layers_svg += f'<path d="{path_a}" class="sketch-antes" fill-rule="evenodd" />'
        if path_d:
            layers_svg += f'<path d="{path_d}" class="sketch-despues" fill-rule="evenodd" />'
        if adits_svg:
            layers_svg += adits_svg

        # Etiqueta de finca / subrecinto: el id unificado tiene forma
        # POL/MASA[-SUBMASA]/REC[-SUBREC]; el último tramo ya es exactamente
        # "REC" o "REC-SUBREC" (con el guión delante solo si el subrecinto
        # es distinto de cero), que es lo que se quiere mostrar en el croquis.
        rec_label = ""
        full_id = d.get('id')
        if full_id:
            rec_label = str(full_id).split('/')[-1]

        label_html = f'<div class="sketch-label">Recinto {rec_label}</div>' if rec_label else ""

        # Escala gráfica: 'scale' ya está en píxeles-SVG por metro (unidades
        # del SRC del proyecto, normalmente metros). Elegimos una longitud
        # redonda que ocupe aprox. 1/4-1/3 del ancho del croquis. Se dibuja
        # como mini-SVG aparte (no dentro del croquis principal) para poder
        # colocarla en la columna lateral, junto a la leyenda.
        # IMPORTANTE: el texto NO va dentro del <svg>; algunos visores HTML
        # (p.ej. el de este informe en ciertos entornos) no escalan el
        # contenido del SVG según el viewBox/CSS y el texto sale enorme y
        # descolocado. Por eso aquí el SVG solo lleva la línea y las marcas
        # (con width/height explícitos para fijar su tamaño real en
        # píxeles, sin depender del viewBox), y el texto "20 m" se pone
        # como HTML normal justo debajo, centrado, con su propio font-size.
        sb_w, sb_h = 120, 14
        scale_len_m = self._pick_scale_length((sb_w * 0.74) / scale)
        scale_len_px = scale_len_m * scale
        sb_x0, sb_y = (sb_w - scale_len_px) / 2.0, sb_h / 2.0
        sb_text = f"{self._fmt_val(scale_len_m, force_int=True)} m"
        scale_svg = f"""
            <div class="sketch-scale-block">
                <svg width="{sb_w}" height="{sb_h}" viewBox="0 0 {sb_w} {sb_h}" class="sketch-scalebar-svg" xmlns="http://www.w3.org/2000/svg">
                    <g class="sketch-scalebar">
                        <line x1="{sb_x0:.1f}" y1="{sb_y}" x2="{sb_x0 + scale_len_px:.1f}" y2="{sb_y}" />
                        <line x1="{sb_x0:.1f}" y1="{sb_y - 3}" x2="{sb_x0:.1f}" y2="{sb_y + 3}" />
                        <line x1="{sb_x0 + scale_len_px:.1f}" y1="{sb_y - 3}" x2="{sb_x0 + scale_len_px:.1f}" y2="{sb_y + 3}" />
                    </g>
                </svg>
                <div class="sketch-scalebar-text">{sb_text}</div>
            </div>
        """

        no_change_note = ""
        if has_a and has_d and not gained_path and not lost_path:
            if summary_mode:
                # El informe resumen no incluye la tabla de métricas, así que
                # no tiene sentido remitir a ella.
                no_change_note = (
                    '<div class="sketch-note">El contorno geométrico del recinto no presenta variación '
                    'apreciable; la notificación se debe a otros parámetros.</div>'
                )
            else:
                no_change_note = (
                    '<div class="sketch-note">El contorno geométrico del recinto no presenta variación '
                    'apreciable; la notificación se debe a otros parámetros (ver tabla superior).</div>'
                )

        adit_legend_items = ""
        if adit_legend_normal:
            adit_legend_items += '<span><i class="leg-swatch leg-adit"></i>Aditamento</span>'
        if adit_legend_alert:
            adit_legend_items += '<span><i class="leg-swatch leg-adit-alert"></i>Aditamento con variación a notificar</span>'

        edif_legend_item = (
            '<span><i class="leg-swatch leg-edif"></i>Edificación (contexto)</span>'
            if context_path_edif else ""
        )

        legend = f"""
            <div class="sketch-legend">
                <span><i class="leg-swatch leg-antes"></i>Situación ANTES</span>
                <span><i class="leg-swatch leg-despues"></i>Situación DESPUÉS</span>
                <span><i class="leg-swatch leg-gained"></i>Superficie ganada</span>
                <span><i class="leg-swatch leg-lost"></i>Superficie perdida</span>
                {edif_legend_item}
                {adit_legend_items}
            </div>"""

        return f"""
            <div class="sketch-section">
                <div class="sketch-frame">
                    <div class="sketch-canvas">
                        {label_html}
                        <svg viewBox="0 0 {svg_w} {svg_h}" class="sketch-svg" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid meet">
                            <defs>
                                <pattern id="aditAlertHatch" patternUnits="userSpaceOnUse" width="6" height="6" patternTransform="rotate(45)">
                                    <rect width="6" height="6" fill="#CC79A7" fill-opacity="0.30" />
                                    <line x1="0" y1="0" x2="0" y2="6" stroke="#000000" stroke-width="2" />
                                </pattern>
                                <pattern id="edifHatch" patternUnits="userSpaceOnUse" width="4" height="4" patternTransform="rotate(45)">
                                    <rect width="4" height="4" fill="#ffffff" fill-opacity="0" />
                                    <line x1="0" y1="0" x2="0" y2="4" stroke="#555555" stroke-width="0.8" />
                                </pattern>
                            </defs>
                            <rect x="1" y="1" width="{svg_w - 2}" height="{svg_h - 2}" class="sketch-bg" />
                            {layers_svg}
                        </svg>
                    </div>
                    <div class="sketch-sidebar">
                        {legend}
                        {scale_svg}
                    </div>
                </div>
                {no_change_note}
            </div>
        """

    def _chk(self, val, threshold):
        """Comprueba si un valor supera un umbral y devuelve '*' o cadena vacía."""
        if threshold is None or threshold == 0: return ""
        
        mark = ""
        if abs(val) > threshold: mark = " *"
        return mark

    def _chk_neg(self, val, threshold):
        """Comprueba si un valor baja de un umbral (mínimo) y devuelve '*' o cadena vacía."""
        if threshold is None or threshold == 0: return ""
        if val < threshold: return " *"
        return ""

    def _html_to_plain(self, html):
        """Reduce un fragmento HTML (los bloques de conclusión de las
        fichas) a texto plano de una línea, para poder incrustarlo en el
        XML de respuestas sin etiquetas ni entidades. Solo se usa sobre
        HTML generado por este mismo módulo (nunca sobre texto de
        usuario), así que un strip de etiquetas por regex es suficiente."""
        if not html:
            return ''
        text = re.sub(r'<[^>]+>', ' ', html)
        text = html_lib.unescape(text)
        text = re.sub(r'\s+', ' ', text).strip()
        return text

    def _supft24_pct(self, supft24, area_gml):
        """Calcula la desviación (supfT24 - superficie_GML) / supfT24, en %,
        entre la superficie de referencia T24 de un recinto y su superficie
        real (GML). Comprobación puramente informativa: nunca condiciona
        ninguna alerta de notificación.

        Devuelve (pct, is_unknown):
          - supfT24 ausente/no numérico, -1 (sin dato) o 0 (evita división
            por cero) -> (None, True): el informe debe mostrar '?'.
          - en cualquier otro caso -> (pct_float, False).

        IMPORTANTE: el % se calcula siempre con la superficie SIN
        decimales (la regla de redondeo de la especificación GML de
        parcela catastral, que es la que se muestra en el informe), no
        con la superficie de doble precisión que maneja QGIS
        internamente -- de lo contrario el % mostrado no se
        correspondería con las superficies (también sin decimales) que
        aparecen justo al lado. Por eso `area_gml` se redondea aquí
        antes de calcular el %; si ya llega redondeada (p.ej. la
        superficie GML truncada por `_gauss_area_truncated`) el
        round() no tiene ningún efecto.
        """
        if supft24 is None:
            return None, True
        try:
            val = float(supft24)
        except (TypeError, ValueError):
            return None, True
        if val == -1 or val == 0:
            return None, True
        try:
            area_val = round(float(area_gml or 0))
        except (TypeError, ValueError):
            area_val = 0.0
        pct = (val - area_val) / val * 100.0
        return pct, False

    def _t24_minus_gml_area(self, supft24, area_gml_trunc):
        """Diferencia en m² -- NO en % -- entre supfT24 y la superficie GML
        de un mismo estado (Antes o Después): supfT24 - area_gml_trunc.

        Es el numerador (sin dividir ni multiplicar por 100) del mismo
        cálculo que hace `_supft24_pct`, así que comparte sus reglas de
        "sin dato" (supfT24 ausente, no numérico, -1 o 0 -> (None, True))
        y también redondea `area_gml_trunc` antes de restar, por la misma
        razón: que la diferencia mostrada cuadre con las superficies (ya
        sin decimales) que se ven justo al lado.

        A propósito NO comparamos supfT24 contra la superficie "gráfica"
        (area_a/area_d, fragmentos de la capa UNION), sino contra
        `area_gml_trunc` -- la superficie truncada según la fórmula de
        Gauss (ver `_gauss_area_truncated`) de ESE MISMO lado: es la
        comparación más representativa, porque supfT24 es en sí mismo un
        valor de referencia catastral y area_gml_trunc es la superficie
        que tendría el recinto en un GML de parcela catastral con esa
        misma precisión -- ambos "hablan el mismo idioma".
        """
        if supft24 is None:
            return None, True
        try:
            val = float(supft24)
        except (TypeError, ValueError):
            return None, True
        if val == -1 or val == 0:
            return None, True
        area_val = round(float(area_gml_trunc or 0))
        return val - area_val, False

    def _render_supft24_row(self, supft24_a, supft24_d, area_a, area_d, thresholds, geom_a=None, geom_d=None):
        """Fila informativa ANTES/DESPUÉS con el % de desviación entre
        'supfT24' y la superficie real (GML), sombreada en rojo (supera el
        umbral '% Validación') o verde (no lo supera); '?' en amarillo con
        texto negro cuando no se puede calcular. Puramente informativa.

        Junto a cada uno de Antes y Después se añade un segundo % ('GML: ')
        calculado igual (supfT24 vs. superficie), pero usando como
        superficie la que resulta de aplicar la fórmula de Gauss (algoritmo
        de la lazada) con las coordenadas de cada vértice truncadas a 2
        decimales y redondeada sin decimales -- replica el área real que
        tendría el recinto en un GML de parcela catastral exportado con
        esa precisión, que puede diferir ligeramente del área de doble
        precisión que usa QGIS internamente. Antes usa geom_a, Después usa
        geom_d.

        Devuelve una tupla (check_html, areas_row_html, diff_gml_cell_html):
        la primera es la fila '% de error' de siempre; la segunda es la
        línea con las cuatro superficies del recinto -- Antes, GML de
        Antes, Después y GML de Después --, todas sin decimales (regla de
        redondeo de la especificación GML de parcela catastral), que el
        llamador coloca junto a la diferencia Antes/Después en la misma
        línea; la tercera es una celda con las DOS diferencias supfT24 -
        GML en m² (Antes y Después por separado, cada una etiquetada), la
        versión en valor absoluto -- más representativa que la superficie
        "gráfica" Antes/Después ya existente -- de los mismos % 'GML:' que
        ya muestra el check_html (todas se devuelven por separado para que
        el llamador pueda maquetarlas donde convenga)."""
        limit = thresholds.get('validacion_pct', 10.0) if thresholds else 10.0
        try:
            limit = float(limit)
        except (TypeError, ValueError):
            limit = 10.0

        def _span(pct, is_unknown, blink=False):
            if is_unknown:
                return '<span class="t24-val t24-unknown">?</span>'
            over_limit = abs(pct) > limit
            cls = "t24-red" if over_limit else "t24-green"
            if blink and over_limit:
                cls += " t24-despues-blink"
            # Interpretación gráfica de la desviación (pct = (supfT24 -
            # area_gml) / supfT24 * 100):
            #   pct < 0 -> supfT24 < area_gml -> el GML es mayor -> flecha arriba
            #   pct > 0 -> supfT24 > area_gml -> el GML es menor (pierde respecto a T24) -> flecha abajo
            #   pct == 0 -> sin diferencia -> sin flecha
            if pct < 0:
                arrow = '<span class="t24-arrow t24-arrow-up" title="La superficie GML es mayor que supfT24">&#8593;</span>'
            elif pct > 0:
                arrow = '<span class="t24-arrow t24-arrow-down" title="La superficie GML es menor que supfT24">&#8595;</span>'
            else:
                arrow = ''
            return f'<span class="t24-val {cls}">{pct:+.2f}%{arrow}</span>'

        def _supft24_label(val, is_unknown):
            if is_unknown:
                return '?'
            return f"{val:.2f}"

        pct_a, unk_a = self._supft24_pct(supft24_a, area_a)
        pct_d, unk_d = self._supft24_pct(supft24_d, area_d)

        # area_gml_trunc_a / area_gml_trunc_d ya llegan redondeadas sin
        # decimales (ver _gauss_area_truncated): esa es la superficie --
        # conforme a la especificación GML de parcela catastral -- sobre
        # la que se calcula el % de error frente a supfT24, y también la
        # que se muestra en la fila de superficies.
        area_gml_trunc_a = self._gauss_area_truncated(geom_a) if geom_a is not None else 0
        pct_gml_a, unk_gml_a = self._supft24_pct(supft24_a, area_gml_trunc_a) if geom_a is not None else (None, True)
        gml_span_a = (
            f'<span class="t24-lbl t24-gml-lbl" title="Desviación de supfT24 respecto a la superficie GML de Antes: fórmula de Gauss (lazada) truncando cada coordenada de vértice a 2 decimales y redondeando el resultado sin decimales, tal y como exige la especificación GML de parcela catastral que después empleará el registrador">GML:</span>{_span(pct_gml_a, unk_gml_a)}'
        )

        area_gml_trunc_d = self._gauss_area_truncated(geom_d) if geom_d is not None else 0
        pct_gml_d, unk_gml_d = self._supft24_pct(supft24_d, area_gml_trunc_d) if geom_d is not None else (None, True)
        gml_span_d = (
            f'<span class="t24-lbl t24-gml-lbl" title="Desviación de supfT24 respecto a la superficie GML de Después: fórmula de Gauss (lazada) truncando cada coordenada de vértice a 2 decimales y redondeando el resultado sin decimales, tal y como exige la especificación GML de parcela catastral que después empleará el registrador">GML:</span>{_span(pct_gml_d, unk_gml_d, blink=True)}'
        )

        def _fmt_area_int(v):
            # Las cuatro superficies (Antes, GML de Antes, Después, GML de
            # Después) se muestran sin decimales: es la regla de redondeo
            # que exige la especificación GML de parcela catastral.
            if v is None:
                return '?'
            try:
                return f"{round(v):d}"
            except (TypeError, ValueError):
                return '?'

        areas_row_html = (
            'Antes/GML - Despu&eacute;s/GML (m<sup>2</sup>): '
            f'{_fmt_area_int(area_a)}/{_fmt_area_int(area_gml_trunc_a)} - '
            f'{_fmt_area_int(area_d)}/{_fmt_area_int(area_gml_trunc_d)}'
        )

        check_html = (
            '<div class="t24-check">'
            f'<span class="t24-lbl">Validaci&oacute;n -&gt; Antes ({_supft24_label(supft24_a, unk_a)} m<sup>2</sup>):</span>{_span(pct_a, unk_a)}'
            f'{gml_span_a}'
            f'<span class="t24-lbl">Despu&eacute;s ({_supft24_label(supft24_d, unk_d)} m<sup>2</sup>):</span>{_span(pct_d, unk_d, blink=True)}'
            f'{gml_span_d}'
            '</div>'
        )

        # Diferencia supfT24 - GML en m² (valor absoluto, no %), Antes y
        # Después por separado -- más representativa que la diferencia
        # "gráfica" Antes/Después (área de la geometría, sin relación con
        # supfT24) que ya se muestra al lado. Con etiqueta SIEMPRE visible
        # (no solo tooltip) para que se entienda qué es cada superficie
        # también en el informe impreso, donde los tooltips no se ven.
        diff_gml_a, diff_unk_a = self._t24_minus_gml_area(supft24_a, area_gml_trunc_a)
        diff_gml_d, diff_unk_d = self._t24_minus_gml_area(supft24_d, area_gml_trunc_d)

        def _diff_gml_span(diff, is_unknown):
            if is_unknown:
                return '<span class="t24-diff-gml-val t24-diff-gml-unknown">?</span>'
            cls = "text-pos" if diff > 0 else "text-neg" if diff < 0 else ""
            return f'<span class="t24-diff-gml-val {cls}">{self._fmt_diff(diff)} m<sup>2</sup></span>'

        diff_gml_cell_html = (
            '<div class="t24-diff-gml-line" '
            'title="supfT24 Antes menos la superficie GML de Antes (misma f&oacute;rmula de Gauss truncada que el % &#8216;GML:&#8217; de arriba). '
            'Positivo = supfT24 mayor que el GML real de Antes.">'
            f'<span class="t24-diff-gml-lbl">T24&minus;GML Antes:</span>{_diff_gml_span(diff_gml_a, diff_unk_a)}'
            '</div>'
            '<div class="t24-diff-gml-line" '
            'title="supfT24 Despu&eacute;s menos la superficie GML de Despu&eacute;s (misma f&oacute;rmula de Gauss truncada que el % &#8216;GML:&#8217; de arriba). '
            'Positivo = supfT24 mayor que el GML real de Despu&eacute;s.">'
            f'<span class="t24-diff-gml-lbl">T24&minus;GML Despu&eacute;s:</span>{_diff_gml_span(diff_gml_d, diff_unk_d)}'
            '</div>'
        )

        return check_html, areas_row_html, diff_gml_cell_html

    def _t24_filter_flags(self, supft24_a, supft24_d, area_a, area_d, thresholds):
        """Clasifica el recinto para el filtro "Validación T24" (facetas del
        TOC), a partir del mismo cálculo que ya usa `_render_supft24_row`:

          - t24_invalid_after: NO valida en Después (|%|>umbral), sin
            importar el estado de Antes. Es el criterio más amplio y el
            mismo que hace parpadear el badge de Después en la ficha.
          - t24_worse:  subconjunto del anterior -- validaba Antes
            (|%|<=umbral) y deja de validar Después. El caso que se pedía
            detectar originalmente.
          - t24_better: NO validaba Antes y sí valida Después (corrección).
          - t24_unknown: al menos uno de los dos (Antes/Después) no tiene
            supfT24 calculable (ausente, -1 o división por cero).

        Un recinto sin dato en uno de los dos lados no puede decir que
        "validaba" ni que "dejó de validar", así que nunca cuenta como
        worse, better ni invalid_after -- solo como unknown. Esto evita
        falsos positivos/negativos silenciosos en el filtro.
        """
        limit = thresholds.get('validacion_pct', 10.0) if thresholds else 10.0
        try:
            limit = float(limit)
        except (TypeError, ValueError):
            limit = 10.0

        pct_a, unk_a = self._supft24_pct(supft24_a, area_a)
        pct_d, unk_d = self._supft24_pct(supft24_d, area_d)

        if unk_a or unk_d:
            return {'worse': False, 'better': False, 'unknown': True, 'invalid_after': False}

        valid_a = abs(pct_a) <= limit
        valid_d = abs(pct_d) <= limit
        return {
            'worse': valid_a and not valid_d,
            'better': (not valid_a) and valid_d,
            'unknown': False,
            'invalid_after': not valid_d,
        }

    def _validacion_filter_flags(self, supft24_a, supft24_d, area_a, area_d, thresholds, geom_d=None):
        """Clasifica el recinto para el filtro "Validación" (facetas del
        TOC), combinando los DOS criterios que ya se muestran en la fila
        informativa (`_render_supft24_row`): el % de Después normal
        ("%VALIDACION", supfT24 vs. área GML real) y el % "GML" (supfT24
        vs. área calculada con la fórmula de Gauss truncando cada
        coordenada a 2 decimales, que replica la precisión de un GML
        exportado). Un recinto se considera "no valida en Después" si
        supera el umbral '% Validación' en CUALQUIERA de los dos (no hace
        falta que fallen ambos).

          - valid_invalid_after: NO valida en Después por %VALIDACION o
            por %GML (o ambos), sin importar si validaba o no en Antes.
          - valid_worse: subconjunto del anterior -- SÍ validaba en Antes
            (único criterio disponible ahí, no existe "%GML" para Antes)
            y deja de validar en Después por cualquiera de los dos
            criterios.
          - valid_better: NO validaba en Antes y pasa a validar en
            Después por AMBOS criterios a la vez (%VALIDACION y %GML) --
            para considerarse "validada" en Después hace falta que no
            falle ninguno de los dos, lo simétrico exacto de
            valid_invalid_after (que basta con que falle uno).
          - valid_unknown: no se puede calcular alguno de los tres valores
            necesarios (Antes, Después, o GML de Después) -- no cuenta
            como worse ni como invalid_after, para evitar falsos
            positivos/negativos silenciosos.
        """
        limit = thresholds.get('validacion_pct', 10.0) if thresholds else 10.0
        try:
            limit = float(limit)
        except (TypeError, ValueError):
            limit = 10.0

        pct_a, unk_a = self._supft24_pct(supft24_a, area_a)
        pct_d, unk_d = self._supft24_pct(supft24_d, area_d)

        area_gml_trunc_d = self._gauss_area_truncated(geom_d) if geom_d is not None else 0.0
        pct_gml_d, unk_gml_d = self._supft24_pct(supft24_d, area_gml_trunc_d) if geom_d is not None else (None, True)

        if unk_a or unk_d or unk_gml_d:
            return {'worse': False, 'better': False, 'unknown': True, 'invalid_after': False}

        valid_a = abs(pct_a) <= limit
        valid_d = abs(pct_d) <= limit
        valid_gml_d = abs(pct_gml_d) <= limit
        invalid_after = (not valid_d) or (not valid_gml_d)
        valid_after = valid_d and valid_gml_d

        return {
            'worse': valid_a and invalid_after,
            'better': (not valid_a) and valid_after,
            'unknown': False,
            'invalid_after': invalid_after,
        }

    def _get_arrow(self, dir_code):
        """Mapea código cardinal a flecha unicode."""
        arrows = {
            'N': '↑', 'S': '↓', 'E': '→', 'O': '←',
            'NE': '↗', 'NO': '↖', 'SE': '↘', 'SO': '↙'
        }
        return arrows.get(dir_code, '')

    def _category_or_id(self, full_id, special_ranges):
        """
        Resuelve la referencia con la que se debe nombrar un recinto dentro
        del comentario de dinámica territorial: si su número de RECINTO cae
        dentro de uno de los rangos parametrizados (VIALES/CURSOS AGUA/
        EDIFICACIONES/EXCLUIDO), se referencia por su CATEGORÍA; en caso
        contrario (finca normal) se referencia por su identificador de finca.
        """
        if not full_id or full_id in ("ALTA (NUEVO)", "BAJA (ELIMINADO)"):
            return None, full_id
        try:
            last = str(full_id).split("/")[-1].split("-")[0]
            rec_val = int(float(last))
        except Exception:
            rec_val = None

        if rec_val is not None and special_ranges:
            for label, r in special_ranges.items():
                try:
                    if rec_val in r:
                        return 'categoria', label
                except Exception:
                    pass
        return 'finca', full_id

    def _format_flow_list(self, flows, special_ranges, direction, max_fincas=4, max_categorias=4):
        """
        Construye fragmentos de texto para la dinámica territorial (orígenes/
        destinos). Para 'input' (de dónde procede la superficie) el recinto
        relevante de cada flujo es su 'source'; para 'output' (hacia dónde
        cede superficie) es su 'target' — NUNCA la propia finca, que es
        siempre el otro extremo del flujo.

        Las fincas NO comunes se referencian de forma individual ("la finca
        X"). Los recintos comunes (VIALES/CURSOS AGUA/EDIFICACIONES/
        EXCLUIDO) se agregan y referencian por su CATEGORÍA ("la categoría
        VIALES"), nunca por su número de finca individual.
        """
        if not flows:
            return []

        field = 'target' if direction == 'output' else 'source'

        # Agregar área por referencia (categoría o finca), por si varios
        # fragmentos de la dinámica apuntan a la misma finca/categoría
        agg = {}
        for fl in flows:
            other_id = fl.get(field)
            kind, ref = self._category_or_id(other_id, special_ranges)
            if ref is None:
                continue
            key = (kind, ref)
            agg[key] = agg.get(key, 0.0) + fl.get('area', 0.0)

        fincas = sorted(((ref, a) for (k, ref), a in agg.items() if k == 'finca'), key=lambda x: x[1], reverse=True)
        categorias = sorted(((ref, a) for (k, ref), a in agg.items() if k == 'categoria'), key=lambda x: x[1], reverse=True)

        out = []
        for ref, area in fincas[:max_fincas]:
            out.append(f"la finca {ref} ({self._fmt_val(area)} m²)")
        for ref, area in categorias[:max_categorias]:
            out.append(f"la categoría {ref} ({self._fmt_val(area)} m²)")
        return out

    def _join_natural(self, items):
        if not items:
            return ""
        if len(items) == 1:
            return items[0]
        return ", ".join(items[:-1]) + f" y {items[-1]}"

    def _generate_notify_comment(self, notify_reasons, st=None, d=None, special_ranges=None, max_reasons=4):
        """
        Construye un breve párrafo en prosa comentando las variaciones más
        sustanciales que llevaron a clasificar la finca como NOTIFICAR.
        No repite los parámetros/umbrales ya mostrados en las tablas: los
        interpreta y los prioriza por relevancia. Incluye además el detalle
        de la dinámica territorial (de dónde procede / a dónde pasa la
        superficie), referenciando la CATEGORÍA cuando el origen/destino es
        un recinto de numeración común (VIALES, CURSOS AGUA, EDIFICACIONES,
        EXCLUIDO) y la FINCA concreta en el resto de casos.

        Si la finca es un ALTA (aparece nueva en DESPUÉS) o una BAJA
        (desaparece de ANTES a DESPUÉS), no tiene sentido comentar los
        valores de los parámetros geométricos/fachadas/etc. porque uno de
        los dos extremos de la comparación no existe; en esos casos el
        comentario se limita a señalar la aparición o desaparición, junto
        con la dinámica territorial correspondiente.
        """
        d = d or {}
        special_ranges = special_ranges or {}
        inputs_txt = self._join_natural(self._format_flow_list(d.get('inputs', []), special_ranges, 'input'))
        outputs_txt = self._join_natural(self._format_flow_list(d.get('outputs', []), special_ranges, 'output'))

        if st == 'ALTA':
            body = ('Esta finca se clasifica como NOTIFICAR porque es de nueva aparición: '
                    'no existía en la situación ANTES y se incorpora como tal en DESPUÉS.')
            if inputs_txt:
                body += f' En cuanto a su dinámica territorial, la superficie procede de {inputs_txt}.'
            return self._wrap_notify_comment(body)

        if st == 'BAJA':
            body = ('Esta finca se clasifica como NOTIFICAR porque desaparece: existía en la '
                    'situación ANTES y no tiene continuidad en DESPUÉS.')
            if outputs_txt:
                body += f' En cuanto a su dinámica territorial, la superficie pasa a {outputs_txt}.'
            return self._wrap_notify_comment(body)

        if not notify_reasons and not inputs_txt and not outputs_txt:
            return ""

        if notify_reasons:
            # Ordenar por magnitud (relevancia) y quedarnos con las más sustanciales
            ordered = sorted(notify_reasons, key=lambda r: r.get('mag', 0), reverse=True)
            top = [r['text'] for r in ordered[:max_reasons]]
            reasons_body = self._join_natural(top) if len(top) <= 2 else (", ".join(top[:-1]) + f", y además {top[-1]}")
            body = (
                f"Esta finca se clasifica como NOTIFICAR porque {reasons_body}. "
                f"Los parámetros aquí comentados son los que superan los umbrales configurados en el "
                f"informe; pueden existir otras variaciones en esta finca que no se mencionan por no "
                f"superar dichos umbrales."
            )
        else:
            body = "Esta finca se clasifica como NOTIFICAR por su dinámica territorial."

        dyn_parts = []
        if inputs_txt:
            dyn_parts.append(f"procede de {inputs_txt}")
        if outputs_txt:
            dyn_parts.append(f"se cede hacia {outputs_txt}")
        if dyn_parts:
            body += f" En cuanto a la dinámica territorial, la superficie {self._join_natural(dyn_parts)}."

        return self._wrap_notify_comment(body)

    def _wrap_notify_comment(self, body):
        return (
            f'<div class="notify-comment" style="margin-top:10px; padding:10px 14px; '
            f'background:#fff8e1; border-left:3px solid #f39c12; border-radius:4px; '
            f'font-size:0.88em; color:#5d4037; line-height:1.5">'
            f'<strong>⚠ Comentario:</strong> {body}'
            f'</div>'
        )

    def _legal_interpretation(self, st,
                               delta_parts, parts_a, parts_d,
                               delta_isl_cnt, isl_deltas,
                               owner_changed, prop_a, prop_d,
                               delta_area, pct_area, m_a_abs, m_a_pct,
                               facade_legal,
                               m_p_abs, m_p_pct, delta_perim, pct_perim,
                               m_g_pct, pct_grav,
                               m_c_abs, m_c_pct,
                               m_desp, displacement, displacement_dir,
                               m_stab, stability_pct,
                               m_inv, pct_rings_area, delta_hole_area,
                               adit_reason_objs):
        """
        Segunda lectura de los MISMOS parámetros ya calculados por el plugin,
        pero clasificados por el régimen legal al que afectan (LMETAGA, Ley
        del suelo de Galicia, LPAC) en vez de por su magnitud estadística
        pura -- ver documento de trabajo "Marco legal para el criterio de
        notificación". Es un análisis técnico orientativo para contrastar
        con el criterio de umbrales puro ya existente en el plugin: NO
        sustituye ni modifica el marcado NOTIFICAR / data-notify real del
        informe, que sigue gobernado exclusivamente por dicho criterio de
        umbrales.

        Clasificación aplicada:
          A) Identidad/existencia (partes, islas, alta/baja, titular,
             discrepancias técnicas de aditamentos) -> disparador absoluto,
             sin umbral.
          B) Valor de uso/explotación (superficie, fachadas/accesos, huecos)
             -> umbral AND (absoluto Y relativo a la vez), en vez de OR.
          C) Forma pura (perímetro, Gravelius/convexidad, desplazamiento del
             centroide, estabilidad del lindero) -> indicio/filtro de
             plausibilidad; solo dispara de forma autónoma ante un cambio
             muy marcado.
        """
        # ALTA / BAJA: la propia aparición/desaparición ya es, por sí sola,
        # un hecho de identidad de la finca (art. 40 LPAC / art. 72 LMETAGA)
        if st == 'ALTA':
            return {
                'notify': True,
                'reasons': ['es de nueva aparición: no existía en la situación ANTES, lo que por '
                            'sí mismo constituye un hecho de identidad de la finca que obliga a '
                            'notificar (art. 40 LPAC)'],
                'notes': [],
            }
        if st == 'BAJA':
            return {
                'notify': True,
                'reasons': ['desaparece: no tiene continuidad en la situación DESPUÉS, lo que por '
                            'sí mismo constituye un hecho de identidad de la finca que obliga a '
                            'notificar (art. 40 LPAC)'],
                'notes': [],
            }

        legal_notify = False
        reasons_a, reasons_b, reasons_c, notes = [], [], [], []

        # --- CATEGORÍA A: identidad / existencia -- disparador absoluto ---
        if delta_parts != 0:
            legal_notify = True
            reasons_a.append(
                f"la parcela pasa de {parts_a} a {parts_d} partes "
                f"({'fragmentación' if delta_parts > 0 else 'unificación'}), operación regulada "
                f"de forma expresa por el art. 72 LMETAGA y sujeta al régimen de segregaciones "
                f"del art. 149 de la Ley del suelo de Galicia"
            )
        if delta_isl_cnt != 0:
            legal_notify = True
            _cnt_a = isl_deltas.get('count_a', 0) if isl_deltas else 0
            _cnt_d = isl_deltas.get('count_d', 0) if isl_deltas else 0
            reasons_a.append(
                f"el número de huecos/islas interiores pasa de {_cnt_a} a {_cnt_d}, alterando "
                f"la delimitación cartográfica de la finca"
            )
        if owner_changed:
            legal_notify = True
            reasons_a.append(
                f"cambia el titular registral (de {prop_a} a {prop_d}), hecho que por sí mismo "
                f"afecta a un interesado distinto (art. 40 LPAC)"
            )
        if adit_reason_objs:
            legal_notify = True
            for r in adit_reason_objs:
                reasons_a.append(f"{r['text']} (discrepancia técnica objetiva en aditamentos)")

        # --- CATEGORÍA B: valor de uso / explotación -- LMETAGA, umbral AND ---
        if m_a_abs and m_a_pct:
            legal_notify = True
            reasons_b.append(
                f"la superficie varía {delta_area:+.1f} m² Y {pct_area:+.1f}% a la vez, "
                f"superando de forma conjunta el umbral absoluto y el relativo -- indicio de "
                f"alteración del valor de uso de la finca (LMETAGA)"
            )
        elif m_a_abs or m_a_pct:
            notes.append(
                f"la superficie varía {delta_area:+.1f} m² ({pct_area:+.1f}%), pero solo supera "
                f"uno de los dos umbrales (absoluto o relativo), no ambos a la vez, por lo que "
                f"bajo un criterio de \"valor proporcionado\" no se considera, por sí sola, "
                f"determinante"
            )

        for f in facade_legal:
            if f['m_abs'] and f['m_pct']:
                legal_notify = True
                reasons_b.append(
                    f"la fachada a {f['label'].lower()} varía {f['delta']:+.1f} m Y {f['pct']:+.1f}% "
                    f"a la vez, afectando al acceso/valor de explotación de la finca (LMETAGA)"
                )
            elif f['m_abs'] or f['m_pct']:
                notes.append(
                    f"la fachada a {f['label'].lower()} varía {f['delta']:+.1f} m ({f['pct']:+.1f}%), "
                    f"pero solo supera uno de los dos umbrales"
                )

        if m_inv:
            legal_notify = True
            reasons_b.append(
                f"el área de huecos interiores varía {delta_hole_area:+.1f} m² ({pct_rings_area:+.1f}%), "
                f"reduciendo o ampliando la superficie realmente aprovechable de la finca"
            )

        # --- CATEGORÍA C: forma pura -- indicio / filtro de plausibilidad ---
        shape_hits = []
        if m_p_abs or m_p_pct:
            shape_hits.append(f"el perímetro cambia {delta_perim:+.1f} m ({pct_perim:+.1f}%)")
        if m_g_pct or m_c_abs or m_c_pct:
            shape_hits.append("la forma de la parcela se modifica de manera apreciable (convexidad/compacidad)")
        if m_desp:
            shape_hits.append(f"el centroide se desplaza {displacement:.1f} m hacia el {displacement_dir}")
        if m_stab:
            shape_hits.append(f"el lindero exterior solo se mantiene estable en un {stability_pct:.1f}% de su trazado")

        # Umbral de "cambio muy marcado" para que la forma dispare por sí
        # sola en vez de quedar solo como indicio/filtro de plausibilidad
        marked = (abs(pct_perim) >= 30.0) or (abs(pct_grav) >= 30.0) or \
                 (m_desp and displacement >= 5.0) or (m_stab and stability_pct < 70.0)

        if shape_hits and marked:
            legal_notify = True
            reasons_c.extend(shape_hits)
        elif shape_hits:
            notes.append(
                "la forma de la parcela presenta variaciones (" + "; ".join(shape_hits) + "), pero "
                "sin llegar a un cambio muy marcado, por lo que bajo el criterio legal se toma "
                "como indicio/filtro de plausibilidad y no como disparador autónomo"
            )

        return {
            'notify': legal_notify,
            'reasons': reasons_a + reasons_b + reasons_c,
            'notes': notes,
        }

    def _render_legal_interpretation(self, legal, diverges=False):
        """Renderiza el veredicto de la interpretación legal en prosa."""
        if legal is None:
            return ""
        reasons = legal.get('reasons', [])
        notes = legal.get('notes', [])

        if legal['notify']:
            if reasons:
                reasons_body = (self._join_natural(reasons) if len(reasons) <= 2
                                 else (", ".join(reasons[:-1]) + f", y además {reasons[-1]}"))
                body = f"esta finca <strong>SÍ</strong> se notificaría porque {reasons_body}."
            else:
                body = "esta finca <strong>SÍ</strong> se notificaría."
        else:
            body = (
                "esta finca <strong>NO</strong> requeriría notificación: no se altera la identidad "
                "de la finca (partes, islas/huecos, alta/baja o titular), no hay discrepancias "
                "técnicas objetivas en aditamentos, y las variaciones de superficie, fachadas o "
                "forma detectadas no llegan a superar de forma conjunta (umbral absoluto Y "
                "relativo a la vez) el criterio de afectación al valor de uso de la finca."
            )

        if notes:
            body += " <em>Matices: " + "; ".join(notes) + ".</em>"

        return self._wrap_legal_comment(body, diverges=diverges)

    def _wrap_legal_comment(self, body, diverges=False):
        bg = "#fdf3e2" if diverges else "#f1ecfb"
        border = "#b45309" if diverges else "#5b3ea6"
        color = "#7a5c00" if diverges else "#3d2a70"
        divergence_note = (
            ' <span style="text-transform:none; font-weight:normal">'
            '(diverge de la interpretación por parámetros puros)</span>'
        ) if diverges else ""
        return (
            f'<div class="legal-comment" style="margin-top:8px; padding:10px 14px; '
            f'background:{bg}; border-left:3px solid {border}; border-radius:4px; '
            f'font-size:0.88em; color:{color}; line-height:1.5">'
            f'<strong>⚖ Interpretación alternativa{divergence_note}:</strong> {body}'
            f'</div>'
        )

    def _wrap_pure_negative_comment(self, dyn_body=""):
        body = (
            "Por parámetros puros (umbrales estadísticos configurados en el informe), esta "
            "finca <strong>NO</strong> se clasificaría para notificar: ningún parámetro "
            "individual supera el umbral configurado."
        )
        if dyn_body:
            body += f" {dyn_body}"
        return (
            f'<div class="notify-comment" style="margin-top:10px; padding:10px 14px; '
            f'background:#eaf7f0; border-left:3px solid #1e7a4c; border-radius:4px; '
            f'font-size:0.88em; color:#1e5c3a; line-height:1.5">'
            f'<strong>✓ Comentario:</strong> {body}'
            f'</div>'
        )

    def _render_dual_interpretation(self, notify_reasons, st, d, special_ranges, legal, notify, split=False):
        """
        Combina, para CUALQUIER recinto (notifique o no por umbrales puros),
        las dos lecturas posibles de los mismos parámetros calculados por
        el plugin:
          1) Interpretación por parámetros puros (umbrales estadísticos ya
             existentes en el informe) -- sigue siendo la que gobierna el
             marcado real (NOTIFICAR / data-notify, borde de alerta, TOC).
          2) Interpretación legal (clasificación por régimen normativo) --
             solo a efectos comparativos/de contraste, ver documento de
             marco legal.

        Se renderiza SIEMPRE, con un veredicto explícito (SÍ/NO) en cada
        lectura, para poder comparar recinto a recinto -- incluidos los que
        NO se notifican por ningún criterio, y el caso inverso: recintos
        que por números puros no saltarían pero que el criterio legal sí
        marcaría.

        Si split=True, en vez de devolver un único bloque combinado, se
        devuelve una tupla (bloque_parametrico, bloque_alternativo) para que
        el llamante pueda colocarlos en celdas/columnas distintas (p.ej. el
        informe resumen de presentación).
        """
        if notify:
            pure_html = self._generate_notify_comment(notify_reasons, st, d, special_ranges)
            if not pure_html:
                # Salvaguarda: notify=True siempre debería traer razones o
                # dinámica territorial, pero por si acaso no queda vacío
                pure_html = self._wrap_notify_comment(
                    "Esta finca se clasifica como NOTIFICAR según los umbrales configurados en el informe."
                )
        else:
            inputs_txt = self._join_natural(self._format_flow_list(d.get('inputs', []) if d else [], special_ranges, 'input'))
            outputs_txt = self._join_natural(self._format_flow_list(d.get('outputs', []) if d else [], special_ranges, 'output'))
            dyn_parts = []
            if inputs_txt: dyn_parts.append(f"procede de {inputs_txt}")
            if outputs_txt: dyn_parts.append(f"se cede hacia {outputs_txt}")
            dyn_body = f"En cuanto a la dinámica territorial, la superficie {self._join_natural(dyn_parts)}." if dyn_parts else ""
            pure_html = self._wrap_pure_negative_comment(dyn_body)

        legal_html = ""
        if legal is not None:
            diverges = legal.get('notify', False) != notify
            legal_html = self._render_legal_interpretation(legal, diverges=diverges)

        label_style = "font-size:0.72em; text-transform:uppercase; letter-spacing:0.5px; color:#999; margin:10px 0 -4px 2px"

        param_block = (
            f'<div style="{label_style}">Interpretación por parámetros (umbrales)</div>'
            f'{pure_html}'
        )
        legal_block = (
            f'<div style="{label_style}">Interpretación alternativa (marco normativo, a efectos de contraste)</div>'
            f'{legal_html}'
        )

        if split:
            return param_block, legal_block

        return (
            '<div class="dual-interpretation">'
            f'{param_block}'
            f'{legal_block}'
            '</div>'
        )

    def _recinto_bbox(self, geom_a, geom_d):
        """Bounding box combinado (Antes + Después, lo que haya de cada
        recinto) en el mismo SCR (UTM) del proyecto QGIS -- las
        geometrías ya llegan reproyectadas a ese SCR desde shp_service,
        así que no hace falta reproyectar nada aquí.

        Devuelve (xmin, ymin, xmax, ymax) redondeado a 3 decimales (mm),
        o None si ninguna de las dos geometrías es válida. Mismo patrón
        de combinación que usa el croquis (`_render_sketch_svg`), con la
        misma cautela de no reasignar el resultado de
        combineExtentWith() (modifica el rectángulo en sitio y devuelve
        None)."""
        bbox = None
        for g in (geom_a, geom_d):
            if g is None:
                continue
            try:
                if g.isNull() or g.isEmpty():
                    continue
            except Exception:
                continue
            bb = g.boundingBox()
            if bbox is None:
                bbox = QgsRectangle(bb)
            else:
                bbox.combineExtentWith(bb)
        if bbox is None or bbox.width() < 0 or bbox.height() < 0:
            return None
        return (
            round(bbox.xMinimum(), 3), round(bbox.yMinimum(), 3),
            round(bbox.xMaximum(), 3), round(bbox.yMaximum(), 3),
        )

    def _render_user_annotation_panel(self, recinto_id, notify, legal_notify=None, geom_a=None, geom_d=None, extra_data=None):
        """
        Panel de "Revisión de esta ficha", al pie de cada ficha (informe
        ampliado y resumen).

        Los dos botones de decisión son SIEMPRE los mismos, con el mismo
        texto y en el mismo orden, independientemente de lo que hayan
        concluido las interpretaciones automáticas (paramétrica /
        alternativa) para esa ficha en concreto:

            ✔ Notificar      -> data-value="si"
            ✘ NO Notificar   -> data-value="no"

        Antes el texto de estos botones cambiaba según la ficha
        ("Confirmar" / "No confirmar → [la contraria]"), lo que obligaba
        al usuario a pensar primero qué decía el plugin para saber a qué
        resultado llevaba cada botón. Con el texto fijo, el usuario
        responde siempre con el mismo criterio, sin depender de la
        interpretación de esa ficha. El aviso ("hint") que aparece encima
        de los botones sigue mostrando, a título informativo, si las
        interpretaciones automáticas coinciden o no -- pero ya no
        condiciona el texto de los botones.

        En cualquier caso, lo que se guarda es siempre uno de estos tres
        valores, sin ambigüedad posible al releerlo o compartirlo:
            ""    -> Sin revisar (semáforo neutro, aún sin decidir)
            "si"  -> el usuario fija que SÍ notifica
            "no"  -> el usuario fija que NO notifica

        "Sin revisar" es también el único botón "destructivo": al
        elegirlo se vacía asimismo el comentario de esta ficha (ya no
        hace falta un botón aparte de "vaciar ficha").

        El estado se guarda en una cápsula JSON embebida en el propio
        HTML (ver script de anotaciones más abajo); este método solo
        genera el marcado -- vacío por defecto, la carga desde la cápsula
        la hace el JS en tiempo de ejecución al abrir la página.
        """
        rid_attr = html_lib.escape(str(recinto_id), quote=True)
        plugin_value = 'si' if notify else 'no'
        # Lectura alternativa (marco normativo), aparte de la paramétrica
        # de arriba. Vacía ("") si el informe no llegó a calcularla para
        # este recinto -- se exporta como "N/D" en el XML compartido.
        legal_value = '' if legal_notify is None else ('si' if legal_notify else 'no')
        agree = (legal_notify is None) or (bool(legal_notify) == bool(notify))

        # Datos ampliados de contexto para el XML de respuestas
        # (conclusiones en prosa de cada interpretación, superficies y %
        # de validación T24), embebidos como un único atributo JSON para
        # no llenar el nodo de decenas de data-* sueltos. getAttribute()
        # ya devuelve el JSON sin escapar -- html.escape aquí es solo para
        # que quepa dentro de la propia comilla del atributo HTML.
        extra_json = html_lib.escape(json.dumps(extra_data or {}, ensure_ascii=False), quote=True)

        bbox = self._recinto_bbox(geom_a, geom_d)
        bbox_attr = ('%s,%s,%s,%s' % bbox) if bbox else ''

        concl_txt = 'SÍ notifica' if notify else 'NO notifica'
        if legal_notify is not None:
            if agree:
                hint = f'Ambas interpretaciones coinciden: esta finca {concl_txt.upper()}.'
                hint_cls = 'user-annot-hint'
            else:
                hint = '⚠ Las dos interpretaciones NO coinciden en esta ficha: decide tú.'
                hint_cls = 'user-annot-hint diverge'
        else:
            hint = f'Interpretación del plugin: {concl_txt.upper()}.'
            hint_cls = 'user-annot-hint'

        # Botones fijos, independientes de la interpretación de esta
        # ficha: siempre "Notificar" / "NO Notificar", en el mismo orden.
        interp_buttons = """<button type="button" class="ua-btn ua-si" data-value="si">✔ Notificar</button>
                                <button type="button" class="ua-btn ua-no" data-value="no">✘ NO Notificar</button>"""

        return f"""
                    <div class="user-annot" data-recinto="{rid_attr}" data-plugin-value="{plugin_value}" data-legal-value="{legal_value}" data-bbox="{bbox_attr}" data-xml-extra="{extra_json}">
                        <div class="user-annot-interactive">
                            <div class="user-annot-header">
                                <strong>📝 Revisión de esta ficha</strong>
                            </div>
                            <div class="{hint_cls}">{hint}</div>
                            <div class="user-annot-interp">
                                <button type="button" class="ua-btn active" data-value="">Sin revisar</button>
                                {interp_buttons}
                            </div>
                            <textarea class="user-annot-comment" placeholder="Comentarios del usuario (sin límite de texto)…" rows="2"></textarea>
                            <div class="user-annot-status">Sin anotaciones para esta ficha.</div>
                        </div>
                        <div class="user-annot-print-view">
                            <strong>Revisión usuario:</strong> <span class="ua-print-interp">Sin revisar</span>
                            <div class="ua-print-comment"></div>
                        </div>
                    </div>
        """

    def _render_annotations_script(self, html_filename, share_filename, total_recintos, report_id, project_crs=''):
        """
        Lógica JS de las anotaciones de usuario (informe ampliado y
        resumen). Diseño de 3 piezas:

          1) Cápsula embebida en el propio HTML: un
             <script type="application/json" id="audinot-user-data">
             delimitado por comentarios-marca (AUDINOT_USER_DATA_START/END).
             Se lee al abrir la página sin fetch ni CORS -- es la fuente de
             verdad "de fábrica" de este archivo (lo que había la última
             vez que se descargó una copia).
          2) Autoguardado silencioso en el navegador (IndexedDB), indexado
             por REPORT_ID (un UUID embebido en el propio HTML, no por
             nombre de archivo): cada cambio se guarda solo, sin botones ni
             diálogos. Al reabrir el mismo HTML en el mismo navegador, esas
             respuestas se recuperan automáticamente aunque el archivo en
             disco siga teniendo la cápsula vacía. La única acción manual
             que existe es "⬇ Descargar mis respuestas", que genera una
             copia completa del HTML con la cápsula al día -- para
             archivarla, enviarla, o abrirla en otro ordenador (el
             autoguardado del navegador no viaja con el archivo).
             (Se abandonó deliberadamente la vinculación en tiempo real vía
             File System Access API: obligaba al usuario a entender qué
             archivo elegir en un diálogo de guardado y a reconceder permiso
             de escritura en cada recarga -- una fuente constante de
             confusión y de "vínculos" apuntando por error a un archivo
             vacío.)
          3) Exportación/Importación para compartir o para procesar en
             ValCAD: un XML con TODAS las fincas del informe (no solo las
             anotadas), cada una con su estado explícito (SIN REVISAR /
             SI NOTIFICA / NO NOTIFICA), la interpretación del usuario, la
             del plugin, comentario, fecha y su bounding box en el SCR/UTM
             del proyecto (atributo "crs" de la cabecera) para poder hacer
             zoom directo al recinto desde cualquier aplicación externa,
             más una cabecera con el nombre del informe y su nº de
             recintos. Al importar, cada ficha del XML sobreescribe la
             correspondiente en la cápsula local del receptor (sin
             fusión campo a campo, incluida la limpieza de lo que ya no
             aplica) y se aplica al instante en pantalla.

        Se genera como texto plano (no f-string) para no tener que escapar
        cada llave de JS; los cuatro valores entre __ __ son los únicos que
        se sustituyen.

        IMPORTANTE sobre "</script" dentro de este propio bloque <script>:
        cualquier ocurrencia literal de esa secuencia -- aunque esté dentro
        de una cadena o un regex de JS -- cierra el <script> para el
        parser HTML. Por eso, donde el código necesita construir o buscar
        un cierre de <script>, se escribe como "<\\/script" (con barra
        invertida) y los datos del usuario se serializan escapando '<' como
        \\u003c antes de escribirlos en disco o en el DOM.
        """
        template = r"""
            <script>
            (function() {
                const HTML_FILENAME = "__HTML_FILENAME__";
                const SHARE_FILENAME = "__SHARE_FILENAME__";
                const REPORT_TOTAL = __REPORT_TOTAL__;
                const REPORT_ID = "__REPORT_ID__";
                const PROJECT_CRS = "__PROJECT_CRS__";
                const AUTOSAVE_DB_NAME = 'audinot-autosave';
                const AUTOSAVE_STORE = 'reports';

                let annotData = {};

                // Puente hacia el script de filtros/facetas (que se ejecuta
                // en otro <script> y no tiene acceso a este cierre): expone
                // solo lectura de la interpretación del usuario por recinto,
                // para el filtro de faceta "Usuario" (marcado para
                // notificar / marcado para no notificar). Es una función,
                // no una copia del objeto, para que siga viendo el valor
                // actual aunque annotData se reasigne entero más adelante
                // (p.ej. al recuperar el autoguardado de IndexedDB).
                window.AudiNOTGetInterp = function (id) {
                    const rec = annotData[id];
                    return rec ? (rec.interp || '') : '';
                };

                const dataScriptEl = document.getElementById('audinot-user-data');
                const saveStatusEl = document.getElementById('annot-save-status');
                const downloadBtn = document.getElementById('annot-download-btn');
                const shareToggleBtn = document.getElementById('annot-share-toggle');
                const shareMenuEl = document.getElementById('annot-share-menu');
                const exportBtn = document.getElementById('annot-export-btn');
                const importBtn = document.getElementById('annot-import-btn');
                const importInput = document.getElementById('annot-import-input');

                function escXml(s) {
                    return String(s == null ? '' : s)
                        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
                }

                function fmtFecha(iso) {
                    try { return new Date(iso).toLocaleString(); } catch (e) { return iso || ''; }
                }

                function interpLabel(interp, pluginValue) {
                    if (interp === 'si' || interp === 'no') {
                        const txt = (interp === 'si') ? 'SÍ notifica' : 'NO notifica';
                        if (pluginValue && interp === pluginValue) return 'Confirmado: ' + txt;
                        return 'Fijado por el usuario: ' + txt;
                    }
                    return 'Sin revisar';
                }

                // Compatibilidad con XML de respuestas exportados por
                // versiones anteriores del informe (esquema antiguo:
                // 'confirmado' / 'alt_notifica' / 'alt_no_notifica').
                // pluginValue es la lectura del plugin ('si'/'no') EN ESTE
                // informe para ese mismo recinto -- 'confirmado' antiguo se
                // traduce a esa lectura actual.
                function normalizeInterp(raw, pluginValue) {
                    if (raw === 'si' || raw === 'no' || raw === '' || raw == null) return raw || '';
                    if (raw === 'confirmado') return pluginValue || '';
                    if (raw === 'alt_notifica') return 'si';
                    if (raw === 'alt_no_notifica') return 'no';
                    return '';
                }

                // ---- cápsula embebida (fuente de verdad local) ----

                function loadEmbeddedCapsule() {
                    if (!dataScriptEl) return;
                    try {
                        const parsed = JSON.parse(dataScriptEl.textContent || '{}');
                        annotData = (parsed && typeof parsed === 'object') ? parsed : {};
                    } catch (e) {
                        console.error('No se pudo leer la cápsula de anotaciones embebida', e);
                        annotData = {};
                    }
                }

                function serializeCapsuleJSON() {
                    // Escapa '<' como \u003c para que un comentario del
                    // usuario que contenga una etiqueta de cierre de
                    // script, o un comentario HTML, nunca pueda romper el
                    // bloque <script> donde vive esta cápsula.
                    return JSON.stringify(annotData).replace(/</g, '\\u003c');
                }

                function updateEmbeddedScriptTag() {
                    if (dataScriptEl) dataScriptEl.textContent = serializeCapsuleJSON();
                }

                function syncTextareasForSerialization() {
                    // textarea.value no se refleja en el nodo de texto al
                    // serializar outerHTML; hay que copiarlo antes de
                    // descargar una copia completa del HTML.
                    document.querySelectorAll('.user-annot-comment').forEach(function (ta) {
                        ta.textContent = ta.value;
                    });
                }

                // ---- XML pequeño para compartir (mensajero, no fuente de verdad) ----

                function serializeShareXML() {
                    const parts = [];
                    parts.push('<?xml version="1.0" encoding="UTF-8"?>');
                    parts.push('<AudiNOTRespuestas version="3" informe="' + escXml(HTML_FILENAME) +
                        '" totalRecintos="' + REPORT_TOTAL + '" crs="' + escXml(PROJECT_CRS) +
                        '" generado="' + new Date().toISOString() + '">');
                    // Se recorre SIEMPRE la lista completa de recintos del
                    // informe (annotPanelsByRecinto), no solo los que
                    // tienen anotación guardada -- así el XML exportado
                    // siempre lleva las N fincas, con "Decision" explícita
                    // (SIN REVISAR / SI NOTIFICA / NO NOTIFICA) para las
                    // que no se han tocado, y ValCAD puede procesarlas
                    // todas sin tener que adivinar qué falta.
                    Object.keys(annotPanelsByRecinto).sort().forEach(function (id) {
                        const panel = annotPanelsByRecinto[id];
                        const pluginValue = panel.getAttribute('data-plugin-value') || '';
                        const legalValue = panel.getAttribute('data-legal-value') || '';
                        const a = annotData[id] || {};
                        const interp = normalizeInterp(a.interp || '', pluginValue);
                        const comentario = a.comentario || '';
                        // Tres campos con un único significado cada uno,
                        // sin nada que adivinar al releer o compartir el
                        // XML:
                        //  - InterpretacionParametrica: lectura del plugin
                        //    por parámetros. Siempre SI o NO (nunca vacía).
                        //  - InterpretacionAlternativa: lectura del plugin
                        //    según el marco normativo/alternativo. SI, NO,
                        //    o "N/D" si el informe no la calculó para este
                        //    recinto.
                        //  - Decision: la única fuente de verdad sobre lo
                        //    que ha decidido el USUARIO. Siempre uno de
                        //    estos tres textos, sin ambigüedad: SIN
                        //    REVISAR / SI NOTIFICA / NO NOTIFICA.
                        const paramLabel = (pluginValue === 'si') ? 'SI' : 'NO';
                        const altLabel = (legalValue === 'si') ? 'SI' : (legalValue === 'no') ? 'NO' : 'N/D';
                        const decision = (interp === 'si') ? 'SI NOTIFICA' : (interp === 'no') ? 'NO NOTIFICA' : 'SIN REVISAR';
                        // Bounding box (Antes+Después combinados) en el
                        // mismo SCR/UTM del proyecto (ver atributo "crs"
                        // de la cabecera), para que cualquier app pueda
                        // hacer zoom directo al recinto sin más contexto.
                        // Los 4 atributos van vacíos si no se pudo
                        // calcular geometría válida para este recinto,
                        // pero el elemento en sí siempre está presente.
                        const bboxRaw = (panel.getAttribute('data-bbox') || '').split(',');
                        const bxmin = bboxRaw[0] || '', bymin = bboxRaw[1] || '', bxmax = bboxRaw[2] || '', bymax = bboxRaw[3] || '';
                        let extra = {};
                        try { extra = JSON.parse(panel.getAttribute('data-xml-extra') || '{}'); } catch (e) { extra = {}; }
                        const numOrND = function (v) { return (v === null || v === undefined || v === '') ? 'N/D' : v; };
                        parts.push('  <Recinto id="' + escXml(id) + '">');
                        parts.push('    <InterpretacionParametrica>' + paramLabel + '</InterpretacionParametrica>');
                        parts.push('    <InterpretacionAlternativa>' + altLabel + '</InterpretacionAlternativa>');
                        // Texto de conclusión en prosa de cada
                        // interpretación (el mismo comentario que se lee
                        // en la ficha), para que cualquier otra
                        // aplicación entienda el porqué sin tener que
                        // abrir el informe HTML.
                        parts.push('    <ConclusionParametrica>' + escXml(extra.conclusionParametrica || '') + '</ConclusionParametrica>');
                        parts.push('    <ConclusionAlternativa>' + escXml(extra.conclusionAlternativa || '') + '</ConclusionAlternativa>');
                        parts.push('    <Decision>' + decision + '</Decision>');
                        // Superficies Antes/Después/GML, supfT24 de cada
                        // lado, y los tres % de desviación de validación
                        // que ya se ven en la fila informativa de la
                        // ficha (Antes, Después, y Después-GML/Gauss).
                        // "N/D" cuando el dato no estaba disponible o no
                        // se pudo calcular para este recinto. La
                        // superficie GML (gmlM2) va siempre sin
                        // decimales, tal y como exige la especificación
                        // GML de parcela catastral.
                        parts.push('    <Superficies antesM2="' + escXml(numOrND(extra.superficieAntes)) + '" despuesM2="' + escXml(numOrND(extra.superficieDespues)) + '" gmlM2="' + escXml(numOrND(extra.superficieGML)) + '"/>');
                        parts.push('    <SupfT24 antesM2="' + escXml(numOrND(extra.supfT24Antes)) + '" despuesM2="' + escXml(numOrND(extra.supfT24Despues)) + '"/>');
                        parts.push('    <ValidacionPct antes="' + escXml(numOrND(extra.validacionPctAntes)) + '" despues="' + escXml(numOrND(extra.validacionPctDespues)) + '" despuesGML="' + escXml(numOrND(extra.validacionPctDespuesGML)) + '"/>');
                        parts.push('    <Comentario>' + escXml(comentario) + '</Comentario>');
                        parts.push('    <FechaModificacion>' + escXml(a.fecha || '') + '</FechaModificacion>');
                        parts.push('    <BoundingBoxUTM xmin="' + escXml(bxmin) + '" ymin="' + escXml(bymin) + '" xmax="' + escXml(bxmax) + '" ymax="' + escXml(bymax) + '"/>');
                        parts.push('  </Recinto>');
                    });
                    parts.push('</AudiNOTRespuestas>');
                    return parts.join('\n');
                }

                function parseShareXML(text) {
                    try {
                        const doc = new DOMParser().parseFromString(text, 'application/xml');
                        if (doc.querySelector('parsererror')) return null;
                        const root = doc.documentElement;
                        if (!root || root.tagName !== 'AudiNOTRespuestas') return null;
                        const meta = {
                            informe: root.getAttribute('informe') || '',
                            totalRecintos: root.getAttribute('totalRecintos') || '',
                            generado: root.getAttribute('generado') || ''
                        };
                        const data = {};
                        doc.querySelectorAll('Recinto').forEach(function (r) {
                            const id = r.getAttribute('id');
                            if (!id) return;
                            const decisionEl = r.querySelector('Decision');
                            const comEl = r.querySelector('Comentario');
                            const fechaEl = r.querySelector('FechaModificacion');
                            let interp = '';
                            if (decisionEl) {
                                const dec = (decisionEl.textContent || '').trim().toUpperCase();
                                // Acepta tanto el formato actual ("SI NOTIFICA" /
                                // "NO NOTIFICA") como el antiguo ("SI" / "NO"),
                                // para poder importar XML compartidos por una
                                // versión anterior del informe.
                                if (dec === 'SI NOTIFICA' || dec === 'SI') interp = 'si';
                                else if (dec === 'NO NOTIFICA' || dec === 'NO') interp = 'no';
                            }
                            data[id] = {
                                interp: interp,
                                comentario: comEl ? comEl.textContent : '',
                                fecha: fechaEl ? fechaEl.textContent : ''
                            };
                        });
                        return { meta: meta, data: data };
                    } catch (e) {
                        console.error('Error al interpretar el XML de respuestas compartidas', e);
                        return null;
                    }
                }

                function applyAnnotationsToDOM() {
                    document.querySelectorAll('.user-annot').forEach(function (panel) {
                        const id = panel.getAttribute('data-recinto');
                        const pluginValue = panel.getAttribute('data-plugin-value') || '';
                        const a = annotData[id];
                        const interp = normalizeInterp(a ? a.interp : '', pluginValue);
                        const comentario = a ? (a.comentario || '') : '';
                        panel.querySelectorAll('.ua-btn').forEach(function (b) {
                            b.classList.toggle('active', b.getAttribute('data-value') === interp);
                        });
                        const textarea = panel.querySelector('.user-annot-comment');
                        if (textarea) textarea.value = comentario;
                        const printInterp = panel.querySelector('.ua-print-interp');
                        const printComment = panel.querySelector('.ua-print-comment');
                        if (printInterp) printInterp.textContent = interpLabel(interp, pluginValue);
                        if (printComment) printComment.textContent = comentario;
                        const statusEl = panel.querySelector('.user-annot-status');
                        if (statusEl) {
                            if (interp || comentario.trim()) {
                                statusEl.textContent = 'Guardado' + (a && a.fecha ? (' · ' + fmtFecha(a.fecha)) : '');
                                statusEl.className = 'user-annot-status saved';
                            } else {
                                statusEl.textContent = 'Sin anotaciones para esta ficha.';
                                statusEl.className = 'user-annot-status';
                            }
                        }
                    });
                    updateReviewProgress();
                    document.dispatchEvent(new CustomEvent('audinot-annot-changed'));
                }

                // ---- Semáforo por recinto en el TOC + contador de progreso ----
                // Mapa de "id de recinto" -> <li class="toc-item"> del
                // índice, construido una sola vez (el TOC no cambia de
                // tamaño en tiempo de ejecución).
                const tocItemsByRecinto = {};
                document.querySelectorAll('.toc-item[data-recinto]').forEach(function (li) {
                    tocItemsByRecinto[li.getAttribute('data-recinto')] = li;
                });

                // Mapa de "id de recinto" -> panel .user-annot de su ficha,
                // que existe para TODOS los recintos del informe (haya o no
                // anotación guardada). Es la lista maestra de ids que usa
                // la exportación a XML para no dejarse ninguna finca fuera,
                // aunque esté "Sin revisar".
                const annotPanelsByRecinto = {};
                document.querySelectorAll('.user-annot[data-recinto]').forEach(function (panel) {
                    annotPanelsByRecinto[panel.getAttribute('data-recinto')] = panel;
                });
                const reviewProgressText = document.getElementById('review-progress-text');
                const reviewProgressFill = document.getElementById('review-progress-fill');

                // Recalcula, para cada recinto, si está sin revisar / el
                // usuario confirmó la lectura del plugin / el usuario la
                // corrigió -- y pinta el punto de color correspondiente en
                // el TOC, además del contador "N de M recintos revisados"
                // de la cabecera. Se apoya solo en lo que ya se guarda
                // (""/"si"/"no" en annotData) frente a data-plugin-value de
                // cada ficha, así que no añade ningún dato nuevo.
                function updateReviewProgress() {
                    let reviewedCount = 0;
                    document.querySelectorAll('.user-annot').forEach(function (panel) {
                        const id = panel.getAttribute('data-recinto');
                        const pluginValue = panel.getAttribute('data-plugin-value') || '';
                        const a = annotData[id];
                        const interp = normalizeInterp(a ? a.interp : '', pluginValue);
                        const comentario = a ? (a.comentario || '') : '';

                        let state = 'pendiente';
                        let title = 'Sin revisar';
                        if (interp === 'si' || interp === 'no') {
                            reviewedCount++;
                            if (interp === pluginValue) {
                                state = 'confirmado';
                                title = 'Confirmado por el usuario';
                            } else {
                                state = 'corregido';
                                title = 'El usuario corrigió al plugin';
                            }
                        }

                        const li = tocItemsByRecinto[id];
                        if (li) {
                            const dot = li.querySelector('.toc-semaforo');
                            if (dot) {
                                dot.classList.remove('sem-pendiente', 'sem-confirmado', 'sem-corregido');
                                dot.classList.add('sem-' + state);
                                dot.title = title;
                            }

                            // Check verde/aspa roja: refleja tal cual la
                            // decisión del usuario (NOTIFICAR / NO NOTIFICAR),
                            // sin comparar con la lectura del plugin. Si aún
                            // no ha decidido, el hueco queda vacío pero
                            // mantiene su ancho fijo (ver CSS .toc-interp-icon).
                            const interpIcon = li.querySelector('.toc-interp-icon');
                            if (interpIcon) {
                                interpIcon.classList.remove('icon-si', 'icon-no');
                                if (interp === 'si') {
                                    interpIcon.classList.add('icon-si');
                                    interpIcon.title = 'El usuario indica que SÍ debe notificarse';
                                } else if (interp === 'no') {
                                    interpIcon.classList.add('icon-no');
                                    interpIcon.title = 'El usuario indica que NO debe notificarse';
                                } else {
                                    interpIcon.title = '';
                                }
                            }

                            // Icono de comentario: solo si hay algún
                            // carácter real (trim no vacío), no basta con
                            // espacios en blanco.
                            const commentIcon = li.querySelector('.toc-comment-icon');
                            if (commentIcon) {
                                const hasComment = comentario.trim().length > 0;
                                commentIcon.classList.toggle('icon-has', hasComment);
                                commentIcon.title = hasComment ? 'Esta ficha tiene comentario' : '';
                            }
                        }
                    });

                    if (reviewProgressText) {
                        reviewProgressText.textContent = reviewedCount + ' de ' + REPORT_TOTAL + ' recintos revisados';
                    }
                    if (reviewProgressFill) {
                        const pct = REPORT_TOTAL > 0 ? (reviewedCount / REPORT_TOTAL * 100) : 0;
                        reviewProgressFill.style.width = pct + '%';
                    }
                }

                // ---- Estado de guardado, en la barra superior siempre
                // visible ----
                // Un único indicador de texto, sin banners que descartar
                // ni botones que "vincular": el autoguardado (más abajo)
                // lo mantiene al día solo.
                function setSaveStatus(kind, text) {
                    if (!saveStatusEl) return;
                    saveStatusEl.textContent = text;
                    saveStatusEl.className = 'annot-topbar-status' + (kind ? ' ' + kind : '');
                }

                // ---- Menú desplegable "Compartir con otra persona" ----
                function toggleShareMenu(forceOpen) {
                    if (!shareMenuEl) return;
                    const open = (typeof forceOpen === 'boolean') ? forceOpen : !shareMenuEl.classList.contains('open');
                    shareMenuEl.classList.toggle('open', open);
                    if (shareToggleBtn) shareToggleBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
                }

                let saveTimer = null;
                function scheduleSave() {
                    updateEmbeddedScriptTag();
                    setSaveStatus('saving', 'Guardando…');
                    if (saveTimer) clearTimeout(saveTimer);
                    saveTimer = setTimeout(autosaveToDB, 500);
                }

                // ---- Autoguardado silencioso en el navegador (IndexedDB) ----
                // Sin botones ni diálogos: cada cambio se guarda solo,
                // indexado por REPORT_ID. Al volver a abrir este mismo
                // HTML en el mismo navegador, se recupera automáticamente
                // (ver loadAutosaveFromDB). No sustituye a "⬇ Descargar mis
                // respuestas": ese guardado en el navegador no viaja si se
                // mueve el archivo a otro equipo, ni sobrevive a borrar
                // datos de navegación.
                function openAutosaveDB() {
                    return new Promise(function (resolve, reject) {
                        if (!window.indexedDB) { reject(new Error('IndexedDB no disponible')); return; }
                        const req = indexedDB.open(AUTOSAVE_DB_NAME, 1);
                        req.onupgradeneeded = function () { req.result.createObjectStore(AUTOSAVE_STORE); };
                        req.onsuccess = function () { resolve(req.result); };
                        req.onerror = function () { reject(req.error); };
                    });
                }

                async function autosaveToDB() {
                    if (!window.indexedDB) {
                        setSaveStatus('warn', 'Autoguardado no disponible en este navegador — usa "⬇ Descargar mis respuestas" tras cada cambio');
                        document.dispatchEvent(new CustomEvent('audinot-annot-saved'));
                        return;
                    }
                    try {
                        const db = await openAutosaveDB();
                        await new Promise(function (resolve, reject) {
                            const tx = db.transaction(AUTOSAVE_STORE, 'readwrite');
                            tx.objectStore(AUTOSAVE_STORE).put({ data: annotData, savedAt: new Date().toISOString() }, REPORT_ID);
                            tx.oncomplete = resolve;
                            tx.onerror = function () { reject(tx.error); };
                        });
                        setSaveStatus('saved', 'Guardado automáticamente · ' + fmtFecha(new Date().toISOString()));
                    } catch (e) {
                        console.error('No se pudo autoguardar', e);
                        setSaveStatus('warn', 'No se pudo autoguardar en este navegador — usa "⬇ Descargar mis respuestas"');
                    }
                    document.dispatchEvent(new CustomEvent('audinot-annot-saved'));
                }

                async function loadAutosaveFromDB() {
                    if (!window.indexedDB) return;
                    try {
                        const db = await openAutosaveDB();
                        const record = await new Promise(function (resolve, reject) {
                            const tx = db.transaction(AUTOSAVE_STORE, 'readonly');
                            const req = tx.objectStore(AUTOSAVE_STORE).get(REPORT_ID);
                            req.onsuccess = function () { resolve(req.result || null); };
                            req.onerror = function () { reject(req.error); };
                        });
                        if (record && record.data && typeof record.data === 'object') {
                            annotData = record.data;
                            applyAnnotationsToDOM();
                            if (record.savedAt) setSaveStatus('saved', 'Recuperado de este navegador · ' + fmtFecha(record.savedAt));
                        }
                    } catch (e) {
                        console.error('No se pudo recuperar el autoguardado de este navegador', e);
                    }
                }

                function downloadUpdatedHtml() {
                    updateEmbeddedScriptTag();
                    syncTextareasForSerialization();
                    const text = '<!DOCTYPE html>\n' + document.documentElement.outerHTML;
                    const blob = new Blob([text], { type: 'text/html' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = HTML_FILENAME;
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                    setTimeout(function () { URL.revokeObjectURL(url); }, 2000);
                    setSaveStatus('saved', 'Descargado ✓ · ' + fmtFecha(new Date().toISOString()));
                }

                function exportShareXml() {
                    const blob = new Blob([serializeShareXML()], { type: 'application/xml' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = SHARE_FILENAME;
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                    setTimeout(function () { URL.revokeObjectURL(url); }, 2000);
                }

                function mergeImportedData(importedData) {
                    // El importado sobreescribe la ficha correspondiente
                    // en el receptor (sin fusión campo a campo). Se
                    // normaliza aquí por si el XML viene de una versión
                    // anterior del informe con el esquema antiguo.
                    Object.keys(importedData).forEach(function (id) {
                        const panel = document.querySelector('.user-annot[data-recinto="' + id.replace(/"/g, '\\"') + '"]');
                        const pluginValue = panel ? panel.getAttribute('data-plugin-value') : '';
                        const incoming = importedData[id] || {};
                        annotData[id] = Object.assign({}, incoming, { interp: normalizeInterp(incoming.interp, pluginValue) });
                    });
                    applyAnnotationsToDOM();
                    scheduleSave();
                }

                function importSharedXmlFile(file) {
                    const reader = new FileReader();
                    reader.onload = function () {
                        const parsed = parseShareXML(String(reader.result));
                        if (!parsed) {
                            alert('El archivo seleccionado no parece un XML de respuestas AudiNOT válido.');
                            return;
                        }
                        const meta = parsed.meta;
                        let proceed = true;
                        if (meta.informe && meta.informe !== HTML_FILENAME) {
                            proceed = confirm(
                                'Este XML de respuestas se generó a partir de "' + meta.informe + '"' +
                                (meta.totalRecintos ? (' (' + meta.totalRecintos + ' recintos)') : '') +
                                ',\npero este informe es "' + HTML_FILENAME + '" (' + REPORT_TOTAL + ' recintos).\n\n' +
                                '¿Seguro que quieres importar sus respuestas aquí?'
                            );
                        } else if (meta.totalRecintos && Number(meta.totalRecintos) !== REPORT_TOTAL) {
                            proceed = confirm(
                                'El XML de respuestas indica ' + meta.totalRecintos + ' recintos, pero este informe tiene ' + REPORT_TOTAL + '.\n' +
                                'Puede tratarse de una versión distinta del informe.\n\n¿Continuar con la importación?'
                            );
                        }
                        if (!proceed) return;
                        const count = Object.keys(parsed.data).length;
                        mergeImportedData(parsed.data);
                        alert('Se han importado las respuestas de ' + count + ' recinto(s).');
                    };
                    reader.readAsText(file);
                }

                function setAnnotation(id, patch) {
                    const current = annotData[id] || { interp: '', comentario: '' };
                    annotData[id] = Object.assign({}, current, patch, { fecha: new Date().toISOString() });
                    scheduleSave();
                    document.dispatchEvent(new CustomEvent('audinot-annot-changed'));
                }

                function clearAnnotation(id) {
                    delete annotData[id];
                    scheduleSave();
                    document.dispatchEvent(new CustomEvent('audinot-annot-changed'));
                }

                function wireCard(panel) {
                    const id = panel.getAttribute('data-recinto');
                    const pluginValue = panel.getAttribute('data-plugin-value') || '';
                    const btns = panel.querySelectorAll('.ua-btn');
                    const textarea = panel.querySelector('.user-annot-comment');
                    const statusEl = panel.querySelector('.user-annot-status');
                    const printInterp = panel.querySelector('.ua-print-interp');
                    const printComment = panel.querySelector('.ua-print-comment');

                    function resetToBlank() {
                        btns.forEach(function (b) { b.classList.remove('active'); });
                        const defaultBtn = panel.querySelector('.ua-btn[data-value=""]');
                        if (defaultBtn) defaultBtn.classList.add('active');
                        if (textarea) textarea.value = '';
                        if (printInterp) printInterp.textContent = interpLabel('', pluginValue);
                        if (printComment) printComment.textContent = '';
                        if (statusEl) {
                            statusEl.textContent = 'Sin anotaciones para esta ficha.';
                            statusEl.className = 'user-annot-status';
                        }
                    }

                    btns.forEach(function (btn) {
                        btn.addEventListener('click', function () {
                            const val = btn.getAttribute('data-value');

                            // "Sin revisar" es el único botón destructivo:
                            // vuelve la ficha a su estado neutro y vacía
                            // también el comentario. Solo se pide
                            // confirmación si hay algo que se perdería.
                            if (val === '') {
                                const current = annotData[id];
                                const hasData = current && (current.interp || (current.comentario || '').trim());
                                if (hasData && !confirm('¿Marcar esta ficha como "Sin revisar"? Se vaciará también el comentario.')) return;
                                clearAnnotation(id);
                                resetToBlank();
                                updateReviewProgress();
                                return;
                            }

                            btns.forEach(function (b) { b.classList.remove('active'); });
                            btn.classList.add('active');
                            if (printInterp) printInterp.textContent = interpLabel(val, pluginValue);
                            if (statusEl) {
                                statusEl.textContent = 'Guardando…';
                                statusEl.className = 'user-annot-status pending';
                            }
                            setAnnotation(id, { interp: val });
                            updateReviewProgress();
                        });
                    });

                    if (textarea) {
                        let debounceTimer = null;
                        textarea.addEventListener('input', function () {
                            if (printComment) printComment.textContent = textarea.value;
                            if (statusEl) {
                                statusEl.textContent = 'Guardando…';
                                statusEl.className = 'user-annot-status pending';
                            }
                            if (debounceTimer) clearTimeout(debounceTimer);
                            debounceTimer = setTimeout(function () {
                                setAnnotation(id, { comentario: textarea.value });
                                updateReviewProgress();
                            }, 500);
                        });
                    }

                    document.addEventListener('audinot-annot-saved', function () {
                        const a = annotData[id];
                        if (!statusEl) return;
                        if (a && (a.interp || (a.comentario || '').trim())) {
                            statusEl.textContent = 'Guardado automáticamente · ' + fmtFecha(a.fecha);
                            statusEl.className = 'user-annot-status saved';
                        } else {
                            statusEl.textContent = 'Sin anotaciones para esta ficha.';
                            statusEl.className = 'user-annot-status';
                        }
                    });
                }

                loadEmbeddedCapsule();
                document.querySelectorAll('.user-annot').forEach(wireCard);
                applyAnnotationsToDOM();

                if (downloadBtn) downloadBtn.addEventListener('click', downloadUpdatedHtml);
                if (shareToggleBtn) shareToggleBtn.addEventListener('click', function (e) {
                    e.stopPropagation();
                    toggleShareMenu();
                });
                if (shareMenuEl) shareMenuEl.addEventListener('click', function (e) { e.stopPropagation(); });
                document.addEventListener('click', function () { toggleShareMenu(false); });
                if (exportBtn) exportBtn.addEventListener('click', function () {
                    exportShareXml();
                    toggleShareMenu(false);
                });
                if (importBtn) importBtn.addEventListener('click', function () { importInput.click(); });
                if (importInput) importInput.addEventListener('change', function () {
                    if (importInput.files && importInput.files[0]) importSharedXmlFile(importInput.files[0]);
                    importInput.value = '';
                    toggleShareMenu(false);
                });

                setSaveStatus('', 'Autoguardado activado en este navegador');
                loadAutosaveFromDB();
            })();
            </script>
        """
        return (template
                .replace("__HTML_FILENAME__", html_filename)
                .replace("__SHARE_FILENAME__", share_filename)
                .replace("__REPORT_TOTAL__", str(total_recintos))
                .replace("__REPORT_ID__", report_id)
                .replace("__PROJECT_CRS__", project_crs or ''))

    def _get_pct(self, antes, despues):
        """
        Calcula la variación porcentual estándar con lógica Senior 20+:
        - Si la diferencia es casi nula (TOL), retorno 0.0
        - Si antes era 0 y después no, retorno +100.0
        - Si antes no era 0 y después es 0, retorno -100.0
        """
        TOL = 0.001
        delta = despues - antes
        
        if abs(delta) < TOL:
            return 0.0
        
        # Caso: Paso de cero a algo (+100%)
        if abs(antes) < TOL:
            return 100.0
        
        # Caso: Desaparición total (-100%)
        if abs(despues) < TOL:
            return -100.0
            
        return (delta / antes) * 100.0

    def _fmt_val(self, val, precision=2, force_int=False):
        """Formatea valor absoluto con alineación decimal fantasma."""
        if abs(val) < 0.0001:
            main = "0"
            phantom = f'<span class="phantom">.{"0"*precision}</span>'
        else:
            s_val = f"{val:.{precision}f}"
            if "." in s_val:
                main, dec = s_val.split(".")
                if force_int:
                    phantom = f'<span class="phantom">.{dec}</span>'
                else:
                    phantom = f".{dec}"
            else:
                main = s_val
                phantom = ""
        
        return f'<span class="num-block">{main}{phantom}</span>'

    def _fmt_diff(self, val, precision=2, force_int=False):
        """Formatea diferencia con alineación de signo y decimales fantasma."""
        sign = "+" if val >= 0.0001 else "-" if val <= -0.0001 else ""
        abs_val = abs(val)
        
        if abs_val < 0.0001:
            main = "0"
            phantom = f'<span class="phantom">.{"0"*precision}</span>'
            sign_part = '<span class="phantom">+</span>'
        else:
            s_val = f"{abs_val:.{precision}f}"
            sign_part = sign
            if "." in s_val:
                main, dec = s_val.split(".")
                if force_int:
                    phantom = f'<span class="phantom">.{dec}</span>'
                else:
                    phantom = f".{dec}"
            else:
                main = s_val
                phantom = ""
        
        return f'<span class="num-block">{sign_part}{main}{phantom}</span>'

    def _fmt_pct(self, val, precision=2):
        """Formatea porcentaje con alineación inteligente (sin %)."""
        # Si el porcentaje es 0, lo forzamos a entero para que alinee con Var = 0
        force = True if abs(val) < 0.0001 else False
        return self._fmt_diff(val, precision, force_int=force)


    def _generate_incidence_svg(self, scores):
        """
        Genera un mini-gráfico SVG de 4 barras (G, I, F, A) que representa el ADN de la notificación.
        """
        w, h = 120, 100
        padding = 20
        bar_w = 15
        gap = 10
        
        svg = f'<svg width="{w}" height="{h+25}" viewBox="0 0 {w} {h+25}" xmlns="http://www.w3.org/2000/svg" style="background:#f9f9f9; border-radius:4px; padding:5px; border:1px solid #eee">'
        
        # Pilares: Geometría, Islas, Fachadas, Aditamentos
        pillars = [('G','#3498db','Geom'), ('I','#9b59b6','Islas'), ('F','#e67e22','Fach'), ('A','#e74c3c','Adit')]
        
        for i, (key, color, label) in enumerate(pillars):
            score = scores.get(key, 0)
            bar_h = (score / 100.0) * h
            x = padding + i * (bar_w + gap)
            y = h - bar_h
            
            svg += f'<rect x="{x}" y="{y}" width="{bar_w}" height="{bar_h}" fill="{color}" rx="2" opacity="0.8">'
            if score > 0:
                svg += f'<animate attributeName="height" from="0" to="{bar_h}" dur="0.5s" fill="freeze" />'
                svg += f'<animate attributeName="y" from="{h}" to="{y}" dur="0.5s" fill="freeze" />'
            svg += '</rect>'
            svg += f'<text x="{x + bar_w/2}" y="{h+12}" font-family="Arial, sans-serif" font-size="8" text-anchor="middle" fill="#666">{key}</text>'
            
        svg += '</svg>'
        return svg


    def _collect_adit_alert_reasons(self, d, thresholds=None):
        """
        Recorre los aditamentos/elementos técnicos vinculados a la finca y
        devuelve, solo para aquellos que SUPERAN los umbrales configurados,
        un fragmento de texto cuantificado (valor antes/después y variación)
        apto para el comentario de NOTIFICAR.
        """
        adits = d.get('aditamentos', {})
        if not adits:
            return []

        TOL = 0.001
        reasons = []

        t_linear_abs = 1.0; t_linear_pct = 5.0
        t_poly_abs = 1.0; t_poly_pct = 5.0
        if thresholds and 'aditamentos' in thresholds:
            t_linear_abs = thresholds['aditamentos'].get('linear', {}).get('abs', 1.0)
            t_linear_pct = thresholds['aditamentos'].get('linear', {}).get('pct', 5.0)
            t_poly_abs = thresholds['aditamentos'].get('poly', {}).get('abs', 1.0)
            t_poly_pct = thresholds['aditamentos'].get('poly', {}).get('pct', 5.0)

        for el_name, data in sorted(adits.items()):
            a = data.get('a', {'len': 0, 'area': 0, 'count': 0})
            dv = data.get('d', {'len': 0, 'area': 0, 'count': 0})

            if a['len'] >= TOL or dv['len'] >= TOL:
                delta = dv['len'] - a['len']
                pct = self._get_pct(a['len'], dv['len'])
                if self._chk(delta, t_linear_abs) or self._chk(pct, t_linear_pct):
                    reasons.append({
                        'mag': abs(pct),
                        'text': f"la longitud de {el_name} pasa de {self._fmt_val(a['len'])} m a {self._fmt_val(dv['len'])} m ({delta:+.1f} m, {pct:+.1f}%)"
                    })

            if a['area'] >= TOL or dv['area'] >= TOL:
                delta = dv['area'] - a['area']
                pct = self._get_pct(a['area'], dv['area'])
                if self._chk(delta, t_poly_abs) or self._chk(pct, t_poly_pct):
                    reasons.append({
                        'mag': abs(pct),
                        'text': f"la superficie de {el_name} pasa de {self._fmt_val(a['area'])} m² a {self._fmt_val(dv['area'])} m² ({delta:+.1f} m², {pct:+.1f}%)"
                    })

            if a['count'] != dv['count']:
                delta = dv['count'] - a['count']
                reasons.append({
                    'mag': abs(delta) * 30,
                    'text': f"el número de elementos de {el_name} pasa de {a['count']} a {dv['count']} ({'+' if delta>0 else ''}{delta})"
                })

        return reasons

    def _generate_adit_table_rows(self, d, thresholds=None):
        """Genera filas de tabla y retorna (html, num_alertas, num_totales)."""
        adits = d.get('aditamentos', {})
        if not adits: return "", 0, 0
        
        TOL = 0.001
        html = ""
        alerts = 0
        total_params = 0
        
        # Umbrales
        t_linear_abs = 1.0; t_linear_pct = 5.0
        t_poly_abs = 1.0; t_poly_pct = 5.0
        if thresholds and 'aditamentos' in thresholds:
            t_linear_abs = thresholds['aditamentos'].get('linear', {}).get('abs', 1.0)
            t_linear_pct = thresholds['aditamentos'].get('linear', {}).get('pct', 5.0)
            t_poly_abs = thresholds['aditamentos'].get('poly', {}).get('abs', 1.0)
            t_poly_pct = thresholds['aditamentos'].get('poly', {}).get('pct', 5.0)

        for el_name, data in sorted(adits.items()):
            a = data.get('a', {'len':0, 'area':0, 'count':0})
            dv = data.get('d', {'len':0, 'area':0, 'count':0})
            
            # Líneas
            if a['len'] >= TOL or dv['len'] >= TOL:
                total_params += 1
                delta = dv['len'] - a['len']
                pct = self._get_pct(a['len'], dv['len'])
                mark = self._chk(delta, t_linear_abs) or self._chk(pct, t_linear_pct)
                if mark: alerts += 1
                cls = "text-pos" if delta > 0.05 else "text-neg" if delta < -0.05 else ""
                html += f'<tr><td>{el_name} (Lon)</td><td class="val-num">{self._fmt_val(a["len"])}</td><td class="val-num">{self._fmt_val(dv["len"])}</td><td class="val-num {cls}">{self._fmt_diff(delta)}</td><td class="mark-slot">{mark}</td><td class="val-num {cls}">{self._fmt_pct(pct)}</td><td class="mark-slot">{mark}</td></tr>'
            
            # Polígonos
            if a['area'] >= TOL or dv['area'] >= TOL:
                total_params += 1
                delta = dv['area'] - a['area']
                pct = self._get_pct(a['area'], dv['area'])
                mark = self._chk(delta, t_poly_abs) or self._chk(pct, t_poly_pct)
                if mark: alerts += 1
                cls = "text-pos" if delta > 0.1 else "text-neg" if delta < -0.1 else ""
                html += f'<tr><td>{el_name} (Sup)</td><td class="val-num">{self._fmt_val(a["area"])}</td><td class="val-num">{self._fmt_val(dv["area"])}</td><td class="val-num {cls}">{self._fmt_diff(delta)}</td><td class="mark-slot">{mark}</td><td class="val-num {cls}">{self._fmt_pct(pct)}</td><td class="mark-slot">{mark}</td></tr>'
            
            # Puntos / Conteo
            if a['count'] != dv['count']:
                total_params += 1
                delta = dv['count'] - a['count']
                alerts += 1
                html += f'<tr><td>{el_name} (Cant)</td><td class="val-num">{a["count"]}</td><td class="val-num">{dv["count"]}</td><td class="val-num">{"%+" if delta > 0 else ""}{delta}</td><td class="mark-slot"> *</td><td class="val-num"></td><td class="mark-slot"></td></tr>'
            elif a['count'] > 0:
                total_params += 1

        return html, alerts, total_params

    def _generate_adit_section_layout(self, content_html, pillar_scores):
        """Monta el layout Flex con la tabla (2/3) y el gráfico (1/3)."""
        if not content_html:
            return f"""
            <div class="panel" style="border-top:1px solid #eee; background:#fcfcfc; display:flex; align-items:center; gap:20px">
                <div style="flex:2">
                    <div class="panel-title">AUDITORÍA DE ADITAMENTOS</div>
                    <div style="color:#ccc; font-style:italic">Sin elementos técnicos vinculados</div>
                </div>
                <div style="flex:1; text-align:center; border-left:1px solid #eee; padding:5px">
                    <div style="font-size:0.7em; color:#999; margin-bottom:5px; font-weight:bold">PERFIL DE IMPACTO (G-I-F-A)</div>
                    {self._generate_incidence_svg(pillar_scores)}
                </div>
            </div>
            """
            
        return f"""
        <div class="panel" style="border-top:1px solid #eee; background:#fcfcfc; display:flex; gap:20px; padding:0">
            <div style="flex:2; border-right:1px solid #eee; padding:15px">
                <div class="panel-title">AUDITORÍA DE ADITAMENTOS</div>
                <table class="mini-table">
                    <colgroup>
                        <col style="width: 35%"><col style="width: 15%"><col style="width: 15%"><col style="width: 12%"><col style="width: 14px"><col style="width: 12%"><col style="width: 14px">
                    </colgroup>
                    <tr><th>ELEMENTO</th><th class="num-col">Antes</th><th class="num-col">Después</th><th class="num-col">Var</th><th></th><th class="num-col">%</th><th></th></tr>
                    {content_html}
                </table>
            </div>
            <div style="flex:1; text-align:center; padding:15px; display:flex; flex-direction:column; justify-content:center; align-items:center; background:#f9f9f9">
                <div style="font-size:0.75em; color:#666; margin-bottom:10px; font-weight:bold; letter-spacing:1px">PERFIL DE IMPACTO</div>
                {self._generate_incidence_svg(pillar_scores)}
            </div>
        </div>
        """

    def _report_css(self):
        """CSS compartido por los informes HTML (completo y resumen), para
        que ambos mantengan idéntico aspecto visual."""
        return """
                :root { --primary: #2c3e50; --sec: #34495e; --accent: #3498db; --bg: #f5f7fa; --card-bg: #fff; --border: #e1e4e8; }
                body { font-family: 'Segoe UI', sans-serif; background: var(--bg); color: #333; margin: 0; display: flex; height: 100vh; overflow: hidden; }
                
                /* Sidebar TOC */
                .sidebar { width: 280px; background: white; border-right: 1px solid var(--border); flex-shrink: 0; display: flex; flex-direction: column; position: relative; }
                .sidebar-header { padding: 20px; background: var(--primary); color: white; position: sticky; top: 0; z-index: 10; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
                .search-container { position: relative; margin-top: 10px; display: flex; align-items: center; }
                .search-box { width: 100%; padding: 8px 30px 8px 12px; border: none; border-radius: 4px; font-size: 0.9em; background: rgba(255,255,255,0.9); color: #333; box-sizing: border-box; }
                .search-box::placeholder { color: #999; }
                .search-box:focus { outline: 2px solid var(--accent); background: white; }
                .clear-btn { position: absolute; right: 8px; cursor: pointer; color: #999; font-weight: bold; background: none; border: none; font-size: 1.2em; display: none; }
                .clear-btn:hover { color: #333; }
                .toc-list { list-style: none; padding: 0; margin: 0; overflow-y: auto; flex-grow: 1; }
                .toc-item { border-bottom: 1px solid var(--border); }
                .toc-item.hidden { display: none; }
                .audit-card.hidden { display: none; }
                .toc-link { display: block; padding: 12px 20px; text-decoration: none; color: #555; font-size: 0.9em; transition: 0.2s; }
                .toc-link:hover { background: #f0f4f8; color: var(--accent); }
                .toc-link.active { background: #e3f2fd; border-left: 4px solid var(--accent); font-weight: bold; }
                .toc-badge { float: right; font-size: 0.75em; padding: 2px 6px; border-radius: 4px; color: white; }

                /* Semáforo de revisión por recinto en el TOC. Paleta
                   pensada para daltonismo (no se distingue por matiz
                   rojo/verde/ámbar, sino por relleno + color muy separado
                   en el espacio de color):
                     - sin revisar: círculo SIN relleno (solo contorno)
                     - confirmado (el usuario acepta la lectura del plugin):
                       relleno azul noche
                     - corregido (el usuario coge la alternativa a la
                       propuesta): relleno rojo
                   Se calcula comparando el valor guardado ("" / "si" / "no")
                   con la lectura del plugin para ese mismo recinto. Solo
                   aplica al informe principal, que es el que tiene panel
                   de anotaciones. */
                .toc-semaforo {
                    display: inline-block; width: 9px; height: 9px; border-radius: 50%;
                    margin-right: 0; vertical-align: middle; background: transparent;
                    border: 1.6px solid #8a8a8a; box-sizing: border-box;
                }
                .toc-semaforo.sem-pendiente { background: transparent; border-color: #8a8a8a; }
                .toc-semaforo.sem-confirmado { background: #16324f; border-color: #16324f; }
                .toc-semaforo.sem-corregido { background: #c0392b; border-color: #c0392b; }

                /* Contenedor de los 3 indicadores de cada finca en el TOC:
                   semáforo de revisión + check de la decisión del usuario
                   (NOTIFICAR/NO NOTIFICAR) + icono de "tiene comentario".
                   Los tres huecos se reservan SIEMPRE, tengan o no icono
                   que mostrar, para que el número de finca quede alineado
                   igual en todas las filas del listado. */
                .toc-icons {
                    display: inline-flex; align-items: center; gap: 4px;
                    margin-right: 7px; vertical-align: middle;
                }
                .toc-interp-icon, .toc-comment-icon {
                    display: inline-flex; align-items: center; justify-content: center;
                    width: 12px; height: 12px; flex: none; font-size: 10px; line-height: 1;
                }
                /* Check verde = el usuario ha marcado esta finca para NOTIFICAR;
                   aspa roja = el usuario ha marcado que NO debe notificarse.
                   Si la finca está "sin revisar" ninguna clase se aplica y el
                   hueco queda vacío, pero conserva su ancho. */
                .toc-interp-icon.icon-si::before { content: "✔"; color: #1e8449; font-weight: 700; }
                .toc-interp-icon.icon-no::before { content: "✘"; color: #c0392b; font-weight: 700; }
                /* Icono de comentario: solo aparece si hay algún carácter
                   real (no solo espacios) en el campo de comentario de esa
                   ficha. */
                .toc-comment-icon.icon-has::before { content: "📝"; font-size: 10px; }

                /* Progreso de revisión, cabecera del sidebar */
                .review-progress { margin-top: 10px; }
                .review-progress-text { font-size: 0.8em; color: rgba(255,255,255,0.92); display: block; margin-bottom: 4px; }
                .review-progress-bar { height: 6px; border-radius: 3px; background: rgba(255,255,255,0.25); overflow: hidden; }
                .review-progress-fill { height: 100%; background: var(--accent); width: 0%; transition: width 0.25s ease; }
                
                /* Warning Badge in Sidebar */
                .toc-warning { display: inline-block; width: 14px; height: 14px; background: red; color: white; border-radius: 50%; font-size: 10px; text-align: center; line-height: 14px; margin-right: 5px; font-weight: bold; }

                /* Report Header (Visible on Screen & Print) */
                .report-header { position: sticky; top: 0; z-index: 100; display: block; padding: 10px 20px; border-bottom: 2px solid var(--primary); margin-bottom: 0; background: white; box-shadow: 0 4px 6px rgba(0,0,0,0.05); }
                .report-header h1 { margin: 0 0 5px 0; font-size: 22px; color: var(--primary); }
                .report-meta { font-size: 12px; color: #555; display: grid; grid-template-columns: 2fr 1fr; gap: 20px; }
                .meta-group strong { display: block; margin-bottom: 2px; color: #000; }

                /* Main Content */
                .main-content { flex-grow: 1; overflow-y: auto; padding: 0; scroll-behavior: smooth; }
                
                .cards-wrapper { padding: 14px; }

                /* Audit Card */
                .audit-card { background: white; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); margin-bottom: 30px; overflow: hidden; border: 1px solid var(--border); }
                .audit-card.alert-border { border: 2px solid #e74c3c; }
                .card-header { background: linear-gradient(to right, #f8f9fa, #fff); padding: 9px 16px; border-bottom: 1px solid var(--border); display: flex; justify-content: space-between; align-items: center; }
                .card-title h2 { margin: 0; color: var(--primary); font-size: 1.3em; }
                .card-title span { color: #7f8c8d; font-size: 0.85em; }
                
                .grid-panels { display: grid; grid-template-columns: repeat(auto-fit, minmax(400px, 1fr)); gap: 0; }
                .panel { padding: 11px 12px; border-bottom: 1px solid var(--border); } /* Padding reducido de 25px a 15px, y luego a 11px/12px */
                .panel:not(:last-child) { border-right: 1px solid var(--border); }
                .panel-title { font-size: 0.8em; text-transform: uppercase; letter-spacing: 1px; color: #888; margin-bottom: 10px; font-weight: bold; border-left: 3px solid var(--accent); padding-left: 8px; }
                
                /* Tables inside cards (7 Columna System) */
                .mini-table { width: 100%; font-size: 0.85em; border-collapse: collapse; table-layout: fixed; }
                .mini-table th { text-align: left; color: #666; font-weight: 600; padding: 4px 0; border-bottom: 1px solid #eee; }
                .mini-table th.num-col { text-align: center; }
                .mini-table td { padding: 3px 0; border-bottom: 1px solid #f9f9f9; }
                
                /* Column Widths (Fixed for Marks) */
                .mini-table td:nth-child(2), .mini-table td:nth-child(3) { text-align: right; }
                .mini-table td:nth-child(4) { text-align: right; }
                .mini-table td:nth-child(5) { text-align: left; padding-left: 2px; overflow: visible; font-weight: bold; color: #e74c3c; width: 14px; }
                .mini-table td:nth-child(6) { text-align: right; }
                .mini-table td:nth-child(7) { text-align: left; padding-left: 2px; overflow: visible; font-weight: bold; color: #e74c3c; width: 14px; }
                
                .mini-table th.num-col { text-align: right !important; }

                .val-num { font-family: 'Consolas', monospace; font-weight: 600; white-space: nowrap; }
                .num-block { display: inline-block; text-align: right; }
                .phantom { visibility: hidden; opacity: 0; pointer-events: none; }
                .mark-slot { color: #e74c3c; font-weight: bold; font-size: 1.1em; line-height: 1; display: inline-block; }
                
                /* Badges & Colors */
                .bg-persiste { background: #27ae60; }
                .bg-alta { background: #2980b9; }
                .bg-baja { background: #c0392b; }
                .bg-cambio { background: #f39c12; }
                .text-pos { color: #27ae60; }
                .text-neg { color: #c0392b; }
                
                /* Flows */
                .flow-item { display: flex; justify-content: space-between; padding: 3px 6px; background: #f8f9fa; border-radius: 3px; margin-bottom: 3px; font-size: 0.85em; line-height: 1.2; }
                .flow-arrow { color: #bbb; margin: 0 10px; }
                
                /* Owner Change Indicator */
                .owner-change { display: inline-block; margin-left: 10px; padding: 4px 10px; border-radius: 4px; font-size: 0.85em; font-weight: bold; }
                .owner-change.changed { background: #ff9800; color: white; }
                .owner-change.unchanged { background: #4caf50; color: white; }
                
                .alert-label { background: #e74c3c; color: white; padding: 4px 8px; border-radius: 4px; font-weight: bold; font-size: 0.8em; margin-right: 10px; }
                .notif-status { display: inline-flex; align-items: center; font-size: 0.8em; font-weight: bold; margin-right: 12px; color: #2c3e50; }
                .notif-status .notif-label-text { margin-right: 5px; }
                .notif-status .notif-value { padding: 3px 9px; border-radius: 4px; font-weight: bold; }
                .notif-status .notif-value.si { background: #e74c3c; color: #ffffff; }
                .notif-status .notif-value.no { background: #2ecc71; color: #1b4332; }

                /* Comprobación informativa Superficie T24 (supfT24 vs. GML) */
                .t24-check { font-size: 0.78em; color: #7f8c8d; margin-bottom: 4px; white-space: nowrap; }
                .t24-check .t24-lbl { margin-right: 3px; }
                .t24-check .t24-lbl.t24-gml-lbl { font-style: italic; opacity: 0.85; }
                .t24-check .t24-val { display: inline-block; padding: 2px 7px; border-radius: 3px; font-weight: bold; margin-right: 8px; }
                .t24-check .t24-val:last-child { margin-right: 0; }
                .t24-check .t24-val.t24-red { background: #c0392b; color: #ffffff; }
                .t24-check .t24-val.t24-green { background: #27ae60; color: #ffffff; }
                .t24-check .t24-val.t24-unknown { background: #fff3cd; color: #000000; }
                .t24-check .t24-arrow { margin-left: 3px; font-weight: bold; font-size: 1.55em; line-height: 1; vertical-align: middle; display: inline-block; }
                @keyframes t24-despues-blink { 0%,100% { background:#c0392b; color:#ffffff; } 50% { background:#ffffff; color:#c0392b; box-shadow: 0 0 0 1px #c0392b inset; } }
                .t24-check .t24-val.t24-despues-blink { animation: t24-despues-blink 1s ease-in-out infinite; }
                .t24-table { margin-left: auto; border-collapse: collapse; }
                .t24-table td { padding: 0; }
                .t24-table tr:first-child td { padding-bottom: 4px; }
                .t24-areas-cell { font-size: 11px; color: #7f8c8d; text-align: left; padding-right: 14px; white-space: nowrap; }
                .t24-diff-cell { font-weight: bold; text-align: right; white-space: nowrap; }
                /* Etiqueta visible (no solo tooltip, para que se entienda
                   también en el informe impreso) delante de la diferencia
                   gráfica Antes/Después ya existente. */
                .t24-diff-cell-lbl { font-weight: normal; font-size: 11px; color: #7f8c8d; }
                /* Segunda celda, junto a la diferencia gráfica: las DOS
                   diferencias supfT24 - GML (Antes y Después, cada una en
                   su propia línea y con su propia etiqueta) -- el % 'GML:'
                   de la fila de validación, pero en m² y separado por
                   estado, más representativo que la diferencia gráfica
                   para juzgar la calidad del dato Antes/Después. */
                .t24-diff-gml-cell { padding-left: 14px; border-left: 1px solid var(--border); font-weight: normal; text-align: right; vertical-align: top; }
                .t24-diff-gml-line { font-size: 11px; white-space: nowrap; }
                .t24-diff-gml-line + .t24-diff-gml-line { margin-top: 2px; }
                .t24-diff-gml-lbl { color: #7f8c8d; margin-right: 4px; }
                .t24-diff-gml-val { font-weight: bold; color: #2c3e50; }
                .t24-diff-gml-val.t24-diff-gml-unknown { font-weight: normal; color: #7a6000; background: #fff3cd; padding: 0 4px; border-radius: 3px; }

                /* Croquis de Alteración ANTES/DESPUÉS */
                .sketch-section { margin-top: 6px; padding: 8px 10px 10px 10px; border-top: 1px dashed var(--border); }
                .sketch-frame { display: flex; flex-wrap: wrap; align-items: flex-start; justify-content: center; gap: 18px; max-width: 720px; margin: 0 auto; }
                .sketch-canvas { position: relative; flex: 1 1 360px; max-width: 560px; min-width: 260px; }
                .sketch-label { position: absolute; top: 4px; left: 8px; background: rgba(255,255,255,0.85); padding: 2px 8px; border-radius: 3px; font-size: 0.78em; font-weight: bold; color: #2c3e50; border: 1px solid #ddd; }
                .sketch-svg { width: 100%; height: auto; display: block; margin: 0 auto; border-radius: 4px; }
                .sketch-bg { fill: #fbfbfa; stroke: #ddd; stroke-width: 1; }
                /* Sombreado sólido del recinto de estudio, para diferenciarlo
                   a simple vista de los recintos de contexto (sin relleno). */
                .sketch-study-fill { fill: #f0f0f0; stroke: none; }
                .sketch-antes { fill: none; stroke: #2980b9; stroke-width: 2; stroke-dasharray: 6 4; }
                .sketch-despues { fill: none; stroke: #2c3e50; stroke-width: 2.2; }
                .sketch-gained { fill: #0072B2; fill-opacity: 0.45; stroke: #004C75; stroke-width: 0.6; }
                .sketch-lost { fill: #E69F00; fill-opacity: 0.45; stroke: #A66F00; stroke-width: 0.6; }
                .sketch-context { fill: none; stroke: #bbb; stroke-width: 0.6; }
                /* Recintos de contexto categorizados como EDIFICACIONES
                   (rango REC de la Ficha 2: Mapeo de Campos): relleno
                   rayado fino para distinguirlos del resto de fincas de
                   contexto (sin relleno) y de los huecos/islas del
                   propio recinto de estudio. */
                .sketch-context-edif { fill: url(#edifHatch); stroke: #777; stroke-width: 0.7; }
                .sketch-context-related { fill: none; stroke: #888; stroke-width: 1.1; stroke-dasharray: 3 2; }
                .sketch-context-label { fill: #aaa; font-size: 8px; font-family: inherit; text-anchor: middle; dominant-baseline: middle; pointer-events: none; }
                .sketch-context-label-related { fill: #555; font-size: 8px; font-weight: bold; font-family: inherit; text-anchor: middle; dominant-baseline: middle; pointer-events: none; }
                /* Aditamentos sobre el croquis (situación DESPUÉS) */
                .sketch-adit { fill: #4d4d4d; fill-opacity: 0.30; stroke: #2b2b2b; stroke-width: 0.8; }
                .sketch-adit-line { fill: none; stroke: #2b2b2b; stroke-width: 1.4; }
                .sketch-adit-point { fill: #4d4d4d; stroke: #2b2b2b; stroke-width: 0.6; }
                .sketch-adit-alert { fill: url(#aditAlertHatch); stroke: #000000; stroke-width: 1.8; }
                .sketch-adit-line-alert { fill: none; stroke: #000000; stroke-width: 2.4; stroke-dasharray: 4 2; }
                .sketch-adit-point-alert { fill: #CC79A7; stroke: #000000; stroke-width: 1.4; }
                /* Aditamentos de fincas de CONTEXTO (vecinas), estilo tenue
                   a juego con .sketch-context, para no confundirlos con los
                   aditamentos del propio recinto de estudio. */
                .sketch-context-adit { fill: #bbb; fill-opacity: 0.25; stroke: #999; stroke-width: 0.5; }
                .sketch-context-adit-line { fill: none; stroke: #999; stroke-width: 0.9; stroke-dasharray: 2 1.5; }
                .sketch-context-adit-point { fill: #bbb; stroke: #999; stroke-width: 0.4; }
                .leg-adit { background: #4d4d4d; opacity: 0.85; }
                .leg-adit-alert { background-image: repeating-linear-gradient(45deg, #CC79A7 0, #CC79A7 2px, #000000 2px, #000000 4px); border: 1px solid #000; }
                .sketch-sidebar { flex: 0 0 130px; display: flex; flex-direction: column; gap: 16px; padding-top: 10px; }
                .sketch-scalebar-svg { display: block; width: 120px; height: 14px; }
                .sketch-scalebar line { stroke: #555; stroke-width: 1; }
                .sketch-scale-block { width: 120px; }
                .sketch-scalebar-text { text-align: center; font-size: 10px; color: #555; margin-top: 1px; line-height: 1.1; }
                .sketch-legend { display: flex; flex-direction: column; gap: 8px; font-size: 0.78em; color: #555; }
                .sketch-legend span { display: flex; align-items: center; gap: 6px; }
                .sketch-note { text-align: center; font-size: 0.78em; color: #888; margin-top: 6px; font-style: italic; }
                .sketch-error { color: #999; }
                .leg-swatch { display: inline-block; width: 16px; height: 10px; border-radius: 2px; }
                .leg-antes { background: transparent; border: 2px dashed #2980b9; height: 6px; }
                .leg-despues { background: transparent; border: 2px solid #2c3e50; height: 6px; }
                .leg-gained { background: #0072B2; opacity: 0.8; }
                .leg-lost { background: #E69F00; opacity: 0.8; }
                .leg-edif { background-image: repeating-linear-gradient(45deg, #fff 0, #fff 3px, #777 3px, #777 4px); border: 1px solid #999; }

                /* Change Indicator */
                .diff-nonzero { color: #e74c3c !important; font-weight: bold; }

                /* Cuerpo del informe RESUMEN: mismo orden vertical que el
                   informe de auditoría gráfica completo -- interpretación
                   por parámetros, interpretación alternativa y, debajo, el
                   croquis a tamaño completo (con su leyenda a la derecha),
                   simplemente sin la tabla de métricas ni la auditoría de
                   aditamentos. Se reutilizan tal cual los estilos de
                   .dual-interpretation / .sketch-section del informe
                   ampliado para que el croquis se vea igual de grande y
                   legible que allí. */
                .resumen-body { padding: 0 14px; }

                /* Print Styles */
                @media print {
                    .sidebar { display: none !important; }
                    .annot-topbar { display: none !important; }
                    body { display: block; height: auto; overflow: visible; background: white; font-size: 11px; padding-top: 0 !important; }
                    .main-content { width: 100%; max-width: 100%; padding: 0; overflow: visible; margin: 0; }
                    .audit-card { page-break-after: auto; page-break-inside: avoid; margin: 0 0 10px 0; box-shadow: none; border: 1px solid #ccc; padding: 0; }
                    .audit-card.hidden { display: none !important; }
                    .card-header { padding: 5px 10px; background: #eee; }
                    .card-title h2 { font-size: 1.1em; margin: 0; }
                    .panel { padding: 5px !important; }
                    .mini-table td, .mini-table th { padding: 2px 0 !important; font-size: 0.9em; }
                    .sketch-section { page-break-inside: avoid; }
                    .sketch-canvas { max-width: 420px; }
                    .report-header { position: static; display: block !important; border: 1px solid #ddd; margin-bottom: 10px; padding: 10px; box-shadow: none; }
                    .cards-wrapper { padding: 0; }
                    * { box-shadow: none !important; }

                    /* Interpretaciones de notificar/no notificar (el texto
                       que justifica el porqué): al imprimir heredan
                       font-size:0.88em del body ya reducido a 11px de
                       arriba y quedaban demasiado pequeñas para leerse
                       bien en papel. Se agrandan un poco aquí (solo en
                       impresión; en pantalla se dejan como estaban). */
                    .notify-comment, .legal-comment { font-size: 0.95em !important; line-height: 1.45 !important; }

                    /* Números de recinto (etiquetas de los recintos de
                       contexto/vecinos) del croquis: a 8px de base se ven
                       casi ilegibles una vez el canvas se reduce a 420px
                       de ancho al imprimir (ver regla .sketch-canvas
                       justo arriba). El factor ~1.35 compensa esa
                       reducción de escala del canvas (560px en pantalla
                       frente a 420px impreso) para que se lean tan bien
                       en papel como en pantalla. */
                    .sketch-context-label, .sketch-context-label-related { font-size: 11px !important; }

                    /* Informe RESUMEN: densidad algo mayor por página, sin
                       partir una ficha entre dos páginas. El croquis usa el
                       mismo tamaño que en el informe ampliado (ver regla
                       .sketch-canvas de más arriba) para que los números
                       sigan siendo legibles también al imprimir. */
                    .resumen-body { page-break-inside: avoid; padding: 0 8px !important; }
                    .resumen-body .legal-comment, .resumen-body .notify-comment {
                        font-size: 0.88em !important; padding: 5px 8px !important; margin-top: 3px !important; line-height: 1.35 !important;
                    }
                }

                /* Filter UI */
                .filter-group { margin-top: 8px; display: flex; flex-wrap: wrap; gap: 8px; }
                .filter-btn { 
                    background: rgba(255,255,255,0.15); border: 1px solid rgba(255,255,255,0.3);
                    color: white; font-size: 0.75em; padding: 4px 8px; border-radius: 4px; 
                    cursor: pointer; transition: 0.2s; user-select: none;
                    display: inline-flex; align-items: center; gap: 4px;
                }
                .filter-btn:hover { background: rgba(255,255,255,0.25); }
                .filter-btn.active { background: var(--accent); border-color: var(--accent); font-weight: bold; }
                .filter-btn.warning-filter { background: rgba(231, 76, 60, 0.4); border-color: #e74c3c; }
                .filter-btn.warning-filter.active { background: #e74c3c; }
                .filter-btn.busy-disabled { pointer-events: none; opacity: 0.55; cursor: wait; }
                .filter-btn .facet-count { font-size: 0.9em; opacity: 0.75; font-weight: normal; }
                .filter-btn.active .facet-count { opacity: 0.9; }
                .filter-btn.facet-zero { opacity: 0.45; }
                /* Icono +/✓ delante de cada opción: refuerza, sin
                   depender solo del color, si al pulsar se añade o se
                   quita el filtro. */
                .filter-btn .facet-icon { display: inline-block; width: 0.9em; opacity: 0.8; }
                .filter-btn .facet-icon::before { content: '+'; }
                .filter-btn.active .facet-icon::before { content: '\2713'; }

                /* Separador "Y" entre categorías de filtros, para dejar a
                   la vista que los grupos se combinan entre sí con Y
                   (mientras que las opciones dentro de un mismo grupo se
                   combinan con O). */
                .facet-category-divider {
                    display: flex; align-items: center; gap: 8px; margin: 2px 0 10px 0;
                    color: rgba(255,255,255,0.45); font-size: 0.65em; font-weight: bold;
                    text-transform: uppercase; letter-spacing: 0.05em;
                }
                .facet-category-divider::before, .facet-category-divider::after {
                    content: ''; flex: 1; border-top: 1px solid rgba(255,255,255,0.15);
                }
                .facet-category-hint {
                    font-size: 0.85em; text-transform: none; letter-spacing: 0; font-weight: normal;
                    color: rgba(255,255,255,0.45); margin-left: 4px;
                }

                /* Resumen en lenguaje natural de qué se está filtrando
                   ahora mismo. Vive fuera del acordeón (junto al botón
                   "Filtros") para que se vea sin necesidad de desplegarlo. */
                .filter-summary-line {
                    display: none; font-size: 0.72em; line-height: 1.4;
                    color: rgba(255,255,255,0.85); padding: 6px 10px 0 10px;
                }
                .filter-summary-line.visible { display: block; }

                /* Filtros por facetas -- acordeón colapsable */
                .facets-container { margin-top: 15px; border: 1px solid rgba(255,255,255,0.25); border-radius: 6px; overflow: hidden; }
                .facets-toggle {
                    width: 100%; display: flex; align-items: center; justify-content: space-between;
                    background: rgba(255,255,255,0.08); border: none; color: white;
                    font-size: 0.8em; font-weight: bold; padding: 8px 10px; cursor: pointer;
                    user-select: none; text-align: left;
                }
                .facets-toggle:hover { background: rgba(255,255,255,0.15); }
                .facets-toggle-badge {
                    background: var(--accent); color: white; font-size: 0.85em; font-weight: bold;
                    padding: 1px 7px; border-radius: 10px; margin-left: 6px;
                }
                .facets-toggle-icon { transition: transform 0.15s ease; margin-left: auto; padding-left: 8px; }
                .facets-container.open .facets-toggle-icon { transform: rotate(180deg); }
                .facets-toggle-left { display: flex; align-items: center; }
                .facets-body { display: none; padding: 10px 10px 4px 10px; max-height: 45vh; overflow-y: auto; overscroll-behavior: contain; }
                .facets-container.open .facets-body { display: block; }
                .facet-category { margin-bottom: 12px; }
                .facet-category:last-child { margin-bottom: 4px; }
                .facet-category-title {
                    font-size: 0.7em; text-transform: uppercase; letter-spacing: 0.04em;
                    color: rgba(255,255,255,0.6); margin-bottom: 5px; font-weight: bold;
                }

                /* Barra de filtros activos */
                .active-filters-bar {
                    display: none; flex-wrap: wrap; align-items: center; gap: 6px;
                    padding: 8px 0 10px 0; margin-bottom: 4px; border-bottom: 1px solid rgba(255,255,255,0.2);
                }
                .active-filters-bar.visible { display: flex; }
                .active-filters-chips { display: flex; flex-wrap: wrap; gap: 6px; flex: 1; }
                .active-filter-chip {
                    display: inline-flex; align-items: center; gap: 5px;
                    background: var(--accent); color: white; font-size: 0.72em;
                    padding: 3px 4px 3px 8px; border-radius: 12px; cursor: default;
                }
                .active-filter-chip .chip-remove {
                    cursor: pointer; font-weight: bold; line-height: 1; padding: 1px 5px;
                    border-radius: 50%; opacity: 0.85;
                }
                .active-filter-chip .chip-remove:hover { opacity: 1; background: rgba(0,0,0,0.2); }
                .clear-filters-btn {
                    background: transparent; border: 1px solid rgba(255,255,255,0.4); color: white;
                    font-size: 0.72em; padding: 3px 8px; border-radius: 4px; cursor: pointer; white-space: nowrap;
                }
                .clear-filters-btn:hover { background: rgba(255,255,255,0.15); }
                @keyframes viales-blink { 0%,100% { background:#fff3cd; color:#856404; font-weight:bold; } 50% { background:#e74c3c; color:#fff; font-weight:bold; } }
                .viales-alert-blink { animation: viales-blink 1.1s ease-in-out infinite; border-radius:3px; padding:1px 3px; }

                /* Indicador de "ocupado" mientras se aplica un filtro/búsqueda */
                .filter-busy-indicator {
                    display: none; align-items: center; gap: 6px; margin-top: 8px;
                    font-size: 0.72em; color: rgba(255,255,255,0.9);
                }
                .filter-busy-indicator.active { display: flex; }
                .filter-spinner {
                    width: 11px; height: 11px; flex-shrink: 0;
                    border: 2px solid rgba(255,255,255,0.35); border-top-color: #fff;
                    border-radius: 50%; animation: filter-spin 0.7s linear infinite;
                }
                @keyframes filter-spin { to { transform: rotate(360deg); } }
                #toc-list.is-filtering, .cards-wrapper.is-filtering { opacity: 0.45; transition: opacity 0.1s ease; pointer-events: none; }
                
                .toc-owner-indicator { 
                    display: inline-block; width: 8px; height: 8px; 
                    background: #ff9800; border-radius: 50%; margin-right: 5px; 
                    box-shadow: 0 0 5px rgba(255,152,0,0.5);
                }

                /* ---- Barra superior de guardado (siempre visible, fija,
                   por encima del scroll) ----
                   Sustituye lo que antes era: banner descartable +
                   botones "Vincular HTML"/"Descargar" repartidos en el
                   panel lateral + toast flotante + estado de vínculo con
                   3 variantes. Ahora es un único sitio, siempre en el
                   mismo lugar: estado de autoguardado a la izquierda,
                   una sola acción primaria (descargar) y "compartir"
                   como desplegable secundario. */
                body { padding-top: 42px; box-sizing: border-box; }
                .annot-topbar {
                    position: fixed; top: 0; left: 0; right: 0; height: 42px; z-index: 1000;
                    display: flex; align-items: center; gap: 12px; padding: 0 16px;
                    background: #16324f; color: #fff; font-size: 0.85em;
                    box-shadow: 0 2px 6px rgba(0,0,0,0.25);
                }
                .annot-topbar-status {
                    flex: 1 1 auto; min-width: 0; overflow: hidden; text-overflow: ellipsis;
                    white-space: nowrap; color: rgba(255,255,255,0.8);
                }
                .annot-topbar-status.saving { color: #ffd479; }
                .annot-topbar-status.saved { color: #a6f3b0; }
                .annot-topbar-status.warn { color: #ff9d8a; }
                .annot-topbar-btn {
                    background: #3498db; border: none; color: #fff; font-weight: bold;
                    font-size: 0.9em; padding: 6px 12px; border-radius: 4px; cursor: pointer; white-space: nowrap;
                }
                .annot-topbar-btn:hover { background: #2d81bf; }
                .annot-share-wrap { position: relative; flex-shrink: 0; }
                .annot-topbar-link {
                    background: none; border: 1px solid rgba(255,255,255,0.4); color: rgba(255,255,255,0.9);
                    font-size: 0.82em; padding: 6px 10px; border-radius: 4px; cursor: pointer; white-space: nowrap;
                }
                .annot-topbar-link:hover { background: rgba(255,255,255,0.12); }
                .annot-share-menu {
                    display: none; flex-direction: column; gap: 6px; position: absolute; top: calc(100% + 6px); right: 0;
                    z-index: 1001; background: #fff; color: #333; border-radius: 6px; padding: 8px; min-width: 240px;
                    box-shadow: 0 4px 14px rgba(0,0,0,0.28);
                }
                .annot-share-menu.open { display: flex; }
                .annot-share-menu button {
                    background: #f0f4f8; border: 1px solid #dfe3e7; color: #333; font-size: 0.78em;
                    padding: 7px 9px; border-radius: 4px; cursor: pointer; text-align: left;
                }
                .annot-share-menu button:hover { background: #e4eaf0; }

                /* Anotaciones de usuario (panel dentro de cada ficha) */
                .user-annot { margin: 14px 16px 4px 16px; border: 1px dashed #c8ccd1; border-radius: 6px; padding: 10px 12px; background: #fbfcfd; }
                .user-annot-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px; }
                .user-annot-header strong { font-size: 0.85em; color: var(--primary); }
                .user-annot-hint { font-size: 0.74em; color: #888; margin-bottom: 8px; }
                .user-annot-hint.diverge { color: #b45309; font-weight: 600; }
                .user-annot-interp { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 8px; }
                .ua-btn { border: 1px solid #ccd2d8; background: white; color: #555; font-size: 0.75em; padding: 4px 8px; border-radius: 4px; cursor: pointer; transition: 0.15s; }
                .ua-btn:hover { background: #f0f4f8; }
                .ua-btn.active { color: white; border-color: transparent; font-weight: bold; }
                .ua-btn.active[data-value=""] { background: #95a5a6; }
                .ua-btn.active.ua-si { background: #27ae60; }
                .ua-btn.active.ua-no { background: #c0392b; }
                .user-annot-comment {
                    width: 100%; box-sizing: border-box; min-height: 44px; resize: vertical;
                    font-family: inherit; font-size: 0.85em; padding: 6px 8px; border: 1px solid #dfe3e7; border-radius: 4px;
                }
                .user-annot-status { margin-top: 6px; font-size: 0.72em; color: #888; }
                .user-annot-status.saved { color: #27ae60; }
                .user-annot-status.pending { color: #e67e22; }
                .user-annot-print-view { display: none; }

                @media print {
                    .user-annot { page-break-inside: avoid; border-style: solid; }
                    .user-annot-interactive { display: none !important; }
                    .user-annot-print-view { display: block !important; font-size: 0.85em; }
                    .user-annot-print-view .ua-print-comment { white-space: pre-wrap; margin-top: 4px; }
                }
        """

    def _timed(self, key, func, *args, **kwargs):
        """Ejecuta func(*args, **kwargs) acumulando el tiempo consumido en
        self._t_acc[key]. Instrumentación temporal para localizar con
        precisión, dentro del bucle de fichas, qué sub-bloque concreto
        (croquis, aditamentos, interpretación legal/dual, islas, flujos,
        fila supfT24, panel de anotaciones...) es el que realmente
        consume el tiempo -- en vez de seguir adivinando a partir del
        tiempo total del bucle."""
        t0 = time.time()
        result = func(*args, **kwargs)
        self._t_acc[key] = self._t_acc.get(key, 0.0) + (time.time() - t0)
        return result

    def _build_html(self, data, thresholds, summary_mode=False, filename="informe_auditoria.html", report_id=None):
        _t_idx0 = time.time()
        matrix = data.get('transition_matrix', [])
        details = data.get('parcel_details', [])
        self._context_geoms_despues = data.get('context_geoms_despues', {})
        self._context_adits = data.get('context_aditamentos', {})
        # Rangos REC (VIALES/CURSOS AGUA/EDIFICACIONES/EXCLUIDO...) tal y
        # como se parametrizaron en la Ficha 2: Mapeo de Campos, para poder
        # distinguir en el croquis los recintos de contexto que son
        # EDIFICACIONES (ver _generate_sketch_svg).
        self._special_ranges = data.get('special_ranges', {})
        # RENDIMIENTO: antes, cada croquis (uno por recinto) recorría TODO
        # el diccionario de contexto (todos los recintos DESPUÉS del
        # proyecto, sin recortar) y TODO el diccionario de aditamentos para
        # filtrar por bounding box "a mano". Con N recintos eso es O(N) por
        # croquis y O(N^2) en total para el informe completo -- el cuello
        # de botella dominante en zonas con muchos cambios (y se pagaba DOS
        # veces: informe ampliado + resumen). Se construye aquí, una única
        # vez por informe, un índice espacial (QgsSpatialIndex) que reduce
        # cada consulta por recinto a O(log N + k), con k = nº de vecinos
        # realmente visibles en el recuadro del croquis.
        self._context_geoms_index, self._context_geoms_ids = self._build_context_geom_index(self._context_geoms_despues)
        self._context_adits_index, self._context_adits_ids = self._build_context_adits_index(self._context_adits)
        self._log(
            f"TIEMPOS [{filename}]: índices de contexto = {time.time() - _t_idx0:.1f}s "
            f"({len(self._context_geoms_despues)} geometrías de contexto, {len(self._context_adits)} recintos con aditamentos)."
        )

        # Las anotaciones del usuario viven embebidas en el propio HTML
        # (cápsula JSON); share_filename es solo el nombre sugerido para el
        # XML ligero de "exportar para compartir" -- un mensajero puntual,
        # nunca la fuente de verdad.
        share_filename = os.path.splitext(filename)[0] + "_respuestas.xml"
        # Identificador estable de ESTA instancia de informe: es la clave
        # con la que el autoguardado (IndexedDB) indexa las respuestas en
        # el navegador, en vez de usar el nombre de archivo (que el usuario
        # puede cambiar libremente al renombrar o descargar copias).
        # Si el llamante pasa un report_id (p.ej. para que el informe
        # ampliado y el resumen generados en la misma pasada compartan
        # anotaciones), se reutiliza tal cual; si no, se genera uno nuevo.
        if not report_id:
            report_id = str(uuid.uuid4())
        try:
            project_crs = QgsProject.instance().crs().authid()
        except Exception:
            project_crs = ''
        annot_script = self._render_annotations_script(filename, share_filename, len(details), report_id, project_crs=project_crs)
        
        # Totales KPI
        total_area = sum(m['area'] for m in matrix)
        total_bajas = sum(m['area'] for m in matrix if m['type'] == 'BAJA')
        
        # Definir tipos de fachada fijos
        fixed_facade_types = ['VIALES', 'CURSOS AGUA', 'EDIFICACIONES', 'EXCLUIDO']

        html = f"""
        <!DOCTYPE html>
        <html lang="es">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>{"Fichas de Auditoría por Recinto (Resumen)" if summary_mode else "Fichas de Auditoría por Recinto"}</title>
            <style>
{self._report_css()}
            </style>
        </head>
        <body>
            <!--AUDINOT_USER_DATA_START-->
            <script type="application/json" id="audinot-user-data">{{}}</script>
            <!--AUDINOT_USER_DATA_END-->
            <div class="annot-topbar" id="annot-topbar" role="status">
                <span class="annot-topbar-status" id="annot-save-status">Autoguardado activado en este navegador</span>
                <button type="button" class="annot-topbar-btn" id="annot-download-btn" title="Descarga una copia completa de este HTML con tus respuestas actuales">⬇ Descargar mis respuestas</button>
                <div class="annot-share-wrap">
                    <button type="button" class="annot-topbar-link" id="annot-share-toggle" aria-haspopup="true" aria-expanded="false">Compartir con otra persona ▾</button>
                    <div class="annot-share-menu" id="annot-share-menu">
                        <button type="button" id="annot-export-btn" title="Genera un XML ligero solo con las respuestas de este usuario, para enviarlo a otra persona">📤 Generar XML para compartir</button>
                        <button type="button" id="annot-import-btn" title="Importa un XML de respuestas recibido de otra persona y lo fusiona en este HTML">📥 Importar respuestas compartidas</button>
                        <input type="file" id="annot-import-input" accept=".xml,text/xml" style="display:none">
                    </div>
                </div>
            </div>
            <div class="sidebar">
                <div class="sidebar-header">
                    <h3 style="margin:0">Índice de Recintos</h3>
                    <small id="parcel-count">{len(details)} Recintos</small>
                    <div class="review-progress" id="review-progress" title="Recintos con revisión del usuario guardada (confirmados o corregidos)">
                        <span class="review-progress-text" id="review-progress-text">0 de {len(details)} recintos revisados</span>
                        <div class="review-progress-bar"><div class="review-progress-fill" id="review-progress-fill"></div></div>
                    </div>
                    <div class="search-container">
                        <input type="text" class="search-box" id="search-box" placeholder="🔍 Buscar recinto..." />
                        <button class="clear-btn" id="clear-btn" title="Limpiar búsqueda">&times;</button>
                    </div>
                    <div class="search-container">
                        <input type="text" class="search-box" id="owner-search-box" placeholder="🔍 Buscar propietario..." />
                        <button class="clear-btn" id="owner-clear-btn" title="Limpiar búsqueda de propietario">&times;</button>
                    </div>
                    <div class="facets-container" id="facets-container">
                        <button type="button" class="facets-toggle" id="facets-toggle" aria-expanded="false">
                            <span class="facets-toggle-left">Filtros<span class="facets-toggle-badge" id="facets-toggle-badge" style="display:none">0 activos</span></span>
                            <span class="facets-toggle-icon">▾</span>
                        </button>
                        <div class="filter-summary-line" id="filter-summary-line"></div>
                        <div class="facets-body" id="facets-body">
                            <div class="active-filters-bar" id="active-filters-bar">
                                <div class="active-filters-chips" id="active-filters-chips"></div>
                                <button type="button" class="clear-filters-btn" id="clear-filters-btn">Limpiar filtros</button>
                            </div>
                            <div class="facet-category">
                                <div class="facet-category-title">Estado<span class="facet-category-hint">elige una o varias</span></div>
                                <div class="filter-group">
                                    <div class="filter-btn facet-btn" data-category="estado" data-filter="ALTA" data-label="Nueva"><span class="facet-icon"></span>NUEVA <span class="facet-count"></span></div>
                                    <div class="filter-btn facet-btn" data-category="estado" data-filter="BAJA" data-label="Desaparece"><span class="facet-icon"></span>DESAPARECE <span class="facet-count"></span></div>
                                    <div class="filter-btn facet-btn" data-category="estado" data-filter="PERSISTENTE" data-label="Persistente"><span class="facet-icon"></span>PERSISTENTE <span class="facet-count"></span></div>
                                </div>
                            </div>
                            <div class="facet-category-divider">Y</div>
                            <div class="facet-category">
                                <div class="facet-category-title">Notificación<span class="facet-category-hint">elige una o varias</span></div>
                                <div class="filter-group">
                                    <div class="filter-btn facet-btn warning-filter" data-category="notificacion" data-filter="NOTIFY" data-label="Paramétrica"><span class="facet-icon"></span>⚠ PARAMÉTRICA <span class="facet-count"></span></div>
                                    <div class="filter-btn facet-btn warning-filter" data-category="notificacion" data-filter="LEGAL_NOTIFY" data-label="Alternativa"><span class="facet-icon"></span>⚠ ALTERNATIVA <span class="facet-count"></span></div>
                                    <div class="filter-btn facet-btn warning-filter" data-category="notificacion" data-filter="DIVERGE" data-label="Divergen" title="La interpretación paramétrica y la alternativa no coinciden en si procede notificar"><span class="facet-icon"></span>⚠ DIVERGEN <span class="facet-count"></span></div>
                                    <div class="filter-btn facet-btn" data-category="notificacion" data-filter="NOTIFY_AGREE" data-label="Coinciden" title="Ambas interpretaciones, paramétrica y alternativa, coinciden en que procede notificar"><span class="facet-icon"></span>COINCIDEN <span class="facet-count"></span></div>
                                </div>
                            </div>
                            <div class="facet-category-divider">Y</div>
                            <div class="facet-category">
                                <div class="facet-category-title">Titular<span class="facet-category-hint">elige una o varias</span></div>
                                <div class="filter-group">
                                    <div class="filter-btn facet-btn" data-category="titular" data-filter="OWNER_CHANGE" data-label="Cambio de titular"><span class="facet-icon"></span>CAMBIO TITULAR <span class="facet-count"></span></div>
                                </div>
                            </div>
                            <div class="facet-category-divider">Y</div>
                            <div class="facet-category">
                                <div class="facet-category-title">Precisión de superficie<span class="facet-category-hint">vs. dato oficial de referencia</span></div>
                                <div class="filter-group">
                                    <div class="filter-btn facet-btn warning-filter" data-category="t24" data-filter="T24_INVALID_AFTER" data-label="Fuera de tolerancia" title="La desviación de la superficie respecto al dato oficial de referencia (campo supfT24) supera el umbral '% Validación' en Después, sin importar si validaba o no en Antes. Incluye 'Empeora la precisión'."><span class="facet-icon"></span>⚠ FUERA DE TOLERANCIA <span class="facet-count"></span></div>
                                    <div class="filter-btn facet-btn warning-filter" data-category="t24" data-filter="T24_WORSE" data-label="Empeora la precisión" title="Subconjunto de 'Fuera de tolerancia': la desviación estaba dentro del umbral en Antes y deja de estarlo en Después. Los recintos sin dato de referencia (supfT24) en Antes o Después no cuentan como válidos y no entran en este filtro."><span class="facet-icon"></span>⚠ EMPEORA LA PRECISIÓN <span class="facet-count"></span></div>
                                    <div class="filter-btn facet-btn" data-category="t24" data-filter="T24_BETTER" data-label="Mejora la precisión" title="La desviación no estaba dentro del umbral en Antes y pasa a estarlo en Después: recintos donde la desviación se corrige."><span class="facet-icon"></span>MEJORA LA PRECISIÓN <span class="facet-count"></span></div>
                                    <div class="filter-btn facet-btn" data-category="t24" data-filter="T24_UNKNOWN" data-label="Sin dato de referencia" title="Al menos uno de los dos (Antes o Después) no tiene un valor de referencia (supfT24) calculable, así que no se puede comprobar la precisión."><span class="facet-icon"></span>SIN DATO DE REFERENCIA <span class="facet-count"></span></div>
                                </div>
                            </div>
                            <div class="facet-category-divider">Y</div>
                            <div class="facet-category">
                                <div class="facet-category-title">Validación<span class="facet-category-hint">%VALIDACION o %GML</span></div>
                                <div class="filter-group">
                                    <div class="filter-btn facet-btn warning-filter" data-category="validacion" data-filter="VALID_WORSE" data-label="Antes validaba, después no" title="Validaba en Antes (%VALIDACION dentro del umbral) y deja de validar en Después, ya sea por %VALIDACION o por %GML (basta con que falle uno de los dos)."><span class="facet-icon"></span>⚠ ANTES VALIDABA, DESPUÉS NO <span class="facet-count"></span></div>
                                    <div class="filter-btn facet-btn warning-filter" data-category="validacion" data-filter="VALID_INVALID_AFTER" data-label="No valida en después" title="No valida en Después por %VALIDACION o por %GML (o ambos), sin importar si validaba o no en Antes."><span class="facet-icon"></span>⚠ NO VALIDA EN DESPUÉS <span class="facet-count"></span></div>
                                    <div class="filter-btn facet-btn" data-category="validacion" data-filter="VALID_BETTER" data-label="Antes no validaba, después sí" title="No validaba en Antes y pasa a validar en Después, tanto por %VALIDACION como por %GML (hace falta que no falle ninguno de los dos): recintos donde la validación se corrige."><span class="facet-icon"></span>ANTES NO VALIDABA, DESPUÉS SÍ <span class="facet-count"></span></div>
                                </div>
                            </div>
                            <div class="facet-category-divider">Y</div>
                            <div class="facet-category">
                                <div class="facet-category-title">Usuario<span class="facet-category-hint">revisión manual del recinto</span></div>
                                <div class="filter-group">
                                    <div class="filter-btn facet-btn" data-category="usuario" data-filter="USER_NOTIFY" data-label="Marcado para notificar" title="El usuario ha revisado la ficha y ha marcado explícitamente que SÍ procede notificar."><span class="facet-icon"></span>MARCADO PARA NOTIFICAR <span class="facet-count"></span></div>
                                    <div class="filter-btn facet-btn" data-category="usuario" data-filter="USER_NO_NOTIFY" data-label="Marcado para no notificar" title="El usuario ha revisado la ficha y ha marcado explícitamente que NO procede notificar."><span class="facet-icon"></span>MARCADO PARA NO NOTIFICAR <span class="facet-count"></span></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="filter-busy-indicator" id="filter-busy-indicator">
                        <span class="filter-spinner"></span> Filtrando…
                    </div>
                </div>
                <ul class="toc-list" id="toc-list">
        """
        
        # Generar TOC y Cards
        def sort_key(d):
            try:
                s = d['id'].replace('-', '/').split('/')
                nums = []
                for p in s:
                    try: nums.append(int(p))
                    except: nums.append(0)
                return tuple(nums)
            except:
                return (0,)
                
        sorted_details = sorted(details, key=sort_key)
        
        # RENDIMIENTO: acumular en listas y unir con "".join() al final,
        # en vez de "toc_html += ..." / "cards_html += ..." dentro del
        # bucle. Con ~2175 recintos y cards de ~50 KB cada una, el patrón
        # "+=" reasigna y copia la cadena completa en cada iteración
        # cuando CPython no puede optimizar la concatenación en sitio (algo
        # que depende del refcount del objeto string y que se pierde con
        # facilidad en el intérprete embebido de QGIS) -- degenerando en
        # O(N^2) y explicando el ~96% del tiempo del bucle no cubierto por
        # los sub-bloques instrumentados en _t_acc. join() es O(N).
        toc_html_parts = []
        cards_html_parts = []
        _t_cards0 = time.time()
        self._t_acc = {}
        
        for d in sorted_details:
            st = d['state']
            
            # Flags de notificación para esta parcela
            notify = False
            notify_reasons = []  # Fragmentos de prosa para el comentario final de la finca
            
            # --- CHECK THRESHOLDS ---
            
            # 1. Geometría
            area_d = d.get('area_final', 0)
            delta_area = d.get('delta_area', 0)
            area_a = area_d - delta_area if st != 'BAJA' else abs(delta_area)
            pct_area = self._get_pct(area_a, area_d)

            # Filtro "Validación T24": mismo cálculo que la fila
            # informativa supfT24 vs. GML, clasificado para poder
            # filtrar por "empeora" / "mejora" / "sin dato" en el TOC.
            t24_flags = self._t24_filter_flags(d.get('supft24_a'), d.get('supft24_d'), area_a, area_d, thresholds)

            # Filtro "Validación": igual que el T24 pero combinando
            # también el % GML (superficie truncada a 2 decimales) como
            # criterio adicional de "no valida en Después".
            validacion_flags = self._validacion_filter_flags(d.get('supft24_a'), d.get('supft24_d'), area_a, area_d, thresholds, geom_d=d.get('geom_d'))

            
            m_a_abs = self._chk(delta_area, thresholds.get('area_abs'))
            m_a_pct = self._chk(pct_area, thresholds.get('area_pct'))
            
            perim_a = d.get('perim_a', 0); perim_d = d.get('perim_d', 0)
            delta_perim = d.get('delta_perim', 0)
            pct_perim = self._get_pct(perim_a, perim_d)
            
            m_p_abs = self._chk(delta_perim, thresholds.get('perim_abs'))
            m_p_pct = self._chk(pct_perim, thresholds.get('perim_pct'))
            
            grav_a = d.get('grav_a', 0); grav_d = d.get('grav_d', 0)
            grav_delta = d.get('delta_grav', 0)
            pct_grav = self._get_pct(grav_a, grav_d)
            m_g_pct = self._chk(grav_delta, thresholds.get('gravelius')) # Gravelius now checks delta, not absolute value
            
            convex_a = d.get('convex_a', 1.0)
            convex_d = d.get('convex_d', 1.0)
            delta_convex = convex_d - convex_a
            pct_convex = self._get_pct(convex_a, convex_d)
            m_c_abs = self._chk(delta_convex, thresholds.get('convexity_abs'))
            m_c_pct = self._chk(pct_convex, thresholds.get('convexity_pct'))

            stability_pct = d.get('stability_pct', 100.0)
            m_stab = self._chk_neg(stability_pct, thresholds.get('stability_pct'))

            displacement = d.get('displacement', 0.0)
            displacement_dir = d.get('displacement_dir', '-')
            m_desp = self._chk(displacement, thresholds.get('desp_max'))
            
            hole_area_a = d.get('hole_area_a', 0.0)
            delta_hole_area = d.get('delta_hole_area', 0.0)
            pct_rings_area = self._get_pct(hole_area_a, d.get('hole_area_d', 0.0))
            m_inv = self._chk(pct_rings_area, thresholds.get('invasion_pct')) # Huecos pct

            # Acumular alertas geométricas
            delta_parts = d.get('parts_d', 1) - d.get('parts_a', 1)
            isl_deltas = d.get('islands')
            delta_isl_cnt = isl_deltas['delta_count'] if isl_deltas else 0
            
            if m_a_abs or m_a_pct or m_p_abs or m_p_pct or m_g_pct or m_inv or m_desp or m_c_abs or m_c_pct or m_stab or delta_parts != 0 or delta_isl_cnt != 0:
                notify = True

            if m_a_abs or m_a_pct:
                notify_reasons.append({
                    'mag': abs(pct_area),
                    'text': f"la superficie varía {delta_area:+.1f} m² ({pct_area:+.1f}%)"
                })
            if m_stab:
                notify_reasons.append({
                    'mag': 100.0 - stability_pct + 50,  # priorizar fuerte: linde es indicio clave
                    'text': f"el lindero exterior solo se mantiene estable en un {stability_pct:.1f}% de su trazado respecto a la situación anterior"
                })
            if m_p_abs or m_p_pct:
                notify_reasons.append({
                    'mag': abs(pct_perim),
                    'text': f"el perímetro cambia {delta_perim:+.1f} m ({pct_perim:+.1f}%)"
                })
            if m_c_abs or m_c_pct or m_g_pct:
                notify_reasons.append({
                    'mag': abs(pct_convex) + abs(pct_grav),
                    'text': "la forma de la parcela se ha modificado de manera apreciable (convexidad/compacidad)"
                })
            if m_desp:
                notify_reasons.append({
                    'mag': displacement,
                    'text': f"el centroide se ha desplazado {displacement:.1f} m hacia el {displacement_dir}"
                })
            if delta_parts != 0:
                notify_reasons.append({
                    'mag': abs(delta_parts) * 20,
                    'text': f"la parcela pasa de {d.get('parts_a',1)} a {d.get('parts_d',1)} partes, es decir, {'se fragmenta' if delta_parts > 0 else 'se unifica'}"
                })
            if delta_isl_cnt != 0:
                _cnt_a = isl_deltas.get('count_a', 0) if isl_deltas else 0
                _cnt_d = isl_deltas.get('count_d', 0) if isl_deltas else 0
                notify_reasons.append({
                    'mag': abs(delta_isl_cnt) * 15,
                    'text': f"el número de huecos/islas interiores pasa de {_cnt_a} a {_cnt_d} ({'+' if delta_isl_cnt>0 else ''}{delta_isl_cnt})"
                })
            if m_inv:
                _isl_area_a = isl_deltas.get('area_a', hole_area_a) if isl_deltas else hole_area_a
                _isl_area_d = isl_deltas.get('area_d', d.get('hole_area_d', 0.0)) if isl_deltas else d.get('hole_area_d', 0.0)
                notify_reasons.append({
                    'mag': abs(pct_rings_area),
                    'text': f"el área de los huecos interiores pasa de {self._fmt_val(_isl_area_a)} m² a {self._fmt_val(_isl_area_d)} m² (variación de {delta_hole_area:+.1f} m², {pct_rings_area:+.1f}%)"
                })

            # 2. Fachadas
            # Pre-calcular colindantes para la condicion de parpadeo de Viales
            _neigh_a_pre = d.get('neighbors_a', 0)
            _neigh_d_pre = d.get('neighbors_d', 0)
            _neigh_delta_pre = _neigh_d_pre - _neigh_a_pre

            facade_rows_html = ""
            facade_labels = {'VIALES': 'Viales', 'CURSOS AGUA': 'AGUAS', 'EDIFICACIONES': 'EDIF', 'EXCLUIDO': 'EXCL'}
            facade_legal = []  # Datos por fachada para la interpretación legal (régimen LMETAGA)
            
            for t_code in fixed_facade_types:
                val_a = d.get(f'facade_antes_{t_code}', 0.0)
                val_d = d.get(f'facade_desp_{t_code}', 0.0)
                delta = val_d - val_a
                pct = self._get_pct(val_a, val_d)
                cls = "text-pos" if delta > 0.01 else "text-neg" if delta < -0.01 else ""
                label = facade_labels.get(t_code, t_code)

                # Parpadeo en etiqueta Viales: variacion relativa en torno al doble (>=80%) + colindantes aumentan
                _VIALES_BLINK_PCT = 80.0  # umbral: variacion relativa >= 80% (entorno al doble)
                _viales_blink = ""
                if t_code == 'VIALES' and _neigh_delta_pre > 0:
                    _pct_v = abs(self._get_pct(val_a, val_d)) if val_a > 0 else (100.0 if val_d > 0 else 0.0)
                    if _pct_v >= _VIALES_BLINK_PCT:
                        _viales_blink = " viales-alert-blink"

                # Check thresholds
                f_lims = thresholds.get('facades', {})
                f_key = 'VIAL' if 'VIAL' in t_code else 'AGUA' if 'AGUA' in t_code else 'EDIF' if 'EDIF' in t_code else 'EXCL'
                lims = f_lims.get(f_key, {})
                
                # Restauración Senior: Variación relativa simple como en el resto de métricas
                pct = self._get_pct(val_a, val_d)
                
                m_f_abs = self._chk(delta, lims.get('abs'))
                m_f_pct = self._chk(pct, lims.get('pct'))
                
                if m_f_abs or m_f_pct: notify = True
                
                if m_f_abs or m_f_pct:
                    notify_reasons.append({
                        'mag': abs(pct) if val_a > 0 else (100.0 if val_d > 0 else 0.0),
                        'text': f"la fachada a {label.lower()} varía {delta:+.1f} m ({pct:+.1f}%)"
                    })

                facade_legal.append({
                    'label': label, 'delta': delta, 'pct': pct,
                    'm_abs': bool(m_f_abs), 'm_pct': bool(m_f_pct)
                })
                
                facade_rows_html += f"""
                    <tr>
                        <td class="{_viales_blink.strip()}">{label} (m)</td>
                        <td class="val-num">{self._fmt_val(val_a)}</td>
                        <td class="val-num">{self._fmt_val(val_d)}</td>
                        <td class="val-num {cls} {'diff-nonzero' if abs(delta) > 0.001 else ''}">{self._fmt_diff(delta)}</td>
                        <td class="mark-slot">{m_f_abs}</td>
                        <td class="val-num {cls} {'diff-nonzero' if abs(delta) > 0.001 else ''}">{self._fmt_pct(pct)}</td>
                        <td class="mark-slot">{m_f_pct}</td>
                    </tr>
                """
            
            # --- CONTEO DE COLINDANTES (Senior 15+ PRO) ---
            neigh_a = d.get('neighbors_a', 0)
            neigh_d = d.get('neighbors_d', 0)
            neigh_delta = neigh_d - neigh_a
            m_neigh = " *" if neigh_delta != 0 else ""
            pct_neigh = self._get_pct(neigh_a, neigh_d)
            m_n_pct = self._chk(pct_neigh, thresholds.get('neigh_pct'))
            
            facade_rows_html += f"""
                <tr>
                    <td>No. Colindantes (n)</td>
                    <td class="val-num">{self._fmt_val(neigh_a, force_int=True)}</td>
                    <td class="val-num">{self._fmt_val(neigh_d, force_int=True)}</td>
                    <td class="val-num {'diff-nonzero' if neigh_delta != 0 else ''}">{self._fmt_diff(neigh_delta, force_int=True)}</td>
                    <td class="mark-slot">{m_neigh}</td>
                    <td class="val-num {'diff-nonzero' if neigh_delta != 0 else ''}">{self._fmt_pct(pct_neigh)}</td>
                    <td class="mark-slot">{m_n_pct}</td>
                </tr>
            """

            # --- PILLAR SCORING (Peak Normalization G-I-F-A) ---
            adit_content_html, adit_alerts, adit_total = self._timed('adit_table', self._generate_adit_table_rows, d, thresholds)
            
            # 1. Contar alertas por categoría
            g_alerts = 0
            if m_a_abs or m_a_pct: g_alerts += 1
            if m_p_abs or m_p_pct: g_alerts += 1
            if m_g_pct: g_alerts += 1
            if m_c_abs or m_c_pct: g_alerts += 1
            if m_stab: g_alerts += 1
            if m_desp: g_alerts += 1
            if delta_parts != 0: g_alerts += 1
            
            i_alerts = 0
            if delta_isl_cnt != 0: i_alerts += 1
            if m_inv: i_alerts += 1
            if isl_deltas and (abs(isl_deltas.get('delta_area',0)) > 0.1 or isl_deltas.get('displacement',0) > 0.05):
                i_alerts += 1

            f_alerts = 0
            f_lims = thresholds.get('facades', {})
            for tc in ['VIALES', 'CURSOS AGUA', 'EDIFICACIONES', 'EXCLUIDO']:
                fk = 'VIAL' if 'VIAL' in tc else 'AGUA' if 'AGUA' in tc else 'EDIF' if 'EDIF' in tc else 'EXCL'
                lims = f_lims.get(fk, {})
                v_a = d.get(f'facade_antes_{tc}', 0.0)
                v_d = d.get(f'facade_desp_{tc}', 0.0)
                if self._chk(v_d - v_a, lims.get('abs')) or self._chk(self._get_pct(v_a, v_d), lims.get('pct')):
                    f_alerts += 1
            
            a_alerts = adit_alerts
            adit_reason_objs = self._collect_adit_alert_reasons(d, thresholds) if a_alerts > 0 else []
            if a_alerts > 0: notify = True # Alerta técnica activa notificación
            if a_alerts > 0:
                notify_reasons.extend(adit_reason_objs)
            
            # 2. Normalizar sobre 100 (El máximo aporte es el techo)
            max_a = max(g_alerts, i_alerts, f_alerts, a_alerts)
            W = 100.0 / max_a if max_a > 0 else 0
            
            pillar_scores = {
                'G': g_alerts * W,
                'I': i_alerts * W,
                'F': f_alerts * W,
                'A': a_alerts * W
            }

            adit_html = self._generate_adit_section_layout(adit_content_html, pillar_scores)

            # --- FIN CHECKS ---

            state_labels = {'ALTA': 'NUEVA', 'BAJA': 'DESAPARECE', 'PERSISTENTE': 'PERSISTENTE'}
            display_st = state_labels.get(st, st)
            letter = display_st[0]
            bg = "#27ae60" if st == 'PERSISTENTE' else "#c0392b" if st == 'BAJA' else "#2980b9" if st == 'ALTA' else "#f39c12"
            anchor_id = d['id'].replace('/', '_')
            
            owner_changed = d.get('owner_changed', False)
            if owner_changed and st == 'PERSISTENTE': 
                notify = True # Cambio de titular también es alerta
                notify_reasons.append({
                    'mag': 200,  # un cambio de titular es siempre lo más relevante a comentar
                    'text': f"cambia el titular registral (de {d.get('prop_a','N/A')} a {d.get('prop_d','N/A')})"
                })

            # Etiquetas de titular (con denominación de propietario especial
            # si procede) y texto de búsqueda por propietario, calculados
            # ya aquí porque el TOC (más abajo) también los necesita.
            special_owners = data.get('special_owners', {})
            p_a = self._format_owner_label(d.get('prop_a', 'N/A'), special_owners)
            p_d = self._format_owner_label(d.get('prop_d', 'N/A'), special_owners)
            owner_search_attr = html_lib.escape(f"{p_a} {p_d}".lower(), quote=True)

            # --- INTERPRETACIÓN LEGAL (segunda lectura de los mismos parámetros, ---
            # --- clasificados por régimen legal en vez de por magnitud pura) ---
            legal_result = self._timed('legal_interp', self._legal_interpretation,
                st=st,
                delta_parts=delta_parts, parts_a=d.get('parts_a', 1), parts_d=d.get('parts_d', 1),
                delta_isl_cnt=delta_isl_cnt, isl_deltas=isl_deltas,
                owner_changed=(owner_changed and st == 'PERSISTENTE'),
                prop_a=d.get('prop_a', 'N/A'), prop_d=d.get('prop_d', 'N/A'),
                delta_area=delta_area, pct_area=pct_area, m_a_abs=bool(m_a_abs), m_a_pct=bool(m_a_pct),
                facade_legal=facade_legal,
                m_p_abs=bool(m_p_abs), m_p_pct=bool(m_p_pct), delta_perim=delta_perim, pct_perim=pct_perim,
                m_g_pct=bool(m_g_pct), pct_grav=pct_grav,
                m_c_abs=bool(m_c_abs), m_c_pct=bool(m_c_pct),
                m_desp=bool(m_desp), displacement=displacement, displacement_dir=displacement_dir,
                m_stab=bool(m_stab), stability_pct=stability_pct,
                m_inv=bool(m_inv), pct_rings_area=pct_rings_area, delta_hole_area=delta_hole_area,
                adit_reason_objs=adit_reason_objs,
            )

            # TOC Item
            legal_notify = bool(legal_result and legal_result.get('notify'))
            diverge_notify = notify != legal_notify
            agree_notify = notify and legal_notify
            warn_icon = '<span class="toc-warning">!</span>' if notify else ""
            badge_html = f'<span class="toc-badge" style="background:{bg}; float:right">{letter}</span>' if st != 'PERSISTENTE' else ""
            
            toc_html_parts.append(f"""
                    <li class="toc-item" data-state="{st}" data-owner-changed="{'true' if owner_changed else 'false'}" data-notify="{'true' if notify else 'false'}" data-legal-notify="{'true' if legal_notify else 'false'}" data-diverge="{'true' if diverge_notify else 'false'}" data-notify-agree="{'true' if agree_notify else 'false'}" data-t24-worse="{'true' if t24_flags['worse'] else 'false'}" data-t24-better="{'true' if t24_flags['better'] else 'false'}" data-t24-unknown="{'true' if t24_flags['unknown'] else 'false'}" data-t24-invalid-after="{'true' if t24_flags['invalid_after'] else 'false'}" data-validacion-worse="{'true' if validacion_flags['worse'] else 'false'}" data-validacion-better="{'true' if validacion_flags['better'] else 'false'}" data-validacion-unknown="{'true' if validacion_flags['unknown'] else 'false'}" data-validacion-invalid-after="{'true' if validacion_flags['invalid_after'] else 'false'}" data-owner="{owner_search_attr}" data-recinto="{html_lib.escape(str(d['id']), quote=True)}">
                        <a href="#id-{anchor_id}" class="toc-link">
                            <span class="toc-icons">
                                <span class="toc-semaforo sem-pendiente" title="Sin revisar"></span>
                                <span class="toc-interp-icon" title=""></span>
                                <span class="toc-comment-icon" title=""></span>
                            </span>{warn_icon}{d['id']}
                            {badge_html}
                        </a>
                    </li>
            """)
            
            # Card HEADER
            param_value_html = '<span class="notif-value si">SI</span>' if notify else '<span class="notif-value no">NO</span>'
            legal_value_html = '<span class="notif-value si">SI</span>' if legal_notify else '<span class="notif-value no">NO</span>'
            alert_label = f'<span class="notif-status"><span class="notif-label-text">Paramétrica?:</span>{param_value_html}</span>'
            legal_label = f'<span class="notif-status"><span class="notif-label-text">Alternativa?:</span>{legal_value_html}</span>'
            
            # Owner display
            owner_display = f'<span style="color:red; font-weight:bold">Titular: {p_a} → {p_d}</span>' if owner_changed else f'<span style="color:#7f8c8d">Titular: {p_d}</span>'
            if st == 'ALTA': owner_display = f'<span>Titular: (Nuevo) → {p_d}</span>'
            if st == 'BAJA': owner_display = f'<span>Titular: {p_a} → (Baja)</span>'

            # Metric Formatters
            diff_area_fmt = f"{delta_area:+.2f}"
            cls_area = "text-pos" if delta_area > 0 else "text-neg" if delta_area < 0 else ""
            card_border_cls = "alert-border" if notify else ""

            parts_a = d.get('parts_a', 1); parts_d = d.get('parts_d', 1); delta_parts = parts_d - parts_a
            pct_parts = (delta_parts / parts_a * 100) if parts_a else 0
            
            grav_a = d.get('grav_a', 0); grav_d = d.get('grav_d', 0); grav_delta = d.get('delta_grav', 0)
            pct_grav = (grav_delta / grav_a * 100) if grav_a else 0
            
            rings_a = d.get('rings_a', 0); rings_d = d.get('rings_d', 0); rings_delta = d.get('delta_rings', 0)
            pct_rings = (rings_delta / rings_a * 100) if rings_a else 0

            topo_label = "Mono-parte" if parts_d <= 1 else f"Multi-parte: {parts_d} partes"
            
            # Cuerpo de la ficha: difiere entre el informe ampliado (todas las
            # métricas) y el informe resumen (sin métricas ni auditoría de
            # aditamentos). El resumen replica el mismo orden vertical que el
            # informe de auditoría gráfica completo: interpretación por
            # parámetros (fila 1), interpretación alternativa (fila 2) y,
            # debajo, el croquis a tamaño completo con su leyenda a la
            # derecha (igual que en el informe ampliado, sin encogerlo en
            # una rejilla 2x2 que dejaba los números ilegibles).
            #
            # RENDIMIENTO: _render_dual_interpretation(split=True) y su
            # variante combinada (split=False) hacen EXACTAMENTE el mismo
            # cálculo (_generate_notify_comment / _format_flow_list /
            # _render_legal_interpretation) -- solo cambia si se devuelve
            # como tupla o como un único div ya envuelto. Antes se llamaba
            # dos veces por ficha (una para mostrarla, otra más abajo para
            # la cápsula de anotaciones). Se calcula aquí UNA sola vez con
            # split=True y se reconstruye el bloque combinado a partir de
            # las dos partes cuando hace falta, en vez de recalcular.
            dual_param_block, dual_legal_block = self._timed('dual_interp', self._render_dual_interpretation,
                notify_reasons, st, d, data.get('special_ranges', {}), legal_result, notify, split=True
            )
            if summary_mode:
                interp_html = f'<div class="dual-interpretation">{dual_param_block}{dual_legal_block}</div>'
                sketch_html = self._timed('sketch', self._generate_sketch_svg, d, thresholds, summary_mode=True)
                card_body_html = f"""
                    <div class="resumen-body">
                        {interp_html}
                        {sketch_html}
                    </div>
                """
            else:
                islands_html = self._timed('islands', self._render_islands_section, d.get('islands'), thresholds)
                flows_in_html = self._timed('flows', self._render_flows, d.get('inputs', []), st, 'ALTA', data.get('special_owners', {}), 'input')
                flows_out_html = self._timed('flows', self._render_flows, d.get('outputs', []), st, 'BAJA', data.get('special_owners', {}), 'output')
                dual_interp_full_html = f'<div class="dual-interpretation">{dual_param_block}{dual_legal_block}</div>'
                sketch_full_html = self._timed('sketch', self._generate_sketch_svg, d, thresholds)
                card_body_html = f"""
                    <div class="grid-panels">
                        <div class="panel">
                            <div class="panel-title">MÉTRICAS GEOMÉTRICAS ({topo_label})</div>
                            <table class="mini-table">
                                <colgroup>
                                    <col style="width: 35%"><col style="width: 15%"><col style="width: 15%"><col style="width: 12%"><col style="width: 14px"><col style="width: 12%"><col style="width: 14px">
                                </colgroup>
                                <tr><th>Parámetro</th><th class="num-col">Antes</th><th class="num-col">Después</th><th class="num-col">Var</th><th></th><th class="num-col">%</th><th></th></tr>
                                <tr>
                                    <td>Superficie (m²)</td>
                                    <td class="val-num">{self._fmt_val(area_a)}</td>
                                    <td class="val-num">{self._fmt_val(area_d)}</td>
                                    <td class="val-num {cls_area} {'diff-nonzero' if abs(delta_area) > 0.001 else ''}">{self._fmt_diff(delta_area)}</td>
                                    <td class="mark-slot">{m_a_abs}</td>
                                    <td class="val-num {cls_area} {'diff-nonzero' if abs(delta_area) > 0.001 else ''}">{self._fmt_pct(pct_area)}</td>
                                    <td class="mark-slot">{m_a_pct}</td>
                                </tr>
                                <tr>
                                    <td>Perímetro (m)</td>
                                    <td class="val-num">{self._fmt_val(perim_a)}</td>
                                    <td class="val-num">{self._fmt_val(perim_d)}</td>
                                    <td class="val-num {cls_area} {'diff-nonzero' if abs(delta_perim) > 0.001 else ''}">{self._fmt_diff(delta_perim)}</td>
                                    <td class="mark-slot">{m_p_abs}</td>
                                    <td class="val-num {cls_area} {'diff-nonzero' if abs(delta_perim) > 0.001 else ''}">{self._fmt_pct(pct_perim)}</td>
                                    <td class="mark-slot">{m_p_pct}</td>
                                </tr>
                                <tr>
                                    <td>Ancho Gravelius (K)</td>
                                    <td class="val-num">{self._fmt_val(grav_a)}</td>
                                    <td class="val-num">{self._fmt_val(grav_d)}</td>
                                    <td class="val-num {'diff-nonzero' if abs(grav_delta) > 0.001 else ''}">{self._fmt_diff(grav_delta)}</td>
                                    <td class="mark-slot">{m_g_pct}</td>
                                    <td class="val-num {'diff-nonzero' if abs(grav_delta) > 0.001 else ''}">{self._fmt_pct(pct_grav)}</td>
                                    <td class="mark-slot">{m_g_pct}</td>
                                </tr>
                                <tr>
                                    <td>Índice Convexidad</td>
                                    <td class="val-num">{self._fmt_val(d.get('convex_a', 1.0))}</td>
                                    <td class="val-num">{self._fmt_val(d.get('convex_d', 1.0))}</td>
                                    <td class="val-num {'diff-nonzero' if abs(delta_convex) > 0.001 else ''}">{self._fmt_diff(delta_convex)}</td>
                                    <td class="mark-slot">{m_c_abs}</td>
                                    <td class="val-num {'diff-nonzero' if abs(delta_convex) > 0.001 else ''}">{self._fmt_pct(pct_convex)}</td>
                                    <td class="mark-slot">{m_c_pct}</td>
                                </tr>
                                <tr>
                                    <td>Estabilidad Linde (%)</td>
                                    <td class="val-num"></td>
                                    <td class="val-num"></td>
                                    <td class="val-num"></td>
                                    <td class="mark-slot"></td>
                                    <td class="val-num">{self._fmt_val(stability_pct)}</td>
                                    <td class="mark-slot">{m_stab}</td>
                                </tr>
                                <tr>
                                    <td>Multi-parte (Cant)</td>
                                    <td class="val-num">{self._fmt_val(parts_a, force_int=True)}</td>
                                    <td class="val-num">{self._fmt_val(parts_d, force_int=True)}</td>
                                    <td class="val-num {'diff-nonzero' if delta_parts != 0 else ''}">{self._fmt_diff(delta_parts, force_int=True)}</td>
                                    <td class="mark-slot">{" *" if delta_parts != 0 else ""}</td>
                                    <td class="val-num {'diff-nonzero' if delta_parts != 0 else ''}">{self._fmt_pct(pct_parts)}</td>
                                    <td class="mark-slot">{" *" if delta_parts != 0 else ""}</td>
                                </tr>
                                <tr>
                                    <td>Desplazamiento (m)</td>
                                    <td class="val-num"></td>
                                    <td class="val-num"></td>
                                    <td class="val-num {'diff-nonzero' if displacement > 0.05 else ''}" style="text-align:right">{self._fmt_val(displacement)}</td>
                                    <td class="mark-slot">{m_desp}</td>
                                    <td class="val-num" style="text-align:center; font-weight:bold; color:var(--primary)">{self._get_arrow(displacement_dir)} {displacement_dir}</td>
                                    <td></td>
                                </tr>
                            </table>
                        </div>
                        
                        <div class="panel">
                            <div class="panel-title">INTERACCIÓN CON ENTORNO (FACHADAS)</div>
                            <table class="mini-table">
                                <colgroup>
                                    <col style="width: 35%"><col style="width: 15%"><col style="width: 15%"><col style="width: 12%"><col style="width: 14px"><col style="width: 12%"><col style="width: 14px">
                                </colgroup>
                                <tr><th>Tipo</th><th class="num-col">Antes</th><th class="num-col">Después</th><th class="num-col">Var</th><th></th><th class="num-col">%</th><th></th></tr>
                                {facade_rows_html}
                            </table>
                        </div>
                    </div>
                    
                    <!-- Sección de Transiciones e Islas -->
                    <div style="display:flex; border-top:1px solid var(--border)">
                        <div class="panel" style="flex:1; border-right:1px solid var(--border); background:#fcfcfc; border-bottom:none">
                             <div class="panel-title">ANÁLISIS DE HUECOS / ISLAS</div>
                             {islands_html}
                        </div>
                        <div class="panel" style="flex:1; background:#fdfdfd; border-right:none; border-bottom:none">
                            <div class="panel-title">DINÁMICA TERRITORIAL</div>
                             <div style="display:flex; gap:20px">
                                 <div style="flex:1">
                                     <h4 style="margin: 0 0 5px 0; font-size:0.85em; color:#666">ORIGEN (INPUTS)</h4>
                                     {flows_in_html}
                                 </div>
                                 <div style="border-left:1px solid #eee"></div>
                                 <div style="flex:1">
                                     <h4 style="margin: 0 0 5px 0; font-size:0.85em; color:#666">DESTINO (OUTPUTS)</h4>
                                     {flows_out_html}
                                 </div>
                             </div>
                        </div>
                    </div>

                    <!-- SECCIÓN ADITAMENTOS -->
                    {adit_html}

                    {dual_interp_full_html}
                    {sketch_full_html}
                """

            # Panel de anotaciones de usuario (confirmar/alternar la
            # interpretación + comentario libre), añadido al final de la
            # ficha tanto en el informe ampliado como en el resumen.
            #
            # Datos ampliados para el XML de respuestas: el texto de
            # conclusión (en prosa, sin HTML) de cada una de las dos
            # interpretaciones, las superficies Antes/Después, el valor
            # de referencia supfT24 de cada lado, y los tres % de
            # desviación de validación que ya se muestran en la fila
            # informativa de la ficha (Antes, Después, y Después-GML).
            #
            # Ya calculado más arriba (dual_param_block/dual_legal_block):
            # no hace falta volver a llamar a _render_dual_interpretation.
            param_block_html, legal_block_html = dual_param_block, dual_legal_block
            _t_html2plain0 = time.time()
            conclusion_parametrica = self._html_to_plain(param_block_html)
            conclusion_alternativa = self._html_to_plain(legal_block_html)
            self._t_acc['html_to_plain'] = self._t_acc.get('html_to_plain', 0.0) + (time.time() - _t_html2plain0)

            supft24_a_raw = d.get('supft24_a')
            supft24_d_raw = d.get('supft24_d')
            val_pct_a, val_unk_a = self._supft24_pct(supft24_a_raw, area_a)
            val_pct_d, val_unk_d = self._supft24_pct(supft24_d_raw, area_d)
            geom_d_val = d.get('geom_d')
            area_gml_trunc_d = self._gauss_area_truncated(geom_d_val) if geom_d_val is not None else 0.0
            val_pct_gml_d, val_unk_gml_d = self._supft24_pct(supft24_d_raw, area_gml_trunc_d) if geom_d_val is not None else (None, True)

            extra_data = {
                'conclusionParametrica': conclusion_parametrica,
                'conclusionAlternativa': conclusion_alternativa,
                'superficieAntes': round(area_a, 2) if area_a is not None else None,
                'superficieDespues': round(area_d, 2) if area_d is not None else None,
                'superficieGML': area_gml_trunc_d if geom_d_val is not None else None,
                'supfT24Antes': supft24_a_raw,
                'supfT24Despues': supft24_d_raw,
                'validacionPctAntes': (round(val_pct_a, 2) if not val_unk_a else None),
                'validacionPctDespues': (round(val_pct_d, 2) if not val_unk_d else None),
                'validacionPctDespuesGML': (round(val_pct_gml_d, 2) if not val_unk_gml_d else None),
            }

            card_body_html += self._timed('annot_panel', self._render_user_annotation_panel,
                d['id'], notify, legal_notify, geom_a=d.get('geom_a'), geom_d=d.get('geom_d'), extra_data=extra_data
            )

            t24_check_html, t24_areas_row_html, t24_diff_gml_cell_html = self._timed('supft24_row', self._render_supft24_row,
                d.get('supft24_a'), d.get('supft24_d'), area_a, area_d, thresholds, geom_a=d.get('geom_a'), geom_d=d.get('geom_d')
            )

            # Generar Card HTML
            card = f"""
                <div id="id-{anchor_id}" class="audit-card {card_border_cls}" data-state="{st}" data-notify="{'true' if notify else 'false'}" data-legal-notify="{'true' if legal_notify else 'false'}" data-diverge="{'true' if diverge_notify else 'false'}" data-notify-agree="{'true' if agree_notify else 'false'}" data-owner-changed="{'true' if owner_changed else 'false'}" data-t24-worse="{'true' if t24_flags['worse'] else 'false'}" data-t24-better="{'true' if t24_flags['better'] else 'false'}" data-t24-unknown="{'true' if t24_flags['unknown'] else 'false'}" data-t24-invalid-after="{'true' if t24_flags['invalid_after'] else 'false'}" data-validacion-worse="{'true' if validacion_flags['worse'] else 'false'}" data-validacion-better="{'true' if validacion_flags['better'] else 'false'}" data-validacion-unknown="{'true' if validacion_flags['unknown'] else 'false'}" data-validacion-invalid-after="{'true' if validacion_flags['invalid_after'] else 'false'}" data-owner="{owner_search_attr}" data-recinto="{html_lib.escape(str(d['id']), quote=True)}">
                    <div class="card-header">
                        <div class="card-title">
                            <h2>{d['id']} {alert_label}{legal_label}</h2>
                            {owner_display}
                        </div>
                        <div style="text-align:right">
                             <table class="t24-table">
                                 <tr><td colspan="3">{t24_check_html}</td></tr>
                                 <tr>
                                     <td class="t24-areas-cell">{t24_areas_row_html}</td>
                                     <td class="t24-diff-cell" style="{cls_area}" title="Diferencia gráfica: superficie de la geometría Después menos superficie de la geometría Antes (no tiene relación con supfT24).">
                                         <span class="t24-diff-cell-lbl">Var. gráfica:</span> {self._fmt_diff(delta_area)} m²
                                     </td>
                                     <td class="t24-diff-cell t24-diff-gml-cell">{t24_diff_gml_cell_html}</td>
                                 </tr>
                             </table>
                        </div>
                    </div>
                    {card_body_html}
                </div>
            """
            cards_html_parts.append(card)

        self._log(
            f"TIEMPOS [{filename}]: bucle de fichas + croquis = {time.time() - _t_cards0:.1f}s "
            f"({len(sorted_details)} recintos)."
        )
        if self._t_acc:
            desglose = ", ".join(f"{k}={v:.1f}s" for k, v in sorted(self._t_acc.items(), key=lambda kv: -kv[1]))
            self._log(f"TIEMPOS [{filename}]: desglose por sub-bloque -> {desglose}")

        _t_join0 = time.time()
        toc_html = "".join(toc_html_parts)
        cards_html = "".join(cards_html_parts)
        self._log(
            f"TIEMPOS [{filename}]: join() de {len(cards_html_parts)} fichas = {time.time() - _t_join0:.1f}s "
            f"({len(cards_html):,} caracteres cards_html, {len(toc_html):,} caracteres toc_html)."
        )

        html += f"""
            {toc_html}
                </ul>
            </div>
            <div class="main-content">
                <div class="report-header">
                    <h1>INFORME DE AUDITORÍA GRÁFICA{" — RESUMEN" if summary_mode else ""}</h1>
                    <div class="report-meta">
                        <div class="meta-group">
                            <strong>Configuración de Umbrales:</strong>
                            <div><strong>Geometría:</strong> Ár:{thresholds.get('area_abs','-')}m²/{thresholds.get('area_pct','-')}% | 
                                 Per:{thresholds.get('perim_abs','-')}m/{thresholds.get('perim_pct','-')}% | 
                                 K:{thresholds.get('gravelius','-')} | Desp:{thresholds.get('desp_max','-')}m | Huecos:{thresholds.get('invasion_pct','-')}%</div>
                            <div><strong>Fachadas:</strong> 
                                 Vial:{thresholds.get('facades',{}).get('VIAL',{}).get('abs','-')}m/{thresholds.get('facades',{}).get('VIAL',{}).get('pct','-')}% |
                                 Agua:{thresholds.get('facades',{}).get('AGUA',{}).get('abs','-')}m/{thresholds.get('facades',{}).get('AGUA',{}).get('pct','-')}% |
                                 Edif:{thresholds.get('facades',{}).get('EDIF',{}).get('abs','-')}m/{thresholds.get('facades',{}).get('EDIF',{}).get('pct','-')}% |
                                 Excl:{thresholds.get('facades',{}).get('EXCL',{}).get('abs','-')}m/{thresholds.get('facades',{}).get('EXCL',{}).get('pct','-')}%</div>
                            <div><strong>Propietarios Especiales:</strong> <sup>1</sup> AGADER | <sup>2</sup> MASA COMÚN | <sup>3</sup> DESCONOCIDOS</div>
                        </div>
                        <div class="meta-group">
                            <strong>Archivos Fuente:</strong>
                            <div>ANTES: {os.path.basename(data.get('input_files', {}).get('antes', 'N/A'))}</div>
                            <div>DESPUÉS: {os.path.basename(data.get('input_files', {}).get('despues', 'N/A'))}</div>
                            <div style="margin-top:5px; padding-top:5px; border-top:1px solid #eee">
                                <strong>Fecha de Auditoría:</strong> {datetime.now().strftime('%d/%m/%Y %H:%M')}
                            </div>
                        </div>
                    </div>
                </div>
                <div class="cards-wrapper">
                    {cards_html}
                </div>
            </div>
            <script>
                const searchBox = document.getElementById('search-box');
                const clearBtn = document.getElementById('clear-btn');
                const ownerSearchBox = document.getElementById('owner-search-box');
                const ownerClearBtn = document.getElementById('owner-clear-btn');
                const facetBtns = document.querySelectorAll('.facet-btn');
                const tocList = document.getElementById('toc-list');
                const parcelCount = document.getElementById('parcel-count');
                const cardsWrapper = document.querySelector('.cards-wrapper');
                const filterBusyIndicator = document.getElementById('filter-busy-indicator');
                const facetsContainer = document.getElementById('facets-container');
                const facetsToggle = document.getElementById('facets-toggle');
                const facetsToggleBadge = document.getElementById('facets-toggle-badge');
                const activeFiltersBar = document.getElementById('active-filters-bar');
                const activeFiltersChips = document.getElementById('active-filters-chips');
                const clearFiltersBtn = document.getElementById('clear-filters-btn');
                const filterSummaryLine = document.getElementById('filter-summary-line');
                const totalParcels = {len(details)};

                // Nombre legible de cada categoría, usado para construir la
                // frase-resumen en lenguaje natural ("Estado: nueva Y
                // Notificación: paramétrica o alternativa").
                const CATEGORY_LABELS = {{
                    estado: 'Estado', notificacion: 'Notificación',
                    titular: 'Titular', t24: 'Precisión de superficie',
                    validacion: 'Validación', usuario: 'Usuario'
                }};

                // Filtros por facetas: AND entre categorías (estado /
                // notificación / titular / validación T24), OR entre las
                // opciones marcadas dentro de cada categoría -- el mismo
                // patrón que cualquier filtro de tienda online. P.ej.
                // "Nueva" + "Paramétrica" da la intersección (fincas
                // nuevas Y con alerta paramétrica).
                let activeFilters = {{ estado: [], notificacion: [], titular: [], t24: [], validacion: [], usuario: [] }};

                // Etiqueta legible de cada filtro, leída del propio botón
                // (data-label), para pintar los chips de "filtros activos".
                const FILTER_LABELS = {{}};
                facetBtns.forEach(btn => {{
                    const cat = btn.getAttribute('data-category');
                    const filt = btn.getAttribute('data-filter');
                    FILTER_LABELS[cat + '::' + filt] = btn.getAttribute('data-label') || filt;
                }});

                function countActiveFilters() {{
                    let n = 0;
                    for (const cat in activeFilters) n += activeFilters[cat].length;
                    return n;
                }}

                function setFilterBusy(isBusy) {{
                    if (isBusy) {{
                        filterBusyIndicator.classList.add('active');
                        facetBtns.forEach(b => b.classList.add('busy-disabled'));
                        tocList.classList.add('is-filtering');
                        if (cardsWrapper) cardsWrapper.classList.add('is-filtering');
                    }} else {{
                        filterBusyIndicator.classList.remove('active');
                        facetBtns.forEach(b => b.classList.remove('busy-disabled'));
                        tocList.classList.remove('is-filtering');
                        if (cardsWrapper) cardsWrapper.classList.remove('is-filtering');
                    }}
                }}

                // Ejecuta performSearch() mostrando un indicador de "ocupado"
                // mientras dura el filtrado (relevante en informes con muchos
                // recintos, donde recorrer todas las fichas puede tardar).
                // El setTimeout(0) deja que el navegador pinte el spinner
                // antes de realizar el trabajo síncrono de filtrado.
                function runFilter() {{
                    setFilterBusy(true);
                    setTimeout(() => {{
                        performSearch();
                        setFilterBusy(false);
                    }}, 10);
                }}

                // Valores booleanos de un recinto (toc-item o audit-card,
                // comparten los mismos atributos data-*) indexados por el
                // código de filtro correspondiente.
                function elVals(el) {{
                    const state = el.getAttribute('data-state');
                    // Interpretación del usuario para este recinto (botones
                    // SÍ/NO NOTIFICA de la ficha): la aporta el script de
                    // anotaciones -- otro <script> con su propio cierre --
                    // vía window.AudiNOTGetInterp, que puede no estar
                    // definida aún en el primer performSearch() de la
                    // carga de página (ver el listener de
                    // 'audinot-annot-changed' más abajo, que vuelve a
                    // filtrar en cuanto esa función está lista y con
                    // datos).
                    const recintoId = el.getAttribute('data-recinto');
                    const userInterp = (typeof window.AudiNOTGetInterp === 'function' && recintoId)
                        ? window.AudiNOTGetInterp(recintoId) : '';
                    return {{
                        ALTA: state === 'ALTA',
                        BAJA: state === 'BAJA',
                        PERSISTENTE: state === 'PERSISTENTE',
                        NOTIFY: el.getAttribute('data-notify') === 'true',
                        LEGAL_NOTIFY: el.getAttribute('data-legal-notify') === 'true',
                        DIVERGE: el.getAttribute('data-diverge') === 'true',
                        NOTIFY_AGREE: el.getAttribute('data-notify-agree') === 'true',
                        OWNER_CHANGE: el.getAttribute('data-owner-changed') === 'true',
                        T24_WORSE: el.getAttribute('data-t24-worse') === 'true',
                        T24_BETTER: el.getAttribute('data-t24-better') === 'true',
                        T24_UNKNOWN: el.getAttribute('data-t24-unknown') === 'true',
                        T24_INVALID_AFTER: el.getAttribute('data-t24-invalid-after') === 'true',
                        VALID_WORSE: el.getAttribute('data-validacion-worse') === 'true',
                        VALID_BETTER: el.getAttribute('data-validacion-better') === 'true',
                        VALID_UNKNOWN: el.getAttribute('data-validacion-unknown') === 'true',
                        VALID_INVALID_AFTER: el.getAttribute('data-validacion-invalid-after') === 'true',
                        USER_NOTIFY: userInterp === 'si',
                        USER_NO_NOTIFY: userInterp === 'no'
                    }};
                }}

                // AND entre categorías con filtros activos, OR dentro de
                // cada categoría. Una categoría sin ninguna opción marcada
                // no restringe nada (se ignora).
                function matchesFilters(vals, filters) {{
                    filters = filters || activeFilters;
                    for (const cat in filters) {{
                        const arr = filters[cat];
                        if (!arr || arr.length === 0) continue;
                        let any = false;
                        for (let i = 0; i < arr.length; i++) {{
                            if (vals[arr[i]]) {{ any = true; break; }}
                        }}
                        if (!any) return false;
                    }}
                    return true;
                }}

                function performSearch() {{
                    const searchTerm = searchBox.value.toLowerCase().trim();
                    const ownerTerm = ownerSearchBox.value.toLowerCase().trim();
                    const items = tocList.querySelectorAll('.toc-item');
                    const cards = document.querySelectorAll('.audit-card');
                    let visibleCount = 0;
                    
                    if (searchTerm !== '') clearBtn.style.display = 'block';
                    else clearBtn.style.display = 'none';

                    if (ownerTerm !== '') ownerClearBtn.style.display = 'block';
                    else ownerClearBtn.style.display = 'none';

                    items.forEach(item => {{
                        const link = item.querySelector('.toc-link');
                        const text = link.textContent.toLowerCase();
                        const ownerText = (item.getAttribute('data-owner') || '').toLowerCase();
                        const vals = elVals(item);

                        let matchesSearch = searchTerm === '' || text.includes(searchTerm);
                        let matchesOwner = ownerTerm === '' || ownerText.includes(ownerTerm);
                        let matchesFilter = matchesFilters(vals);

                        if (matchesSearch && matchesOwner && matchesFilter) {{
                            item.classList.remove('hidden');
                            visibleCount++;
                        }} else {{
                            item.classList.add('hidden');
                        }}
                    }});

                    cards.forEach(card => {{
                        const vals = elVals(card);
                        const ownerText = (card.getAttribute('data-owner') || '').toLowerCase();
                        
                        // Match search: use the card's h2 text
                        const h2 = card.querySelector('.card-title h2');
                        const cardText = h2 ? h2.textContent.toLowerCase() : '';
                        let matchesSearch = searchTerm === '' || cardText.includes(searchTerm);
                        let matchesOwner = ownerTerm === '' || ownerText.includes(ownerTerm);
                        let matchesFilter = matchesFilters(vals);

                        if (matchesSearch && matchesOwner && matchesFilter) {{
                            card.classList.remove('hidden');
                        }} else {{
                            card.classList.add('hidden');
                        }}
                    }});
                    
                    if (searchTerm === '' && ownerTerm === '' && countActiveFilters() === 0) {{
                        parcelCount.textContent = `${{totalParcels}} Recintos`;
                    }} else {{
                        parcelCount.textContent = `${{visibleCount}} de ${{totalParcels}} Recintos`;
                    }}

                    updateFacetCounts(searchTerm, ownerTerm);
                    updateActiveFiltersBar();
                    updateFacetsToggleBadge();
                    updateFilterSummaryLine(visibleCount);
                    syncUrlHash();
                }}

                // Contador en vivo por chip: cuántos recintos habría si,
                // además de los filtros ya activos, también se marcara esta
                // opción (unión con lo ya seleccionado en su categoría). Así
                // el usuario ve el resultado de una combinación antes de
                // aplicarla, sin ensayo-error.
                function updateFacetCounts(searchTerm, ownerTerm) {{
                    const items = tocList.querySelectorAll('.toc-item');
                    facetBtns.forEach(btn => {{
                        const cat = btn.getAttribute('data-category');
                        const filt = btn.getAttribute('data-filter');
                        const tempFilters = {{}};
                        for (const c in activeFilters) tempFilters[c] = activeFilters[c].slice();
                        if (!tempFilters[cat].includes(filt)) tempFilters[cat] = tempFilters[cat].concat([filt]);

                        let count = 0;
                        items.forEach(item => {{
                            const link = item.querySelector('.toc-link');
                            const text = link.textContent.toLowerCase();
                            const ownerText = (item.getAttribute('data-owner') || '').toLowerCase();
                            let matchesSearch = searchTerm === '' || text.includes(searchTerm);
                            let matchesOwner = ownerTerm === '' || ownerText.includes(ownerTerm);
                            if (!matchesSearch || !matchesOwner) return;
                            if (matchesFilters(elVals(item), tempFilters)) count++;
                        }});

                        const countSpan = btn.querySelector('.facet-count');
                        if (countSpan) countSpan.textContent = `(${{count}})`;
                        btn.classList.toggle('facet-zero', count === 0 && !btn.classList.contains('active'));
                    }});
                }}

                // Chips borrables ("Nueva ✕ · Paramétrica ✕") encima de la
                // lista, con acceso directo a quitar un filtro sin ir botón
                // por botón.
                function updateActiveFiltersBar() {{
                    activeFiltersChips.innerHTML = '';
                    let any = false;
                    for (const cat in activeFilters) {{
                        activeFilters[cat].forEach(filt => {{
                            any = true;
                            const chip = document.createElement('span');
                            chip.className = 'active-filter-chip';
                            const label = document.createElement('span');
                            label.textContent = FILTER_LABELS[cat + '::' + filt] || filt;
                            const remove = document.createElement('span');
                            remove.className = 'chip-remove';
                            remove.textContent = '✕';
                            remove.title = 'Quitar filtro';
                            remove.addEventListener('click', () => toggleFilter(cat, filt, false));
                            chip.appendChild(label);
                            chip.appendChild(remove);
                            activeFiltersChips.appendChild(chip);
                        }});
                    }}
                    activeFiltersBar.classList.toggle('visible', any);
                }}

                // Frase en lenguaje natural con lo que se está filtrando
                // ahora mismo, siempre visible junto al botón "Filtros"
                // (no hace falta desplegar el panel para saber sobre qué
                // se está aplicando el filtrado ni si son varios a la vez).
                function updateFilterSummaryLine(visibleCount) {{
                    const parts = [];
                    for (const cat in activeFilters) {{
                        const arr = activeFilters[cat];
                        if (arr.length === 0) continue;
                        const labels = arr.map(f => (FILTER_LABELS[cat + '::' + f] || f).toLowerCase());
                        parts.push(`${{CATEGORY_LABELS[cat] || cat}}: ${{labels.join(' o ')}}`);
                    }}
                    if (parts.length === 0) {{
                        filterSummaryLine.classList.remove('visible');
                        filterSummaryLine.textContent = '';
                        return;
                    }}
                    filterSummaryLine.textContent = `${{visibleCount}} de ${{totalParcels}} recintos que cumplen: ${{parts.join('  Y  ')}}`;
                    filterSummaryLine.classList.add('visible');
                }}

                function updateFacetsToggleBadge() {{
                    const n = countActiveFilters();
                    if (n > 0) {{
                        facetsToggleBadge.style.display = 'inline-block';
                        facetsToggleBadge.textContent = n + (n === 1 ? ' activo' : ' activos');
                    }} else {{
                        facetsToggleBadge.style.display = 'none';
                    }}
                }}

                // Añade/quita un filtro y sincroniza el botón correspondiente.
                // forceState opcional: true para forzar activado, false para
                // forzar desactivado (usado al borrar un chip).
                function toggleFilter(cat, filt, forceState) {{
                    const idx = activeFilters[cat].indexOf(filt);
                    const shouldBeOn = forceState !== undefined ? forceState : idx === -1;
                    if (shouldBeOn && idx === -1) {{
                        activeFilters[cat].push(filt);
                    }} else if (!shouldBeOn && idx !== -1) {{
                        activeFilters[cat].splice(idx, 1);
                    }} else {{
                        return;
                    }}
                    const btn = document.querySelector('.facet-btn[data-category="' + cat + '"][data-filter="' + filt + '"]');
                    if (btn) btn.classList.toggle('active', shouldBeOn);
                    runFilter();
                }}

                // Estado de filtros reflejado en la URL (#estado=ALTA&notificacion=NOTIFY,DIVERGE)
                // -- sin backend, permite copiar el enlace con la vista ya
                // filtrada y mandarlo a otra persona.
                function syncUrlHash() {{
                    const parts = [];
                    for (const cat in activeFilters) {{
                        if (activeFilters[cat].length > 0) {{
                            parts.push(cat + '=' + activeFilters[cat].map(encodeURIComponent).join(','));
                        }}
                    }}
                    const hash = parts.length > 0 ? '#' + parts.join('&') : '';
                    if (window.history && window.history.replaceState) {{
                        window.history.replaceState(null, '', window.location.pathname + window.location.search + hash);
                    }}
                }}

                function loadFiltersFromUrl() {{
                    const hash = window.location.hash.replace(/^#/, '');
                    if (!hash) return;
                    hash.split('&').forEach(pair => {{
                        const eq = pair.indexOf('=');
                        if (eq === -1) return;
                        const cat = decodeURIComponent(pair.substring(0, eq));
                        if (!activeFilters.hasOwnProperty(cat)) return;
                        const vals = decodeURIComponent(pair.substring(eq + 1));
                        vals.split(',').forEach(filt => {{
                            if (!filt) return;
                            const btn = document.querySelector('.facet-btn[data-category="' + cat + '"][data-filter="' + filt + '"]');
                            if (btn && activeFilters[cat].indexOf(filt) === -1) {{
                                activeFilters[cat].push(filt);
                                btn.classList.add('active');
                            }}
                        }});
                    }});
                    if (countActiveFilters() > 0) {{
                        facetsContainer.classList.add('open');
                        facetsToggle.setAttribute('aria-expanded', 'true');
                    }}
                }}

                searchBox.addEventListener('input', performSearch);
                ownerSearchBox.addEventListener('input', performSearch);
                
                facetBtns.forEach(btn => {{
                    btn.addEventListener('click', () => {{
                        const cat = btn.getAttribute('data-category');
                        const filt = btn.getAttribute('data-filter');
                        toggleFilter(cat, filt);
                    }});
                }});

                clearFiltersBtn.addEventListener('click', () => {{
                    for (const cat in activeFilters) activeFilters[cat] = [];
                    facetBtns.forEach(b => b.classList.remove('active'));
                    runFilter();
                }});

                facetsToggle.addEventListener('click', () => {{
                    const isOpen = facetsContainer.classList.toggle('open');
                    facetsToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
                }});
                
                clearBtn.addEventListener('click', function() {{
                    searchBox.value = '';
                    runFilter();
                    searchBox.focus();
                }});

                ownerClearBtn.addEventListener('click', function() {{
                    ownerSearchBox.value = '';
                    runFilter();
                    ownerSearchBox.focus();
                }});
                
                searchBox.addEventListener('keydown', function(e) {{
                    if (e.key === 'Escape') {{
                        searchBox.value = '';
                        runFilter();
                    }}
                }});

                ownerSearchBox.addEventListener('keydown', function(e) {{
                    if (e.key === 'Escape') {{
                        ownerSearchBox.value = '';
                        runFilter();
                    }}
                }});

                // El script de anotaciones de usuario vive en otro <script>
                // aparte (se ejecuta después de este) y dispara este evento
                // cada vez que cambia annotData: al cargar la cápsula
                // embebida o el autoguardado de IndexedDB, al importar un
                // XML, o al pulsar SÍ/NO NOTIFICA/Sin revisar en una ficha.
                // Hace falta refiltrar en cada uno de esos casos porque la
                // faceta "Usuario" (MARCADO PARA NOTIFICAR / MARCADO PARA
                // NO NOTIFICAR) depende de ese dato, que no existe todavía
                // en el primer performSearch() de la carga de página.
                document.addEventListener('audinot-annot-changed', function () {{
                    runFilter();
                }});

                loadFiltersFromUrl();
                performSearch();
            </script>
            {annot_script}
        </body>
        </html>
        """
        return html

    def _render_islands_section(self, isl, thresholds=None):
        """Renderiza la tabla de análisis de huecos/islas con lógica de umbrales."""
        if not isl:
            return '<div style="color:#ccc; font-style:italic; padding:10px">Sin huecos detectados</div>'
            
        # Umbrales
        if thresholds is None: thresholds = {}
        
        # 1. Área
        m_a_abs = self._chk(isl['delta_area'], thresholds.get('area_abs'))
        pct_area = self._get_pct(isl['area_a'], isl['area_d'])
        m_a_pct = self._chk(pct_area, thresholds.get('area_pct'))
        cls_area = "text-pos" if isl['delta_area'] > 0.1 else "text-neg" if isl['delta_area'] < -0.1 else ""
        
        # 2. Perímetro
        m_p_abs = self._chk(isl['delta_perim'], thresholds.get('perim_abs'))
        pct_perim = self._get_pct(isl['perim_a'], isl['perim_d'])
        m_p_pct = self._chk(pct_perim, thresholds.get('perim_pct'))
        cls_perim = "text-pos" if isl['delta_perim'] > 0.1 else "text-neg" if isl['delta_perim'] < -0.1 else ""
        
        # 3. Desplazamiento (Usa el umbral desp_max)
        m_desp = self._chk(isl['displacement'], thresholds.get('desp_max'))
        
        html = f"""
        <table class="mini-table">
            <colgroup>
                <col style="width: 35%"><col style="width: 15%"><col style="width: 15%"><col style="width: 12%"><col style="width: 14px"><col style="width: 12%"><col style="width: 14px">
            </colgroup>
            <tr><th>Parámetro</th><th class="num-col">Antes</th><th class="num-col">Después</th><th class="num-col">Var</th><th></th><th class="num-col">%</th><th></th></tr>
            <tr>
                <td>Sup. Islas (m²)</td>
                <td class="val-num">{self._fmt_val(isl['area_a'])}</td>
                <td class="val-num">{self._fmt_val(isl['area_d'])}</td>
                <td class="val-num {cls_area} {'diff-nonzero' if abs(isl['delta_area']) > 0.001 else ''}">{self._fmt_diff(isl['delta_area'])}</td>
                <td class="mark-slot">{m_a_abs}</td>
                <td class="val-num {cls_area} {'diff-nonzero' if abs(isl['delta_area']) > 0.001 else ''}">{self._fmt_pct(pct_area)}</td>
                <td class="mark-slot">{m_a_pct}</td>
            </tr>
            <tr>
                <td>Perim. Islas (m)</td>
                <td class="val-num">{self._fmt_val(isl['perim_a'])}</td>
                <td class="val-num">{self._fmt_val(isl['perim_d'])}</td>
                <td class="val-num {cls_perim} {'diff-nonzero' if abs(isl['delta_perim']) > 0.001 else ''}">{self._fmt_diff(isl['delta_perim'])}</td>
                <td class="mark-slot">{m_p_abs}</td>
                <td class="val-num {cls_perim} {'diff-nonzero' if abs(isl['delta_perim']) > 0.001 else ''}">{self._fmt_pct(pct_perim)}</td>
                <td class="mark-slot">{m_p_pct}</td>
            </tr>
            <tr>
                <td>Cant. Islas (n)</td>
                <td class="val-num">{self._fmt_val(isl['count_a'], force_int=True)}</td>
                <td class="val-num">{self._fmt_val(isl['count_d'], force_int=True)}</td>
                <td class="val-num {'diff-nonzero' if isl['delta_count'] != 0 else ''}">{self._fmt_diff(isl['delta_count'], force_int=True)}</td>
                <td class="mark-slot">{" *" if isl['delta_count'] != 0 else ""}</td>
                <td class="val-num {'diff-nonzero' if isl['delta_count'] != 0 else ''}">{self._fmt_pct(self._get_pct(isl['count_a'], isl['count_d']))}</td>
                <td class="mark-slot">{" *" if isl['delta_count'] != 0 else ""}</td>
            </tr>
            <tr style="background:#fcfcfc">
                <td>Desplazamiento (m)</td>
                <td></td>
                <td></td>
                <td class="val-num {'diff-nonzero' if isl['displacement'] > 0.05 else ''}" style="text-align:right">{self._fmt_val(isl['displacement'])}</td>
                <td class="mark-slot">{m_desp}</td>
            <td style="text-align:center; color:var(--primary); font-family:Consolas, monospace">{self._get_arrow(isl['displacement_dir'])} {isl['displacement_dir']}</td>
                <td></td>
            </tr>
        </table>
        """
        return html

    def _render_flows(self, flows, current_st, target_st, special_owners=None, flow_direction='input'):
        """Renderiza flujos de entrada (inputs) o salida (outputs).
        
        Args:
            flows: Lista de flujos a renderizar
            current_st: Estado actual de la parcela
            target_st: Estado objetivo ('ALTA' o 'BAJA')
            special_owners: Diccionario de propietarios especiales
            flow_direction: 'input' para ORIGEN o 'output' para DESTINO
        """
        if special_owners is None:
            special_owners = {}
            
        if not flows and current_st == target_st:
            color = "#3498db" if target_st == 'ALTA' else "#c0392b"
            text = "ALTA PURA (Sin matriz previa)" if target_st == 'ALTA' else "BAJA PURA (Desaparición física)"
            return f"<div class='flow-item' style='border-left:3px solid {color}'>{text}</div>"
        elif not flows:
            return "<div style='color:#ccc; font-style:italic'>Sin registros</div>"
        
        html = ""
        for flow in flows:
            # Seleccionar campos correctos según la dirección del flujo
            if flow_direction == 'input':
                # Para INPUTS (ORIGEN): mostrar de dónde viene
                parcel_id = flow.get('source', 'N/A')
                owner = flow.get('prop_source', 'Desc.')
            else:
                # Para OUTPUTS (DESTINO): mostrar hacia dónde va
                parcel_id = flow.get('target', 'N/A')
                owner = flow.get('prop_target', 'Desc.')
            
            # Marcar si el propietario es especial (comparación numérica)
            symbol = ""
            try:
                # Intentar convertir owner a int para comparación numérica
                owner_num = int(owner) if owner not in ["Desc.", None, "", "-"] else None
                if owner_num is not None and owner_num in special_owners:
                    symbol = f"<sup style='font-size: 0.8em; font-weight: bold;'>{special_owners[owner_num]['symbol']}</sup>"
            except (ValueError, TypeError):
                # Si owner no es numérico, no marcar
                pass
            
            html += f"""
                <div class="flow-item">
                    <span><b>{parcel_id}{symbol}</b> ({owner})</span>
                    <span class="val-num" style="background:none">{self._fmt_val(flow['area'])} m²</span>
                </div>
            """
        return html

    # ------------------------------------------------------------------
    # FICHA "4: AUDITORÍA" -- exportación a capa GeoPackage
    # ------------------------------------------------------------------
    #
    # Método AISLADO, añadido sin tocar ni una línea de _build_html() ni
    # de ningún otro método existente. Su única función es recorrer
    # metrics_data['parcel_details'] y, para cada recinto, producir un
    # DICCIONARIO plano (no HTML) con exactamente la misma información
    # que ya calcula el informe HTML -- reutilizando los mismos métodos
    # privados (self._chk, self._legal_interpretation,
    # self._generate_notify_comment, self._render_sketch_svg,
    # self._recinto_bbox, self._html_to_plain, etc.) para que NUNCA
    # pueda divergir el criterio de "notifica / no notifica" entre el
    # informe HTML y la capa de auditoría: es la misma fuente de verdad.
    #
    # La única pieza que no se reutiliza literalmente es la comprobación
    # de umbrales que decide 'notify' (booleano paramétrico) y que
    # alimenta a self._legal_interpretation(): esa comprobación vive
    # entrelazada dentro del bucle gigante de _build_html() y no está
    # extraída a un método propio. Aquí se repite (mismo código, mismas
    # llamadas a self._chk/self._chk_neg/self._get_pct que usa
    # _build_html) para no tener que tocar ese método ya probado. Si en
    # el futuro cambian los umbrales que disparan 'notify' en
    # _build_html, hay que replicar el cambio aquí.
    @staticmethod
    def _json_geom_safe(obj):
        """
        Función 'default' para json.dumps: convierte cualquier objeto no
        serializable de forma nativa (en la práctica, QgsGeometry) en algo
        volcable a JSON.

        audinot_json arrastra estructuras (inputs/outputs de la matriz de
        trasvases, aditamentos por recinto...) que se reutilizan tal cual
        para dibujar el croquis (ver _generate_sketch_svg) y por tanto
        conservan objetos QgsGeometry "vivos". En vez de tener que limpiar
        a mano cada campo que pudiera contener geometría (y arriesgarse a
        que aparezca una nueva en el futuro y vuelva a romper el volcado),
        cualquier objeto con método asWkt() se serializa como su WKT; el
        resto de tipos no serializables se convierten a str() como último
        recurso para no tumbar el informe completo.
        """
        if hasattr(obj, 'asWkt'):
            try:
                return obj.asWkt()
            except Exception:
                return None
        return str(obj)

    def build_audit_records(self, metrics_data, thresholds=None, project_crs=''):
        """
        Devuelve una lista de dicts, uno por recinto, lista para volcar a
        una capa GeoPackage de auditoría (ver core/audit_service.py).

        Cada dict contiene:
          - Campos planos (id, estado, superficies, notifica paramétrico
            / alternativo, nº de alertas...) pensados para filtrar y
            simbolizar en QGIS.
          - 'audinot_json': paquete COMPLETO sin resumir (matriz de
            trasvases inputs/outputs, aditamentos, conclusiones en
            prosa de ambas interpretaciones, validación T24...) igual
            al que ya viaja en el XML de respuestas del informe HTML.
          - 'croquis_svg': el SVG del croquis de esa ficha, ya
            renderizado, listo para pintar con QSvgWidget sin recalcular.
          - 'bbox': (xmin, ymin, xmax, ymax) en el SCR del proyecto.
        """
        thresholds = thresholds or {}
        details = metrics_data.get('parcel_details', [])
        special_ranges = metrics_data.get('special_ranges', {})
        special_owners = metrics_data.get('special_owners', {})
        # Igual que _context_geoms_despues, normalmente ya queda fijado en
        # self por la llamada previa a generate_html()/_build_html() sobre
        # esta misma instancia, pero se fija también aquí por si en algún
        # momento se llama a build_audit_records() de forma aislada (ver
        # _generate_sketch_svg, clasificación de recintos EDIFICACIONES).
        self._special_ranges = special_ranges
        fixed_facade_types = ['VIALES', 'CURSOS AGUA', 'EDIFICACIONES', 'EXCLUIDO']

        records = []

        for d in details:
            st = d.get('state')

            notify = False
            notify_reasons = []

            area_d = d.get('area_final', 0)
            delta_area = d.get('delta_area', 0)
            area_a = area_d - delta_area if st != 'BAJA' else abs(delta_area)
            pct_area = self._get_pct(area_a, area_d)

            m_a_abs = self._chk(delta_area, thresholds.get('area_abs'))
            m_a_pct = self._chk(pct_area, thresholds.get('area_pct'))

            perim_a = d.get('perim_a', 0); perim_d = d.get('perim_d', 0)
            delta_perim = d.get('delta_perim', 0)
            pct_perim = self._get_pct(perim_a, perim_d)
            m_p_abs = self._chk(delta_perim, thresholds.get('perim_abs'))
            m_p_pct = self._chk(pct_perim, thresholds.get('perim_pct'))

            grav_a = d.get('grav_a', 0); grav_d = d.get('grav_d', 0)
            grav_delta = d.get('delta_grav', 0)
            pct_grav = self._get_pct(grav_a, grav_d)
            m_g_pct = self._chk(grav_delta, thresholds.get('gravelius'))

            convex_a = d.get('convex_a', 1.0); convex_d = d.get('convex_d', 1.0)
            delta_convex = convex_d - convex_a
            pct_convex = self._get_pct(convex_a, convex_d)
            m_c_abs = self._chk(delta_convex, thresholds.get('convexity_abs'))
            m_c_pct = self._chk(pct_convex, thresholds.get('convexity_pct'))

            stability_pct = d.get('stability_pct', 100.0)
            m_stab = self._chk_neg(stability_pct, thresholds.get('stability_pct'))

            displacement = d.get('displacement', 0.0)
            displacement_dir = d.get('displacement_dir', '-')
            m_desp = self._chk(displacement, thresholds.get('desp_max'))

            hole_area_a = d.get('hole_area_a', 0.0)
            delta_hole_area = d.get('delta_hole_area', 0.0)
            pct_rings_area = self._get_pct(hole_area_a, d.get('hole_area_d', 0.0))
            m_inv = self._chk(pct_rings_area, thresholds.get('invasion_pct'))

            delta_parts = d.get('parts_d', 1) - d.get('parts_a', 1)
            isl_deltas = d.get('islands')
            delta_isl_cnt = isl_deltas['delta_count'] if isl_deltas else 0

            if m_a_abs or m_a_pct or m_p_abs or m_p_pct or m_g_pct or m_inv or m_desp or m_c_abs or m_c_pct or m_stab or delta_parts != 0 or delta_isl_cnt != 0:
                notify = True

            if m_a_abs or m_a_pct:
                notify_reasons.append({'mag': abs(pct_area), 'text': f"la superficie varía {delta_area:+.1f} m² ({pct_area:+.1f}%)"})
            if m_stab:
                notify_reasons.append({'mag': 100.0 - stability_pct + 50, 'text': f"el lindero exterior solo se mantiene estable en un {stability_pct:.1f}% de su trazado respecto a la situación anterior"})
            if m_p_abs or m_p_pct:
                notify_reasons.append({'mag': abs(pct_perim), 'text': f"el perímetro cambia {delta_perim:+.1f} m ({pct_perim:+.1f}%)"})
            if m_c_abs or m_c_pct or m_g_pct:
                notify_reasons.append({'mag': abs(pct_convex) + abs(pct_grav), 'text': "la forma de la parcela se ha modificado de manera apreciable (convexidad/compacidad)"})
            if m_desp:
                notify_reasons.append({'mag': displacement, 'text': f"el centroide se ha desplazado {displacement:.1f} m hacia el {displacement_dir}"})
            if delta_parts != 0:
                notify_reasons.append({'mag': abs(delta_parts) * 20, 'text': f"la parcela pasa de {d.get('parts_a',1)} a {d.get('parts_d',1)} partes, es decir, {'se fragmenta' if delta_parts > 0 else 'se unifica'}"})
            if delta_isl_cnt != 0:
                _cnt_a = isl_deltas.get('count_a', 0) if isl_deltas else 0
                _cnt_d = isl_deltas.get('count_d', 0) if isl_deltas else 0
                notify_reasons.append({'mag': abs(delta_isl_cnt) * 15, 'text': f"el número de huecos/islas interiores pasa de {_cnt_a} a {_cnt_d} ({'+' if delta_isl_cnt>0 else ''}{delta_isl_cnt})"})
            if m_inv:
                _isl_area_a = isl_deltas.get('area_a', hole_area_a) if isl_deltas else hole_area_a
                _isl_area_d = isl_deltas.get('area_d', d.get('hole_area_d', 0.0)) if isl_deltas else d.get('hole_area_d', 0.0)
                notify_reasons.append({'mag': abs(pct_rings_area), 'text': f"el área de los huecos interiores pasa de {self._fmt_val(_isl_area_a)} m² a {self._fmt_val(_isl_area_d)} m² (variación de {delta_hole_area:+.1f} m², {pct_rings_area:+.1f}%)"})

            facade_legal = []
            facade_flat = {}
            for t_code in fixed_facade_types:
                val_a = d.get(f'facade_antes_{t_code}', 0.0)
                val_d = d.get(f'facade_desp_{t_code}', 0.0)
                delta = val_d - val_a
                pct = self._get_pct(val_a, val_d)
                f_lims = thresholds.get('facades', {})
                f_key = 'VIAL' if 'VIAL' in t_code else 'AGUA' if 'AGUA' in t_code else 'EDIF' if 'EDIF' in t_code else 'EXCL'
                lims = f_lims.get(f_key, {})
                m_f_abs = self._chk(delta, lims.get('abs'))
                m_f_pct = self._chk(pct, lims.get('pct'))
                if m_f_abs or m_f_pct:
                    notify = True
                    notify_reasons.append({'mag': abs(pct) if val_a > 0 else (100.0 if val_d > 0 else 0.0), 'text': f"la fachada a {t_code.lower()} varía {delta:+.1f} m ({pct:+.1f}%)"})
                facade_legal.append({'label': t_code, 'delta': delta, 'pct': pct, 'm_abs': bool(m_f_abs), 'm_pct': bool(m_f_pct)})
                facade_flat[t_code] = {'antes': val_a, 'despues': val_d, 'delta': delta, 'pct': pct}

            adit_content_html, adit_alerts, adit_total = self._generate_adit_table_rows(d, thresholds)
            adit_reason_objs = self._collect_adit_alert_reasons(d, thresholds) if adit_alerts > 0 else []
            if adit_alerts > 0:
                notify = True
                notify_reasons.extend(adit_reason_objs)

            owner_changed = d.get('owner_changed', False)
            owner_changed_effective = bool(owner_changed and st == 'PERSISTENTE')
            if owner_changed_effective:
                notify = True
                notify_reasons.append({'mag': 200, 'text': f"cambia el titular registral (de {d.get('prop_a','N/A')} a {d.get('prop_d','N/A')})"})

            p_a = self._format_owner_label(d.get('prop_a', 'N/A'), special_owners)
            p_d = self._format_owner_label(d.get('prop_d', 'N/A'), special_owners)

            legal_result = self._legal_interpretation(
                st=st,
                delta_parts=delta_parts, parts_a=d.get('parts_a', 1), parts_d=d.get('parts_d', 1),
                delta_isl_cnt=delta_isl_cnt, isl_deltas=isl_deltas,
                owner_changed=owner_changed_effective,
                prop_a=d.get('prop_a', 'N/A'), prop_d=d.get('prop_d', 'N/A'),
                delta_area=delta_area, pct_area=pct_area, m_a_abs=bool(m_a_abs), m_a_pct=bool(m_a_pct),
                facade_legal=facade_legal,
                m_p_abs=bool(m_p_abs), m_p_pct=bool(m_p_pct), delta_perim=delta_perim, pct_perim=pct_perim,
                m_g_pct=bool(m_g_pct), pct_grav=pct_grav,
                m_c_abs=bool(m_c_abs), m_c_pct=bool(m_c_pct),
                m_desp=bool(m_desp), displacement=displacement, displacement_dir=displacement_dir,
                m_stab=bool(m_stab), stability_pct=stability_pct,
                m_inv=bool(m_inv), pct_rings_area=pct_rings_area, delta_hole_area=delta_hole_area,
                adit_reason_objs=adit_reason_objs,
            )
            legal_notify = bool(legal_result and legal_result.get('notify'))

            conclusion_parametrica = self._html_to_plain(self._generate_notify_comment(notify_reasons, st, d, special_ranges)) if notify else ''
            conclusion_alternativa = self._html_to_plain(self._render_legal_interpretation(legal_result)) if legal_result else ''

            geom_a = d.get('geom_a')
            geom_d = d.get('geom_d')
            bbox = self._recinto_bbox(geom_a, geom_d)

            try:
                croquis_svg = self._generate_sketch_svg(d, thresholds)
            except Exception as e:
                croquis_svg = f'<div style="font-size:0.8em; color:#999">No se ha podido generar el croquis: {e}</div>'

            supft24_a_raw = d.get('supft24_a')
            supft24_d_raw = d.get('supft24_d')
            val_pct_a, val_unk_a = self._supft24_pct(supft24_a_raw, area_a)
            val_pct_d, val_unk_d = self._supft24_pct(supft24_d_raw, area_d)

            # Superficie "GML" (fórmula de Gauss/lazada con las coordenadas
            # de cada vértice truncadas a 2 decimales, redondeada sin
            # decimales) y su % de desviación frente a supfT24, para cada
            # lado. Es el mismo cálculo que ya usa la fila informativa del
            # informe HTML (_render_supft24_row) y el filtro "Validación"
            # del TOC (_validacion_filter_flags): lo replicamos aquí para
            # que el GeoPackage de auditoría lleve estos valores como
            # campos planos, en vez de solo dentro de audinot_json.
            area_gml_trunc_a = self._gauss_area_truncated(geom_a) if geom_a is not None else None
            area_gml_trunc_d = self._gauss_area_truncated(geom_d) if geom_d is not None else None
            val_pct_gml_a, val_unk_gml_a = self._supft24_pct(supft24_a_raw, area_gml_trunc_a) if geom_a is not None else (None, True)
            val_pct_gml_d, val_unk_gml_d = self._supft24_pct(supft24_d_raw, area_gml_trunc_d) if geom_d is not None else (None, True)

            validacion_limit = thresholds.get('validacion_pct', 10.0) if thresholds else 10.0
            try:
                validacion_limit = float(validacion_limit)
            except (TypeError, ValueError):
                validacion_limit = 10.0
            # Único criterio para resaltar en el GeoPackage: el % GML de
            # Después (supfT24 vs. superficie GML de Después) es el más
            # exigente de los dos que se comprueban en Después (ver
            # _validacion_filter_flags) y el que pide expresamente la
            # Ficha 4.
            val_gml_d_supera = bool((not val_unk_gml_d) and abs(val_pct_gml_d) > validacion_limit)

            audinot_json = {
                'id': d.get('id'),
                'estado': st,
                'titularAntes': p_a,
                'titularDespues': p_d,
                'titularCambia': owner_changed_effective,
                'superficieAntes': round(area_a, 2) if area_a is not None else None,
                'superficieDespues': round(area_d, 2) if area_d is not None else None,
                'perimetroAntes': perim_a, 'perimetroDespues': perim_d,
                'gravelius': {'antes': grav_a, 'despues': grav_d},
                'convexidad': {'antes': convex_a, 'despues': convex_d},
                'estabilidadLindePct': stability_pct,
                'desplazamiento': {'m': displacement, 'direccion': displacement_dir},
                'partes': {'antes': d.get('parts_a', 1), 'despues': d.get('parts_d', 1)},
                'islas': isl_deltas,
                'fachadas': facade_flat,
                'aditamentos': d.get('aditamentos', {}),
                'inputs': d.get('inputs', []),
                'outputs': d.get('outputs', []),
                'supfT24Antes': supft24_a_raw, 'supfT24Despues': supft24_d_raw,
                'superficieGMLAntes': area_gml_trunc_a,
                'superficieGMLDespues': area_gml_trunc_d,
                'validacionPctAntes': (round(val_pct_a, 2) if not val_unk_a else None),
                'validacionPctDespues': (round(val_pct_d, 2) if not val_unk_d else None),
                'validacionPctAntesGML': (round(val_pct_gml_a, 2) if not val_unk_gml_a else None),
                'validacionPctDespuesGML': (round(val_pct_gml_d, 2) if not val_unk_gml_d else None),
                'conclusionParametrica': conclusion_parametrica,
                'conclusionAlternativa': conclusion_alternativa,
                'razonesNotificacion': [r['text'] for r in sorted(notify_reasons, key=lambda r: r.get('mag', 0), reverse=True)],
            }

            records.append({
                'audinot_id': str(d.get('id')),
                'estado': st,
                # Todo lo que llega aquí procede de parcel_details, que el
                # motor de métricas ya filtra a "PARCELA" (los recintos
                # mapeados como VIALES/CURSOS AGUA/EDIFICACIONES/EXCLUIDO
                # -- Identificación por REC/Rangos -- se excluyen de este
                # análisis paramétrico a propósito, no son fincas a
                # notificar). Ver build_infra_records() para esos.
                'tipo_recinto': 'PARCELA',
                'titular_a': p_a,
                'titular_d': p_d,
                'titular_cambia': owner_changed_effective,
                'sup_a': round(area_a, 2) if area_a is not None else None,
                'sup_d': round(area_d, 2) if area_d is not None else None,
                'var_sup': round(delta_area, 2) if delta_area is not None else None,
                'var_sup_pct': round(pct_area, 2) if pct_area is not None else None,
                'var_perim': round(delta_perim, 2),
                'n_partes_a': d.get('parts_a', 1), 'n_partes_d': d.get('parts_d', 1),
                'n_islas_delta': delta_isl_cnt,
                'notifica_param': notify,
                'notifica_legal': legal_notify,
                'notif_divergen': (notify != legal_notify),
                'n_alertas': len(notify_reasons),
                'sup_t24_a': (round(supft24_a_raw, 2) if isinstance(supft24_a_raw, (int, float)) and supft24_a_raw != -1 else None),
                'sup_t24_d': (round(supft24_d_raw, 2) if isinstance(supft24_d_raw, (int, float)) and supft24_d_raw != -1 else None),
                'sup_gml_a': (round(area_gml_trunc_a, 2) if area_gml_trunc_a is not None else None),
                'sup_gml_d': (round(area_gml_trunc_d, 2) if area_gml_trunc_d is not None else None),
                'val_pct_a': (round(val_pct_a, 2) if not val_unk_a else None),
                'val_pct_d': (round(val_pct_d, 2) if not val_unk_d else None),
                'val_pct_gml_a': (round(val_pct_gml_a, 2) if not val_unk_gml_a else None),
                'val_pct_gml_d': (round(val_pct_gml_d, 2) if not val_unk_gml_d else None),
                'val_gml_d_supera': val_gml_d_supera,
                'val_limite_pct': validacion_limit,
                'geom_a': geom_a,
                'geom_d': geom_d,
                'bbox': bbox,
                'croquis_svg': croquis_svg,
                'conclusion_param': conclusion_parametrica,
                'conclusion_legal': conclusion_alternativa,
                'audinot_json': json.dumps(audinot_json, ensure_ascii=False, default=self._json_geom_safe),
                # Campos de revisión humana: valores por defecto para
                # una finca NUEVA en la capa de auditoría. audit_service
                # los respeta (no los pisa) si la finca ya existía.
                'revision_estado': '',
                'revision_obs': '',
                'revision_fecha': None,
                'revision_desactualizada': False,
            })

        return records

    def build_infra_records(self, layer_desp):
        """
        Registros mínimos, para el GeoPackage de auditoría, de los
        recintos de DESPUÉS mapeados como infraestructura fija por
        "Identificación por REC (Rangos)" -- VIALES, CURSOS AGUA,
        EDIFICACIONES, EXCLUIDO (Ficha 3) -- que build_audit_records()
        nunca ve: el motor de métricas (metrics_calculation.py) los
        excluye a propósito de parcel_details porque no son "fincas" a
        notificar al registrador (no tienen titular, superficie
        comparable Antes/Después, conclusión legal, etc.).

        Aun así, la Ficha 4 necesita que el GeoPackage refleje TODOS los
        recintos de DESPUÉS, así que se generan aquí aparte, directamente
        a partir de la capa DESPUÉS ya enriquecida con los campos 'TIPO'
        y 'xID' (la capa 'ok_despues'/'DESPUES-ok.shp' que construye
        AnalysisEngine.run(), NO la capa DESPUÉS original sin procesar).
        Solo llevan geometría, identificador, tipo y superficie: el resto
        de campos (titular, % de validación, croquis, conclusiones...)
        quedan vacíos/None porque no aplican a infraestructura.

        layer_desp: QgsVectorLayer con campos 'TIPO' y 'xID' ya
                    calculados (ver ShpService.enrich_layer). Si no los
                    tiene (capa de una fase anterior al enriquecimiento),
                    se devuelve una lista vacía sin lanzar excepción.
        """
        if layer_desp is None:
            return []

        idx_tipo = layer_desp.fields().indexFromName('TIPO')
        idx_xid = layer_desp.fields().indexFromName('xID')
        if idx_tipo == -1 or idx_xid == -1:
            return []

        infra_labels = {'VIALES', 'CURSOS AGUA', 'EDIFICACIONES', 'EXCLUIDO'}

        # Un mismo recinto de infraestructura puede llegar fragmentado en
        # varias features (p.ej. un VIAL dividido por los límites de las
        # fincas colindantes que sí se estudian): se agrupan por xID y se
        # disuelven en una única geometría, igual que hace el motor de
        # métricas para las parcelas normales.
        groups = {}
        for f in layer_desp.getFeatures():
            tipo = str(f[idx_tipo]).strip() if f[idx_tipo] is not None else ''
            if tipo not in infra_labels:
                continue
            xid = f[idx_xid]
            if xid is None or str(xid).strip() == '':
                continue
            xid = str(xid)
            g = f.geometry()
            if g is None or g.isNull() or g.isEmpty():
                continue
            grp = groups.setdefault(xid, {'tipo': tipo, 'geoms': []})
            grp['geoms'].append(QgsGeometry(g))

        records = []
        for xid, data in groups.items():
            geom = self._dissolve_for_sketch(data['geoms'])
            area = round(geom.area(), 2) if geom is not None else None
            records.append({
                'audinot_id': xid,
                'estado': 'INFRAESTRUCTURA',
                'tipo_recinto': data['tipo'],
                'titular_a': '', 'titular_d': '',
                'titular_cambia': False,
                'sup_a': None,
                'sup_d': area,
                'var_sup': None, 'var_sup_pct': None, 'var_perim': None,
                'n_partes_a': None, 'n_partes_d': None, 'n_islas_delta': None,
                'notifica_param': False, 'notifica_legal': False, 'notif_divergen': False,
                'n_alertas': 0,
                'sup_t24_a': None, 'sup_t24_d': None,
                'sup_gml_a': None, 'sup_gml_d': None,
                'val_pct_a': None, 'val_pct_d': None,
                'val_pct_gml_a': None, 'val_pct_gml_d': None,
                'val_gml_d_supera': False,
                'geom_a': None,
                'geom_d': geom,
                'bbox': None,
                'croquis_svg': '',
                'conclusion_param': '', 'conclusion_legal': '',
                'audinot_json': '',
                'revision_estado': '',
                'revision_obs': '',
                'revision_fecha': None,
                'revision_desactualizada': False,
            })

        return records

    # ------------------------------------------------------------------
    # Ficha individual imprimible (botón "Exportar ficha HTML" de la
    # Ficha 4: Auditoría)
    # ------------------------------------------------------------------
    @staticmethod
    def _render_flat_t24_gml_line(attrs):
        """Versión de _render_supft24_row que NO necesita las geometrías
        Antes/Después (el GeoPackage de auditoría solo conserva la
        geometría de Después): usa únicamente los campos PLANOS ya
        calculados y guardados por build_audit_records (sup_t24_a/d,
        sup_gml_a/d, val_pct_a/d, val_pct_gml_d, val_gml_d_supera). Debe
        mantenerse alineada visualmente con TabAudit._render_t24_gml_line
        (ui/components/tab_audit.py), que es la misma lógica para el
        panel de detalle dentro de QGIS."""
        def _fmt(v):
            return f"{v:g}" if isinstance(v, (int, float)) else "?"

        def _pct_span(pct, supera=False, positivo=False):
            if not isinstance(pct, (int, float)):
                return '<span style="color:#888">?</span>'
            if not supera:
                color = "#27ae60"
            else:
                color = "#e67e22" if positivo else "#8e44ad"
            return f'<span style="color:{color}; font-weight:bold">{pct:+.2f}%</span>'

        val_pct_gml_d = attrs.get('val_pct_gml_d')
        supera = bool(attrs.get('val_gml_d_supera'))
        positivo = bool(val_pct_gml_d and val_pct_gml_d > 0)

        return (
            f"<b>supfT24:</b> {_fmt(attrs.get('sup_t24_a'))} m² → {_fmt(attrs.get('sup_t24_d'))} m² &nbsp;&nbsp; "
            f"<b>Superficie GML:</b> {_fmt(attrs.get('sup_gml_a'))} m² → {_fmt(attrs.get('sup_gml_d'))} m²<br>"
            f"<b>% Validación (T24 vs. gráfica):</b> {_pct_span(attrs.get('val_pct_a'))} → "
            f"{_pct_span(attrs.get('val_pct_d'))} &nbsp;&nbsp; "
            f"<b>% Validación GML (T24 vs. GML) Después:</b> {_pct_span(val_pct_gml_d, supera, positivo)}<br>"
        )

    def generate_parcel_card_html(self, attrs, audinot_json, thresholds=None):
        """Genera una página HTML AUTOCONTENIDA con el mismo aspecto
        (misma hoja de estilos, mismo croquis SVG con leyenda y escala,
        misma tabla de aditamentos) que la tarjeta de esta finca en el
        informe completo -- pero construida SOLO a partir de lo que ya
        está guardado en el GeoPackage de auditoría, sin volver a tocar
        las capas Antes/Después ni recalcular métricas.

        attrs: dict con los campos planos de la feature de auditoría
               (audinot_id, estado, titular_a/d, sup_a/d, croquis_svg,
               conclusion_param/legal, revision_estado/obs/fecha, etc.
               -- ver CALC_FIELDS/REVIEW_FIELDS en core/audit_service.py).
        audinot_json: dict ya decodificado del campo 'audinot_json'
               (paquete completo por finca, ver build_audit_records).
        thresholds: opcional, los de la Ficha 3 vigentes AHORA MISMO (si
               se pasan, se usan solo para resaltar en rojo la tabla de
               aditamentos con el mismo criterio que usaría un informe
               recién generado; si no se pasan, se usan los umbrales por
               defecto de _generate_adit_table_rows).

        NOTA: 'conclusion_param'/'conclusion_legal' llegan ya como texto
        plano (sin los resaltados de color de la prosa del informe
        completo, porque build_audit_records los guarda con
        _html_to_plain para poder mostrarlos también en cualquier tabla
        de atributos de QGIS): aquí se muestran tal cual, como párrafo
        normal.
        """
        aid = attrs.get('audinot_id') or ''
        estado = attrs.get('estado') or ''
        audinot_json = audinot_json or {}

        adit_content_html, adit_alerts, adit_total = self._generate_adit_table_rows(
            {'aditamentos': audinot_json.get('aditamentos', {})}, thresholds
        )
        if adit_content_html:
            adit_html = f"""
            <div class="panel" style="border-top:1px solid #eee; background:#fcfcfc; padding:15px">
                <div class="panel-title">AUDITORÍA DE ADITAMENTOS ({adit_alerts} alerta(s) de {adit_total})</div>
                <table class="mini-table">
                    <colgroup>
                        <col style="width: 35%"><col style="width: 15%"><col style="width: 15%"><col style="width: 12%"><col style="width: 14px"><col style="width: 12%"><col style="width: 14px">
                    </colgroup>
                    <tr><th>ELEMENTO</th><th class="num-col">Antes</th><th class="num-col">Después</th><th class="num-col">Var</th><th></th><th class="num-col">%</th><th></th></tr>
                    {adit_content_html}
                </table>
            </div>"""
        else:
            adit_html = ""

        t24_line = self._render_flat_t24_gml_line(attrs)

        def _esc(v):
            return html_lib.escape(str(v)) if v not in (None, '') else ''

        titular_cambia_tag = (
            ' <span style="color:#e67e22; font-weight:bold">(cambia)</span>'
            if audinot_json.get('titularCambia') else ''
        )

        rev_estado = attrs.get('revision_estado') or ''
        rev_txt = {'si': '✔ NOTIFICAR', 'no': '✘ NO NOTIFICAR', 'rev': '👁 REVISAR'}.get(rev_estado, '⬜ Sin revisar')
        rev_color = {'si': '#c0392b', 'no': '#27ae60', 'rev': '#2980b9'}.get(rev_estado, '#7f8c8d')
        rev_obs_raw = attrs.get('revision_obs') or ''
        rev_obs = html_lib.escape(rev_obs_raw).replace('\n', '<br>') if rev_obs_raw else '<i style="color:#999">(sin observaciones)</i>'
        rev_fecha = _esc(attrs.get('revision_fecha')) or '—'
        desact_html = (
            '<p style="color:#b45309; font-weight:bold">⚠ Las métricas de esta finca han cambiado desde '
            'la última revisión. Comprueba si la decisión anterior sigue siendo válida.</p>'
            if attrs.get('revision_desactualizada') else ''
        )

        param_txt = "SÍ" if attrs.get('notifica_param') else "NO"
        legal_txt = "SÍ" if attrs.get('notifica_legal') else "NO"
        diverge = ' ⚠ (las dos interpretaciones no coinciden)' if attrs.get('notif_divergen') else ''

        def _pill(txt, positive):
            bg = '#fdecea' if positive else '#eafaf1'
            fg = '#c0392b' if positive else '#1e8449'
            return f'<span class="pill" style="background:{bg}; color:{fg}">{_esc(txt)}</span>'

        param_pill = _pill(param_txt, bool(attrs.get('notifica_param')))
        legal_pill = _pill(legal_txt, bool(attrs.get('notifica_legal')))

        conclusion_html = ""
        if attrs.get('conclusion_param'):
            conclusion_html += f'<p><span class="tag-param">⚠ Conclusión paramétrica</span><br>{_esc(attrs.get("conclusion_param"))}</p>'
        if attrs.get('conclusion_legal'):
            conclusion_html += f'<p><span class="tag-legal">⚖ Conclusión alternativa</span><br>{_esc(attrs.get("conclusion_legal"))}</p>'
        if not conclusion_html:
            conclusion_html = '<p class="conclusion-ok"><b>✓ Sin incidencias que motiven notificación.</b></p>'
        conclusion_box = f'<div class="callout callout-conclusion">{conclusion_html}</div>'

        rev_bg = {'si': '#fdecea', 'no': '#eafaf1'}.get(rev_estado, '#f4f5f6')
        estado_lc = (estado or '').strip().lower()
        estado_bg = {'ok': '#2ecc71', 'alerta': '#e74c3c', 'aviso': '#f39c12'}.get(estado_lc, 'rgba(255,255,255,0.18)')

        html = f"""<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Ficha {_esc(aid)} — AudiNOT</title>
<style>
{self._report_css()}
/* ------------------------------------------------------------------
   Ficha individual imprimible: la hoja de estilos de arriba (compartida
   con el informe completo) está pensada para un panel con sidebar fijo
   a pantalla completa; aquí se reconvierte en un documento A4 normal,
   pensado tanto para pantalla (vista previa tipo "hoja de papel") como
   para impresión/PDF real.
   ------------------------------------------------------------------ */
@page {{ size: A4; margin: 16mm 14mm; }}

html {{ background: #dfe3e8; }}
body {{
    display: block; height: auto; overflow: visible; padding-top: 0 !important;
    background: #dfe3e8; font-family: 'Segoe UI', Arial, sans-serif; color: #2c3e50;
    -webkit-print-color-adjust: exact; print-color-adjust: exact;
}}

/* "Hoja" A4 centrada en pantalla; en impresión pierde el marco y las
   sombras y pasa a ocupar el área normal de la página. */
.print-wrapper {{
    width: 210mm; min-height: 297mm; box-sizing: border-box;
    margin: 10mm auto; padding: 16mm 14mm 14mm 14mm;
    background: #fff; box-shadow: 0 4px 22px rgba(0,0,0,0.18);
    border-radius: 2px;
}}

/* Barra de acciones flotante, solo en pantalla */
.no-print {{ position: fixed; top: 14px; right: 18px; z-index: 50; }}
.print-btn {{
    background: var(--primary); color: #fff; border: none; padding: 9px 18px;
    border-radius: 5px; font-size: 0.9em; cursor: pointer; box-shadow: 0 2px 6px rgba(0,0,0,0.25);
    font-family: inherit;
}}
.print-btn:hover {{ background: #1a252f; }}

/* Letterhead / cabecera de la ficha */
.letterhead {{
    display: flex; justify-content: space-between; align-items: flex-start;
    border-bottom: 3px solid var(--primary); padding-bottom: 10px; margin-bottom: 4px;
}}
.letterhead .brand {{ font-size: 0.78em; letter-spacing: 2px; text-transform: uppercase; color: #95a5a6; font-weight: 700; }}
.letterhead .brand-sub {{ font-size: 0.72em; color: #b0b7bd; margin-top: 1px; }}
.letterhead .meta-right {{ text-align: right; font-size: 0.72em; color: #95a5a6; }}

.audit-card {{ box-shadow: none; border: none; margin: 0; border-radius: 0; }}
.card-header {{
    background: var(--primary); background: linear-gradient(135deg, var(--primary), var(--sec));
    color: #fff; padding: 16px 20px; border-radius: 6px; margin: 10px 0 16px 0;
    display: flex; justify-content: space-between; align-items: center;
}}
.card-title h2 {{ margin: 0; color: #fff; font-size: 1.55em; letter-spacing: 0.3px; }}
.card-title .card-subtitle {{ display: block; color: rgba(255,255,255,0.65); font-size: 0.62em; font-weight: normal; letter-spacing: 1px; text-transform: uppercase; margin-top: 2px; }}
.card-title span.estado-badge {{
    display: inline-block; margin-top: 6px; background: {estado_bg}; color: #fff;
    padding: 3px 12px; border-radius: 20px; font-size: 0.72em; font-weight: 600; letter-spacing: 0.5px;
}}

/* Apartados destacados: cada bloque de contenido va en su propia
   "sección" con etiqueta en mayúsculas y borde de acento, en vez del
   texto corrido que usaba la vista anterior. */
.section {{ margin: 0 0 14px 0; }}
.section-label {{
    font-size: 0.72em; text-transform: uppercase; letter-spacing: 1.2px; color: #7f8c8d;
    font-weight: 700; border-left: 4px solid var(--accent); padding-left: 9px; margin-bottom: 8px;
}}
.resumen-body {{ padding: 0; }}

.data-grid {{ display: grid; grid-template-columns: 1fr 1fr; gap: 8px 24px; font-size: 0.92em; margin-bottom: 6px; }}
.data-grid .full {{ grid-column: 1 / -1; }}
.data-grid dt {{ color: #7f8c8d; font-size: 0.78em; text-transform: uppercase; letter-spacing: 0.4px; margin: 0; }}
.data-grid dd {{ margin: 1px 0 0 0; font-weight: 600; color: #2c3e50; }}

.pill {{ display: inline-block; padding: 2px 10px; border-radius: 20px; font-size: 0.85em; font-weight: 700; }}

.callout {{ border: 1px solid var(--border); border-left: 4px solid var(--accent); background: #f8fafc; border-radius: 4px; padding: 10px 14px; margin: 10px 0; }}
.callout p {{ margin: 4px 0; }}
.callout .tag-param {{ color: #c0392b; font-weight: 700; font-size: 0.85em; }}
.callout .tag-legal {{ color: #8e44ad; font-weight: 700; font-size: 0.85em; }}
.callout .conclusion-ok {{ color: #1e8449; }}

.decision-banner {{
    background: {rev_bg}; border: 1px solid var(--border); border-left: 4px solid {rev_color};
    border-radius: 4px; padding: 12px 16px; margin-top: 4px;
}}
.decision-banner .decision-line {{ font-size: 1.02em; }}
.decision-banner .decision-line b {{ color: {rev_color}; }}
.decision-banner .obs-label {{ color: #7f8c8d; font-size: 0.8em; text-transform: uppercase; letter-spacing: 0.5px; margin-top: 8px; display: block; }}

.panel {{ border-radius: 4px; border: 1px solid var(--border); background: #fcfcfc; margin-bottom: 14px; padding: 12px 14px !important; }}

@media print {{
    html, body {{ background: #fff !important; }}
    .no-print {{ display: none !important; }}
    .print-wrapper {{ width: auto; min-height: 0; margin: 0; padding: 0; box-shadow: none; border-radius: 0; }}
    .letterhead {{ margin-bottom: 2px; page-break-after: avoid; }}
    .card-header {{ margin-top: 6px; page-break-after: avoid; page-break-inside: avoid; }}
    /* "page-break-inside: avoid" en .section (el contenedor grande de
       croquis + datos + conclusion) era la causa de la hoja en blanco:
       si ese bloque no cabia entero en lo que quedaba de pagina tras la
       cabecera, el navegador lo empujaba COMPLETO a la pagina 2, dejando
       la pagina 1 con solo la cabecera y un hueco enorme debajo. Ahora
       se deja que la seccion se reparta con normalidad entre paginas y
       solo se protegen de un corte feo sus piezas realmente indivisibles
       (croquis, tabla de aditamentos, panel de revision, cada linea del
       cuadro de datos). */
    .section {{ page-break-inside: auto; }}
    .section-label {{ page-break-after: avoid; }}
    .panel-title {{ page-break-after: avoid; }}
    .data-grid {{ page-break-inside: avoid; }}
    .data-grid > div {{ page-break-inside: avoid; }}
    .callout, .decision-banner, .panel {{ page-break-inside: avoid; }}
    .audit-card svg {{ page-break-inside: avoid; }}
    * {{ orphans: 3; widows: 3; }}
}}
</style>
</head>
<body>
<button class="no-print print-btn" onclick="window.print()">🖨️ Imprimir / Guardar PDF</button>
<div class="print-wrapper">
  <div class="letterhead">
    <div>
      <div class="brand">AudiNOT</div>
      <div class="brand-sub">Ficha individual de auditoría ANTES vs DESPUÉS</div>
    </div>
    <div class="meta-right">
      Generada el {datetime.now().strftime('%d/%m/%Y %H:%M')}
    </div>
  </div>

  <div class="audit-card">
    <div class="card-header">
      <div class="card-title">
        <span class="card-subtitle">Finca</span>
        <h2>{_esc(aid)}</h2>
        <span class="estado-badge">{_esc(estado)}</span>
      </div>
    </div>

    <div class="section">
      {attrs.get('croquis_svg') or ''}
      <dl class="data-grid">
        <div class="full"><dt>Nº propietario</dt><dd>{_esc(audinot_json.get('titularAntes'))} → {_esc(audinot_json.get('titularDespues'))}{titular_cambia_tag}</dd></div>
        <div><dt>Superficie</dt><dd>{attrs.get('sup_a')} m² → {attrs.get('sup_d')} m² &nbsp;(Δ {attrs.get('var_sup')} m², {attrs.get('var_sup_pct')}%)</dd></div>
        <div><dt>Perímetro / partes</dt><dd>Δ {attrs.get('var_perim')} m &nbsp;·&nbsp; {attrs.get('n_partes_a')} → {attrs.get('n_partes_d')} partes</dd></div>
        <div class="full"><dt>Validación T24 / GML</dt><dd style="font-weight:normal">{t24_line}</dd></div>
        <div><dt>Notifica (paramétrico)</dt><dd>{param_pill}</dd></div>
        <div><dt>Notifica (alternativo)</dt><dd>{legal_pill}{f'<span style="color:#e67e22; font-weight:600; font-size:0.78em"> {diverge}</span>' if diverge else ''}</dd></div>
      </dl>
      {conclusion_box}
    </div>

    {f'<div class="section">{adit_html}</div>' if adit_html else ''}

    <div class="section">
      <div class="section-label">📝 Revisión de auditoría</div>
      {desact_html}
      <div class="decision-banner">
        <div class="decision-line"><b>{rev_txt}</b> <span style="color:#999">&nbsp;({rev_fecha})</span></div>
        <span class="obs-label">Observación</span>
        {rev_obs}
      </div>
    </div>
  </div>
</div>
</body>
</html>"""
        return html

    def render_parcel_metrics_preview(self, attrs, audinot_json, croquis_html=None,
                                       thresholds=None, special_ranges=None,
                                       special_owners=None):
        """Genera una página HTML AUTOCONTENIDA con la "sección de
        métricas" de UNA finca, tal y como aparece hoy en las páginas por
        finca del Informe HTML completo (`_build_html`, modo
        summary_mode=False) -- pero reconstruida SOLO a partir de lo que
        ya está guardado en el GeoPackage de auditoría (audinot_json +
        campos planos), sin recalcular nada ni tocar geometría real.

        Es una VISTA PREVIA desechable (botón "Vista previa de métricas"
        de la Ficha 4): a diferencia de generate_parcel_card_html,
        incluye las tablas de MÉTRICAS GEOMÉTRICAS / FACHADAS (con
        columnas Antes/Después/Var/Marca/%/Marca), HUECOS/ISLAS, DINÁMICA
        TERRITORIAL y la AUDITORÍA DE ADITAMENTOS con su gráfico de
        incidencia -- exactamente lo que generate_parcel_card_html deja
        fuera. NO incluye el panel interactivo de anotaciones del usuario
        (pertenece al flujo de revisión del informe multi-finca). El
        croquis SÍ se incluye, al final de la página (ver croquis_html):
        aunque ya es visible en el panel de la Ficha 4 justo encima del
        botón, esta vista previa es un documento pensado para poder
        imprimirse o compartirse de forma autónoma, así que lleva también
        su propio croquis.

        attrs: dict con los campos planos de la feature de auditoría
               (audinot_id, estado, conclusion_param/legal, sup_a/d...).
        audinot_json: dict ya decodificado del campo 'audinot_json'.
        croquis_html: fragmento HTML del croquis ya renderizado (campo
               'croquis_svg' de la feature de auditoría, el mismo que
               pinta el panel de la Ficha 4). Es un <div
               class="sketch-section"> autocontenido que reutiliza las
               clases .sketch-* de _report_css(), ya incluido en el
               <style> de esta misma página -- no requiere recalcularlo.
               Si no se pasa (None/''), la sección del croquis se omite.
        thresholds/special_ranges/special_owners: los tres sub-dicts que
               devuelve AuditService.read_parameters() (vigentes en el
               momento del cálculo guardado). Si no se pasan, se usan los
               valores por defecto de cada método auxiliar.

        NOTA sobre duplicación de umbrales: igual que ya hace
        build_audit_records() (ver su comentario), aquí se repite el
        pequeño bloque de comprobación de "marcas" (self._chk/_chk_neg)
        que en el informe completo vive entrelazado dentro del bucle
        gigante de _build_html(), en vez de tocar ese método. El resto de
        paneles reutiliza tal cual las funciones granulares ya existentes
        (_render_islands_section, _render_flows,
        _generate_adit_table_rows, _generate_adit_section_layout,
        _render_flat_t24_gml_line, _report_css).

        NOTA sobre "Nº Colindantes": esa fila del panel FACHADAS del
        informe completo (neighbors_a/neighbors_d) no viaja ni en
        audinot_json ni en ningún campo plano -- se pierde tras el
        cálculo -- así que aquí se omite.
        """
        thresholds = thresholds or {}
        special_ranges = special_ranges or {}
        special_owners = special_owners or {}
        audinot_json = audinot_json or {}

        aid = attrs.get('audinot_id') or audinot_json.get('id') or ''
        estado = attrs.get('estado') or audinot_json.get('estado') or ''
        st = audinot_json.get('estado') or estado

        def _esc(v):
            return html_lib.escape(str(v)) if v not in (None, '') else ''

        # ------------------------------------------------------------
        # 1. Geometría (tabla de mapeo del prompt de implementación)
        # ------------------------------------------------------------
        area_a = audinot_json.get('superficieAntes')
        area_d = audinot_json.get('superficieDespues')
        if area_a is None:
            area_a = attrs.get('sup_a') or 0.0
        if area_d is None:
            area_d = attrs.get('sup_d') or 0.0
        delta_area = area_d - area_a
        pct_area = self._get_pct(area_a, area_d)
        m_a_abs = self._chk(delta_area, thresholds.get('area_abs'))
        m_a_pct = self._chk(pct_area, thresholds.get('area_pct'))
        cls_area = "text-pos" if delta_area > 0 else "text-neg" if delta_area < 0 else ""

        perim_a = audinot_json.get('perimetroAntes') or 0.0
        perim_d = audinot_json.get('perimetroDespues') or 0.0
        delta_perim = perim_d - perim_a
        pct_perim = self._get_pct(perim_a, perim_d)
        m_p_abs = self._chk(delta_perim, thresholds.get('perim_abs'))
        m_p_pct = self._chk(pct_perim, thresholds.get('perim_pct'))

        grav = audinot_json.get('gravelius') or {}
        grav_a = grav.get('antes') or 0.0
        grav_d = grav.get('despues') or 0.0
        grav_delta = grav_d - grav_a
        pct_grav = self._get_pct(grav_a, grav_d)
        m_g_pct = self._chk(grav_delta, thresholds.get('gravelius'))

        convex = audinot_json.get('convexidad') or {}
        convex_a = convex.get('antes', 1.0)
        convex_d = convex.get('despues', 1.0)
        if convex_a is None:
            convex_a = 1.0
        if convex_d is None:
            convex_d = 1.0
        delta_convex = convex_d - convex_a
        pct_convex = self._get_pct(convex_a, convex_d)
        m_c_abs = self._chk(delta_convex, thresholds.get('convexity_abs'))
        m_c_pct = self._chk(pct_convex, thresholds.get('convexity_pct'))

        stability_pct = audinot_json.get('estabilidadLindePct')
        if stability_pct is None:
            stability_pct = 100.0
        m_stab = self._chk_neg(stability_pct, thresholds.get('stability_pct'))

        desp = audinot_json.get('desplazamiento') or {}
        displacement = desp.get('m') or 0.0
        displacement_dir = desp.get('direccion') or '-'
        m_desp = self._chk(displacement, thresholds.get('desp_max'))

        partes = audinot_json.get('partes') or {}
        parts_a = partes.get('antes') or 1
        parts_d = partes.get('despues') or 1
        delta_parts = parts_d - parts_a
        pct_parts = (delta_parts / parts_a * 100) if parts_a else 0
        topo_label = "Mono-parte" if parts_d <= 1 else f"Multi-parte: {parts_d} partes"

        # ------------------------------------------------------------
        # 2. Fachadas (4 tipos fijos, ya agregados en audinot_json)
        # ------------------------------------------------------------
        fixed_facade_types = ['VIALES', 'CURSOS AGUA', 'EDIFICACIONES', 'EXCLUIDO']
        facade_labels = {'VIALES': 'Viales', 'CURSOS AGUA': 'AGUAS', 'EDIFICACIONES': 'EDIF', 'EXCLUIDO': 'EXCL'}
        fachadas = audinot_json.get('fachadas') or {}
        facade_rows_html = ""
        f_alerts = 0
        for t_code in fixed_facade_types:
            fdata = fachadas.get(t_code) or {}
            val_a = fdata.get('antes') or 0.0
            val_d = fdata.get('despues') or 0.0
            delta = fdata.get('delta')
            if delta is None:
                delta = val_d - val_a
            pct = fdata.get('pct')
            if pct is None:
                pct = self._get_pct(val_a, val_d)
            cls = "text-pos" if delta > 0.01 else "text-neg" if delta < -0.01 else ""
            label = facade_labels.get(t_code, t_code)

            f_lims = thresholds.get('facades', {})
            f_key = 'VIAL' if 'VIAL' in t_code else 'AGUA' if 'AGUA' in t_code else 'EDIF' if 'EDIF' in t_code else 'EXCL'
            lims = f_lims.get(f_key, {})
            m_f_abs = self._chk(delta, lims.get('abs'))
            m_f_pct = self._chk(pct, lims.get('pct'))
            if m_f_abs or m_f_pct:
                f_alerts += 1

            facade_rows_html += f"""
                <tr>
                    <td>{label} (m)</td>
                    <td class="val-num">{self._fmt_val(val_a)}</td>
                    <td class="val-num">{self._fmt_val(val_d)}</td>
                    <td class="val-num {cls} {'diff-nonzero' if abs(delta) > 0.001 else ''}">{self._fmt_diff(delta)}</td>
                    <td class="mark-slot">{m_f_abs}</td>
                    <td class="val-num {cls} {'diff-nonzero' if abs(delta) > 0.001 else ''}">{self._fmt_pct(pct)}</td>
                    <td class="mark-slot">{m_f_pct}</td>
                </tr>
            """

        # ------------------------------------------------------------
        # 3. Huecos / islas
        # ------------------------------------------------------------
        isl = audinot_json.get('islas')
        islands_html = self._render_islands_section(isl, thresholds)
        i_alerts = 0
        if isl:
            delta_isl_cnt = isl.get('delta_count', 0) or 0
            if delta_isl_cnt != 0:
                i_alerts += 1
            pct_rings_area = self._get_pct(isl.get('area_a', 0.0) or 0.0, isl.get('area_d', 0.0) or 0.0)
            m_inv = self._chk(pct_rings_area, thresholds.get('invasion_pct'))
            if m_inv:
                i_alerts += 1
            if abs(isl.get('delta_area', 0.0) or 0.0) > 0.1 or (isl.get('displacement', 0.0) or 0.0) > 0.05:
                i_alerts += 1

        # ------------------------------------------------------------
        # 4. Dinámica territorial (trasvases ya guardados tal cual)
        # ------------------------------------------------------------
        flows_in_html = self._render_flows(audinot_json.get('inputs', []), st, 'ALTA', special_owners, 'input')
        flows_out_html = self._render_flows(audinot_json.get('outputs', []), st, 'BAJA', special_owners, 'output')

        # ------------------------------------------------------------
        # 5. Aditamentos + gráfico de incidencia G-I-F-A
        # ------------------------------------------------------------
        adit_content_html, adit_alerts, adit_total = self._generate_adit_table_rows(audinot_json, thresholds)

        g_alerts = 0
        if m_a_abs or m_a_pct: g_alerts += 1
        if m_p_abs or m_p_pct: g_alerts += 1
        if m_g_pct: g_alerts += 1
        if m_c_abs or m_c_pct: g_alerts += 1
        if m_stab: g_alerts += 1
        if m_desp: g_alerts += 1
        if delta_parts != 0: g_alerts += 1

        a_alerts = adit_alerts
        max_a = max(g_alerts, i_alerts, f_alerts, a_alerts)
        W = 100.0 / max_a if max_a > 0 else 0
        pillar_scores = {'G': g_alerts * W, 'I': i_alerts * W, 'F': f_alerts * W, 'A': a_alerts * W}
        adit_html = self._generate_adit_section_layout(adit_content_html, pillar_scores)

        # ------------------------------------------------------------
        # 6. Fila T24 / GML y conclusiones (texto plano, sin geometría)
        # ------------------------------------------------------------
        t24_line = self._render_flat_t24_gml_line(attrs)

        # Formateo de los umbrales configurados (sección "Umbrales
        # configurados" más abajo): a diferencia de los valores propios
        # de la finca, un umbral puede faltar sin más (config antigua,
        # .anot incompleto...) -- self._fmt_val() no admite None
        # (hace abs(val) directamente), así que aquí se cubre ese caso
        # con un guion en vez de dejar que reviente el render.
        def _fmt_th(v):
            return self._fmt_val(v) if isinstance(v, (int, float)) else '—'

        # Sub-dicts de umbrales por fachada/aditamento: se sacan aquí como
        # variables normales (en vez de encadenar .get(...).get(...) en la
        # plantilla) para poder cubrir con `or {}` cualquier nivel ausente
        # sin arriesgarse a errores de precedencia en el f-string.
        fac_th = thresholds.get('facades') or {}
        adit_th_lims = thresholds.get('aditamentos') or {}

        conclusion_html = ""
        if attrs.get('conclusion_param'):
            conclusion_html += f'<p><span class="tag-param">Conclusión paramétrica</span><br>{_esc(attrs.get("conclusion_param"))}</p>'
        if attrs.get('conclusion_legal'):
            conclusion_html += f'<p><span class="tag-legal">Conclusión alternativa</span><br>{_esc(attrs.get("conclusion_legal"))}</p>'
        if not conclusion_html:
            conclusion_html = '<p class="conclusion-ok"><b>Sin incidencias que motiven notificación.</b></p>'
        conclusion_box = f'<div class="callout callout-conclusion">{conclusion_html}</div>'

        razones = audinot_json.get('razonesNotificacion') or []
        if razones:
            razones_html = '<ul style="margin:6px 0 0 0; padding-left:18px">' + "".join(
                f'<li>{_esc(r)}</li>' for r in razones
            ) + '</ul>'
            conclusion_box += (
                '<div class="callout" style="border-left-color:#e67e22">'
                '<b style="font-size:0.75em; text-transform:uppercase; letter-spacing:0.5px; color:#7f8c8d">'
                'Razones de notificación</b>'
                f'{razones_html}</div>'
            )

        estado_lc = (estado or '').strip().lower()
        estado_bg = {'ok': '#2ecc71', 'alerta': '#e74c3c', 'aviso': '#f39c12'}.get(estado_lc, 'rgba(255,255,255,0.18)')

        html = f"""<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Vista previa de métricas — Finca {_esc(aid)} — AudiNOT</title>
<style>
{self._report_css()}
@page {{ size: A4; margin: 16mm 14mm; }}

html {{ background: #dfe3e8; }}
body {{
    display: block; height: auto; overflow: visible; padding-top: 0 !important;
    background: #dfe3e8; font-family: 'Segoe UI', Arial, sans-serif; color: #2c3e50;
    -webkit-print-color-adjust: exact; print-color-adjust: exact;
}}

.print-wrapper {{
    width: 210mm; min-height: 297mm; box-sizing: border-box;
    margin: 10mm auto; padding: 16mm 14mm 14mm 14mm;
    background: #fff; box-shadow: 0 4px 22px rgba(0,0,0,0.18);
    border-radius: 2px;
}}

.no-print {{ position: fixed; top: 14px; right: 18px; z-index: 50; }}
.print-btn {{
    background: var(--primary); color: #fff; border: none; padding: 9px 18px;
    border-radius: 5px; font-size: 0.9em; cursor: pointer; box-shadow: 0 2px 6px rgba(0,0,0,0.25);
    font-family: inherit;
}}
.print-btn:hover {{ background: #1a252f; }}

/* Texto de las tablas de métricas un pelín más grande que en el resto
   de plantillas (informe completo / ficha exportada): esta vista previa
   se consulta sobre todo en pantalla, y a 0.85em costaba leerla. Solo
   afecta a esta página (no toca _report_css, que comparten las demás
   plantillas).
   OJO: ese 0.95em solo se aplica en impresión/PDF (@media print), que es
   donde hay márgen de sobra en la página A4. En pantalla (navegador) el
   ancho disponible es más ajustado y ese tamaño hacía que los valores de
   las columnas (Var/%) se solaparan con la columna siguiente, así que en
   @media screen se mantiene un tamaño más contenido. */
.mini-table th, .mini-table td {{ padding: 4px 0; }}
.panel-title {{ font-size: 0.85em; }}

@media print {{
    .mini-table {{ font-size: 0.95em; }}
}}
@media screen {{
    .mini-table {{ font-size: 0.82em; }}
}}

.letterhead {{
    display: flex; justify-content: space-between; align-items: flex-start;
    border-bottom: 3px solid var(--primary); padding-bottom: 10px; margin-bottom: 4px;
}}
.letterhead .brand {{ font-size: 0.78em; letter-spacing: 2px; text-transform: uppercase; color: #95a5a6; font-weight: 700; }}
.letterhead .brand-sub {{ font-size: 0.72em; color: #b0b7bd; margin-top: 1px; }}
.letterhead .brand-date {{ font-size: 0.72em; color: #95a5a6; margin-top: 2px; }}
.letterhead .meta-right {{ text-align: right; font-size: 0.72em; color: #95a5a6; }}
.letterhead .meta-right img.brand-logo {{ display: block; height: 1.1cm; width: auto; margin: 0 0 4px auto; opacity: 0.92; }}

.audit-card {{ box-shadow: none; border: none; margin: 0; border-radius: 0; }}
.card-header {{
    background: var(--primary); background: linear-gradient(135deg, var(--primary), var(--sec));
    color: #fff; padding: 16px 20px; border-radius: 6px; margin: 10px 0 16px 0;
    display: flex; justify-content: space-between; align-items: center;
}}
.card-title h2 {{ margin: 0; color: #fff; font-size: 1.55em; letter-spacing: 0.3px; }}
.card-title .card-subtitle {{ display: block; color: rgba(255,255,255,0.65); font-size: 0.62em; font-weight: normal; letter-spacing: 1px; text-transform: uppercase; margin-top: 2px; }}
.card-title span.estado-badge {{
    display: inline-block; margin-top: 6px; background: {estado_bg}; color: #fff;
    padding: 3px 12px; border-radius: 20px; font-size: 0.72em; font-weight: 600; letter-spacing: 0.5px;
}}

.section {{ margin: 0 0 14px 0; }}
.section-label {{
    font-size: 0.72em; text-transform: uppercase; letter-spacing: 1.2px; color: #7f8c8d;
    font-weight: 700; border-left: 4px solid var(--accent); padding-left: 9px; margin-bottom: 8px;
}}

.callout {{ border: 1px solid var(--border); border-left: 4px solid var(--accent); background: #f8fafc; border-radius: 4px; padding: 10px 14px; margin: 10px 0; }}
.callout p {{ margin: 4px 0; }}
.callout .tag-param {{ color: #c0392b; font-weight: 700; font-size: 0.85em; }}
.callout .tag-legal {{ color: #8e44ad; font-weight: 700; font-size: 0.85em; }}
.callout .conclusion-ok {{ color: #1e8449; }}

.panel {{ border-radius: 4px; border: 1px solid var(--border); background: #fcfcfc; margin-bottom: 14px; padding: 12px 14px !important; }}

.thresholds-compact {{
    display: flex; flex-wrap: wrap; row-gap: 4px; column-gap: 0;
    font-size: 0.8em; color: #34495e;
}}
.thresholds-compact span {{ white-space: nowrap; }}
.thresholds-compact span:not(:last-child)::after {{
    content: "•"; color: #bbb; margin: 0 10px;
}}

@media print {{
    html, body {{ background: #fff !important; }}
    .no-print {{ display: none !important; }}
    .print-wrapper {{ width: auto; min-height: 0; margin: 0; padding: 0; box-shadow: none; border-radius: 0; }}
    .letterhead {{ margin-bottom: 2px; page-break-after: avoid; }}
    .card-header {{ margin-top: 6px; page-break-after: avoid; page-break-inside: avoid; }}
    .section {{ page-break-inside: auto; }}
    .section-label {{ page-break-after: avoid; }}
    .panel-title {{ page-break-after: avoid; }}
    .callout, .panel {{ page-break-inside: avoid; }}
    .grid-panels {{ page-break-inside: auto; }}
    * {{ orphans: 3; widows: 3; }}
}}
</style>
</head>
<body>
<button class="no-print print-btn" onclick="window.print()">Imprimir / Guardar PDF</button>
<div class="print-wrapper">
  <div class="letterhead">
    <div>
      <div class="brand">AudiNOT</div>
      <div class="brand-sub">Vista previa de métricas</div>
      <div class="brand-date">Generada el {datetime.now().strftime('%d/%m/%Y %H:%M')}</div>
    </div>
    <div class="meta-right">
      {f'<img class="brand-logo" src="{self._tragsatec_logo_data_uri()}" alt="Tragsatec">' if self._tragsatec_logo_data_uri() else ''}
    </div>
  </div>

  <div class="audit-card">
    <div class="card-header">
      <div class="card-title">
        <span class="card-subtitle">Finca</span>
        <h2>{_esc(aid)}</h2>
        <span class="estado-badge">{_esc(estado)}</span>
      </div>
    </div>

    <div class="section">
      <div style="font-size:0.85em; color:#555">{t24_line}</div>
    </div>

    <div class="grid-panels">
        <div class="panel">
            <div class="panel-title">MÉTRICAS GEOMÉTRICAS ({topo_label})</div>
            <table class="mini-table">
                <colgroup>
                    <col style="width: 35%"><col style="width: 15%"><col style="width: 15%"><col style="width: 12%"><col style="width: 14px"><col style="width: 12%"><col style="width: 14px">
                </colgroup>
                <tr><th>Parámetro</th><th class="num-col">Antes</th><th class="num-col">Después</th><th class="num-col">Var</th><th></th><th class="num-col">%</th><th></th></tr>
                <tr>
                    <td>Superficie (m²)</td>
                    <td class="val-num">{self._fmt_val(area_a)}</td>
                    <td class="val-num">{self._fmt_val(area_d)}</td>
                    <td class="val-num {cls_area} {'diff-nonzero' if abs(delta_area) > 0.001 else ''}">{self._fmt_diff(delta_area)}</td>
                    <td class="mark-slot">{m_a_abs}</td>
                    <td class="val-num {cls_area} {'diff-nonzero' if abs(delta_area) > 0.001 else ''}">{self._fmt_pct(pct_area)}</td>
                    <td class="mark-slot">{m_a_pct}</td>
                </tr>
                <tr>
                    <td>Perímetro (m)</td>
                    <td class="val-num">{self._fmt_val(perim_a)}</td>
                    <td class="val-num">{self._fmt_val(perim_d)}</td>
                    <td class="val-num {'diff-nonzero' if abs(delta_perim) > 0.001 else ''}">{self._fmt_diff(delta_perim)}</td>
                    <td class="mark-slot">{m_p_abs}</td>
                    <td class="val-num {'diff-nonzero' if abs(delta_perim) > 0.001 else ''}">{self._fmt_pct(pct_perim)}</td>
                    <td class="mark-slot">{m_p_pct}</td>
                </tr>
                <tr>
                    <td>Ancho Gravelius (K)</td>
                    <td class="val-num">{self._fmt_val(grav_a)}</td>
                    <td class="val-num">{self._fmt_val(grav_d)}</td>
                    <td class="val-num {'diff-nonzero' if abs(grav_delta) > 0.001 else ''}">{self._fmt_diff(grav_delta)}</td>
                    <td class="mark-slot">{m_g_pct}</td>
                    <td class="val-num {'diff-nonzero' if abs(grav_delta) > 0.001 else ''}">{self._fmt_pct(pct_grav)}</td>
                    <td class="mark-slot">{m_g_pct}</td>
                </tr>
                <tr>
                    <td>Índice Convexidad</td>
                    <td class="val-num">{self._fmt_val(convex_a)}</td>
                    <td class="val-num">{self._fmt_val(convex_d)}</td>
                    <td class="val-num {'diff-nonzero' if abs(delta_convex) > 0.001 else ''}">{self._fmt_diff(delta_convex)}</td>
                    <td class="mark-slot">{m_c_abs}</td>
                    <td class="val-num {'diff-nonzero' if abs(delta_convex) > 0.001 else ''}">{self._fmt_pct(pct_convex)}</td>
                    <td class="mark-slot">{m_c_pct}</td>
                </tr>
                <tr>
                    <td>Estabilidad Linde (%)</td>
                    <td class="val-num"></td>
                    <td class="val-num"></td>
                    <td class="val-num"></td>
                    <td class="mark-slot"></td>
                    <td class="val-num">{self._fmt_val(stability_pct)}</td>
                    <td class="mark-slot">{m_stab}</td>
                </tr>
                <tr>
                    <td>Multi-parte (Cant)</td>
                    <td class="val-num">{self._fmt_val(parts_a, force_int=True)}</td>
                    <td class="val-num">{self._fmt_val(parts_d, force_int=True)}</td>
                    <td class="val-num {'diff-nonzero' if delta_parts != 0 else ''}">{self._fmt_diff(delta_parts, force_int=True)}</td>
                    <td class="mark-slot">{" *" if delta_parts != 0 else ""}</td>
                    <td class="val-num {'diff-nonzero' if delta_parts != 0 else ''}">{self._fmt_pct(pct_parts)}</td>
                    <td class="mark-slot">{" *" if delta_parts != 0 else ""}</td>
                </tr>
                <tr>
                    <td>Desplazamiento (m)</td>
                    <td class="val-num"></td>
                    <td class="val-num"></td>
                    <td class="val-num {'diff-nonzero' if displacement > 0.05 else ''}" style="text-align:right">{self._fmt_val(displacement)}</td>
                    <td class="mark-slot">{m_desp}</td>
                    <td class="val-num" style="text-align:center; font-weight:bold; color:var(--primary)">{self._get_arrow(displacement_dir)} {displacement_dir}</td>
                    <td></td>
                </tr>
            </table>
        </div>

        <div class="panel">
            <div class="panel-title">INTERACCIÓN CON ENTORNO (FACHADAS)</div>
            <table class="mini-table">
                <colgroup>
                    <col style="width: 35%"><col style="width: 15%"><col style="width: 15%"><col style="width: 12%"><col style="width: 14px"><col style="width: 12%"><col style="width: 14px">
                </colgroup>
                <tr><th>Tipo</th><th class="num-col">Antes</th><th class="num-col">Después</th><th class="num-col">Var</th><th></th><th class="num-col">%</th><th></th></tr>
                {facade_rows_html}
            </table>
        </div>
    </div>

    <div style="display:flex; border-top:1px solid var(--border)">
        <div class="panel" style="flex:1; border-right:1px solid var(--border); background:#fcfcfc; border-bottom:none">
             <div class="panel-title">ANÁLISIS DE HUECOS / ISLAS</div>
             {islands_html}
        </div>
        <div class="panel" style="flex:1; background:#fdfdfd; border-right:none; border-bottom:none">
            <div class="panel-title">DINÁMICA TERRITORIAL</div>
             <div style="display:flex; gap:20px">
                 <div style="flex:1">
                     <h4 style="margin: 0 0 5px 0; font-size:0.85em; color:#666">ORIGEN (INPUTS)</h4>
                     {flows_in_html}
                 </div>
                 <div style="border-left:1px solid #eee"></div>
                 <div style="flex:1">
                     <h4 style="margin: 0 0 5px 0; font-size:0.85em; color:#666">DESTINO (OUTPUTS)</h4>
                     {flows_out_html}
                 </div>
             </div>
        </div>
    </div>

    <div class="section">
      {adit_html}
    </div>

    <div class="section">
      <div class="section-label">Umbrales configurados</div>
      <div class="panel">
        <div class="thresholds-compact">
            <span>Superficie: {_fmt_th(thresholds.get('area_abs'))} m²/{_fmt_th(thresholds.get('area_pct'))}%</span>
            <span>Perímetro: {_fmt_th(thresholds.get('perim_abs'))} m/{_fmt_th(thresholds.get('perim_pct'))}%</span>
            <span>Ancho Gravelius (K): {_fmt_th(thresholds.get('gravelius'))}</span>
            <span>Desplazamiento máx.: {_fmt_th(thresholds.get('desp_max'))} m</span>
            <span>Invasión de huecos: {_fmt_th(thresholds.get('invasion_pct'))}%</span>
            <span>Estabilidad mínima lindes: {_fmt_th(thresholds.get('stability_pct'))}%</span>
            <span>Validación T24 (informativa): {_fmt_th(thresholds.get('validacion_pct'))}%</span>
        </div>
        <div class="thresholds-compact" style="margin-top:6px">
            <span>Fachada VIALES: {_fmt_th((fac_th.get('VIAL') or {}).get('abs'))} m/{_fmt_th((fac_th.get('VIAL') or {}).get('pct'))}%</span>
            <span>Fachada AGUAS: {_fmt_th((fac_th.get('AGUA') or {}).get('abs'))} m/{_fmt_th((fac_th.get('AGUA') or {}).get('pct'))}%</span>
            <span>Fachada EDIF: {_fmt_th((fac_th.get('EDIF') or {}).get('abs'))} m/{_fmt_th((fac_th.get('EDIF') or {}).get('pct'))}%</span>
            <span>Fachada EXCL: {_fmt_th((fac_th.get('EXCL') or {}).get('abs'))} m/{_fmt_th((fac_th.get('EXCL') or {}).get('pct'))}%</span>
            <span>Aditamentos lineales: {_fmt_th((adit_th_lims.get('linear') or {}).get('abs'))} m/{_fmt_th((adit_th_lims.get('linear') or {}).get('pct'))}%</span>
            <span>Aditamentos poligonales: {_fmt_th((adit_th_lims.get('poly') or {}).get('abs'))} m²/{_fmt_th((adit_th_lims.get('poly') or {}).get('pct'))}%</span>
            <span>Aditamentos puntuales: cualquier cambio alerta</span>
        </div>
        <div style="font-size:0.75em; color:#7f8c8d; margin-top:10px; line-height:1.5">
          <p style="margin:4px 0"><b>PERFIL DE IMPACTO (G-I-F-A):</b> el gráfico de barras de la
          AUDITORÍA DE ADITAMENTOS resume en cuatro pilares las alertas de esta finca —
          <b>G</b>eometría (superficie, perímetro, forma, desplazamiento, nº de partes),
          <b>I</b>slas/huecos internos, <b>F</b>achadas (accesos a viales, aguas, edificaciones y excluido)
          y <b>A</b>ditamentos (elementos técnicos vinculados). La altura de cada barra es proporcional
          al nº de alertas de ese pilar sobre el máximo alcanzado por cualquiera de los cuatro; no es una
          magnitud física, solo el peso relativo de cada uno en la notificación.</p>
          <p style="margin:4px 0"><b>Asterisco (*):</b> junto a un valor indica que esa variación supera
          el umbral configurado para ese parámetro (tabla de arriba) y, por tanto, es una de las causas de
          la notificación de esta finca.</p>
        </div>
      </div>
    </div>

    <div class="section">
      <div class="section-label">Conclusiones</div>
      {conclusion_box}
    </div>

    {f'<div class="section"><div class="section-label">Croquis</div>{croquis_html}</div>' if croquis_html else ''}
  </div>
</div>
</body>
</html>"""
        return html

    @staticmethod
    def render_html_to_pdf(html, out_path, page_size='A4', margins_mm=(14, 16, 14, 16)):
        """Renderiza una cadena HTML autocontenida (con su propio
        <style>, como la que genera generate_parcel_card_html) a un PDF
        real en `out_path`, usando el motor QtWebEngine (Chromium
        embebido) que trae QGIS -- así se respeta el CSS de impresión
        (@page, page-break-*, etc.) igual que si el usuario hiciera
        "Imprimir / Guardar PDF" desde el botón del propio HTML, pero
        sin pasar por el navegador.

        margins_mm: (izquierda, arriba, derecha, abajo).

        Devuelve (ok: bool, error: str|None). No lanza excepción salvo
        que QtWebEngine no esté disponible en esta instalación de QGIS,
        en cuyo caso levanta RuntimeError para que el llamante pueda
        avisar y ofrecer la alternativa manual (botón "Imprimir /
        Guardar PDF" del HTML, vía navegador).
        """
        try:
            from PyQt5.QtWebEngineWidgets import QWebEnginePage
            from PyQt5.QtGui import QPageLayout, QPageSize
            from PyQt5.QtCore import QMarginsF, QEventLoop, QUrl, QTimer
        except ImportError as e:
            raise RuntimeError(
                "Esta instalación de QGIS no incluye QtWebEngine, necesario para "
                "exportar directamente a PDF. Usa el botón «🖨️ Imprimir / Guardar "
                "PDF» que trae la propia ficha HTML (se abre en el navegador; "
                "desde ahí, Imprimir → Guardar como PDF)."
            ) from e

        size_map = {'A4': QPageSize.A4, 'Letter': QPageSize.Letter}
        left, top, right, bottom = margins_mm
        page_layout = QPageLayout(
            QPageSize(size_map.get(page_size, QPageSize.A4)),
            QPageLayout.Portrait,
            QMarginsF(left, top, right, bottom),
            QPageLayout.Millimeter,
        )

        page = QWebEnginePage()
        loop = QEventLoop()
        result = {'ok': False, 'error': None}

        def _on_timeout():
            result['error'] = "Tiempo de espera agotado generando el PDF."
            loop.quit()

        timeout_timer = QTimer()
        timeout_timer.setSingleShot(True)
        timeout_timer.timeout.connect(_on_timeout)

        def _on_pdf_finished(path, ok):
            timeout_timer.stop()
            result['ok'] = ok
            if not ok:
                result['error'] = "El motor de renderizado no pudo escribir el PDF."
            loop.quit()

        def _on_load_finished(ok):
            if not ok:
                timeout_timer.stop()
                result['error'] = "No se pudo cargar el HTML de la ficha en el motor de renderizado."
                loop.quit()
                return
            page.printToPdf(out_path, page_layout)

        page.pdfPrintingFinished.connect(_on_pdf_finished)
        page.loadFinished.connect(_on_load_finished)
        timeout_timer.start(20000)
        page.setHtml(html, QUrl('file:///'))
        loop.exec_()

        return result['ok'], result['error']

    @staticmethod
    def parcel_export_filename(audinot_id, widths=(3, 3, 3, 4, 3)):
        """Construye el nombre de fichero
        poligono-masa-submasa-finca-subfinca.html a partir de un
        audinot_id con formato POL/MASA[-SUBMASA]/REC[-SUBREC] (ver
        ShpService.enrich_layer y TabAudit._audinot_id_sort_key), con
        ceros a la izquierda en cada tramo para que el listado de
        ficheros de la carpeta de RESULTADO quede ordenado alfabéticamente
        en el MISMO orden lógico que la Ficha 4 (numérico, no alfabético).

        `widths` fija la anchura de cada tramo (polígono, masa, submasa,
        finca/recinto, subfinca); con los valores por defecto un polígono
        7, masa 12, recinto 345 sin submasa/subrecinto da
        "007-012-000-0345-000.html".
        """
        aid = audinot_id or ''
        pol_part, _, rest = aid.partition('/')
        masa_part, _, rec_part = rest.partition('/')
        masa, _, submasa = masa_part.partition('-')
        rec, _, subrec = rec_part.partition('-')
        tokens = [pol_part, masa, submasa, rec, subrec]

        def _pad(token, width):
            token = (token or '').strip()
            if not token:
                return '0' * width
            try:
                return str(int(float(token))).zfill(width)
            except (TypeError, ValueError):
                return (token.zfill(width) if len(token) <= width else token[-width:])

        parts = [_pad(t, w) for t, w in zip(tokens, widths)]
        return "-".join(parts) + ".html"
