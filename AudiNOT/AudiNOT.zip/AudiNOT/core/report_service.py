import os
from datetime import datetime

class ReportService:
    def __init__(self, output_dir):
        self.output_dir = output_dir
        self.informes_dir = os.path.join(output_dir, "informes")
        os.makedirs(self.informes_dir, exist_ok=True)

    def generate_html(self, metrics_data, filename="informe_auditoria.html", thresholds=None):
        path = os.path.join(self.informes_dir, filename)
        
        # Si no pasan umbrales, usar diccionario vacío para evitar errores
        if thresholds is None:
            thresholds = {}
            
        html_content = self._build_html(metrics_data, thresholds)
        
        with open(path, 'w', encoding='utf-8') as f:
            f.write(html_content)
            
        return path

    def _chk(self, val, threshold):
        """Comprueba si un valor supera un umbral y devuelve '*' o cadena vacía."""
        if threshold is None or threshold == 0: return ""
        
        mark = ""
        if abs(val) > threshold: mark = " *"
        return mark

    def _chk_neg(self, val, threshold):
        """Comprueba si un valor baja de un umbral (mínimo) y devuelve '*' o cadena vacía."""
        if threshold is None or threshold == 0: return ""
        if val < threshold: return " *"
        return ""

    def _get_arrow(self, dir_code):
        """Mapea código cardinal a flecha unicode."""
        arrows = {
            'N': '↑', 'S': '↓', 'E': '→', 'O': '←',
            'NE': '↗', 'NO': '↖', 'SE': '↘', 'SO': '↙'
        }
        return arrows.get(dir_code, '')

    def _get_pct(self, antes, despues):
        """
        Calcula la variación porcentual estándar con lógica Senior 20+:
        - Si la diferencia es casi nula (TOL), retorno 0.0
        - Si antes era 0 y después no, retorno +100.0
        - Si antes no era 0 y después es 0, retorno -100.0
        """
        TOL = 0.001
        delta = despues - antes
        
        if abs(delta) < TOL:
            return 0.0
        
        # Caso: Paso de cero a algo (+100%)
        if abs(antes) < TOL:
            return 100.0
        
        # Caso: Desaparición total (-100%)
        if abs(despues) < TOL:
            return -100.0
            
        return (delta / antes) * 100.0

    def _fmt_val(self, val, precision=2, force_int=False):
        """Formatea valor absoluto con alineación decimal fantasma."""
        if abs(val) < 0.0001:
            main = "0"
            phantom = f'<span class="phantom">.{"0"*precision}</span>'
        else:
            s_val = f"{val:.{precision}f}"
            if "." in s_val:
                main, dec = s_val.split(".")
                if force_int:
                    phantom = f'<span class="phantom">.{dec}</span>'
                else:
                    phantom = f".{dec}"
            else:
                main = s_val
                phantom = ""
        
        return f'<span class="num-block">{main}{phantom}</span>'

    def _fmt_diff(self, val, precision=2, force_int=False):
        """Formatea diferencia con alineación de signo y decimales fantasma."""
        sign = "+" if val >= 0.0001 else "-" if val <= -0.0001 else ""
        abs_val = abs(val)
        
        if abs_val < 0.0001:
            main = "0"
            phantom = f'<span class="phantom">.{"0"*precision}</span>'
            sign_part = '<span class="phantom">+</span>'
        else:
            s_val = f"{abs_val:.{precision}f}"
            sign_part = sign
            if "." in s_val:
                main, dec = s_val.split(".")
                if force_int:
                    phantom = f'<span class="phantom">.{dec}</span>'
                else:
                    phantom = f".{dec}"
            else:
                main = s_val
                phantom = ""
        
        return f'<span class="num-block">{sign_part}{main}{phantom}</span>'

    def _fmt_pct(self, val, precision=2):
        """Formatea porcentaje con alineación inteligente (sin %)."""
        # Si el porcentaje es 0, lo forzamos a entero para que alinee con Var = 0
        force = True if abs(val) < 0.0001 else False
        return self._fmt_diff(val, precision, force_int=force)


    def _generate_incidence_svg(self, scores):
        """
        Genera un mini-gráfico SVG de 4 barras (G, I, F, A) que representa el ADN de la notificación.
        """
        w, h = 120, 100
        padding = 20
        bar_w = 15
        gap = 10
        
        svg = f'<svg width="{w}" height="{h+25}" viewBox="0 0 {w} {h+25}" xmlns="http://www.w3.org/2000/svg" style="background:#f9f9f9; border-radius:4px; padding:5px; border:1px solid #eee">'
        
        # Pilares: Geometría, Islas, Fachadas, Aditamentos
        pillars = [('G','#3498db','Geom'), ('I','#9b59b6','Islas'), ('F','#e67e22','Fach'), ('A','#e74c3c','Adit')]
        
        for i, (key, color, label) in enumerate(pillars):
            score = scores.get(key, 0)
            bar_h = (score / 100.0) * h
            x = padding + i * (bar_w + gap)
            y = h - bar_h
            
            svg += f'<rect x="{x}" y="{y}" width="{bar_w}" height="{bar_h}" fill="{color}" rx="2" opacity="0.8">'
            if score > 0:
                svg += f'<animate attributeName="height" from="0" to="{bar_h}" dur="0.5s" fill="freeze" />'
                svg += f'<animate attributeName="y" from="{h}" to="{y}" dur="0.5s" fill="freeze" />'
            svg += '</rect>'
            svg += f'<text x="{x + bar_w/2}" y="{h+12}" font-family="Arial, sans-serif" font-size="8" text-anchor="middle" fill="#666">{key}</text>'
            
        svg += '</svg>'
        return svg


    def _generate_adit_table_rows(self, d, thresholds=None):
        """Genera filas de tabla y retorna (html, num_alertas, num_totales)."""
        adits = d.get('aditamentos', {})
        if not adits: return "", 0, 0
        
        TOL = 0.001
        html = ""
        alerts = 0
        total_params = 0
        
        # Umbrales
        t_linear_abs = 1.0; t_linear_pct = 5.0
        t_poly_abs = 1.0; t_poly_pct = 5.0
        if thresholds and 'aditamentos' in thresholds:
            t_linear_abs = thresholds['aditamentos'].get('linear', {}).get('abs', 1.0)
            t_linear_pct = thresholds['aditamentos'].get('linear', {}).get('pct', 5.0)
            t_poly_abs = thresholds['aditamentos'].get('poly', {}).get('abs', 1.0)
            t_poly_pct = thresholds['aditamentos'].get('poly', {}).get('pct', 5.0)

        for el_name, data in sorted(adits.items()):
            a = data.get('a', {'len':0, 'area':0, 'count':0})
            dv = data.get('d', {'len':0, 'area':0, 'count':0})
            
            # Líneas
            if a['len'] >= TOL or dv['len'] >= TOL:
                total_params += 1
                delta = dv['len'] - a['len']
                pct = self._get_pct(a['len'], dv['len'])
                mark = self._chk(delta, t_linear_abs) or self._chk(pct, t_linear_pct)
                if mark: alerts += 1
                cls = "text-pos" if delta > 0.05 else "text-neg" if delta < -0.05 else ""
                html += f'<tr><td>{el_name} (Lon)</td><td class="val-num">{self._fmt_val(a["len"])}</td><td class="val-num">{self._fmt_val(dv["len"])}</td><td class="val-num {cls}">{self._fmt_diff(delta)}</td><td class="mark-slot">{mark}</td><td class="val-num {cls}">{self._fmt_pct(pct)}</td><td class="mark-slot">{mark}</td></tr>'
            
            # Polígonos
            if a['area'] >= TOL or dv['area'] >= TOL:
                total_params += 1
                delta = dv['area'] - a['area']
                pct = self._get_pct(a['area'], dv['area'])
                mark = self._chk(delta, t_poly_abs) or self._chk(pct, t_poly_pct)
                if mark: alerts += 1
                cls = "text-pos" if delta > 0.1 else "text-neg" if delta < -0.1 else ""
                html += f'<tr><td>{el_name} (Sup)</td><td class="val-num">{self._fmt_val(a["area"])}</td><td class="val-num">{self._fmt_val(dv["area"])}</td><td class="val-num {cls}">{self._fmt_diff(delta)}</td><td class="mark-slot">{mark}</td><td class="val-num {cls}">{self._fmt_pct(pct)}</td><td class="mark-slot">{mark}</td></tr>'
            
            # Puntos / Conteo
            if a['count'] != dv['count']:
                total_params += 1
                delta = dv['count'] - a['count']
                alerts += 1
                html += f'<tr><td>{el_name} (Cant)</td><td class="val-num">{a["count"]}</td><td class="val-num">{dv["count"]}</td><td class="val-num">{"%+" if delta > 0 else ""}{delta}</td><td class="mark-slot"> *</td><td class="val-num"></td><td class="mark-slot"></td></tr>'
            elif a['count'] > 0:
                total_params += 1

        return html, alerts, total_params

    def _generate_adit_section_layout(self, content_html, pillar_scores):
        """Monta el layout Flex con la tabla (2/3) y el gráfico (1/3)."""
        if not content_html:
            return f"""
            <div class="panel" style="border-top:1px solid #eee; background:#fcfcfc; display:flex; align-items:center; gap:20px">
                <div style="flex:2">
                    <div class="panel-title">AUDITORÍA DE ADITAMENTOS</div>
                    <div style="color:#ccc; font-style:italic">Sin elementos técnicos vinculados</div>
                </div>
                <div style="flex:1; text-align:center; border-left:1px solid #eee; padding:5px">
                    <div style="font-size:0.7em; color:#999; margin-bottom:5px; font-weight:bold">PERFIL DE IMPACTO (G-I-F-A)</div>
                    {self._generate_incidence_svg(pillar_scores)}
                </div>
            </div>
            """
            
        return f"""
        <div class="panel" style="border-top:1px solid #eee; background:#fcfcfc; display:flex; gap:20px; padding:0">
            <div style="flex:2; border-right:1px solid #eee; padding:15px">
                <div class="panel-title">AUDITORÍA DE ADITAMENTOS</div>
                <table class="mini-table">
                    <colgroup>
                        <col style="width: 35%"><col style="width: 15%"><col style="width: 15%"><col style="width: 12%"><col style="width: 14px"><col style="width: 12%"><col style="width: 14px">
                    </colgroup>
                    <tr><th>ELEMENTO</th><th class="num-col">Antes</th><th class="num-col">Después</th><th class="num-col">Var</th><th></th><th class="num-col">%</th><th></th></tr>
                    {content_html}
                </table>
            </div>
            <div style="flex:1; text-align:center; padding:15px; display:flex; flex-direction:column; justify-content:center; align-items:center; background:#f9f9f9">
                <div style="font-size:0.75em; color:#666; margin-bottom:10px; font-weight:bold; letter-spacing:1px">PERFIL DE IMPACTO</div>
                {self._generate_incidence_svg(pillar_scores)}
            </div>
        </div>
        """

    def _build_html(self, data, thresholds):
        matrix = data.get('transition_matrix', [])
        details = data.get('parcel_details', [])
        
        # Totales KPI
        total_area = sum(m['area'] for m in matrix)
        total_bajas = sum(m['area'] for m in matrix if m['type'] == 'BAJA')
        
        # Definir tipos de fachada fijos
        fixed_facade_types = ['VIALES', 'CURSOS AGUA', 'EDIFICACIONES', 'EXCLUIDO']

        html = f"""
        <!DOCTYPE html>
        <html lang="es">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Fichas de Auditoría por Recinto</title>
            <style>
                :root {{ --primary: #2c3e50; --sec: #34495e; --accent: #3498db; --bg: #f5f7fa; --card-bg: #fff; --border: #e1e4e8; }}
                body {{ font-family: 'Segoe UI', sans-serif; background: var(--bg); color: #333; margin: 0; display: flex; height: 100vh; overflow: hidden; }}
                
                /* Sidebar TOC */
                .sidebar {{ width: 280px; background: white; border-right: 1px solid var(--border); flex-shrink: 0; display: flex; flex-direction: column; position: relative; }}
                .sidebar-header {{ padding: 20px; background: var(--primary); color: white; position: sticky; top: 0; z-index: 10; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }}
                .search-container {{ position: relative; margin-top: 10px; display: flex; align-items: center; }}
                .search-box {{ width: 100%; padding: 8px 30px 8px 12px; border: none; border-radius: 4px; font-size: 0.9em; background: rgba(255,255,255,0.9); color: #333; box-sizing: border-box; }}
                .search-box::placeholder {{ color: #999; }}
                .search-box:focus {{ outline: 2px solid var(--accent); background: white; }}
                .clear-btn {{ position: absolute; right: 8px; cursor: pointer; color: #999; font-weight: bold; background: none; border: none; font-size: 1.2em; display: none; }}
                .clear-btn:hover {{ color: #333; }}
                .toc-list {{ list-style: none; padding: 0; margin: 0; overflow-y: auto; flex-grow: 1; }}
                .toc-item {{ border-bottom: 1px solid var(--border); }}
                .toc-item.hidden {{ display: none; }}
                .toc-link {{ display: block; padding: 12px 20px; text-decoration: none; color: #555; font-size: 0.9em; transition: 0.2s; }}
                .toc-link:hover {{ background: #f0f4f8; color: var(--accent); }}
                .toc-link.active {{ background: #e3f2fd; border-left: 4px solid var(--accent); font-weight: bold; }}
                .toc-badge {{ float: right; font-size: 0.75em; padding: 2px 6px; border-radius: 4px; color: white; }}
                
                /* Warning Badge in Sidebar */
                .toc-warning {{ display: inline-block; width: 14px; height: 14px; background: red; color: white; border-radius: 50%; font-size: 10px; text-align: center; line-height: 14px; margin-right: 5px; font-weight: bold; }}

                /* Report Header (Visible on Screen & Print) */
                .report-header {{ position: sticky; top: 0; z-index: 100; display: block; padding: 15px 30px; border-bottom: 2px solid var(--primary); margin-bottom: 0; background: white; box-shadow: 0 4px 6px rgba(0,0,0,0.05); }}
                .report-header h1 {{ margin: 0 0 5px 0; font-size: 22px; color: var(--primary); }}
                .report-meta {{ font-size: 12px; color: #555; display: grid; grid-template-columns: 2fr 1fr; gap: 20px; }}
                .meta-group strong {{ display: block; margin-bottom: 2px; color: #000; }}

                /* Main Content */
                .main-content {{ flex-grow: 1; overflow-y: auto; padding: 0; scroll-behavior: smooth; }}
                
                .cards-wrapper {{ padding: 20px; }}

                /* Audit Card */
                .audit-card {{ background: white; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); margin-bottom: 30px; overflow: hidden; border: 1px solid var(--border); }}
                .audit-card.alert-border {{ border: 2px solid #e74c3c; }}
                .card-header {{ background: linear-gradient(to right, #f8f9fa, #fff); padding: 12px 20px; border-bottom: 1px solid var(--border); display: flex; justify-content: space-between; align-items: center; }}
                .card-title h2 {{ margin: 0; color: var(--primary); font-size: 1.3em; }}
                .card-title span {{ color: #7f8c8d; font-size: 0.85em; }}
                
                .grid-panels {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(400px, 1fr)); gap: 0; }}
                .panel {{ padding: 15px; border-bottom: 1px solid var(--border); }} /* Padding reducido de 25px a 15px */
                .panel:not(:last-child) {{ border-right: 1px solid var(--border); }}
                .panel-title {{ font-size: 0.8em; text-transform: uppercase; letter-spacing: 1px; color: #888; margin-bottom: 10px; font-weight: bold; border-left: 3px solid var(--accent); padding-left: 8px; }}
                
                /* Tables inside cards (7 Columna System) */
                .mini-table {{ width: 100%; font-size: 0.85em; border-collapse: collapse; table-layout: fixed; }}
                .mini-table th {{ text-align: left; color: #666; font-weight: 600; padding: 4px 0; border-bottom: 1px solid #eee; }}
                .mini-table th.num-col {{ text-align: center; }}
                .mini-table td {{ padding: 3px 0; border-bottom: 1px solid #f9f9f9; }}
                
                /* Column Widths (Fixed for Marks) */
                .mini-table td:nth-child(2), .mini-table td:nth-child(3) {{ text-align: right; }}
                .mini-table td:nth-child(4) {{ text-align: right; }}
                .mini-table td:nth-child(5) {{ text-align: left; padding-left: 2px; overflow: visible; font-weight: bold; color: #e74c3c; width: 14px; }}
                .mini-table td:nth-child(6) {{ text-align: right; }}
                .mini-table td:nth-child(7) {{ text-align: left; padding-left: 2px; overflow: visible; font-weight: bold; color: #e74c3c; width: 14px; }}
                
                .mini-table th.num-col {{ text-align: right !important; }}

                .val-num {{ font-family: 'Consolas', monospace; font-weight: 600; white-space: nowrap; }}
                .num-block {{ display: inline-block; text-align: right; }}
                .phantom {{ visibility: hidden; opacity: 0; pointer-events: none; }}
                .mark-slot {{ color: #e74c3c; font-weight: bold; font-size: 1.1em; line-height: 1; display: inline-block; }}
                
                /* Badges & Colors */
                .bg-persiste {{ background: #27ae60; }}
                .bg-alta {{ background: #2980b9; }}
                .bg-baja {{ background: #c0392b; }}
                .bg-cambio {{ background: #f39c12; }}
                .text-pos {{ color: #27ae60; }}
                .text-neg {{ color: #c0392b; }}
                
                /* Flows */
                .flow-item {{ display: flex; justify-content: space-between; padding: 3px 6px; background: #f8f9fa; border-radius: 3px; margin-bottom: 3px; font-size: 0.85em; line-height: 1.2; }}
                .flow-arrow {{ color: #bbb; margin: 0 10px; }}
                
                /* Owner Change Indicator */
                .owner-change {{ display: inline-block; margin-left: 10px; padding: 4px 10px; border-radius: 4px; font-size: 0.85em; font-weight: bold; }}
                .owner-change.changed {{ background: #ff9800; color: white; }}
                .owner-change.unchanged {{ background: #4caf50; color: white; }}
                
                .alert-label {{ background: #e74c3c; color: white; padding: 4px 8px; border-radius: 4px; font-weight: bold; font-size: 0.8em; margin-right: 10px; }}

                /* Change Indicator */
                .diff-nonzero {{ color: #e74c3c !important; font-weight: bold; }}

                /* Print Styles */
                @media print {{
                    .sidebar {{ display: none !important; }}
                    body {{ display: block; height: auto; overflow: visible; background: white; font-size: 11px; }}
                    .main-content {{ width: 100%; max-width: 100%; padding: 0; overflow: visible; margin: 0; }}
                    .audit-card {{ page-break-after: auto; page-break-inside: avoid; margin: 0 0 10px 0; box-shadow: none; border: 1px solid #ccc; padding: 0; }}
                    .audit-card.hidden {{ display: none !important; }}
                    .card-header {{ padding: 5px 10px; background: #eee; }}
                    .card-title h2 {{ font-size: 1.1em; margin: 0; }}
                    .panel {{ padding: 5px !important; }}
                    .mini-table td, .mini-table th {{ padding: 2px 0 !important; font-size: 0.9em; }}
                    .report-header {{ position: static; display: block !important; border: 1px solid #ddd; margin-bottom: 10px; padding: 10px; box-shadow: none; }}
                    .cards-wrapper {{ padding: 0; }}
                    * {{ box-shadow: none !important; }}
                }}

                /* Filter UI */
                .filter-group {{ margin-top: 15px; display: flex; flex-wrap: wrap; gap: 8px; }}
                .filter-btn {{ 
                    background: rgba(255,255,255,0.15); border: 1px solid rgba(255,255,255,0.3);
                    color: white; font-size: 0.75em; padding: 4px 8px; border-radius: 4px; 
                    cursor: pointer; transition: 0.2s; user-select: none;
                }}
                .filter-btn:hover {{ background: rgba(255,255,255,0.25); }}
                .filter-btn.active {{ background: var(--accent); border-color: var(--accent); font-weight: bold; }}
                .filter-btn.warning-filter {{ background: rgba(231, 76, 60, 0.4); border-color: #e74c3c; }}
                .filter-btn.warning-filter.active {{ background: #e74c3c; }}
                
                .toc-owner-indicator {{ 
                    display: inline-block; width: 8px; height: 8px; 
                    background: #ff9800; border-radius: 50%; margin-right: 5px; 
                    box-shadow: 0 0 5px rgba(255,152,0,0.5);
                }}
            </style>
        </head>
        <body>
            <div class="sidebar">
                <div class="sidebar-header">
                    <h3 style="margin:0">Índice de Recintos</h3>
                    <small id="parcel-count">{len(details)} Recintos</small>
                    <div class="search-container">
                        <input type="text" class="search-box" id="search-box" placeholder="🔍 Buscar recinto..." />
                        <button class="clear-btn" id="clear-btn" title="Limpiar búsqueda">&times;</button>
                    </div>
                    <div class="filter-group">
                        <div class="filter-btn" data-filter="ALTA">NUEVA</div>
                        <div class="filter-btn" data-filter="BAJA">DESAPARECE</div>
                        <div class="filter-btn" data-filter="OWNER_CHANGE">TITULAR</div>
                        <div class="filter-btn warning-filter" data-filter="NOTIFY">⚠ NOTIFICAR</div>
                    </div>
                </div>
                <ul class="toc-list" id="toc-list">
        """
        
        # Generar TOC y Cards
        def sort_key(d):
            try:
                s = d['id'].replace('-', '/').split('/')
                nums = []
                for p in s:
                    try: nums.append(int(p))
                    except: nums.append(0)
                return tuple(nums)
            except:
                return (0,)
                
        sorted_details = sorted(details, key=sort_key)
        
        toc_html = ""
        cards_html = ""
        
        for d in sorted_details:
            st = d['state']
            
            # Flags de notificación para esta parcela
            notify = False
            
            # --- CHECK THRESHOLDS ---
            
            # 1. Geometría
            area_d = d.get('area_final', 0)
            delta_area = d.get('delta_area', 0)
            area_a = area_d - delta_area if st != 'BAJA' else abs(delta_area)
            pct_area = self._get_pct(area_a, area_d)
            
            m_a_abs = self._chk(delta_area, thresholds.get('area_abs'))
            m_a_pct = self._chk(pct_area, thresholds.get('area_pct'))
            
            perim_a = d.get('perim_a', 0); perim_d = d.get('perim_d', 0)
            delta_perim = d.get('delta_perim', 0)
            pct_perim = self._get_pct(perim_a, perim_d)
            
            m_p_abs = self._chk(delta_perim, thresholds.get('perim_abs'))
            m_p_pct = self._chk(pct_perim, thresholds.get('perim_pct'))
            
            grav_a = d.get('grav_a', 0); grav_d = d.get('grav_d', 0)
            grav_delta = d.get('delta_grav', 0)
            pct_grav = self._get_pct(grav_a, grav_d)
            m_g_pct = self._chk(grav_delta, thresholds.get('gravelius')) # Gravelius now checks delta, not absolute value
            
            convex_a = d.get('convex_a', 1.0)
            convex_d = d.get('convex_d', 1.0)
            delta_convex = convex_d - convex_a
            pct_convex = self._get_pct(convex_a, convex_d)
            m_c_abs = self._chk(delta_convex, thresholds.get('convexity_abs'))
            m_c_pct = self._chk(pct_convex, thresholds.get('convexity_pct'))

            stability_pct = d.get('stability_pct', 100.0)
            m_stab = self._chk_neg(stability_pct, thresholds.get('stability_pct'))

            displacement = d.get('displacement', 0.0)
            displacement_dir = d.get('displacement_dir', '-')
            m_desp = self._chk(displacement, thresholds.get('desp_max'))
            
            hole_area_a = d.get('hole_area_a', 0.0)
            delta_hole_area = d.get('delta_hole_area', 0.0)
            pct_rings_area = self._get_pct(hole_area_a, d.get('hole_area_d', 0.0))
            m_inv = self._chk(pct_rings_area, thresholds.get('invasion_pct')) # Huecos pct

            # Acumular alertas geométricas
            delta_parts = d.get('parts_d', 1) - d.get('parts_a', 1)
            isl_deltas = d.get('islands')
            delta_isl_cnt = isl_deltas['delta_count'] if isl_deltas else 0
            
            if m_a_abs or m_a_pct or m_p_abs or m_p_pct or m_g_pct or m_inv or m_desp or m_c_abs or m_c_pct or m_stab or delta_parts != 0 or delta_isl_cnt != 0:
                notify = True

            # 2. Fachadas
            facade_rows_html = ""
            facade_labels = {'VIALES': 'Viales', 'CURSOS AGUA': 'AGUAS', 'EDIFICACIONES': 'EDIF', 'EXCLUIDO': 'EXCL'}
            
            for t_code in fixed_facade_types:
                val_a = d.get(f'facade_antes_{t_code}', 0.0)
                val_d = d.get(f'facade_desp_{t_code}', 0.0)
                delta = val_d - val_a
                pct = self._get_pct(val_a, val_d)
                cls = "text-pos" if delta > 0.01 else "text-neg" if delta < -0.01 else ""
                label = facade_labels.get(t_code, t_code)
                
                # Check thresholds
                f_lims = thresholds.get('facades', {})
                f_key = 'VIAL' if 'VIAL' in t_code else 'AGUA' if 'AGUA' in t_code else 'EDIF' if 'EDIF' in t_code else 'EXCL'
                lims = f_lims.get(f_key, {})
                
                # Restauración Senior: Variación relativa simple como en el resto de métricas
                pct = self._get_pct(val_a, val_d)
                
                m_f_abs = self._chk(delta, lims.get('abs'))
                m_f_pct = self._chk(pct, lims.get('pct'))
                
                if m_f_abs or m_f_pct: notify = True
                
                facade_rows_html += f"""
                    <tr>
                        <td>{label} (m)</td>
                        <td class="val-num">{self._fmt_val(val_a)}</td>
                        <td class="val-num">{self._fmt_val(val_d)}</td>
                        <td class="val-num {cls} {'diff-nonzero' if abs(delta) > 0.001 else ''}">{self._fmt_diff(delta)}</td>
                        <td class="mark-slot">{m_f_abs}</td>
                        <td class="val-num {cls} {'diff-nonzero' if abs(delta) > 0.001 else ''}">{self._fmt_pct(pct)}</td>
                        <td class="mark-slot">{m_f_pct}</td>
                    </tr>
                """
            
            # --- CONTEO DE COLINDANTES (Senior 15+ PRO) ---
            neigh_a = d.get('neighbors_a', 0)
            neigh_d = d.get('neighbors_d', 0)
            neigh_delta = neigh_d - neigh_a
            m_neigh = " *" if neigh_delta != 0 else ""
            pct_neigh = self._get_pct(neigh_a, neigh_d)
            m_n_pct = self._chk(pct_neigh, thresholds.get('neigh_pct'))
            
            facade_rows_html += f"""
                <tr>
                    <td>No. Colindantes (n)</td>
                    <td class="val-num">{self._fmt_val(neigh_a, force_int=True)}</td>
                    <td class="val-num">{self._fmt_val(neigh_d, force_int=True)}</td>
                    <td class="val-num {'diff-nonzero' if neigh_delta != 0 else ''}">{self._fmt_diff(neigh_delta, force_int=True)}</td>
                    <td class="mark-slot">{m_neigh}</td>
                    <td class="val-num {'diff-nonzero' if neigh_delta != 0 else ''}">{self._fmt_pct(pct_neigh)}</td>
                    <td class="mark-slot">{m_n_pct}</td>
                </tr>
            """

            # --- PILLAR SCORING (Peak Normalization G-I-F-A) ---
            adit_content_html, adit_alerts, adit_total = self._generate_adit_table_rows(d, thresholds)
            
            # 1. Contar alertas por categoría
            g_alerts = 0
            if m_a_abs or m_a_pct: g_alerts += 1
            if m_p_abs or m_p_pct: g_alerts += 1
            if m_g_pct: g_alerts += 1
            if m_c_abs or m_c_pct: g_alerts += 1
            if m_stab: g_alerts += 1
            if m_desp: g_alerts += 1
            if delta_parts != 0: g_alerts += 1
            
            i_alerts = 0
            if delta_isl_cnt != 0: i_alerts += 1
            if m_inv: i_alerts += 1
            if isl_deltas and (abs(isl_deltas.get('delta_area',0)) > 0.1 or isl_deltas.get('displacement',0) > 0.05):
                i_alerts += 1

            f_alerts = 0
            f_lims = thresholds.get('facades', {})
            for tc in ['VIALES', 'CURSOS AGUA', 'EDIFICACIONES', 'EXCLUIDO']:
                fk = 'VIAL' if 'VIAL' in tc else 'AGUA' if 'AGUA' in tc else 'EDIF' if 'EDIF' in tc else 'EXCL'
                lims = f_lims.get(fk, {})
                v_a = d.get(f'facade_antes_{tc}', 0.0)
                v_d = d.get(f'facade_desp_{tc}', 0.0)
                if self._chk(v_d - v_a, lims.get('abs')) or self._chk(self._get_pct(v_a, v_d), lims.get('pct')):
                    f_alerts += 1
            
            a_alerts = adit_alerts
            if a_alerts > 0: notify = True # Alerta técnica activa notificación
            
            # 2. Normalizar sobre 100 (El máximo aporte es el techo)
            max_a = max(g_alerts, i_alerts, f_alerts, a_alerts)
            W = 100.0 / max_a if max_a > 0 else 0
            
            pillar_scores = {
                'G': g_alerts * W,
                'I': i_alerts * W,
                'F': f_alerts * W,
                'A': a_alerts * W
            }

            adit_html = self._generate_adit_section_layout(adit_content_html, pillar_scores)

            # --- FIN CHECKS ---

            state_labels = {'ALTA': 'NUEVA', 'BAJA': 'DESAPARECE', 'PERSISTENTE': 'PERSISTENTE'}
            display_st = state_labels.get(st, st)
            letter = display_st[0]
            bg = "#27ae60" if st == 'PERSISTENTE' else "#c0392b" if st == 'BAJA' else "#2980b9" if st == 'ALTA' else "#f39c12"
            anchor_id = d['id'].replace('/', '_')
            
            owner_changed = d.get('owner_changed', False)
            if owner_changed and st == 'PERSISTENTE': 
                notify = True # Cambio de titular también es alerta

            # TOC Item
            warn_icon = '<span class="toc-warning">!</span>' if notify else ""
            badge_html = f'<span class="toc-badge" style="background:{bg}; float:right">{letter}</span>' if st != 'PERSISTENTE' else ""
            
            toc_html += f"""
                    <li class="toc-item" data-state="{st}" data-owner-changed="{'true' if owner_changed else 'false'}" data-notify="{'true' if notify else 'false'}">
                        <a href="#id-{anchor_id}" class="toc-link">
                            {warn_icon}{d['id']}
                            {badge_html}
                        </a>
                    </li>
            """
            
            # Card HEADER
            alert_label = '<span class="alert-label">⚠ NOTIFICAR</span>' if notify else ""
            
            # Owner display
            p_a = d.get('prop_a', 'N/A')
            p_d = d.get('prop_d', 'N/A')
            owner_display = f'<span style="color:red; font-weight:bold">Titular: {p_a} → {p_d}</span>' if owner_changed else f'<span style="color:#7f8c8d">Titular: {p_d}</span>'
            if st == 'ALTA': owner_display = f'<span>Titular: (Nuevo) → {p_d}</span>'
            if st == 'BAJA': owner_display = f'<span>Titular: {p_a} → (Baja)</span>'

            # Metric Formatters
            diff_area_fmt = f"{delta_area:+.2f}"
            cls_area = "text-pos" if delta_area > 0 else "text-neg" if delta_area < 0 else ""
            card_border_cls = "alert-border" if notify else ""

            parts_a = d.get('parts_a', 1); parts_d = d.get('parts_d', 1); delta_parts = parts_d - parts_a
            pct_parts = (delta_parts / parts_a * 100) if parts_a else 0
            
            grav_a = d.get('grav_a', 0); grav_d = d.get('grav_d', 0); grav_delta = d.get('delta_grav', 0)
            pct_grav = (grav_delta / grav_a * 100) if grav_a else 0
            
            rings_a = d.get('rings_a', 0); rings_d = d.get('rings_d', 0); rings_delta = d.get('delta_rings', 0)
            pct_rings = (rings_delta / rings_a * 100) if rings_a else 0

            topo_label = "Mono-parte" if parts_d <= 1 else f"Multi-parte: {parts_d} partes"
            
            # Generar Card HTML
            card = f"""
                <div id="id-{anchor_id}" class="audit-card {card_border_cls}">
                    <div class="card-header">
                        <div class="card-title">
                            <h2>{d['id']} {alert_label}</h2>
                            {owner_display}
                        </div>
                        <div style="text-align:right">
                             <div style="margin-top:5px; font-weight:bold; {cls_area}">{self._fmt_diff(delta_area)} m²</div>
                        </div>
                    </div>
                    
                    <div class="grid-panels">
                        <div class="panel">
                            <div class="panel-title">MÉTRICAS GEOMÉTRICAS ({topo_label})</div>
                            <table class="mini-table">
                                <colgroup>
                                    <col style="width: 35%"><col style="width: 15%"><col style="width: 15%"><col style="width: 12%"><col style="width: 14px"><col style="width: 12%"><col style="width: 14px">
                                </colgroup>
                                <tr><th>Parámetro</th><th class="num-col">Antes</th><th class="num-col">Después</th><th class="num-col">Var</th><th></th><th class="num-col">%</th><th></th></tr>
                                <tr>
                                    <td>Superficie (m²)</td>
                                    <td class="val-num">{self._fmt_val(area_a)}</td>
                                    <td class="val-num">{self._fmt_val(area_d)}</td>
                                    <td class="val-num {cls_area} {'diff-nonzero' if abs(delta_area) > 0.001 else ''}">{self._fmt_diff(delta_area)}</td>
                                    <td class="mark-slot">{m_a_abs}</td>
                                    <td class="val-num {cls_area} {'diff-nonzero' if abs(delta_area) > 0.001 else ''}">{self._fmt_pct(pct_area)}</td>
                                    <td class="mark-slot">{m_a_pct}</td>
                                </tr>
                                <tr>
                                    <td>Perímetro (m)</td>
                                    <td class="val-num">{self._fmt_val(perim_a)}</td>
                                    <td class="val-num">{self._fmt_val(perim_d)}</td>
                                    <td class="val-num {cls_area} {'diff-nonzero' if abs(delta_perim) > 0.001 else ''}">{self._fmt_diff(delta_perim)}</td>
                                    <td class="mark-slot">{m_p_abs}</td>
                                    <td class="val-num {cls_area} {'diff-nonzero' if abs(delta_perim) > 0.001 else ''}">{self._fmt_pct(pct_perim)}</td>
                                    <td class="mark-slot">{m_p_pct}</td>
                                </tr>
                                <tr>
                                    <td>Ancho Gravelius (K)</td>
                                    <td class="val-num">{self._fmt_val(grav_a)}</td>
                                    <td class="val-num">{self._fmt_val(grav_d)}</td>
                                    <td class="val-num {'diff-nonzero' if abs(grav_delta) > 0.001 else ''}">{self._fmt_diff(grav_delta)}</td>
                                    <td class="mark-slot">{m_g_pct}</td>
                                    <td class="val-num {'diff-nonzero' if abs(grav_delta) > 0.001 else ''}">{self._fmt_pct(pct_grav)}</td>
                                    <td class="mark-slot">{m_g_pct}</td>
                                </tr>
                                <tr>
                                    <td>Índice Convexidad</td>
                                    <td class="val-num">{self._fmt_val(d.get('convex_a', 1.0))}</td>
                                    <td class="val-num">{self._fmt_val(d.get('convex_d', 1.0))}</td>
                                    <td class="val-num {'diff-nonzero' if abs(delta_convex) > 0.001 else ''}">{self._fmt_diff(delta_convex)}</td>
                                    <td class="mark-slot">{m_c_abs}</td>
                                    <td class="val-num {'diff-nonzero' if abs(delta_convex) > 0.001 else ''}">{self._fmt_pct(pct_convex)}</td>
                                    <td class="mark-slot">{m_c_pct}</td>
                                </tr>
                                <tr>
                                    <td>Estabilidad Linde (%)</td>
                                    <td class="val-num"></td>
                                    <td class="val-num"></td>
                                    <td class="val-num"></td>
                                    <td class="mark-slot"></td>
                                    <td class="val-num">{self._fmt_val(stability_pct)}</td>
                                    <td class="mark-slot">{m_stab}</td>
                                </tr>
                                <tr>
                                    <td>Multi-parte (Cant)</td>
                                    <td class="val-num">{self._fmt_val(parts_a, force_int=True)}</td>
                                    <td class="val-num">{self._fmt_val(parts_d, force_int=True)}</td>
                                    <td class="val-num {'diff-nonzero' if delta_parts != 0 else ''}">{self._fmt_diff(delta_parts, force_int=True)}</td>
                                    <td class="mark-slot">{" *" if delta_parts != 0 else ""}</td>
                                    <td class="val-num {'diff-nonzero' if delta_parts != 0 else ''}">{self._fmt_pct(pct_parts)}</td>
                                    <td class="mark-slot">{" *" if delta_parts != 0 else ""}</td>
                                </tr>
                                <tr>
                                    <td>Desplazamiento (m)</td>
                                    <td class="val-num"></td>
                                    <td class="val-num"></td>
                                    <td class="val-num {'diff-nonzero' if displacement > 0.05 else ''}" style="text-align:right">{self._fmt_val(displacement)}</td>
                                    <td class="mark-slot">{m_desp}</td>
                                    <td class="val-num" style="text-align:center; font-weight:bold; color:var(--primary)">{self._get_arrow(displacement_dir)} {displacement_dir}</td>
                                    <td></td>
                                </tr>
                            </table>
                        </div>
                        
                        <div class="panel">
                            <div class="panel-title">INTERACCIÓN CON ENTORNO (FACHADAS)</div>
                            <table class="mini-table">
                                <colgroup>
                                    <col style="width: 35%"><col style="width: 15%"><col style="width: 15%"><col style="width: 12%"><col style="width: 14px"><col style="width: 12%"><col style="width: 14px">
                                </colgroup>
                                <tr><th>Tipo</th><th class="num-col">Antes</th><th class="num-col">Después</th><th class="num-col">Var</th><th></th><th class="num-col">%</th><th></th></tr>
                                {facade_rows_html}
                            </table>
                        </div>
                    </div>
                    
                    <!-- Sección de Transiciones e Islas -->
                    <div style="display:flex; border-top:1px solid var(--border)">
                        <div class="panel" style="flex:1; border-right:1px solid var(--border); background:#fcfcfc; border-bottom:none">
                             <div class="panel-title">ANÁLISIS DE HUECOS / ISLAS</div>
                             {self._render_islands_section(d.get('islands'), thresholds)}
                        </div>
                        <div class="panel" style="flex:1; background:#fdfdfd; border-right:none; border-bottom:none">
                            <div class="panel-title">DINÁMICA TERRITORIAL</div>
                             <div style="display:flex; gap:20px">
                                 <div style="flex:1">
                                     <h4 style="margin: 0 0 5px 0; font-size:0.85em; color:#666">ORIGEN (INPUTS)</h4>
                                     {self._render_flows(d.get('inputs', []), st, 'ALTA', data.get('special_owners', {}), 'input')}
                                 </div>
                                 <div style="border-left:1px solid #eee"></div>
                                 <div style="flex:1">
                                     <h4 style="margin: 0 0 5px 0; font-size:0.85em; color:#666">DESTINO (OUTPUTS)</h4>
                                     {self._render_flows(d.get('outputs', []), st, 'BAJA', data.get('special_owners', {}), 'output')}
                                 </div>
                             </div>
                        </div>
                    </div>

                    <!-- SECCIÓN ADITAMENTOS -->
                    {adit_html}
                </div>
            """
            cards_html += card

        html += f"""
            {toc_html}
                </ul>
            </div>
            <div class="main-content">
                <div class="report-header">
                    <h1>INFORME DE AUDITORÍA GRÁFICA</h1>
                    <div class="report-meta">
                        <div class="meta-group">
                            <strong>Configuración de Umbrales:</strong>
                            <div><strong>Geometría:</strong> Ár:{thresholds.get('area_abs','-')}m²/{thresholds.get('area_pct','-')}% | 
                                 Per:{thresholds.get('perim_abs','-')}m/{thresholds.get('perim_pct','-')}% | 
                                 K:{thresholds.get('gravelius','-')} | Desp:{thresholds.get('desp_max','-')}m | Huecos:{thresholds.get('invasion_pct','-')}%</div>
                            <div><strong>Fachadas:</strong> 
                                 Vial:{thresholds.get('facades',{}).get('VIAL',{}).get('abs','-')}m/{thresholds.get('facades',{}).get('VIAL',{}).get('pct','-')}% |
                                 Agua:{thresholds.get('facades',{}).get('AGUA',{}).get('abs','-')}m/{thresholds.get('facades',{}).get('AGUA',{}).get('pct','-')}% |
                                 Edif:{thresholds.get('facades',{}).get('EDIF',{}).get('abs','-')}m/{thresholds.get('facades',{}).get('EDIF',{}).get('pct','-')}% |
                                 Excl:{thresholds.get('facades',{}).get('EXCL',{}).get('abs','-')}m/{thresholds.get('facades',{}).get('EXCL',{}).get('pct','-')}%</div>
                            <div><strong>Propietarios Especiales:</strong> <sup>1</sup> AGADER | <sup>2</sup> MASA COMÚN | <sup>3</sup> DESCONOCIDOS</div>
                        </div>
                        <div class="meta-group">
                            <strong>Archivos Fuente:</strong>
                            <div>ANTES: {os.path.basename(data.get('input_files', {}).get('antes', 'N/A'))}</div>
                            <div>DESPUÉS: {os.path.basename(data.get('input_files', {}).get('despues', 'N/A'))}</div>
                            <div style="margin-top:5px; padding-top:5px; border-top:1px solid #eee">
                                <strong>Fecha de Auditoría:</strong> {datetime.now().strftime('%d/%m/%Y %H:%M')}
                            </div>
                        </div>
                    </div>
                </div>
                <div class="cards-wrapper">
                    {cards_html}
                </div>
            </div>
            <script>
                const searchBox = document.getElementById('search-box');
                const clearBtn = document.getElementById('clear-btn');
                const filterBtns = document.querySelectorAll('.filter-btn');
                const tocList = document.getElementById('toc-list');
                const parcelCount = document.getElementById('parcel-count');
                const totalParcels = {len(details)};
                
                let activeFilters = [];

                function performSearch() {{
                    const searchTerm = searchBox.value.toLowerCase().trim();
                    const items = tocList.querySelectorAll('.toc-item');
                    let visibleCount = 0;
                    
                    if (searchTerm !== '') clearBtn.style.display = 'block';
                    else clearBtn.style.display = 'none';

                    items.forEach(item => {{
                        const link = item.querySelector('.toc-link');
                        const text = link.textContent.toLowerCase();
                        const state = item.getAttribute('data-state');
                        const isNotify = item.getAttribute('data-notify') === 'true';
                        const isOwnerChanged = item.getAttribute('data-owner-changed') === 'true';
                        
                        let matchesSearch = searchTerm === '' || text.includes(searchTerm);
                        let matchesFilter = activeFilters.length === 0;
                        if (activeFilters.length > 0) {{
                            activeFilters.forEach(f => {{
                                if (f === 'ALTA' && state === 'ALTA') matchesFilter = true;
                                if (f === 'BAJA' && state === 'BAJA') matchesFilter = true;
                                if (f === 'OWNER_CHANGE' && isOwnerChanged) matchesFilter = true;
                                if (f === 'NOTIFY' && isNotify) matchesFilter = true;
                            }});
                        }}

                        if (matchesSearch && matchesFilter) {{
                            item.classList.remove('hidden');
                            visibleCount++;
                        }} else {{
                            item.classList.add('hidden');
                        }}
                    }});
                    
                    if (searchTerm === '' && activeFilters.length === 0) {{
                        parcelCount.textContent = `${{totalParcels}} Recintos`;
                    }} else {{
                        parcelCount.textContent = `${{visibleCount}} de ${{totalParcels}} Recintos`;
                    }}
                }}

                searchBox.addEventListener('input', performSearch);
                
                filterBtns.forEach(btn => {{
                    btn.addEventListener('click', () => {{
                        const filter = btn.getAttribute('data-filter');
                        btn.classList.toggle('active');
                        
                        if (btn.classList.contains('active')) {{
                            activeFilters.push(filter);
                        }} else {{
                            activeFilters = activeFilters.filter(f => f !== filter);
                        }}
                        
                        performSearch();
                    }});
                }});
                
                clearBtn.addEventListener('click', function() {{
                    searchBox.value = '';
                    performSearch();
                    searchBox.focus();
                }});
                
                searchBox.addEventListener('keydown', function(e) {{
                    if (e.key === 'Escape') {{
                        searchBox.value = '';
                        performSearch();
                    }}
                }});
            </script>
        </body>
        </html>
        """
        return html

    def _render_islands_section(self, isl, thresholds=None):
        """Renderiza la tabla de análisis de huecos/islas con lógica de umbrales."""
        if not isl:
            return '<div style="color:#ccc; font-style:italic; padding:10px">Sin huecos detectados</div>'
            
        # Umbrales
        if thresholds is None: thresholds = {}
        
        # 1. Área
        m_a_abs = self._chk(isl['delta_area'], thresholds.get('area_abs'))
        pct_area = self._get_pct(isl['area_a'], isl['area_d'])
        m_a_pct = self._chk(pct_area, thresholds.get('area_pct'))
        cls_area = "text-pos" if isl['delta_area'] > 0.1 else "text-neg" if isl['delta_area'] < -0.1 else ""
        
        # 2. Perímetro
        m_p_abs = self._chk(isl['delta_perim'], thresholds.get('perim_abs'))
        pct_perim = self._get_pct(isl['perim_a'], isl['perim_d'])
        m_p_pct = self._chk(pct_perim, thresholds.get('perim_pct'))
        cls_perim = "text-pos" if isl['delta_perim'] > 0.1 else "text-neg" if isl['delta_perim'] < -0.1 else ""
        
        # 3. Desplazamiento (Usa el umbral desp_max)
        m_desp = self._chk(isl['displacement'], thresholds.get('desp_max'))
        
        html = f"""
        <table class="mini-table">
            <colgroup>
                <col style="width: 35%"><col style="width: 15%"><col style="width: 15%"><col style="width: 12%"><col style="width: 14px"><col style="width: 12%"><col style="width: 14px">
            </colgroup>
            <tr><th>Parámetro</th><th class="num-col">Antes</th><th class="num-col">Después</th><th class="num-col">Var</th><th></th><th class="num-col">%</th><th></th></tr>
            <tr>
                <td>Sup. Islas (m²)</td>
                <td class="val-num">{self._fmt_val(isl['area_a'])}</td>
                <td class="val-num">{self._fmt_val(isl['area_d'])}</td>
                <td class="val-num {cls_area} {'diff-nonzero' if abs(isl['delta_area']) > 0.001 else ''}">{self._fmt_diff(isl['delta_area'])}</td>
                <td class="mark-slot">{m_a_abs}</td>
                <td class="val-num {cls_area} {'diff-nonzero' if abs(isl['delta_area']) > 0.001 else ''}">{self._fmt_pct(pct_area)}</td>
                <td class="mark-slot">{m_a_pct}</td>
            </tr>
            <tr>
                <td>Perim. Islas (m)</td>
                <td class="val-num">{self._fmt_val(isl['perim_a'])}</td>
                <td class="val-num">{self._fmt_val(isl['perim_d'])}</td>
                <td class="val-num {cls_perim} {'diff-nonzero' if abs(isl['delta_perim']) > 0.001 else ''}">{self._fmt_diff(isl['delta_perim'])}</td>
                <td class="mark-slot">{m_p_abs}</td>
                <td class="val-num {cls_perim} {'diff-nonzero' if abs(isl['delta_perim']) > 0.001 else ''}">{self._fmt_pct(pct_perim)}</td>
                <td class="mark-slot">{m_p_pct}</td>
            </tr>
            <tr>
                <td>Cant. Islas (n)</td>
                <td class="val-num">{self._fmt_val(isl['count_a'], force_int=True)}</td>
                <td class="val-num">{self._fmt_val(isl['count_d'], force_int=True)}</td>
                <td class="val-num {'diff-nonzero' if isl['delta_count'] != 0 else ''}">{self._fmt_diff(isl['delta_count'], force_int=True)}</td>
                <td class="mark-slot">{" *" if isl['delta_count'] != 0 else ""}</td>
                <td class="val-num {'diff-nonzero' if isl['delta_count'] != 0 else ''}">{self._fmt_pct(self._get_pct(isl['count_a'], isl['count_d']))}</td>
                <td class="mark-slot">{" *" if isl['delta_count'] != 0 else ""}</td>
            </tr>
            <tr style="background:#fcfcfc">
                <td>Desplazamiento (m)</td>
                <td></td>
                <td></td>
                <td class="val-num {'diff-nonzero' if isl['displacement'] > 0.05 else ''}" style="text-align:right">{self._fmt_val(isl['displacement'])}</td>
                <td class="mark-slot">{m_desp}</td>
            <td style="text-align:center; color:var(--primary); font-family:Consolas, monospace">{self._get_arrow(isl['displacement_dir'])} {isl['displacement_dir']}</td>
                <td></td>
            </tr>
        </table>
        """
        return html

    def _render_flows(self, flows, current_st, target_st, special_owners=None, flow_direction='input'):
        """Renderiza flujos de entrada (inputs) o salida (outputs).
        
        Args:
            flows: Lista de flujos a renderizar
            current_st: Estado actual de la parcela
            target_st: Estado objetivo ('ALTA' o 'BAJA')
            special_owners: Diccionario de propietarios especiales
            flow_direction: 'input' para ORIGEN o 'output' para DESTINO
        """
        if special_owners is None:
            special_owners = {}
            
        if not flows and current_st == target_st:
            color = "#3498db" if target_st == 'ALTA' else "#c0392b"
            text = "ALTA PURA (Sin matriz previa)" if target_st == 'ALTA' else "BAJA PURA (Desaparición física)"
            return f"<div class='flow-item' style='border-left:3px solid {color}'>{text}</div>"
        elif not flows:
            return "<div style='color:#ccc; font-style:italic'>Sin registros</div>"
        
        html = ""
        for flow in flows:
            # Seleccionar campos correctos según la dirección del flujo
            if flow_direction == 'input':
                # Para INPUTS (ORIGEN): mostrar de dónde viene
                parcel_id = flow.get('source', 'N/A')
                owner = flow.get('prop_source', 'Desc.')
            else:
                # Para OUTPUTS (DESTINO): mostrar hacia dónde va
                parcel_id = flow.get('target', 'N/A')
                owner = flow.get('prop_target', 'Desc.')
            
            # Marcar si el propietario es especial (comparación numérica)
            symbol = ""
            try:
                # Intentar convertir owner a int para comparación numérica
                owner_num = int(owner) if owner not in ["Desc.", None, "", "-"] else None
                if owner_num is not None and owner_num in special_owners:
                    symbol = f"<sup style='font-size: 0.8em; font-weight: bold;'>{special_owners[owner_num]['symbol']}</sup>"
            except (ValueError, TypeError):
                # Si owner no es numérico, no marcar
                pass
            
            html += f"""
                <div class="flow-item">
                    <span><b>{parcel_id}{symbol}</b> ({owner})</span>
                    <span class="val-num" style="background:none">{self._fmt_val(flow['area'])} m²</span>
                </div>
            """
        return html
