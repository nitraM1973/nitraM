import os
from datetime import datetime

class ReportService:
    def __init__(self, output_dir):
        self.output_dir = output_dir
        self.informes_dir = os.path.join(output_dir, "informes")
        os.makedirs(self.informes_dir, exist_ok=True)

    def generate_html(self, metrics_data, filename="informe_auditoria.html", thresholds=None):
        path = os.path.join(self.informes_dir, filename)
        
        # Si no pasan umbrales, usar diccionario vacío para evitar errores
        if thresholds is None:
            thresholds = {}
            
        html_content = self._build_html(metrics_data, thresholds)
        
        with open(path, 'w', encoding='utf-8') as f:
            f.write(html_content)
            
        return path

    def _chk(self, val, threshold, is_pct=False):
        """
        Retorna una tupla (str_asterisco, bool_exceeded).
        """
        if threshold is None:
            return "", False
            
        # Para umbrales numéricos, 0 suele significar "cualquier cambio" 
        # pero en métricas de área/perímetro a veces se usa para desactivar.
        # Mantenemos la lógica de que 0 desactiva EXCEPTO si es explícito.
        if threshold == 0 and not is_pct:
            return "", False
        
        # Comparación inclusiva (Senior request: >=)
        if abs(val) >= threshold:
            return " *", True
        
        return "", False

    def _generate_aditamentos_section(self, d, thresholds=None):
        """Genera el HTML para la sección de aditamentos de una parcela."""
        adits = d.get('aditamentos', {})
        if not adits:
            html = """
            <div class="panel" style="border-top:1px solid #eee; background:#fcfcfc">
                <div class="panel-title">AUDITORÍA DE ADITAMENTOS</div>
                <div style="color:#ccc; font-style:italic">Sin salidas</div>
            </div>
            """
            return html, False
            
        TOL = 0.001 # Tolerancia para ruidos milimétricos en geometrías

        def get_pct(delta, antes):
            if abs(delta) < TOL: return 0.0
            if abs(antes) < TOL:
                return 100.0 if abs(delta) >= TOL else 0.0
            return (delta / antes) * 100.0

        html = """
        <div class="panel" style="border-top:1px solid #eee; background:#fcfcfc">
            <div class="panel-title">AUDITORÍA DE ADITAMENTOS</div>
            <table class="mini-table">
                <tr><th>ELEMENTO</th><th>Antes</th><th>Después</th><th>Var</th><th>%</th></tr>
        """
        
        # Obtener umbrales desde configuración o usar defaults
        if thresholds and 'aditamentos' in thresholds:
            t_linear_abs = thresholds['aditamentos']['linear']['abs']
            t_linear_pct = thresholds['aditamentos']['linear']['pct']
            t_poly_abs = thresholds['aditamentos']['poly']['abs']
            t_poly_pct = thresholds['aditamentos']['poly']['pct']
            t_point = 0  # Cualquier cambio en puntos
        else:
            # Defaults si no hay configuración
            t_linear_abs = 1.0
            t_linear_pct = 5.0
            t_poly_abs = 1.0
            t_poly_pct = 5.0
            t_point = 0
        
        any_adit_alert = False

        # Ordenar elementos para consistencia
        for el_name, data in sorted(adits.items()):
            a = data['a']
            d_val = data['d']
            
            # 1. Líneas (Longitud) - Usar umbrales lineales
            if a['len'] >= TOL or d_val['len'] >= TOL:
                delta = d_val['len'] - a['len']
                pct = get_pct(delta, a['len'])
                
                # Check threshold con lógica unificada para marcar en ambas columnas
                _, e_abs = self._chk(delta, t_linear_abs)
                _, e_pct = self._chk(pct, t_linear_pct, is_pct=True)
                exceeded = abs(delta) >= TOL and (e_abs or e_pct)
                mark = " *" if exceeded else ""
                if exceeded: any_adit_alert = True
                
                cls = "text-pos" if delta > 0.05 else "text-neg" if delta < -0.05 else ""
                html += f"""
                    <tr>
                        <td>{el_name} (Longitud)</td>
                        <td class="val-num">{a['len']:.1f} m</td>
                        <td class="val-num">{d_val['len']:.1f} m</td>
                        <td class="val-num {cls} {'diff-nonzero' if abs(delta) >= TOL else ''}">{delta:+.1f} m{mark}</td>
                        <td class="val-num {cls} {'diff-nonzero' if abs(delta) >= TOL else ''}">{pct:+.1f}%{mark}</td>
                    </tr>
                """
            
            # 2. Polígonos (Superficie y Conteo) - Usar umbrales poligonales
            if a['area'] >= TOL or d_val['area'] >= TOL:
                # Superficie
                delta_area = d_val['area'] - a['area']
                pct_area = get_pct(delta_area, a['area'])
                
                _, e_abs_a = self._chk(delta_area, t_poly_abs)
                _, e_pct_a = self._chk(pct_area, t_poly_pct, is_pct=True)
                exceeded_area = abs(delta_area) >= TOL and (e_abs_a or e_pct_a)
                mark_a = " *" if exceeded_area else ""
                if exceeded_area: any_adit_alert = True
                
                cls_area = "text-pos" if delta_area > 0.1 else "text-neg" if delta_area < -0.1 else ""
                html += f"""
                    <tr>
                        <td>{el_name} (Superficie)</td>
                        <td class="val-num">{a['area']:.1f} m²</td>
                        <td class="val-num">{d_val['area']:.1f} m²</td>
                        <td class="val-num {cls_area} {'diff-nonzero' if abs(delta_area) >= TOL else ''}">{delta_area:+.1f} m²{mark_a}</td>
                        <td class="val-num {cls_area} {'diff-nonzero' if abs(delta_area) >= TOL else ''}">{pct_area:+.1f}%{mark_a}</td>
                    </tr>
                """
                # Conteo de polígonos - Usar umbral de puntos (cualquier cambio)
                delta_cnt = d_val['count'] - a['count']
                pct_cnt = get_pct(delta_cnt, a['count'])
                
                exceeded_cnt = delta_cnt != t_point
                mark_c = " *" if exceeded_cnt else ""
                if exceeded_cnt: any_adit_alert = True
 
                cls_cnt = "text-pos" if delta_cnt > 0 else "text-neg" if delta_cnt < 0 else ""
                html += f"""
                    <tr>
                        <td>{el_name} (Cant. Políg.)</td>
                        <td class="val-num">{a['count']}</td>
                        <td class="val-num">{d_val['count']}</td>
                        <td class="val-num {cls_cnt} {'diff-nonzero' if delta_cnt != 0 else ''}">{delta_cnt:+d}{mark_c}</td>
                        <td class="val-num {cls_cnt} {'diff-nonzero' if delta_cnt != 0 else ''}">{pct_cnt:+.1f}%{mark_c}</td>
                    </tr>
                """
            
            # 3. Puntos (Solo Conteo) - Cualquier cambio es alerta
            # Detectamos si es punto si tiene count pero NO tiene longitud ni area
            elif a['count'] > 0 or d_val['count'] > 0:
                 delta_cnt = d_val['count'] - a['count']
                 pct_cnt = get_pct(delta_cnt, a['count'])
                 
                 exceeded_cnt = delta_cnt != t_point
                 mark_c = " *" if exceeded_cnt else ""
                 if exceeded_cnt: any_adit_alert = True
 
                 cls_cnt = "text-pos" if delta_cnt > 0 else "text-neg" if delta_cnt < 0 else ""
                 html += f"""
                    <tr>
                        <td>{el_name} (Unidades)</td>
                        <td class="val-num">{a['count']}</td>
                        <td class="val-num">{d_val['count']}</td>
                        <td class="val-num {cls_cnt} {'diff-nonzero' if delta_cnt != 0 else ''}">{delta_cnt:+d}{mark_c}</td>
                        <td class="val-num {cls_cnt} {'diff-nonzero' if delta_cnt != 0 else ''}">{pct_cnt:+.1f}%{mark_c}</td>
                    </tr>
                """
        
        html += "</table></div>"
        return html, any_adit_alert

    def _build_html(self, data, thresholds):
        matrix = data.get('transition_matrix', [])
        details = data.get('parcel_details', [])
        
        # Totales KPI
        total_area = sum(m['area'] for m in matrix)
        total_bajas = sum(m['area'] for m in matrix if m['type'] == 'BAJA')
        
        # Definir tipos de fachada fijos
        fixed_facade_types = ['VIALES', 'CURSOS AGUA', 'EDIFICACIONES', 'EXCLUIDO']

        html = f"""
        <!DOCTYPE html>
        <html lang="es">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Fichas de Auditoría por Recinto</title>
            <style>
                :root {{ --primary: #2c3e50; --sec: #34495e; --accent: #3498db; --bg: #f5f7fa; --card-bg: #fff; --border: #e1e4e8; }}
                body {{ font-family: 'Segoe UI', sans-serif; background: var(--bg); color: #333; margin: 0; display: flex; height: 100vh; overflow: hidden; }}
                
                /* Sidebar TOC */
                .sidebar {{ width: 280px; background: white; border-right: 1px solid var(--border); flex-shrink: 0; display: flex; flex-direction: column; position: relative; }}
                .sidebar-header {{ padding: 20px; background: var(--primary); color: white; position: sticky; top: 0; z-index: 10; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }}
                .search-container {{ position: relative; margin-top: 10px; display: flex; align-items: center; }}
                .search-box {{ width: 100%; padding: 8px 30px 8px 12px; border: none; border-radius: 4px; font-size: 0.9em; background: rgba(255,255,255,0.9); color: #333; box-sizing: border-box; }}
                .search-box::placeholder {{ color: #999; }}
                .search-box:focus {{ outline: 2px solid var(--accent); background: white; }}
                .clear-btn {{ position: absolute; right: 8px; cursor: pointer; color: #999; font-weight: bold; background: none; border: none; font-size: 1.2em; display: none; }}
                .clear-btn:hover {{ color: #333; }}
                .toc-list {{ list-style: none; padding: 0; margin: 0; overflow-y: auto; flex-grow: 1; }}
                .toc-item {{ border-bottom: 1px solid var(--border); }}
                .toc-item.hidden {{ display: none; }}
                .toc-link {{ display: block; padding: 12px 20px; text-decoration: none; color: #555; font-size: 0.9em; transition: 0.2s; }}
                .toc-link:hover {{ background: #f0f4f8; color: var(--accent); }}
                .toc-link.active {{ background: #e3f2fd; border-left: 4px solid var(--accent); font-weight: bold; }}
                .toc-badge {{ float: right; font-size: 0.75em; padding: 2px 6px; border-radius: 4px; color: white; }}
                
                /* Warning Badge in Sidebar */
                .toc-warning {{ display: inline-block; width: 14px; height: 14px; background: red; color: white; border-radius: 50%; font-size: 10px; text-align: center; line-height: 14px; margin-right: 5px; font-weight: bold; }}

                /* Report Header (Visible on Screen & Print) */
                .report-header {{ position: sticky; top: 0; z-index: 100; display: block; padding: 15px 30px; border-bottom: 2px solid var(--primary); margin-bottom: 0; background: white; box-shadow: 0 4px 6px rgba(0,0,0,0.05); }}
                .report-header h1 {{ margin: 0 0 5px 0; font-size: 22px; color: var(--primary); }}
                .report-meta {{ font-size: 12px; color: #555; display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }}
                .meta-group strong {{ display: block; margin-bottom: 2px; color: #000; }}

                /* Main Content */
                .main-content {{ flex-grow: 1; overflow-y: auto; padding: 0; scroll-behavior: smooth; }}
                
                .cards-wrapper {{ padding: 20px; }}

                /* Audit Card */
                .audit-card {{ background: white; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); margin-bottom: 30px; overflow: hidden; border: 1px solid var(--border); }}
                .audit-card.alert-border {{ border: 2px solid #e74c3c; }}
                .card-header {{ background: linear-gradient(to right, #f8f9fa, #fff); padding: 12px 20px; border-bottom: 1px solid var(--border); display: flex; justify-content: space-between; align-items: center; }}
                .card-title h2 {{ margin: 0; color: var(--primary); font-size: 1.3em; }}
                .card-title span {{ color: #7f8c8d; font-size: 0.85em; }}
                
                .grid-panels {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(400px, 1fr)); gap: 0; }}
                .panel {{ padding: 15px; border-bottom: 1px solid var(--border); }} /* Padding reducido de 25px a 15px */
                .panel:not(:last-child) {{ border-right: 1px solid var(--border); }}
                .panel-title {{ font-size: 0.8em; text-transform: uppercase; letter-spacing: 1px; color: #888; margin-bottom: 10px; font-weight: bold; border-left: 3px solid var(--accent); padding-left: 8px; }}
                
                /* Tables inside cards */
                .mini-table {{ width: 100%; font-size: 0.85em; border-collapse: collapse; }}
                .mini-table th {{ text-align: left; color: #666; font-weight: 600; padding: 4px 0; border-bottom: 1px solid #eee; }}
                .mini-table td {{ padding: 5px 0; border-bottom: 1px solid #f9f9f9; }}
                .val-num {{ font-family: 'Consolas', monospace; font-weight: 600; }}
                
                /* Badges & Colors */
                .bg-persiste {{ background: #27ae60; }}
                .bg-alta {{ background: #2980b9; }}
                .bg-baja {{ background: #c0392b; }}
                .bg-cambio {{ background: #f39c12; }}
                .text-pos {{ color: #27ae60; }}
                .text-neg {{ color: #c0392b; }}
                
                /* Flows */
                .flow-item {{ display: flex; justify-content: space-between; padding: 8px; background: #f8f9fa; border-radius: 6px; margin-bottom: 6px; font-size: 0.9em; }}
                .flow-arrow {{ color: #bbb; margin: 0 10px; }}
                
                /* Owner Change Indicator */
                .owner-change {{ display: inline-block; margin-left: 10px; padding: 4px 10px; border-radius: 4px; font-size: 0.85em; font-weight: bold; }}
                .owner-change.changed {{ background: #ff9800; color: white; }}
                .owner-change.unchanged {{ background: #4caf50; color: white; }}
                
                .alert-label {{ background: #e74c3c; color: white; padding: 4px 8px; border-radius: 4px; font-weight: bold; font-size: 0.8em; margin-right: 10px; }}

                /* Change Indicator */
                .diff-nonzero {{ color: #e74c3c !important; font-weight: bold; }}

                /* Print Styles */
                @media print {{
                    .sidebar {{ display: none !important; }}
                    body {{ display: block; height: auto; overflow: visible; background: white; font-size: 11px; }}
                    .main-content {{ width: 100%; max-width: 100%; padding: 0; overflow: visible; margin: 0; }}
                    .audit-card {{ page-break-after: auto; page-break-inside: avoid; margin: 0 0 10px 0; box-shadow: none; border: 1px solid #ccc; padding: 0; }}
                    .audit-card.hidden {{ display: none !important; }}
                    .card-header {{ padding: 5px 10px; background: #eee; }}
                    .card-title h2 {{ font-size: 1.1em; margin: 0; }}
                    .panel {{ padding: 5px !important; }}
                    .mini-table td, .mini-table th {{ padding: 2px 0 !important; font-size: 0.9em; }}
                    .report-header {{ position: static; display: block !important; border: 1px solid #ddd; margin-bottom: 10px; padding: 10px; box-shadow: none; }}
                    .cards-wrapper {{ padding: 0; }}
                    * {{ box-shadow: none !important; }}
                }}

                /* Filter UI */
                .filter-group {{ margin-top: 15px; display: flex; flex-wrap: wrap; gap: 8px; }}
                .filter-btn {{ 
                    background: rgba(255,255,255,0.15); border: 1px solid rgba(255,255,255,0.3);
                    color: white; font-size: 0.75em; padding: 4px 8px; border-radius: 4px; 
                    cursor: pointer; transition: 0.2s; user-select: none;
                }}
                .filter-btn:hover {{ background: rgba(255,255,255,0.25); }}
                .filter-btn.active {{ background: var(--accent); border-color: var(--accent); font-weight: bold; }}
                .filter-btn.warning-filter {{ background: rgba(231, 76, 60, 0.4); border-color: #e74c3c; }}
                .filter-btn.warning-filter.active {{ background: #e74c3c; }}
                
                .toc-owner-indicator {{ 
                    display: inline-block; width: 8px; height: 8px; 
                    background: #ff9800; border-radius: 50%; margin-right: 5px; 
                    box-shadow: 0 0 5px rgba(255,152,0,0.5);
                }}
            </style>
        </head>
        <body>
            <div class="sidebar">
                <div class="sidebar-header">
                    <h3 style="margin:0">Índice de Recintos</h3>
                    <small id="parcel-count">{len(details)} Recintos</small>
                    <div class="search-container">
                        <input type="text" class="search-box" id="search-box" placeholder="🔍 Buscar recinto..." />
                        <button class="clear-btn" id="clear-btn" title="Limpiar búsqueda">&times;</button>
                    </div>
                    <div class="filter-group">
                        <div class="filter-btn" data-filter="ALTA">NUEVA</div>
                        <div class="filter-btn" data-filter="BAJA">DESAPARECE</div>
                        <div class="filter-btn" data-filter="OWNER_CHANGE">TITULAR</div>
                        <div class="filter-btn warning-filter" data-filter="NOTIFY">⚠ REVISAR</div>
                    </div>
                </div>
                <ul class="toc-list" id="toc-list">
        """
        
        # Generar TOC y Cards
        def sort_key(d):
            try:
                s = d['id'].replace('-', '/').split('/')
                nums = []
                for p in s:
                    try: nums.append(int(p))
                    except: nums.append(0)
                return tuple(nums)
            except:
                return (0,)
                
        sorted_details = sorted(details, key=sort_key)
        
        toc_html = ""
        cards_html = ""
        
        for d in sorted_details:
            st = d['state']
            
            # Flags de notificación para esta parcela
            notify = False
            
            # --- CHECK THRESHOLDS ---
            
            # 1. Geometría
            area_d = d.get('area_final', 0)
            delta_area = d.get('delta_area', 0)
            area_a = area_d - delta_area if st != 'BAJA' else abs(delta_area)
            pct_area = (delta_area / area_a * 100) if area_a else (100 if delta_area else 0)
            
            m_a_abs, e1 = self._chk(delta_area, thresholds.get('area_abs'))
            m_a_pct, e2 = self._chk(pct_area, thresholds.get('area_pct'))
            
            perim_a = d.get('perim_a', 0); perim_d = d.get('perim_d', 0)
            delta_perim = d.get('delta_perim', 0)
            pct_perim = (delta_perim / perim_a * 100) if perim_a else (100 if delta_perim else 0)
            
            m_p_abs, e3 = self._chk(delta_perim, thresholds.get('perim_abs'))
            m_p_pct, e4 = self._chk(pct_perim, thresholds.get('perim_pct'))
            
            grav_d = d.get('grav_d', 0)
            m_k, e5 = self._chk(grav_d, thresholds.get('gravelius')) # Gravelius es absoluto
            
            hole_area_a = d.get('hole_area_a', 0.0)
            delta_hole_area = d.get('delta_hole_area', 0.0)
            pct_rings_area = (delta_hole_area / hole_area_a * 100) if hole_area_a else (100 if delta_hole_area else 0)
            m_inv, e6 = self._chk(pct_rings_area, thresholds.get('invasion_pct')) # Huecos pct

            # Acumular alertas geométricas
            if e1 or e2 or e3 or e4 or e5 or e6:
                notify = True

            # 2. Fachadas
            facade_rows_html = ""
            facade_labels = {'VIALES': 'Viales', 'CURSOS AGUA': 'AGUAS', 'EDIFICACIONES': 'EDIF', 'EXCLUIDO': 'EXCL'}
            
            for t_code in fixed_facade_types:
                val_a = d.get(f'facade_antes_{t_code}', 0.0)
                val_d = d.get(f'facade_desp_{t_code}', 0.0)
                delta = val_d - val_a
                pct = (delta / val_a * 100) if val_a else (100 if delta else 0)
                cls = "text-pos" if delta > 0.01 else "text-neg" if delta < -0.01 else ""
                label = facade_labels.get(t_code, t_code)
                
                # Check thresholds
                f_lims = thresholds.get('facades', {})
                f_key = 'VIAL' if 'VIAL' in t_code else 'AGUA' if 'AGUA' in t_code else 'EDIF' if 'EDIF' in t_code else 'EXCL'
                lims = f_lims.get(f_key, {})
                
                m_f_abs, ef1 = self._chk(delta, lims.get('abs'))
                m_f_pct, ef2 = self._chk(pct, lims.get('pct'))
                
                if ef1 or ef2: notify = True
                
                facade_rows_html += f"""
                    <tr>
                        <td>{label}</td>
                        <td class="val-num">{val_a:.1f} m</td>
                        <td class="val-num">{val_d:.1f} m</td>
                        <td class="val-num {cls} {'diff-nonzero' if abs(delta) > 0.001 else ''}">{delta:+.1f} m{m_f_abs}</td>
                        <td class="val-num {cls} {'diff-nonzero' if abs(delta) > 0.001 else ''}">{pct:+.1f}%{m_f_pct}</td>
                    </tr>
                """

            # 3. Aditamentos (Check interno y generación HTML)
            adit_html, adit_alert = self._generate_aditamentos_section(d, thresholds)
            if adit_alert: notify = True

            # --- FIN CHECKS ---

            state_labels = {'ALTA': 'NUEVA', 'BAJA': 'DESAPARECE', 'PERSISTENTE': 'PERSISTENTE'}
            display_st = state_labels.get(st, st)
            letter = display_st[0]
            bg = "#27ae60" if st == 'PERSISTENTE' else "#c0392b" if st == 'BAJA' else "#2980b9" if st == 'ALTA' else "#f39c12"
            anchor_id = d['id'].replace('/', '_')
            
            owner_changed = d.get('owner_changed', False)
            if owner_changed and st == 'PERSISTENTE': 
                notify = True # Cambio de titular también es alerta

            # TOC Item
            warn_icon = '<span class="toc-warning">!</span>' if notify else ""
            badge_html = f'<span class="toc-badge" style="background:{bg}; float:right">{letter}</span>' if st != 'PERSISTENTE' else ""
            
            toc_html += f"""
                    <li class="toc-item" data-state="{st}" data-owner-changed="{'true' if owner_changed else 'false'}" data-notify="{'true' if notify else 'false'}">
                        <a href="#id-{anchor_id}" class="toc-link">
                            {warn_icon}{d['id']}
                            {badge_html}
                        </a>
                    </li>
            """
            
            # Card HEADER
            alert_label = '<span class="alert-label">⚠ REVISAR</span>' if notify else ""
            
            # Owner display
            p_a = d.get('prop_a', 'N/A')
            p_d = d.get('prop_d', 'N/A')
            owner_display = f'<span style="color:red; font-weight:bold">Titular: {p_a} → {p_d}</span>' if owner_changed else f'<span style="color:#7f8c8d">Titular: {p_d}</span>'
            if st == 'ALTA': owner_display = f'<span>Titular: (Nuevo) → {p_d}</span>'
            if st == 'BAJA': owner_display = f'<span>Titular: {p_a} → (Baja)</span>'

            # Metric Formatters
            diff_area_fmt = f"{delta_area:+.2f}"
            cls_area = "text-pos" if delta_area > 0 else "text-neg" if delta_area < 0 else ""
            card_border_cls = "alert-border" if notify else ""

            parts_a = d.get('parts_a', 1); parts_d = d.get('parts_d', 1); delta_parts = parts_d - parts_a
            pct_parts = (delta_parts / parts_a * 100) if parts_a else 0
            
            grav_a = d.get('grav_a', 0); grav_d = d.get('grav_d', 0); grav_delta = d.get('delta_grav', 0)
            pct_grav = (grav_delta / grav_a * 100) if grav_a else 0
            
            rings_a = d.get('rings_a', 0); rings_d = d.get('rings_d', 0); rings_delta = d.get('delta_rings', 0)
            pct_rings = (rings_delta / rings_a * 100) if rings_a else 0

            topo_label = "Mono-parte" if parts_d <= 1 else f"Multi-parte: {parts_d} partes"
            
            # Generar Card HTML
            card = f"""
                <div id="id-{anchor_id}" class="audit-card {card_border_cls}">
                    <div class="card-header">
                        <div class="card-title">
                            <h2>{d['id']} {alert_label}</h2>
                            {owner_display}
                        </div>
                        <div style="text-align:right">
                             <div style="margin-top:5px; font-weight:bold; {cls_area}">{diff_area_fmt} m²</div>
                        </div>
                    </div>
                    
                    <div class="grid-panels">
                        <div class="panel">
                            <div class="panel-title">MÉTRICAS GEOMÉTRICAS ({topo_label})</div>
                            <table class="mini-table">
                                <tr><th>Parámetro</th><th>Antes</th><th>Después</th><th>Var</th><th>%</th></tr>
                                <tr>
                                    <td>Superficie</td>
                                    <td class="val-num">{area_a:.2f} m²</td>
                                    <td class="val-num">{area_d:.2f} m²</td>
                                    <td class="val-num {cls_area} {'diff-nonzero' if abs(delta_area) > 0.001 else ''}">{delta_area:+.2f}{m_a_abs}</td>
                                    <td class="val-num {cls_area} {'diff-nonzero' if abs(delta_area) > 0.001 else ''}">{pct_area:+.1f}%{m_a_pct}</td>
                                </tr>
                                <tr>
                                    <td>Perímetro</td>
                                    <td class="val-num">{perim_a:.1f} m</td>
                                    <td class="val-num">{perim_d:.1f} m</td>
                                    <td class="val-num {cls_area} {'diff-nonzero' if abs(delta_perim) > 0.001 else ''}">{delta_perim:+.1f}{m_p_abs}</td>
                                    <td class="val-num {cls_area} {'diff-nonzero' if abs(delta_perim) > 0.001 else ''}">{pct_perim:+.1f}%{m_p_pct}</td>
                                </tr>
                                <tr>
                                    <td>Irregularidad (K)</td>
                                    <td class="val-num">{grav_a:.3f}</td>
                                    <td class="val-num">{grav_d:.3f}{m_k}</td>
                                    <td class="val-num {'diff-nonzero' if abs(grav_delta) > 0.001 else ''}">{grav_delta:+.3f}</td>
                                    <td class="val-num {'diff-nonzero' if abs(grav_delta) > 0.001 else ''}">{pct_grav:+.1f}%</td>
                                </tr>
                                <tr>
                                    <td>No. Islas/Partes</td>
                                    <td class="val-num">{rings_a}</td>
                                    <td class="val-num">{rings_d}</td>
                                    <td class="val-num {'diff-nonzero' if rings_delta != 0 else ''}">{rings_delta:+d}</td>
                                    <td class="val-num {'diff-nonzero' if rings_delta != 0 else ''}">{pct_rings:+.1f}%</td>
                                </tr>
                                <tr>
                                    <td>Sup. Huecos</td>
                                    <td class="val-num">{hole_area_a:.2f} m²</td>
                                    <td class="val-num">{d.get('hole_area_d',0):.2f} m²</td>
                                    <td class="val-num {'diff-nonzero' if abs(delta_hole_area) > 0.001 else ''}">{delta_hole_area:+.2f} m²</td>
                                    <td class="val-num {'diff-nonzero' if abs(delta_hole_area) > 0.001 else ''}">{pct_rings_area:+.1f}%{m_inv}</td>
                                </tr>
                            </table>
                        </div>
                        
                        <div class="panel">
                            <div class="panel-title">INTERACCIÓN CON ENTORNO (FACHADAS)</div>
                            <table class="mini-table">
                                <tr><th>Tipo</th><th>Antes</th><th>Después</th><th>Var</th><th>%</th></tr>
                                {facade_rows_html}
                            </table>
                        </div>
                    </div>
                    
                    <!-- Dinámica Territorial (Sin cambios grandes aquí, solo visualización) -->
                    <div class="panel" style="border-bottom:none; border-right:none; background:#fdfdfd">
                        <div class="panel-title">DINÁMICA TERRITORIAL</div>
                         <div style="display:flex; gap:30px">
                             <div style="flex:1">
                                 <h4 style="margin-top:0; font-size:0.9em; color:#666">ORIGEN (INPUTS)</h4>
                                 {self._render_flows(d.get('inputs', []), st, 'ALTA', data.get('special_owners', {}), 'input')}
                             </div>
                             <div style="border-left:1px solid #eee"></div>
                             <div style="flex:1">
                                 <h4 style="margin-top:0; font-size:0.9em; color:#666">DESTINO (OUTPUTS)</h4>
                                 {self._render_flows(d.get('outputs', []), st, 'BAJA', data.get('special_owners', {}), 'output')}
                             </div>
                         </div>
                    </div>

                    <!-- SECCIÓN ADITAMENTOS -->
                    {adit_html}
                </div>
            """
            cards_html += card

        html += f"""
            {toc_html}
                </ul>
            </div>
            <div class="main-content">
                <div class="report-header">
                    <h1>INFORME DE AUDITORÍA GRÁFICA</h1>
                    <div class="report-meta">
                        <div class="meta-group">
                            <strong>Archivos Fuente:</strong>
                            <div>ANTES: {data.get('input_files', {}).get('antes', 'N/A')}</div>
                            <div>DESPUÉS: {data.get('input_files', {}).get('despues', 'N/A')}</div>
                        </div>
                        <div class="meta-group">
                            <strong>Configuración de Análisis:</strong>
                            <div>Fecha: {datetime.now().strftime('%d/%m/%Y %H:%M')}</div>
                            <div><strong>Geometría:</strong> Ár:{thresholds.get('area_abs','-')}m²/{thresholds.get('area_pct','-')}% | 
                                 Per:{thresholds.get('perim_abs','-')}m/{thresholds.get('perim_pct','-')}% | 
                                 K:{thresholds.get('gravelius','-')} | Desp:{thresholds.get('desp_max','-')}m | Huecos:{thresholds.get('invasion_pct','-')}%</div>
                            <div><strong>Fachadas:</strong> 
                                 Vial:{thresholds.get('facades',{}).get('VIAL',{}).get('abs','-')}m/{thresholds.get('facades',{}).get('VIAL',{}).get('pct','-')}% |
                                 Agua:{thresholds.get('facades',{}).get('AGUA',{}).get('abs','-')}m/{thresholds.get('facades',{}).get('AGUA',{}).get('pct','-')}% |
                                 Edif:{thresholds.get('facades',{}).get('EDIF',{}).get('abs','-')}m/{thresholds.get('facades',{}).get('EDIF',{}).get('pct','-')}% |
                                 Excl:{thresholds.get('facades',{}).get('EXCL',{}).get('abs','-')}m/{thresholds.get('facades',{}).get('EXCL',{}).get('pct','-')}%</div>
                            <div><strong>Propietarios Especiales:</strong> <sup>1</sup> AGADER | <sup>2</sup> MASA COMÚN | <sup>3</sup> DESCONOCIDOS</div>
                        </div>
                    </div>
                </div>
                <div class="cards-wrapper">
                    {cards_html}
                </div>
            </div>
            <script>
                const searchBox = document.getElementById('search-box');
                const clearBtn = document.getElementById('clear-btn');
                const filterBtns = document.querySelectorAll('.filter-btn');
                const tocList = document.getElementById('toc-list');
                const parcelCount = document.getElementById('parcel-count');
                const totalParcels = {len(details)};
                
                let activeFilters = [];

                function performSearch() {{
                    const searchTerm = searchBox.value.toLowerCase().trim();
                    const items = tocList.querySelectorAll('.toc-item');
                    let visibleCount = 0;
                    
                    if (searchTerm !== '') clearBtn.style.display = 'block';
                    else clearBtn.style.display = 'none';

                    items.forEach(item => {{
                        const link = item.querySelector('.toc-link');
                        const text = link.textContent.toLowerCase();
                        const state = item.getAttribute('data-state');
                        const isNotify = item.getAttribute('data-notify') === 'true';
                        const isOwnerChanged = item.getAttribute('data-owner-changed') === 'true';
                        
                        let matchesSearch = searchTerm === '' || text.includes(searchTerm);
                        let matchesFilter = activeFilters.length === 0;
                        if (activeFilters.length > 0) {{
                            activeFilters.forEach(f => {{
                                if (f === 'ALTA' && state === 'ALTA') matchesFilter = true;
                                if (f === 'BAJA' && state === 'BAJA') matchesFilter = true;
                                if (f === 'OWNER_CHANGE' && isOwnerChanged) matchesFilter = true;
                                if (f === 'NOTIFY' && isNotify) matchesFilter = true;
                            }});
                        }}

                        if (matchesSearch && matchesFilter) {{
                            item.classList.remove('hidden');
                            visibleCount++;
                        }} else {{
                            item.classList.add('hidden');
                        }}
                    }});
                    
                    if (searchTerm === '' && activeFilters.length === 0) {{
                        parcelCount.textContent = `${{totalParcels}} Recintos`;
                    }} else {{
                        parcelCount.textContent = `${{visibleCount}} de ${{totalParcels}} Recintos`;
                    }}
                }}

                searchBox.addEventListener('input', performSearch);
                
                filterBtns.forEach(btn => {{
                    btn.addEventListener('click', () => {{
                        const filter = btn.getAttribute('data-filter');
                        btn.classList.toggle('active');
                        
                        if (btn.classList.contains('active')) {{
                            activeFilters.push(filter);
                        }} else {{
                            activeFilters = activeFilters.filter(f => f !== filter);
                        }}
                        
                        performSearch();
                    }});
                }});
                
                clearBtn.addEventListener('click', function() {{
                    searchBox.value = '';
                    performSearch();
                    searchBox.focus();
                }});
                
                searchBox.addEventListener('keydown', function(e) {{
                    if (e.key === 'Escape') {{
                        searchBox.value = '';
                        performSearch();
                    }}
                }});
            </script>
        </body>
        </html>
        """
        return html

    def _render_flows(self, flows, current_st, target_st, special_owners=None, flow_direction='input'):
        """Renderiza flujos de entrada (inputs) o salida (outputs).
        
        Args:
            flows: Lista de flujos a renderizar
            current_st: Estado actual de la parcela
            target_st: Estado objetivo ('ALTA' o 'BAJA')
            special_owners: Diccionario de propietarios especiales
            flow_direction: 'input' para ORIGEN o 'output' para DESTINO
        """
        if special_owners is None:
            special_owners = {}
            
        if not flows and current_st == target_st:
            color = "#3498db" if target_st == 'ALTA' else "#c0392b"
            text = "ALTA PURA (Sin matriz previa)" if target_st == 'ALTA' else "BAJA PURA (Desaparición física)"
            return f"<div class='flow-item' style='border-left:3px solid {color}'>{text}</div>"
        elif not flows:
            return "<div style='color:#ccc; font-style:italic'>Sin registros</div>"
        
        html = ""
        for flow in flows:
            # Seleccionar campos correctos según la dirección del flujo
            if flow_direction == 'input':
                # Para INPUTS (ORIGEN): mostrar de dónde viene
                parcel_id = flow.get('source', 'N/A')
                owner = flow.get('prop_source', 'Desc.')
            else:
                # Para OUTPUTS (DESTINO): mostrar hacia dónde va
                parcel_id = flow.get('target', 'N/A')
                owner = flow.get('prop_target', 'Desc.')
            
            # Marcar si el propietario es especial (comparación numérica)
            symbol = ""
            try:
                # Intentar convertir owner a int para comparación numérica
                owner_num = int(owner) if owner not in ["Desc.", None, "", "-"] else None
                if owner_num is not None and owner_num in special_owners:
                    symbol = f"<sup style='font-size: 0.8em; font-weight: bold;'>{special_owners[owner_num]['symbol']}</sup>"
            except (ValueError, TypeError):
                # Si owner no es numérico, no marcar
                pass
            
            html += f"""
                <div class="flow-item">
                    <span><b>{parcel_id}{symbol}</b> ({owner})</span>
                    <span class="val-num">{flow['area']:.2f} m²</span>
                </div>
            """
        return html
