# -*- coding: utf-8 -*-
"""
core/pdf_export/svg_sketch.py
================================

Renderizado del croquis (el dibujo vectorial ANTES/DESPUÉS de la finca,
con leyenda y escala gráfica) dentro del PDF, sin QtWebEngine.

DE DÓNDE VIENE EL DATO
-----------------------
``attrs['croquis_svg']`` contiene el fragmento HTML ya generado por
``ReportService._generate_sketch_svg`` (guardado tal cual en el
GeoPackage de auditoría): un ``<div class="sketch-section">`` con dos
partes:

    1. Un ``<svg class="sketch-svg" viewBox="0 0 W H">`` con la geometría
       real del croquis (contornos antes/después, superficie ganada/
       perdida, aditamentos, fincas colindantes de contexto...). Los
       elementos usan atributos ``class="sketch-..."`` que en el informe
       HTML se resuelven contra la hoja de estilos común
       (``ReportService._report_css()``) -- aquí NO hay ninguna hoja de
       estilos externa, así que antes de pasarle ese SVG a
       ``QSvgRenderer`` le inyectamos un ``<style>`` con esas mismas
       reglas (ver ``build_styled_svg_bytes``).
    2. Una barra lateral en HTML normal (leyenda + escala gráfica en
       metros + etiqueta "Recinto N") que en el informe HTML se maqueta
       con CSS al lado del SVG. Aquí se extrae el TEXTO de esas piezas
       con expresiones regulares (la estructura la genera siempre
       nuestro propio código, nunca contenido arbitrario de usuario, así
       que un regex dirigido es seguro y muchísimo más simple que meter
       un parser HTML completo) y se vuelve a dibujar a mano con
       QPainter, con el mismo criterio visual (colores, textos).

Si no hay croquis disponible (``croquis_svg`` vacío, o el SVG no es
válido para ``QSvgRenderer`` por cualquier motivo), se dibuja un
recuadro de aviso en vez de fallar: una ficha en PDF sin croquis sigue
siendo útil, un error a media exportación no.
"""

import re
import html as html_lib
from dataclasses import dataclass
from typing import Optional

from PyQt5.QtCore import QByteArray, QPointF, QRectF, Qt
from PyQt5.QtGui import QColor, QFont, QPen
from PyQt5.QtSvg import QSvgRenderer

from . import geometry as geo


# ---------------------------------------------------------------------
# Extracción de las piezas del fragmento guardado
# ---------------------------------------------------------------------

_RE_MAIN_SVG = re.compile(
    r'<svg\b[^>]*class="sketch-svg"[^>]*>.*?</svg>', re.S | re.I
)
_RE_VIEWBOX = re.compile(r'viewBox="0\s+0\s+([\d.]+)\s+([\d.]+)"')
_RE_LABEL = re.compile(r'<div class="sketch-label">(.*?)</div>', re.S)
_RE_SCALE_TEXT = re.compile(r'<div class="sketch-scalebar-text">(.*?)</div>', re.S)
_RE_NOTE = re.compile(r'<div class="sketch-note">(.*?)</div>', re.S)
_RE_PHANTOM_SPAN = re.compile(r'<span class="phantom">.*?</span>', re.S)
_RE_ANY_TAG = re.compile(r'<[^>]+>')


def _strip_html(fragment):
    """Convierte un fragmento HTML sencillo (generado por nuestro propio
    código, nunca HTML arbitrario) a texto plano:
      1. elimina los ``<span class="phantom">...</span>`` -- son decimales
         invisibles usados en el HTML solo para alinear columnas, no deben
         aparecer en el texto plano;
      2. quita el resto de etiquetas;
      3. des-escapa entidades (&nbsp;, &amp;...);
      4. colapsa espacios en blanco.
    """
    if not fragment:
        return ""
    txt = _RE_PHANTOM_SPAN.sub("", fragment)
    txt = _RE_ANY_TAG.sub("", txt)
    txt = html_lib.unescape(txt)
    return re.sub(r"\s+", " ", txt).strip()


@dataclass
class SketchParts:
    svg_markup: Optional[str] = None
    view_w: float = 100.0
    view_h: float = 100.0
    label_text: str = ""
    scale_text: str = ""
    note_text: str = ""
    has_adit_normal: bool = False
    has_adit_alert: bool = False
    has_context_edif: bool = False

    @property
    def is_available(self):
        return bool(self.svg_markup)


def extract_sketch_parts(croquis_svg_html):
    """Analiza el fragmento guardado en ``attrs['croquis_svg']`` y
    devuelve un ``SketchParts`` con todo lo necesario para dibujarlo.
    Nunca lanza excepción: ante cualquier fragmento inesperado devuelve
    un ``SketchParts`` "vacío" (``is_available == False``)."""
    parts = SketchParts()
    if not croquis_svg_html:
        return parts

    try:
        m = _RE_MAIN_SVG.search(croquis_svg_html)
        if m:
            parts.svg_markup = m.group(0)
            vb = _RE_VIEWBOX.search(parts.svg_markup)
            if vb:
                parts.view_w = float(vb.group(1))
                parts.view_h = float(vb.group(2))

        m = _RE_LABEL.search(croquis_svg_html)
        if m:
            parts.label_text = _strip_html(m.group(1))

        m = _RE_SCALE_TEXT.search(croquis_svg_html)
        if m:
            parts.scale_text = _strip_html(m.group(1))

        m = _RE_NOTE.search(croquis_svg_html)
        if m:
            parts.note_text = _strip_html(m.group(1))

        parts.has_adit_normal = 'class="leg-swatch leg-adit"' in croquis_svg_html
        parts.has_adit_alert = "leg-adit-alert" in croquis_svg_html
        parts.has_context_edif = "leg-edif" in croquis_svg_html
    except Exception:
        # Cualquier problema al analizar el fragmento no debe tirar
        # abajo la exportación de la ficha entera: nos quedamos sin
        # croquis y seguimos.
        return SketchParts()

    return parts


# ---------------------------------------------------------------------
# Inyección de estilos para que QSvgRenderer entienda las clases
# ---------------------------------------------------------------------

# Réplica textual de las reglas .sketch-* de ReportService._report_css().
# QtSvg entiende un <style> con selectores de clase sencillos (es el
# mismo mecanismo que usan la mayoría de temas de iconos SVG que carga
# QIcon/QSvgRenderer en cualquier aplicación Qt), así que basta con
# incrustar aquí las mismas reglas para que el SVG guardado se pinte con
# los colores correctos sin depender de ninguna hoja de estilos externa.
_SKETCH_STYLE = f"""
<style type="text/css"><![CDATA[
.sketch-bg {{ fill: {geo.SKETCH_BG_FILL}; stroke: {geo.SKETCH_BG_STROKE}; stroke-width: 1; }}
.sketch-study-fill {{ fill: #f0f0f0; stroke: none; }}
.sketch-antes {{ fill: none; stroke: {geo.SKETCH_ANTES_STROKE}; stroke-width: 2; stroke-dasharray: 6 4; }}
.sketch-despues {{ fill: none; stroke: {geo.SKETCH_DESPUES_STROKE}; stroke-width: 2.2; }}
.sketch-gained {{ fill: {geo.SKETCH_GAINED_FILL}; fill-opacity: 0.45; stroke: #004C75; stroke-width: 0.6; }}
.sketch-lost {{ fill: {geo.SKETCH_LOST_FILL}; fill-opacity: 0.45; stroke: #A66F00; stroke-width: 0.6; }}
.sketch-context {{ fill: none; stroke: {geo.SKETCH_CONTEXT_STROKE}; stroke-width: 0.6; }}
.sketch-context-edif {{ fill: url(#edifHatch); stroke: #777; stroke-width: 0.7; }}
.sketch-context-related {{ fill: none; stroke: #888; stroke-width: 1.1; stroke-dasharray: 3 2; }}
.sketch-context-label {{ fill: #aaa; font-size: 8px; font-family: sans-serif; text-anchor: middle; }}
.sketch-context-label-related {{ fill: #555; font-size: 8px; font-weight: bold; font-family: sans-serif; text-anchor: middle; }}
.sketch-adit {{ fill: {geo.SKETCH_ADIT_FILL}; fill-opacity: 0.30; stroke: {geo.SKETCH_ADIT_STROKE}; stroke-width: 0.8; }}
.sketch-adit-line {{ fill: none; stroke: {geo.SKETCH_ADIT_STROKE}; stroke-width: 1.4; }}
.sketch-adit-point {{ fill: {geo.SKETCH_ADIT_FILL}; stroke: {geo.SKETCH_ADIT_STROKE}; stroke-width: 0.6; }}
.sketch-adit-alert {{ fill: url(#aditAlertHatch); stroke: {geo.SKETCH_ADIT_ALERT_STROKE}; stroke-width: 1.8; }}
.sketch-adit-line-alert {{ fill: none; stroke: {geo.SKETCH_ADIT_ALERT_STROKE}; stroke-width: 2.4; stroke-dasharray: 4 2; }}
.sketch-adit-point-alert {{ fill: {geo.SKETCH_ADIT_ALERT_FILL}; stroke: {geo.SKETCH_ADIT_ALERT_STROKE}; stroke-width: 1.4; }}
.sketch-context-adit {{ fill: #bbb; fill-opacity: 0.25; stroke: #999; stroke-width: 0.5; }}
.sketch-context-adit-line {{ fill: none; stroke: #999; stroke-width: 0.9; stroke-dasharray: 2 1.5; }}
.sketch-context-adit-point {{ fill: #bbb; stroke: #999; stroke-width: 0.4; }}
]]></style>
""".strip()

_RE_SVG_OPEN_TAG = re.compile(r"(<svg\b[^>]*>)", re.I)

# Réplica de las mismas reglas de _SKETCH_STYLE, pero como diccionario
# clase -> declaraciones CSS, para poder escribirlas TAMBIÉN como
# atributo ``style="..."`` directamente sobre cada elemento.
#
# Por qué hace falta esto además del bloque ``<style>`` de arriba: el
# soporte de CSS de ``QSvgRenderer`` es muy limitado (no es un motor de
# navegador) y en la práctica no aplica de forma fiable reglas como
# ``fill: none`` declaradas solo vía selector de clase en un ``<style>``
# -- el resultado es que el elemento se queda con el relleno negro por
# defecto que marca la especificación SVG cuando no hay ``fill``
# resuelto, que es exactamente el problema de "todos los recintos en
# negro sólido". Los atributos de presentación puestos directamente en
# el elemento (``style="fill:...;stroke:..."``) sí se aplican siempre,
# así que se inyectan aquí como refuerzo, sin quitar el bloque
# ``<style>`` (inofensivo y útil si algún otro visor sí lo respeta).
_CLASS_STYLES = {
    "sketch-bg": f"fill:{geo.SKETCH_BG_FILL};stroke:{geo.SKETCH_BG_STROKE};stroke-width:1;",
    "sketch-study-fill": "fill:#f0f0f0;stroke:none;",
    "sketch-antes": f"fill:none;stroke:{geo.SKETCH_ANTES_STROKE};stroke-width:2;stroke-dasharray:6 4;",
    "sketch-despues": f"fill:none;stroke:{geo.SKETCH_DESPUES_STROKE};stroke-width:2.2;",
    "sketch-gained": f"fill:{geo.SKETCH_GAINED_FILL};fill-opacity:0.45;stroke:#004C75;stroke-width:0.6;",
    "sketch-lost": f"fill:{geo.SKETCH_LOST_FILL};fill-opacity:0.45;stroke:#A66F00;stroke-width:0.6;",
    "sketch-context": f"fill:none;stroke:{geo.SKETCH_CONTEXT_STROKE};stroke-width:0.6;",
    "sketch-context-edif": "fill:url(#edifHatch);stroke:#777;stroke-width:0.7;",
    "sketch-context-related": "fill:none;stroke:#888;stroke-width:1.1;stroke-dasharray:3 2;",
    "sketch-context-label": "fill:#aaa;font-size:8px;font-family:sans-serif;text-anchor:middle;",
    "sketch-context-label-related": (
        "fill:#555;font-size:8px;font-weight:bold;font-family:sans-serif;text-anchor:middle;"
    ),
    "sketch-adit": f"fill:{geo.SKETCH_ADIT_FILL};fill-opacity:0.30;stroke:{geo.SKETCH_ADIT_STROKE};stroke-width:0.8;",
    "sketch-adit-line": f"fill:none;stroke:{geo.SKETCH_ADIT_STROKE};stroke-width:1.4;",
    "sketch-adit-point": f"fill:{geo.SKETCH_ADIT_FILL};stroke:{geo.SKETCH_ADIT_STROKE};stroke-width:0.6;",
    "sketch-adit-alert": f"fill:url(#aditAlertHatch);stroke:{geo.SKETCH_ADIT_ALERT_STROKE};stroke-width:1.8;",
    "sketch-adit-line-alert": (
        f"fill:none;stroke:{geo.SKETCH_ADIT_ALERT_STROKE};stroke-width:2.4;stroke-dasharray:4 2;"
    ),
    "sketch-adit-point-alert": (
        f"fill:{geo.SKETCH_ADIT_ALERT_FILL};stroke:{geo.SKETCH_ADIT_ALERT_STROKE};stroke-width:1.4;"
    ),
    "sketch-context-adit": "fill:#bbb;fill-opacity:0.25;stroke:#999;stroke-width:0.5;",
    "sketch-context-adit-line": "fill:none;stroke:#999;stroke-width:0.9;stroke-dasharray:2 1.5;",
    "sketch-context-adit-point": "fill:#bbb;stroke:#999;stroke-width:0.4;",
}

_RE_CLASS_ATTR = re.compile(r'class="(sketch-[a-zA-Z0-9-]+)"')


def _inline_class_styles(svg_markup):
    """Añade ``style="..."`` junto a cada ``class="sketch-..."`` con las
    declaraciones equivalentes de ``_CLASS_STYLES``, para que
    ``QSvgRenderer`` las aplique aunque ignore el ``<style>`` global."""

    def _repl(match):
        cls = match.group(1)
        decl = _CLASS_STYLES.get(cls)
        if not decl:
            return match.group(0)
        return f'class="{cls}" style="{decl}"'

    return _RE_CLASS_ATTR.sub(_repl, svg_markup)


def build_styled_svg_bytes(svg_markup):
    """Inserta el bloque ``<style>`` de arriba justo tras la etiqueta de
    apertura ``<svg ...>`` (como primer hijo, delante de ``<defs>`` y del
    resto de contenido) y además escribe el estilo de cada clase
    ``sketch-*`` como atributo ``style`` directamente sobre el elemento
    (ver ``_inline_class_styles``), porque ``QSvgRenderer`` no aplica de
    forma fiable las reglas del ``<style>`` por selector de clase.
    Devuelve el resultado como ``bytes`` UTF-8, listo para
    ``QSvgRenderer``."""
    styled = _RE_SVG_OPEN_TAG.sub(r"\1" + _SKETCH_STYLE, svg_markup, count=1)
    styled = _inline_class_styles(styled)
    return styled.encode("utf-8")


# ---------------------------------------------------------------------
# Dibujo
# ---------------------------------------------------------------------

_LEGEND_ITEMS_BASE = [
    ("Situaci\u00f3n ANTES", "line-dashed", geo.SKETCH_ANTES_STROKE),
    ("Situaci\u00f3n DESPU\u00c9S", "line-solid", geo.SKETCH_DESPUES_STROKE),
    ("Superficie ganada", "fill", geo.SKETCH_GAINED_FILL),
    ("Superficie perdida", "fill", geo.SKETCH_LOST_FILL),
]


def render_sketch(painter, rect_mm, metrics, parts, flow):
    """Dibuja el croquis completo (marco + svg vectorial + barra lateral
    con leyenda y escala) dentro de ``rect_mm`` (tupla x,y,w,h en mm,
    relativa al origen de página que usa ``flow``).

    ``flow`` se usa solo para convertir coordenadas de página -> device px
    (ver ``FlowCanvas._px``) y para acceder a las fuentes por defecto.
    """
    x, y, w, h = rect_mm
    outer = flow._px_rect(x, y, w, h)

    pen = QPen(geo.qcolor(geo.BORDER))
    pen.setWidthF(metrics.mm(0.25))
    painter.setPen(pen)
    painter.setBrush(Qt.NoBrush)
    painter.drawRect(outer)

    if not parts.is_available:
        painter.setPen(QPen(geo.qcolor(geo.MUTED_TEXT)))
        font = QFont(flow.base_font_family)
        font.setPointSizeF(9)
        font.setItalic(True)
        painter.setFont(font)
        painter.drawText(outer, Qt.AlignCenter | Qt.TextWordWrap,
                          "(No se ha podido generar el croquis de esta finca)")
        return

    pad = 2.0  # mm
    label_h = 5.0 if parts.label_text else 0.0
    sidebar_w = 46.0  # mm, ancho de la columna de leyenda+escala

    # -- Etiqueta "Recinto N" --
    if parts.label_text:
        lbl_rect = flow._px_rect(x + pad, y + pad, w - 2 * pad, label_h)
        painter.setPen(QPen(geo.qcolor(geo.PRIMARY)))
        f = QFont(flow.base_font_family)
        f.setPointSizeF(8)
        f.setBold(True)
        painter.setFont(f)
        painter.drawText(lbl_rect, Qt.AlignLeft | Qt.AlignVCenter, parts.label_text)

    canvas_x = x + pad
    canvas_y = y + pad + label_h
    canvas_w = max(20.0, w - 2 * pad - sidebar_w - pad)
    canvas_h = max(20.0, h - 2 * pad - label_h)

    # -- SVG vectorial principal, encajado con relación de aspecto --
    try:
        svg_bytes = build_styled_svg_bytes(parts.svg_markup)
        renderer = QSvgRenderer(QByteArray(svg_bytes))
    except Exception:
        renderer = None

    if renderer is not None and renderer.isValid():
        aspect = parts.view_w / parts.view_h if parts.view_h else 1.0
        box_aspect = canvas_w / canvas_h if canvas_h else 1.0
        if aspect >= box_aspect:
            draw_w = canvas_w
            draw_h = canvas_w / aspect if aspect else canvas_h
        else:
            draw_h = canvas_h
            draw_w = canvas_h * aspect
        draw_x = canvas_x + (canvas_w - draw_w) / 2.0
        draw_y = canvas_y + (canvas_h - draw_h) / 2.0
        target = flow._px_rect(draw_x, draw_y, draw_w, draw_h)

        # QSvgRenderer NO recorta automáticamente al viewBox del SVG (a
        # diferencia de un navegador, donde el <svg> raíz tiene
        # "overflow: hidden" por defecto): cualquier geometría que caiga
        # fuera de los límites 0..W / 0..H declarados en el viewBox se
        # sigue dibujando igual, pudiendo salirse del recuadro asignado
        # al croquis. Se fuerza el recorte explícitamente con un clip de
        # QPainter ceñido al rectángulo de destino antes de renderizar.
        painter.save()
        painter.setClipRect(target)
        renderer.render(painter, target)
        painter.restore()
    else:
        placeholder = flow._px_rect(canvas_x, canvas_y, canvas_w, canvas_h)
        painter.setPen(QPen(geo.qcolor(geo.MUTED_TEXT)))
        painter.drawText(placeholder, Qt.AlignCenter | Qt.TextWordWrap,
                          "(SVG del croquis no v\u00e1lido)")

    # -- Barra lateral: leyenda + escala --
    sb_x = x + w - pad - sidebar_w
    sb_y = canvas_y
    cursor = sb_y

    items = list(_LEGEND_ITEMS_BASE)
    if parts.has_context_edif:
        items.append(("Edificaci\u00f3n (contexto)", "fill", geo.SKETCH_CONTEXT_EDIF_STROKE))
    if parts.has_adit_normal:
        items.append(("Aditamento", "fill", geo.SKETCH_ADIT_FILL))
    if parts.has_adit_alert:
        items.append(("Aditamento con variaci\u00f3n a notificar", "fill", geo.SKETCH_ADIT_ALERT_STROKE))

    leg_font = QFont(flow.base_font_family)
    leg_font.setPointSizeF(6.6)
    painter.setFont(leg_font)
    swatch_w, swatch_h = 6.0, 2.6
    row_h = 5.4
    for text, kind, color in items:
        sw_rect = flow._px_rect(sb_x, cursor + (row_h - swatch_h) / 2.0, swatch_w, swatch_h)
        if kind == "fill":
            painter.setPen(Qt.NoPen)
            c = geo.qcolor(color, alpha=200)
            painter.setBrush(c)
            painter.drawRect(sw_rect)
        else:
            p = QPen(geo.qcolor(color))
            p.setWidthF(metrics.mm(0.5))
            if kind == "line-dashed":
                p.setStyle(Qt.DashLine)
            painter.setPen(p)
            cy = sw_rect.center().y()
            painter.drawLine(QPointF(sw_rect.left(), cy), QPointF(sw_rect.right(), cy))
        txt_rect = flow._px_rect(sb_x + swatch_w + 1.6, cursor, sidebar_w - swatch_w - 1.6, row_h)
        painter.setPen(QPen(geo.qcolor(geo.PRIMARY)))
        painter.drawText(txt_rect, Qt.AlignLeft | Qt.AlignVCenter | Qt.TextWordWrap, text)
        cursor += row_h

    # -- Escala gráfica: una línea con topes y el texto debajo --
    if parts.scale_text:
        cursor += 3.0
        bar_w = sidebar_w * 0.6
        bar_x0 = sb_x + (sidebar_w - bar_w) / 2.0
        bar_y = cursor + 2.0
        pen = QPen(geo.qcolor(geo.PRIMARY))
        pen.setWidthF(metrics.mm(0.4))
        painter.setPen(pen)
        line = flow._px_line(bar_x0, bar_y, bar_x0 + bar_w, bar_y)
        painter.drawLine(QPointF(line[0], line[1]), QPointF(line[2], line[3]))
        tick_h = 1.4
        for tx in (bar_x0, bar_x0 + bar_w):
            t = flow._px_line(tx, bar_y - tick_h, tx, bar_y + tick_h)
            painter.drawLine(QPointF(t[0], t[1]), QPointF(t[2], t[3]))
        cursor += 4.0  # avanzar el cursor (en mm) para dejar sitio al texto "N m"
        txt_rect = flow._px_rect(sb_x, cursor, sidebar_w, 4.5)
        f2 = QFont(flow.base_font_family)
        f2.setPointSizeF(7)
        painter.setFont(f2)
        painter.setPen(QPen(geo.qcolor(geo.MUTED_TEXT)))
        painter.drawText(txt_rect, Qt.AlignCenter, parts.scale_text)

    # -- Nota "sin variación geométrica apreciable" --
    if parts.note_text:
        note_y = y + h - pad - 6.0
        note_rect = flow._px_rect(x + pad, note_y, w - 2 * pad, 6.0)
        f3 = QFont(flow.base_font_family)
        f3.setPointSizeF(7)
        f3.setItalic(True)
        painter.setFont(f3)
        painter.setPen(QPen(geo.qcolor(geo.MUTED_TEXT)))
        painter.drawText(note_rect, Qt.AlignLeft | Qt.TextWordWrap, parts.note_text)
