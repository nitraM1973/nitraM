# -*- coding: utf-8 -*-
"""
core/pdf_export/geometry.py
============================

Constantes de paleta de color y utilidades de conversión de unidades para
el generador de PDF "nativo" de las fichas individuales de AudiNOT.

CONTEXTO / POR QUÉ EXISTE ESTE PAQUETE
---------------------------------------
La ficha individual de una finca ya se genera como HTML autocontenido en
``ReportService.generate_parcel_card_html`` y se puede convertir a PDF con
``ReportService.render_html_to_pdf``, que usa ``QWebEnginePage`` (el motor
Chromium que trae Qt) para "imprimir" ese HTML.

El problema es que ``QtWebEngineWidgets`` es un módulo *opcional* de Qt:
muchas instalaciones de QGIS (paquetes mínimos de distro Linux, algunos
instaladores de red de OSGeo4W, entornos conda-forge headless, Docker,
compilaciones LTR antiguas...) no lo incluyen. Un plugin que se vaya a
distribuir a terceros no puede asumir que esté presente.

Este paquete (``core/pdf_export``) genera el mismo PDF de la ficha
individual **sin usar QtWebEngine en absoluto**: dibuja directamente con
``QPainter`` sobre un ``QPrinter``, usando solo módulos que SÍ forman parte
del núcleo de cualquier instalación de QGIS/Qt porque el propio QGIS
depende de ellos para funcionar:

    - ``PyQt5.QtGui``          (QPainter, QFont, QColor, QPen, QBrush...)
    - ``PyQt5.QtCore``         (QRectF, Qt, QMarginsF...)
    - ``PyQt5.QtPrintSupport`` (QPrinter) -- usado por el propio Compositor
      de Impresión / Print Layout de QGIS, es decir, siempre presente.
    - ``PyQt5.QtSvg``          (QSvgRenderer) -- usado por QGIS para pintar
      símbolos SVG en el lienzo del mapa, también siempre presente.

Este módulo es completamente independiente de ``core/report_service.py``:
no lo importa, no lo modifica, y no depende de que ese fichero cambie en
el futuro. Toda la lógica de formateo/umbrales que necesita se ha vuelto a
implementar aquí de forma aislada (ver ``data_prep.py``), a partir de la
MISMA estructura de datos (``attrs`` / ``audinot_json`` / ``thresholds``)
que ya usa ``generate_parcel_card_html``.
"""

from PyQt5.QtGui import QColor


# ---------------------------------------------------------------------
# Paleta de color -- copiada 1:1 de las variables CSS (:root { --primary,
# --sec, --accent, --border, ... }) y de las reglas .sketch-*/.leg-*/
# .pill/.callout/.decision-banner definidas en ReportService._report_css(),
# para que la ficha en PDF tenga el mismo aspecto que la ficha en HTML.
# Si en algún momento se retoca la paleta del informe HTML, hay que
# reflejar el cambio aquí también (son dos "renderizadores" distintos que
# dibujan lo mismo, no hay forma de compartir la hoja de estilos CSS con
# un QPainter).
# ---------------------------------------------------------------------

PRIMARY = "#2c3e50"
SECONDARY = "#34495e"
ACCENT = "#3498db"
BG = "#f5f7fa"
CARD_BG = "#ffffff"
BORDER = "#e1e4e8"
MUTED_TEXT = "#7f8c8d"
LIGHT_TEXT = "#95a5a6"

# Insignia de estado de la ficha (card-title .estado-badge)
ESTADO_COLORS = {
    "ok": "#2ecc71",
    "alerta": "#e74c3c",
    "aviso": "#f39c12",
}
ESTADO_DEFAULT = QColor(255, 255, 255, 46)  # rgba(255,255,255,0.18) aprox.

# Panel de revisión / decisión (.decision-banner)
REVISION_TEXT = {
    "si": "\u2714 NOTIFICAR",
    "no": "\u2718 NO NOTIFICAR",
    "rev": "\U0001F441 REVISAR",
}
REVISION_TEXT_DEFAULT = "\u2b1c Sin revisar"
REVISION_COLOR = {"si": "#c0392b", "no": "#27ae60", "rev": "#2980b9"}
REVISION_COLOR_DEFAULT = "#7f8c8d"
REVISION_BG = {"si": "#fdecea", "no": "#eafaf1"}
REVISION_BG_DEFAULT = "#f4f5f6"

# Píldoras "Notifica (paramétrico/alternativo)" (.pill)
PILL_POSITIVE_BG = "#fdecea"
PILL_POSITIVE_FG = "#c0392b"
PILL_NEGATIVE_BG = "#eafaf1"
PILL_NEGATIVE_FG = "#1e8449"

# Cuadro de conclusión (.callout .tag-param / .tag-legal / .conclusion-ok)
TAG_PARAM_COLOR = "#c0392b"
TAG_LEGAL_COLOR = "#8e44ad"
CONCLUSION_OK_COLOR = "#1e8449"

# Línea supfT24/GML (._render_flat_t24_gml_line -> _pct_span)
PCT_OK_COLOR = "#27ae60"
PCT_EXCEEDS_POS_COLOR = "#e67e22"
PCT_EXCEEDS_NEG_COLOR = "#8e44ad"
PCT_UNKNOWN_COLOR = "#888888"

# Variación positiva/negativa en la tabla de aditamentos (.text-pos/.text-neg)
TEXT_POS_COLOR = "#27ae60"
TEXT_NEG_COLOR = "#c0392b"

# Croquis: colores de relleno/trazo (._generate_sketch_svg / reglas .sketch-*)
SKETCH_BG_FILL = "#fbfbfa"
SKETCH_BG_STROKE = "#dddddd"
SKETCH_ANTES_STROKE = "#2980b9"       # discontinuo
SKETCH_DESPUES_STROKE = "#2c3e50"
SKETCH_GAINED_FILL = "#0072B2"        # opacidad 0.45
SKETCH_LOST_FILL = "#E69F00"          # opacidad 0.45
SKETCH_ADIT_FILL = "#4d4d4d"          # opacidad 0.30
SKETCH_ADIT_STROKE = "#2b2b2b"
SKETCH_ADIT_ALERT_FILL = "#CC79A7"    # opacidad 0.30 (aprox. del hachurado)
SKETCH_ADIT_ALERT_STROKE = "#000000"
SKETCH_CONTEXT_STROKE = "#bbbbbb"
SKETCH_CONTEXT_EDIF_STROKE = "#777777"  # recintos de contexto EDIFICACIONES (relleno rayado)


def qcolor(hex_str, alpha=255):
    """Crea un ``QColor`` a partir de un '#rrggbb', con alfa opcional
    (0-255) para reproducir las opacidades fraccionarias de la hoja de
    estilos original (p.ej. fill-opacity: 0.45)."""
    c = QColor(hex_str)
    if alpha != 255:
        c.setAlpha(alpha)
    return c


class Metrics:
    """Conversión milímetro -> píxel-de-dispositivo para un ``QPrinter``
    concreto.

    IMPORTANTE (motivo de que exista esta clase en vez de usar
    ``painter.scale(...)``): sería tentador hacer
    ``painter.scale(dpi/25.4, dpi/25.4)`` una sola vez tras
    ``painter.begin(printer)`` y trabajar "como si" cada unidad de
    QPainter fuera un milímetro. NO se hace así aquí a propósito: ese
    escalado del ``QPainter`` afecta también al tamaño con el que se
    renderiza el texto (``QFont`` ya calcula su tamaño en píxeles de
    dispositivo a partir del DPI del ``QPrinter``; si además se aplica un
    ``scale()`` global, el texto sale re-escalado por partida doble y
    aparece gigantesco). Por eso aquí la conversión mm -> px se hace de
    forma explícita solo para las magnitudes de POSICIÓN/TAMAÑO
    (rectángulos, líneas, márgenes...), y los tamaños de fuente se dejan
    siempre en puntos (``QFont.setPointSizeF``), que Qt ya resuelve
    correctamente contra el DPI real del ``QPrinter`` sin necesidad de
    convertir nada.
    """

    def __init__(self, dpi_x, dpi_y):
        self.dpi_x = float(dpi_x) if dpi_x else 300.0
        self.dpi_y = float(dpi_y) if dpi_y else 300.0

    def mm(self, value_mm):
        """Convierte un valor en mm a píxeles de dispositivo usando el
        DPI horizontal (válido también para casos "isótropos", que es lo
        habitual: dpi_x == dpi_y en el 99% de los backends de impresión
        a PDF)."""
        return value_mm * self.dpi_x / 25.4

    def mm_x(self, value_mm):
        return value_mm * self.dpi_x / 25.4

    def mm_y(self, value_mm):
        return value_mm * self.dpi_y / 25.4
