# -*- coding: utf-8 -*-
"""
core/pdf_export/flow_canvas.py
=================================

Pequeño motor de maquetación "de flujo" (como un documento de texto que
va llenando páginas de arriba a abajo) construido sobre ``QPainter`` +
``QPrinter``. Es el sustituto casero de "imprimir HTML/CSS" que necesita
este paquete para no depender de QtWebEngine: en vez de que un motor de
render entienda el CSS y decida dónde partir las páginas, aquí somos
nosotros los que llevamos la cuenta manualmente de cuánto espacio queda
en la página actual y cuándo hay que saltar a la siguiente.

No es un motor de maquetación genérico de propósito general (eso sería
reinventar un motor HTML entero); es deliberadamente pequeño y solo
ofrece las primitivas que necesita ``ficha_renderer.py`` para dibujar la
ficha de una finca: texto/párrafos con ajuste de línea, una rejilla de
"etiqueta: valor" a dos columnas, cajas con borde de acento (paneles /
avisos / banners), píldoras de estado y una tabla sencilla con
cabecera repetida si se parte entre páginas.

Todas las coordenadas que recibe la API pública están en MILÍMETROS,
relativas a la esquina superior izquierda del ÁREA IMPRIMIBLE de la
página (es decir, ya sin contar los márgenes, que los gestiona
``QPrinter``/``QPageLayout`` por su cuenta). La conversión a píxeles de
dispositivo la hace ``Metrics`` (ver ``geometry.py``).
"""

from PyQt5.QtCore import QPointF, QRectF, Qt
from PyQt5.QtGui import QColor, QFont, QFontMetrics, QPen

from . import geometry as geo


class FlowCanvas:
    """Gestiona el cursor vertical, los saltos de página y las
    primitivas de dibujo de alto nivel usadas por ``FichaPdfRenderer``.
    """

    BASE_FONT_FAMILY = "Arial"  # 'Segoe UI' no siempre existe fuera de Windows;
                                  # Arial/Helvetica es la alternativa más segura
                                  # y universal para un PDF generado en cualquier SO.

    def __init__(self, painter, printer, metrics, content_width_mm, content_height_mm):
        self.painter = painter
        self.printer = printer
        self.metrics = metrics
        self.content_w = content_width_mm
        self.content_h = content_height_mm
        self.base_font_family = self.BASE_FONT_FAMILY

        self.cursor_y = 0.0
        self.page_count = 1

    # -- utilidades internas de conversión de coordenadas --------------

    def _px_rect(self, x_mm, y_mm, w_mm, h_mm):
        m = self.metrics
        return QRectF(m.mm_x(x_mm), m.mm_y(y_mm), m.mm_x(w_mm), m.mm_y(h_mm))

    def _px_line(self, x1_mm, y1_mm, x2_mm, y2_mm):
        m = self.metrics
        return (m.mm_x(x1_mm), m.mm_y(y1_mm), m.mm_x(x2_mm), m.mm_y(y2_mm))

    def _px(self, v_mm):
        return self.metrics.mm(v_mm)

    # -- paginación ------------------------------------------------------

    def new_page(self):
        self.printer.newPage()
        self.cursor_y = 0.0
        self.page_count += 1

    def ensure_space(self, height_mm, min_before_break=0.0):
        """Si lo que queda de página actual no basta para ``height_mm``,
        salta de página. ``min_before_break`` permite exigir un mínimo de
        espacio residual además de la altura exacta del bloque (para
        evitar, por ejemplo, dejar un titular de sección solo al final de
        la hoja)."""
        if self.cursor_y + height_mm + min_before_break > self.content_h:
            self.new_page()

    def advance(self, height_mm):
        self.cursor_y += height_mm

    # -- fuentes -----------------------------------------------------------

    def font(self, size_pt, bold=False, italic=False):
        # OJO: QFont(family, pointSize) exige pointSize int -- con floats
        # (habituales aquí, p.ej. tamaños a 6.6/8.5 pt para ajustar la
        # ficha) revienta con "arguments did not match any overloaded
        # call". Se construye sin tamaño y se fija aparte con
        # setPointSizeF, que sí admite decimales.
        f = QFont(self.base_font_family)
        f.setPointSizeF(float(size_pt))
        f.setBold(bold)
        f.setItalic(italic)
        return f

    def text_height_mm(self, text, size_pt, bold=False, width_mm=None, line_spacing=1.28):
        """Altura aproximada (en mm) que ocupará ``text`` con ajuste de
        línea a ``width_mm`` (o una sola línea si no se indica ancho)."""
        f = self.font(size_pt, bold=bold)
        fm = QFontMetrics(f, self.printer)
        if width_mm is None:
            return fm.height() / self.metrics.dpi_y * 25.4 * line_spacing
        rect = fm.boundingRect(
            0, 0, int(self._px(width_mm)), 100000,
            Qt.TextWordWrap, text
        )
        return (rect.height() / self.metrics.dpi_y * 25.4) * line_spacing / 1.0 + 0.5

    # -- primitivas de dibujo ------------------------------------------

    def draw_rule(self, color=geo.BORDER, thickness_mm=0.3, margin_top_mm=0.0, margin_bottom_mm=1.5):
        self.cursor_y += margin_top_mm
        pen = QPen(geo.qcolor(color))
        pen.setWidthF(self._px(thickness_mm))
        self.painter.setPen(pen)
        y = self.cursor_y
        x1, y1, x2, y2 = self._px_line(0, y, self.content_w, y)
        # OJO: drawLine(x1, y1, x2, y2) con floats revienta en algunas
        # builds de PyQt5 -- solo exponen las sobrecargas con int, o con
        # QPointF/QLineF. QPointF acepta floats siempre.
        self.painter.drawLine(QPointF(x1, y1), QPointF(x2, y2))
        self.cursor_y += thickness_mm + margin_bottom_mm

    def draw_text(self, text, size_pt=10, bold=False, italic=False, color=geo.PRIMARY,
                   x_mm=0.0, width_mm=None, align=Qt.AlignLeft, margin_bottom_mm=1.0,
                   underline=False):
        """Dibuja un bloque de texto (con ajuste de línea si se supera
        ``width_mm``) empezando en el cursor actual y avanza el cursor lo
        que ocupe."""
        if width_mm is None:
            width_mm = self.content_w - x_mm
        h_mm = self.text_height_mm(text, size_pt, bold=bold, width_mm=width_mm)
        self.ensure_space(h_mm)
        f = self.font(size_pt, bold=bold, italic=italic)
        f.setUnderline(underline)
        self.painter.setFont(f)
        self.painter.setPen(QPen(geo.qcolor(color)))
        rect = self._px_rect(x_mm, self.cursor_y, width_mm, h_mm + 2)
        self.painter.drawText(rect, align | Qt.TextWordWrap, text)
        self.cursor_y += h_mm + margin_bottom_mm
        return h_mm

    def measure_text(self, text, size_pt=10, bold=False, width_mm=None):
        return self.text_height_mm(text, size_pt, bold=bold, width_mm=width_mm)

    def draw_section_label(self, text, color=geo.MUTED_TEXT, accent=geo.ACCENT):
        """Réplica de ``.section-label``: texto en mayúsculas, pequeño,
        con una barra de acento vertical a la izquierda."""
        h_mm = 5.5
        self.ensure_space(h_mm)
        bar = self._px_rect(0, self.cursor_y + 0.3, 0.9, h_mm - 0.6)
        self.painter.setPen(Qt.NoPen)
        self.painter.setBrush(geo.qcolor(accent))
        self.painter.drawRect(bar)
        f = self.font(7.6, bold=True)
        self.painter.setFont(f)
        self.painter.setPen(QPen(geo.qcolor(color)))
        rect = self._px_rect(2.4, self.cursor_y, self.content_w - 2.4, h_mm)
        self.painter.drawText(rect, Qt.AlignLeft | Qt.AlignVCenter, text.upper())
        self.cursor_y += h_mm

    def draw_pill(self, text, x_mm, y_mm, bg, fg, size_pt=8.2):
        f = self.font(size_pt, bold=True)
        fm = QFontMetrics(f, self.printer)
        text_w_px = fm.horizontalAdvance(text)
        pad_px = self._px(2.6)
        h_px = self._px(4.6)
        w_px = text_w_px + 2 * pad_px
        rect = QRectF(self.metrics.mm_x(x_mm), self.metrics.mm_y(y_mm), w_px, h_px)
        self.painter.setPen(Qt.NoPen)
        self.painter.setBrush(geo.qcolor(bg))
        self.painter.drawRoundedRect(rect, h_px / 2.0, h_px / 2.0)
        self.painter.setPen(QPen(geo.qcolor(fg)))
        self.painter.setFont(f)
        self.painter.drawText(rect, Qt.AlignCenter, text)
        return w_px / self.metrics.mm_x(1)  # ancho ocupado, en mm

    def draw_key_value_grid(self, pairs):
        """``pairs``: lista de tuplas ``(label, value, full_width)``.
        Réplica de ``.data-grid`` (dos columnas, con filas "full" que
        ocupan el ancho completo).

        El avance del cursor se calcula SIEMPRE antes de dibujar (altura
        de la fila = altura de la etiqueta + altura del valor más alto de
        la fila), y ``ensure_space`` se llama una única vez por fila con
        esa altura ya conocida -- así se evita que la etiqueta y el valor
        queden repartidos en dos páginas distintas.
        """
        col_w = (self.content_w - 6.0) / 2.0
        col_gap = 6.0
        row_gap = 2.4
        label_h = 3.6

        i = 0
        n = len(pairs)
        while i < n:
            label, value, full = pairs[i]

            if full:
                full_w = col_w * 2 + col_gap
                val_h = self.measure_text(value, 9.4, bold=True, width_mm=full_w)
                row_h = label_h + val_h
                self.ensure_space(row_h)
                self._draw_kv_cell(label, value, 0.0, full_w)
                self.cursor_y += row_h + row_gap
                i += 1
                continue

            has_second = (i + 1 < n) and not pairs[i + 1][2]
            h1 = self.measure_text(value, 9.4, bold=True, width_mm=col_w)
            h2 = self.measure_text(pairs[i + 1][1], 9.4, bold=True, width_mm=col_w) if has_second else 0.0
            row_h = label_h + max(h1, h2)
            self.ensure_space(row_h)

            self._draw_kv_cell(label, value, 0.0, col_w)
            if has_second:
                label2, value2, _ = pairs[i + 1]
                self._draw_kv_cell(label2, value2, col_w + col_gap, col_w)
                i += 2
            else:
                i += 1
            self.cursor_y += row_h + row_gap

    def _draw_kv_cell(self, label, value, x_mm, w_mm):
        """Dibuja una celda etiqueta+valor en la posición actual del
        cursor (no lo mueve: quien llama ya ha reservado el espacio con
        ``ensure_space`` antes)."""
        label_h = 3.6
        self.painter.setFont(self.font(6.6, bold=False))
        self.painter.setPen(QPen(geo.qcolor(geo.MUTED_TEXT)))
        lbl_rect = self._px_rect(x_mm, self.cursor_y, w_mm, label_h)
        self.painter.drawText(lbl_rect, Qt.AlignLeft | Qt.TextWordWrap, label.upper())

        val_h = self.measure_text(value, 9.4, bold=True, width_mm=w_mm)
        self.painter.setFont(self.font(9.4, bold=True))
        self.painter.setPen(QPen(geo.qcolor(geo.PRIMARY)))
        val_rect = self._px_rect(x_mm, self.cursor_y + label_h, w_mm, val_h + 1.0)
        self.painter.drawText(val_rect, Qt.AlignLeft | Qt.TextWordWrap, value)

    def draw_box(self, height_mm, bg=None, border=geo.BORDER, accent=None, accent_width_mm=1.0):
        """Dibuja el fondo/borde de una caja tipo ``.callout``/
        ``.decision-banner``/``.panel`` en la posición actual del cursor,
        SIN mover el cursor (el contenido se dibuja encima, después, y es
        quien decide cuánto avanzar realmente)."""
        rect = self._px_rect(0, self.cursor_y, self.content_w, height_mm)
        if bg:
            self.painter.setPen(Qt.NoPen)
            self.painter.setBrush(geo.qcolor(bg))
            self.painter.drawRect(rect)
        pen = QPen(geo.qcolor(border))
        pen.setWidthF(self._px(0.25))
        self.painter.setPen(pen)
        self.painter.setBrush(Qt.NoBrush)
        self.painter.drawRect(rect)
        if accent:
            accent_rect = self._px_rect(0, self.cursor_y, accent_width_mm, height_mm)
            self.painter.setPen(Qt.NoPen)
            self.painter.setBrush(geo.qcolor(accent))
            self.painter.drawRect(accent_rect)
        return rect

    def draw_table(self, headers, rows, col_widths_mm, aligns=None, header_bg=geo.BG,
                    row_height_mm=5.4, font_size_pt=8.0, header_font_size_pt=7.6):
        """Tabla simple, con cabecera que se repite automáticamente si la
        tabla se parte entre páginas.

        ``rows``: lista de listas de strings (mismo nº de columnas que
        ``headers``). ``aligns``: lista opcional de ``Qt.Alignment`` por
        columna (por defecto, izquierda).
        """
        aligns = aligns or [Qt.AlignLeft] * len(headers)

        def _draw_header():
            self.ensure_space(row_height_mm)
            rect = self._px_rect(0, self.cursor_y, self.content_w, row_height_mm)
            self.painter.setPen(Qt.NoPen)
            self.painter.setBrush(geo.qcolor(header_bg))
            self.painter.drawRect(rect)
            self.painter.setFont(self.font(header_font_size_pt, bold=True))
            self.painter.setPen(QPen(geo.qcolor(geo.MUTED_TEXT)))
            x = 0.0
            for h_text, w, al in zip(headers, col_widths_mm, aligns):
                cell = self._px_rect(x + 0.8, self.cursor_y, w - 1.6, row_height_mm)
                self.painter.drawText(cell, al | Qt.AlignVCenter, h_text.upper())
                x += w
            self.cursor_y += row_height_mm

        _draw_header()
        for row_i, row in enumerate(rows):
            # Si no cabe la fila, saltamos de página y repetimos cabecera.
            if self.cursor_y + row_height_mm > self.content_h:
                self.new_page()
                _draw_header()

            colors = None
            if isinstance(row, tuple):
                row, colors = row  # (valores, colores_por_celda opcional)

            rect = self._px_rect(0, self.cursor_y, self.content_w, row_height_mm)
            if row_i % 2 == 1:
                self.painter.setPen(Qt.NoPen)
                self.painter.setBrush(geo.qcolor("#fafbfc"))
                self.painter.drawRect(rect)

            self.painter.setFont(self.font(font_size_pt))
            x = 0.0
            for i, (cell_text, w, al) in enumerate(zip(row, col_widths_mm, aligns)):
                color = geo.PRIMARY
                if colors and colors[i]:
                    color = colors[i]
                self.painter.setPen(QPen(geo.qcolor(color)))
                cell = self._px_rect(x + 0.8, self.cursor_y, w - 1.6, row_height_mm)
                self.painter.drawText(cell, al | Qt.AlignVCenter, str(cell_text))
                x += w

            bottom_pen = QPen(geo.qcolor(geo.BORDER))
            bottom_pen.setWidthF(self._px(0.15))
            self.painter.setPen(bottom_pen)
            y2 = self.cursor_y + row_height_mm
            x1, y1, x2, yy2 = self._px_line(0, y2, self.content_w, y2)
            self.painter.drawLine(QPointF(x1, y1), QPointF(x2, yy2))

            self.cursor_y += row_height_mm
