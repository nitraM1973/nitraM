# -*- coding: utf-8 -*-
"""
core/pdf_export/data_prep.py
==============================

Preparación de datos "puros" (sin nada de HTML ni de Qt) para dibujar la
ficha en PDF.

Este módulo reimplementa, de forma DELIBERADAMENTE independiente, la
misma aritmética que ``ReportService`` usa para construir la ficha HTML
(``_get_pct``, ``_chk``, ``_fmt_val``/``_fmt_diff``/``_fmt_pct``,
``_generate_adit_table_rows`` y ``_render_flat_t24_gml_line``). No importa
nada de ``core/report_service.py`` a propósito, para que este paquete de
exportación a PDF pueda vivir -- y evolucionar -- sin ningún acoplamiento
con el resto del plugin ni riesgo de romper (ni de que le rompan) la
generación de las fichas HTML.

Si en el futuro se cambian los umbrales por defecto o el redondeo de las
fichas HTML, hay que replicar el cambio aquí también: es el precio de la
independencia total que se pidió para este módulo.

Todas las funciones de aquí devuelven texto plano o pequeñas estructuras
de datos (tuplas/dataclasses), nunca HTML: el dibujo con QPainter se hace
en otros módulos de este mismo paquete (``flow_canvas``, ``ficha_renderer``).
"""

from dataclasses import dataclass, field
from typing import List, Optional, Tuple

TOL = 0.001

# Umbrales por defecto usados por _generate_adit_table_rows cuando no se
# pasan 'thresholds' (misma Ficha 3 por defecto que en report_service.py).
DEFAULT_LINEAR_ABS = 1.0
DEFAULT_LINEAR_PCT = 5.0
DEFAULT_POLY_ABS = 1.0
DEFAULT_POLY_PCT = 5.0


# ---------------------------------------------------------------------
# Aritmética básica (réplica de ReportService._get_pct / ._chk)
# ---------------------------------------------------------------------

def pct_variacion(antes, despues):
    """Variación porcentual estándar de la finca (misma lógica que
    ``ReportService._get_pct``):
      - diferencia casi nula (< TOL) -> 0.0
      - antes ~ 0 y después no -> +100.0
      - antes no ~ 0 y después ~ 0 -> -100.0
      - caso general -> (despues-antes)/antes * 100
    """
    delta = despues - antes
    if abs(delta) < TOL:
        return 0.0
    if abs(antes) < TOL:
        return 100.0
    if abs(despues) < TOL:
        return -100.0
    return (delta / antes) * 100.0


def exceeds_threshold(val, threshold):
    """True si abs(val) > threshold (con threshold None o 0 => nunca)."""
    if threshold is None or threshold == 0:
        return False
    return abs(val) > threshold


def fmt_num(val, precision=2):
    """Formatea un valor absoluto en texto plano, p.ej. 12.5 -> '12.50'."""
    try:
        return f"{float(val):.{precision}f}"
    except (TypeError, ValueError):
        return "?"


def fmt_diff(val, precision=2):
    """Formatea una diferencia con signo explícito, p.ej. 3.2 -> '+3.20',
    -1.0 -> '-1.00', 0.0 -> '0.00' (sin signo si es ~cero)."""
    try:
        val = float(val)
    except (TypeError, ValueError):
        return "?"
    if abs(val) < 0.0001:
        return f"{0:.{precision}f}"
    sign = "+" if val > 0 else "-"
    return f"{sign}{abs(val):.{precision}f}"


def fmt_pct(val, precision=2):
    """Formatea un porcentaje con signo, sin el símbolo '%' (se añade
    aparte al dibujar, igual que en la tabla HTML)."""
    return fmt_diff(val, precision)


# ---------------------------------------------------------------------
# Tabla de aditamentos (réplica de ReportService._generate_adit_table_rows)
# ---------------------------------------------------------------------

@dataclass
class AditRow:
    label: str          # p.ej. "Piscina (Sup)"
    antes: str           # valor formateado, p.ej. "48.20"
    despues: str
    delta: str            # con signo, p.ej. "+3.10"
    pct: str               # con signo, sin '%', puede ser "" (fila de conteo)
    is_alert: bool
    delta_color: Optional[str] = None  # TEXT_POS_COLOR / TEXT_NEG_COLOR / None


@dataclass
class AditTableData:
    rows: List[AditRow] = field(default_factory=list)
    alerts: int = 0
    total: int = 0

    @property
    def has_rows(self):
        return bool(self.rows)


def _thresholds_from(thresholds):
    t_linear_abs, t_linear_pct = DEFAULT_LINEAR_ABS, DEFAULT_LINEAR_PCT
    t_poly_abs, t_poly_pct = DEFAULT_POLY_ABS, DEFAULT_POLY_PCT
    if thresholds and "aditamentos" in thresholds:
        t_linear_abs = thresholds["aditamentos"].get("linear", {}).get("abs", DEFAULT_LINEAR_ABS)
        t_linear_pct = thresholds["aditamentos"].get("linear", {}).get("pct", DEFAULT_LINEAR_PCT)
        t_poly_abs = thresholds["aditamentos"].get("poly", {}).get("abs", DEFAULT_POLY_ABS)
        t_poly_pct = thresholds["aditamentos"].get("poly", {}).get("pct", DEFAULT_POLY_PCT)
    return t_linear_abs, t_linear_pct, t_poly_abs, t_poly_pct


def build_adit_table(aditamentos, thresholds=None):
    """Construye la tabla de aditamentos (longitud/superficie/nº de
    elementos por tipo) a partir del dict ``audinot_json['aditamentos']``,
    con la misma regla de umbrales/alertas que la ficha HTML.

    Devuelve un ``AditTableData`` (nunca None) -- ``.has_rows`` es False
    si no hay aditamentos que mostrar.
    """
    result = AditTableData()
    if not aditamentos:
        return result

    t_linear_abs, t_linear_pct, t_poly_abs, t_poly_pct = _thresholds_from(thresholds)

    for el_name in sorted(aditamentos.keys()):
        data = aditamentos[el_name] or {}
        a = data.get("a", {"len": 0, "area": 0, "count": 0})
        dv = data.get("d", {"len": 0, "area": 0, "count": 0})

        # -- longitud (elementos lineales: vallados, setos...) --
        a_len, d_len = a.get("len", 0) or 0, dv.get("len", 0) or 0
        if a_len >= TOL or d_len >= TOL:
            result.total += 1
            delta = d_len - a_len
            pct = pct_variacion(a_len, d_len)
            mark = exceeds_threshold(delta, t_linear_abs) or exceeds_threshold(pct, t_linear_pct)
            if mark:
                result.alerts += 1
            color = "pos" if delta > 0.05 else ("neg" if delta < -0.05 else None)
            result.rows.append(AditRow(
                label=f"{el_name} (Lon)",
                antes=fmt_num(a_len), despues=fmt_num(d_len),
                delta=f"{fmt_diff(delta)} m", pct=f"{fmt_pct(pct)}%",
                is_alert=mark, delta_color=color,
            ))

        # -- superficie (elementos poligonales: piscinas, porches...) --
        a_area, d_area = a.get("area", 0) or 0, dv.get("area", 0) or 0
        if a_area >= TOL or d_area >= TOL:
            result.total += 1
            delta = d_area - a_area
            pct = pct_variacion(a_area, d_area)
            mark = exceeds_threshold(delta, t_poly_abs) or exceeds_threshold(pct, t_poly_pct)
            if mark:
                result.alerts += 1
            color = "pos" if delta > 0.1 else ("neg" if delta < -0.1 else None)
            result.rows.append(AditRow(
                label=f"{el_name} (Sup)",
                antes=fmt_num(a_area), despues=fmt_num(d_area),
                delta=f"{fmt_diff(delta)} m\u00b2", pct=f"{fmt_pct(pct)}%",
                is_alert=mark, delta_color=color,
            ))

        # -- número de elementos (puntuales: árboles, postes...) --
        a_cnt, d_cnt = a.get("count", 0) or 0, dv.get("count", 0) or 0
        if a_cnt != d_cnt:
            result.total += 1
            delta = d_cnt - a_cnt
            result.alerts += 1
            sign = "+" if delta > 0 else ""
            result.rows.append(AditRow(
                label=f"{el_name} (Cant)",
                antes=str(a_cnt), despues=str(d_cnt),
                delta=f"{sign}{delta}", pct="",
                is_alert=True, delta_color=None,
            ))
        elif a_cnt > 0:
            result.total += 1

    return result


# ---------------------------------------------------------------------
# Línea supfT24 / GML (réplica de ReportService._render_flat_t24_gml_line)
# ---------------------------------------------------------------------

@dataclass
class PctBadge:
    text: str    # p.ej. "+2.15%" o "?"
    color: str   # color hex a usar al dibujar


def _fmt_flat(v):
    if isinstance(v, (int, float)):
        # Qt no tiene el formato 'g' de Python incorporado en QString, así
        # que se resuelve aquí en Python puro (quita ceros sobrantes).
        return f"{v:g}"
    return "?"


def _pct_badge(pct, supera=False, positivo=False):
    from . import geometry as geo
    if not isinstance(pct, (int, float)):
        return PctBadge("?", geo.PCT_UNKNOWN_COLOR)
    if not supera:
        color = geo.PCT_OK_COLOR
    else:
        color = geo.PCT_EXCEEDS_POS_COLOR if positivo else geo.PCT_EXCEEDS_NEG_COLOR
    return PctBadge(f"{pct:+.2f}%", color)


@dataclass
class T24GmlData:
    sup_t24_a: str
    sup_t24_d: str
    sup_gml_a: str
    sup_gml_d: str
    val_pct_a: PctBadge
    val_pct_d: PctBadge
    val_pct_gml_d: PctBadge


def build_t24_gml_data(attrs):
    """Reconstruye, a partir de los campos PLANOS ya calculados y
    guardados en el GeoPackage de auditoría (sup_t24_a/d, sup_gml_a/d,
    val_pct_a/d, val_pct_gml_d, val_gml_d_supera), la misma información
    que pinta ``ReportService._render_flat_t24_gml_line`` -- aquí como
    datos estructurados en vez de HTML."""
    val_pct_gml_d = attrs.get("val_pct_gml_d")
    supera = bool(attrs.get("val_gml_d_supera"))
    positivo = bool(val_pct_gml_d and val_pct_gml_d > 0)

    return T24GmlData(
        sup_t24_a=_fmt_flat(attrs.get("sup_t24_a")),
        sup_t24_d=_fmt_flat(attrs.get("sup_t24_d")),
        sup_gml_a=_fmt_flat(attrs.get("sup_gml_a")),
        sup_gml_d=_fmt_flat(attrs.get("sup_gml_d")),
        val_pct_a=_pct_badge(attrs.get("val_pct_a")),
        val_pct_d=_pct_badge(attrs.get("val_pct_d")),
        val_pct_gml_d=_pct_badge(val_pct_gml_d, supera, positivo),
    )


# ---------------------------------------------------------------------
# Píldoras "Notifica (paramétrico / alternativo)"
# ---------------------------------------------------------------------

@dataclass
class NotifyData:
    param_text: str
    param_positive: bool
    legal_text: str
    legal_positive: bool
    diverge: bool


def build_notify_data(attrs):
    param_positive = bool(attrs.get("notifica_param"))
    legal_positive = bool(attrs.get("notifica_legal"))
    return NotifyData(
        param_text="S\u00cd" if param_positive else "NO",
        param_positive=param_positive,
        legal_text="S\u00cd" if legal_positive else "NO",
        legal_positive=legal_positive,
        diverge=bool(attrs.get("notif_divergen")),
    )


# ---------------------------------------------------------------------
# Conclusión (parámetrica / legal) -- ya llega como texto plano en attrs
# ---------------------------------------------------------------------

@dataclass
class ConclusionParagraph:
    tag: Optional[str]     # "param" | "legal" | None (sin incidencias)
    text: str


def build_conclusion_paragraphs(attrs):
    paragraphs = []
    if attrs.get("conclusion_param"):
        paragraphs.append(ConclusionParagraph("param", str(attrs.get("conclusion_param"))))
    if attrs.get("conclusion_legal"):
        paragraphs.append(ConclusionParagraph("legal", str(attrs.get("conclusion_legal"))))
    if not paragraphs:
        paragraphs.append(ConclusionParagraph(None, "\u2713 Sin incidencias que motiven notificaci\u00f3n."))
    return paragraphs


# ---------------------------------------------------------------------
# Panel de revisión / decisión
# ---------------------------------------------------------------------

@dataclass
class DecisionData:
    estado: str           # 'si' | 'no' | 'rev' | '' (sin revisar)
    text: str
    color: str
    bg: str
    obs: str
    fecha: str
    desactualizada: bool


def build_decision_data(attrs):
    from . import geometry as geo
    rev_estado = attrs.get("revision_estado") or ""
    obs_raw = attrs.get("revision_obs") or ""
    return DecisionData(
        estado=rev_estado,
        text=geo.REVISION_TEXT.get(rev_estado, geo.REVISION_TEXT_DEFAULT),
        color=geo.REVISION_COLOR.get(rev_estado, geo.REVISION_COLOR_DEFAULT),
        bg=geo.REVISION_BG.get(rev_estado, geo.REVISION_BG_DEFAULT),
        obs=obs_raw.strip() if obs_raw else "(sin observaciones)",
        fecha=str(attrs.get("revision_fecha") or "\u2014"),
        desactualizada=bool(attrs.get("revision_desactualizada")),
    )
