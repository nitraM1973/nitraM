# -*- coding: utf-8 -*-
"""
core/pdf_export
==================

Generador de PDF "nativo" (sin QtWebEngine) de la ficha individual de una
finca de AudiNOT. Paquete completamente independiente de
``core/report_service.py`` y del resto del plugin: solo depende de
``PyQt5`` (QtGui, QtCore, QtPrintSupport, QtSvg), módulos que forman
parte del núcleo de cualquier instalación de QGIS.

Ver ``export_service.py`` para el punto de entrada público
(``PdfFichaExportService``) y ``geometry.py`` para una explicación más
larga del porqué de este paquete frente a la alternativa basada en
``QWebEnginePage.printToPdf``.
"""

from .export_service import PdfFichaExportService, ExportResult, ExportSummary

__all__ = ["PdfFichaExportService", "ExportResult", "ExportSummary"]
