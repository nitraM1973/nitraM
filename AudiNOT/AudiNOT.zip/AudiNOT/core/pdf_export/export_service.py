# -*- coding: utf-8 -*-
"""
core/pdf_export/export_service.py
=====================================

Fachada pública del paquete ``core.pdf_export``: es el único punto de
entrada que debería usar el resto del plugin (p.ej. ``tab_audit.py``)
para generar el PDF de una ficha individual sin pasar por
``ReportService.render_html_to_pdf`` (que depende de QtWebEngine).

USO TÍPICO
-----------
    from AudiNOT.core.pdf_export import PdfFichaExportService

    svc = PdfFichaExportService()
    ok, err = svc.render_parcel_card_pdf(attrs, audinot_json, "/ruta/ficha.pdf",
                                          thresholds=thresholds_ficha3)
    if not ok:
        # err es un mensaje de error listo para mostrar al usuario
        ...

Para exportación masiva (una ficha por finca, análogo a
``TabAudit._export_bulk_pdf``):

    summary = svc.export_many(
        items=[(attrs1, json1), (attrs2, json2), ...],
        out_dir="/ruta/carpeta",
        thresholds=thresholds_ficha3,
        progress_cb=lambda i, total, aid: print(f"{i}/{total}: {aid}"),
    )
    print(summary.ok, summary.failed, summary.errors)

Esta fachada es deliberadamente independiente de cualquier widget de
Qt Widgets (no usa ``QMessageBox``, ``QProgressDialog``, etc.): el
``progress_cb`` es una función cualquiera que la UI decide cómo mostrar
(barra de progreso, log, nada). Así el paquete se puede reutilizar igual
de bien desde un script de línea de comandos, un test o la propia UI del
plugin, sin arrastrar dependencias de interfaz.
"""

import os
import re
import unicodedata
from dataclasses import dataclass, field
from typing import Callable, Iterable, List, Optional, Tuple

from PyQt5.QtGui import QPageLayout, QPageSize
from PyQt5.QtPrintSupport import QPrinter

from . import geometry as geo
from .flow_canvas import FlowCanvas
from .ficha_renderer import FichaPdfRenderer


# Márgenes de página, en mm (izq, arriba, der, abajo) -- mismos valores
# que usa el '@page { margin: 16mm 14mm }' de la ficha HTML.
DEFAULT_MARGINS_MM = (14.0, 16.0, 14.0, 16.0)

# DPI de renderizado del PDF. 300 es una resolución de impresión estándar
# de calidad "documento" (el croquis vectorial se ve nítido a cualquier
# nivel de zoom porque QSvgRenderer dibuja curvas reales, no un mapa de
# bits, así que no hace falta subir más el DPI solo por el croquis).
DEFAULT_DPI = 300


@dataclass
class ExportResult:
    """Resultado de exportar UNA ficha."""
    audinot_id: str
    ok: bool
    out_path: Optional[str] = None
    error: Optional[str] = None


@dataclass
class ExportSummary:
    """Resultado de una exportación masiva (``export_many``)."""
    total: int = 0
    ok: int = 0
    failed: int = 0
    results: List[ExportResult] = field(default_factory=list)

    @property
    def errors(self):
        return [(r.audinot_id, r.error) for r in self.results if not r.ok]


class PdfFichaExportService:
    """Genera el PDF de la ficha individual de una finca dibujando
    directamente con ``QPainter`` sobre ``QPrinter`` (sin QtWebEngine).

    Cada instancia es sin estado (salvo la configuración de página que se
    le pase en el constructor) y se puede reutilizar libremente para
    exportar muchas fichas seguidas.
    """

    def __init__(self, margins_mm=DEFAULT_MARGINS_MM, dpi=DEFAULT_DPI, page_size="A4"):
        self.margins_mm = margins_mm
        self.dpi = dpi
        self.page_size = page_size

    # -----------------------------------------------------------------
    # Nombre de fichero -- réplica autocontenida y simplificada de la
    # utilidad de nombrado que ya usa el plugin, para no depender de
    # ningún otro módulo (ver nota de independencia en el docstring del
    # paquete). Si el nombre resultante coincide con el que usa el resto
    # del plugin, mejor (consistencia para el usuario), pero no es
    # obligatorio: el llamante siempre puede pasar su propio
    # ``filename_fn`` a ``export_many``.
    # -----------------------------------------------------------------

    @staticmethod
    def sanitize_filename(text):
        text = str(text or "")
        text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("ascii")
        text = re.sub(r"[^A-Za-z0-9_.-]+", "_", text).strip("_")
        return text or "ficha"

    @classmethod
    def default_filename(cls, audinot_id):
        return f"Ficha_{cls.sanitize_filename(audinot_id)}.pdf"

    # -----------------------------------------------------------------
    # Exportación de una sola ficha
    # -----------------------------------------------------------------

    def render_parcel_card_pdf(self, attrs, audinot_json, out_path, thresholds=None):
        """Genera el PDF de la ficha de UNA finca en ``out_path``.

        Devuelve ``(True, None)`` si todo fue bien, o ``(False, mensaje)``
        si algo falló -- nunca lanza una excepción hacia el llamante
        (cualquier error inesperado durante el dibujado se captura y se
        convierte en un mensaje legible), para que un fallo en una ficha
        concreta no interrumpa una exportación masiva de cientos de
        fincas.
        """
        printer = None
        painter = None
        try:
            out_dir = os.path.dirname(out_path)
            if out_dir and not os.path.isdir(out_dir):
                os.makedirs(out_dir, exist_ok=True)

            printer = self._build_printer(out_path)

            from PyQt5.QtGui import QPainter
            painter = QPainter()
            if not painter.begin(printer):
                return False, "No se ha podido inicializar el motor de impresión de Qt (QPainter.begin devolvió False)."

            painter.setRenderHint(QPainter.Antialiasing, True)
            painter.setRenderHint(QPainter.TextAntialiasing, True)
            painter.setRenderHint(QPainter.SmoothPixmapTransform, True)

            metrics = geo.Metrics(printer.logicalDpiX(), printer.logicalDpiY())
            page_rect_mm = printer.pageRect(QPrinter.Millimeter)
            content_w = float(page_rect_mm.width())
            content_h = float(page_rect_mm.height())

            flow = FlowCanvas(painter, printer, metrics, content_w, content_h)
            renderer = FichaPdfRenderer(flow)
            renderer.render(attrs, audinot_json, thresholds=thresholds)

            painter.end()
            painter = None
            return True, None

        except Exception as exc:  # noqa: BLE001 -- queremos capturar cualquier fallo de dibujado
            try:
                if painter is not None and painter.isActive():
                    painter.end()
            except Exception:
                pass
            return False, f"Error generando el PDF de la ficha: {exc}"

    # -----------------------------------------------------------------
    # Exportación masiva
    # -----------------------------------------------------------------

    def export_many(self, items, out_dir, thresholds=None,
                     filename_fn: Optional[Callable[[dict], str]] = None,
                     progress_cb: Optional[Callable[[int, int, str], None]] = None,
                     stop_check: Optional[Callable[[], bool]] = None):
        """Exporta una ficha PDF por cada elemento de ``items``.

        ``items``: iterable de tuplas ``(attrs, audinot_json)``.
        ``filename_fn``: función opcional ``attrs -> nombre_de_fichero``
            (por defecto, ``default_filename(attrs['audinot_id'])``).
        ``progress_cb``: función opcional ``(indice_1based, total, audinot_id)``
            llamada antes de procesar cada ficha -- pensada para que la UI
            actualice una barra de progreso, sin acoplar este paquete a
            ningún widget concreto.
        ``stop_check``: función opcional que, si devuelve True, corta la
            exportación en curso (para poder cancelar desde la UI).

        Devuelve un ``ExportSummary``. Un fallo en una ficha NO detiene el
        resto del lote (queda registrado en ``summary.errors``).
        """
        items = list(items)
        total = len(items)
        summary = ExportSummary(total=total)

        os.makedirs(out_dir, exist_ok=True)

        for idx, (attrs, audinot_json) in enumerate(items, start=1):
            aid = str((attrs or {}).get("audinot_id") or f"registro_{idx}")

            if stop_check is not None and stop_check():
                break

            if progress_cb is not None:
                try:
                    progress_cb(idx, total, aid)
                except Exception:
                    pass  # un fallo en el callback de progreso no debe abortar la exportación

            filename = filename_fn(attrs) if filename_fn else self.default_filename(aid)
            out_path = os.path.join(out_dir, filename)

            ok, err = self.render_parcel_card_pdf(attrs, audinot_json, out_path, thresholds=thresholds)
            summary.results.append(ExportResult(audinot_id=aid, ok=ok, out_path=out_path if ok else None, error=err))
            if ok:
                summary.ok += 1
            else:
                summary.failed += 1

        return summary

    # -----------------------------------------------------------------
    def _build_printer(self, out_path):
        printer = QPrinter(QPrinter.HighResolution)
        printer.setOutputFormat(QPrinter.PdfFormat)
        printer.setOutputFileName(out_path)
        printer.setResolution(self.dpi)

        page_size = QPageSize(QPageSize.A4) if self.page_size == "A4" else QPageSize(QPageSize.Letter)
        printer.setPageSize(page_size)
        printer.setPageOrientation(QPageLayout.Portrait)

        left, top, right, bottom = self.margins_mm
        # OJO: la sobrecarga setPageMargins(QMarginsF, QPageLayout.Unit) no
        # está disponible en todas las builds de PyQt5 (en algunas
        # instalaciones de QGIS, p.ej. OSGeo4W con Qt/PyQt5 más antiguos,
        # el binding SIP solo expone la firma clásica de 5 argumentos).
        # Usamos esa firma clásica -- setPageMargins(left, top, right,
        # bottom, unit) -- que sí existe en QPagedPaintDevice desde Qt4 y
        # funciona en cualquier versión de PyQt5.
        printer.setPageMargins(left, top, right, bottom, QPrinter.Millimeter)
        return printer
