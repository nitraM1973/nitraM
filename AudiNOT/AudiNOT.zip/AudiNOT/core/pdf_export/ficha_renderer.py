# -*- coding: utf-8 -*-
"""
core/pdf_export/ficha_renderer.py
====================================

Ensamblador de la ficha individual de una finca en PDF: recorre las
mismas secciones que ``ReportService.generate_parcel_card_html`` (cabecera
con estado, croquis + rejilla de datos, conclusión, tabla de aditamentos,
panel de revisión) pero dibujándolas con ``QPainter`` a través de
``FlowCanvas`` en vez de generar HTML.

Este módulo NO importa nada de ``core/report_service.py``: toma los
mismos ``attrs`` / ``audinot_json`` / ``thresholds`` que ya usa la ficha
HTML, y delega el cálculo de los valores derivados en ``data_prep.py``
(ver ese módulo para el detalle de la reimplementación independiente de
la aritmética de umbrales/formateo).
"""

from datetime import datetime

from PyQt5.QtCore import QRectF, Qt
from PyQt5.QtGui import QColor, QFont, QLinearGradient, QPen

from . import geometry as geo
from . import data_prep as dp
from .svg_sketch import extract_sketch_parts, render_sketch


class FichaPdfRenderer:
    """Dibuja la ficha completa de UNA finca sobre un ``FlowCanvas`` ya
    preparado (una página de impresora por ficha, con tantas páginas
    adicionales como haga falta si el contenido no cabe en una sola)."""

    def __init__(self, flow):
        self.flow = flow
        self.painter = flow.painter
        self.metrics = flow.metrics

    # -----------------------------------------------------------------
    def render(self, attrs, audinot_json, thresholds=None):
        audinot_json = audinot_json or {}
        aid = str(attrs.get("audinot_id") or "")
        estado = str(attrs.get("estado") or "")

        self._draw_letterhead()
        self._draw_card_header(aid, estado)

        self.flow.cursor_y += 2.0
        self._draw_sketch_and_data(attrs, audinot_json)
        self._draw_conclusion(attrs)

        adit_table = dp.build_adit_table(audinot_json.get("aditamentos", {}), thresholds)
        if adit_table.has_rows:
            self.flow.cursor_y += 3.0
            self._draw_adit_section(adit_table)

        self.flow.cursor_y += 3.0
        self._draw_revision_section(attrs)

    # -----------------------------------------------------------------
    def _draw_letterhead(self):
        f = self.flow
        p = self.painter

        p.setFont(f.font(8.4, bold=True))
        p.setPen(QPen(geo.qcolor(geo.LIGHT_TEXT)))
        p.drawText(f._px_rect(0, f.cursor_y, f.content_w * 0.6, 4.5),
                   Qt.AlignLeft | Qt.AlignVCenter, "AUDINOT")

        p.setFont(f.font(9.0, bold=False))
        p.setPen(QPen(geo.qcolor(geo.LIGHT_TEXT)))
        p.drawText(f._px_rect(0, f.cursor_y + 4.2, f.content_w * 0.6, 4.0),
                   Qt.AlignLeft | Qt.AlignVCenter, "Ficha individual de auditor\u00eda ANTES vs DESPU\u00c9S")

        meta = "Generada el " + datetime.now().strftime("%d/%m/%Y %H:%M")
        p.setFont(f.font(7.4))
        p.setPen(QPen(geo.qcolor(geo.LIGHT_TEXT)))
        p.drawText(f._px_rect(f.content_w * 0.4, f.cursor_y, f.content_w * 0.6, 8.0),
                   Qt.AlignRight | Qt.AlignVCenter, meta)

        f.cursor_y += 9.5
        f.draw_rule(color=geo.PRIMARY, thickness_mm=0.6, margin_bottom_mm=3.0)

    # -----------------------------------------------------------------
    def _draw_card_header(self, aid, estado):
        f = self.flow
        p = self.painter
        h_mm = 16.0
        f.ensure_space(h_mm)

        rect = f._px_rect(0, f.cursor_y, f.content_w, h_mm)
        grad = QLinearGradient(rect.topLeft(), rect.bottomRight())
        grad.setColorAt(0.0, geo.qcolor(geo.PRIMARY))
        grad.setColorAt(1.0, geo.qcolor(geo.SECONDARY))
        p.setPen(Qt.NoPen)
        p.setBrush(grad)
        p.drawRoundedRect(rect, f._px(1.2), f._px(1.2))

        pad_x = 6.0
        p.setPen(QPen(QColor(255, 255, 255, 190)))
        p.setFont(f.font(6.8, bold=False))
        p.drawText(f._px_rect(pad_x, f.cursor_y + 2.0, f.content_w - 2 * pad_x, 3.5),
                   Qt.AlignLeft | Qt.AlignVCenter, "FINCA")

        p.setPen(QPen(QColor(255, 255, 255)))
        p.setFont(f.font(15.5, bold=True))
        p.drawText(f._px_rect(pad_x, f.cursor_y + 5.0, f.content_w - 2 * pad_x, 7.5),
                   Qt.AlignLeft | Qt.AlignVCenter, aid or "\u2014")

        if estado:
            badge_color = geo.ESTADO_COLORS.get(estado.strip().lower())
            bg = geo.qcolor(badge_color) if badge_color else geo.ESTADO_DEFAULT
            ef = f.font(7.2, bold=True)
            from PyQt5.QtGui import QFontMetrics
            fm = QFontMetrics(ef, f.printer)
            text_w = fm.horizontalAdvance(estado)
            badge_h_px = f._px(4.4)
            badge_w_px = text_w + f._px(5.0)
            badge_rect = QRectF(
                f.metrics.mm_x(pad_x), f.metrics.mm_y(f.cursor_y + 12.2),
                badge_w_px, badge_h_px,
            )
            p.setPen(Qt.NoPen)
            p.setBrush(bg)
            p.drawRoundedRect(badge_rect, badge_h_px / 2.0, badge_h_px / 2.0)
            p.setPen(QPen(QColor(255, 255, 255)))
            p.setFont(ef)
            p.drawText(badge_rect, Qt.AlignCenter, estado)

        f.cursor_y += h_mm + 3.0

    # -----------------------------------------------------------------
    def _draw_sketch_and_data(self, attrs, audinot_json):
        f = self.flow

        sketch_h = 62.0
        f.ensure_space(sketch_h)
        parts = extract_sketch_parts(attrs.get("croquis_svg") or "")
        render_sketch(self.painter, (0, f.cursor_y, f.content_w, sketch_h), self.metrics, parts, f)
        f.cursor_y += sketch_h + 4.0

        titular_a = audinot_json.get("titularAntes") or ""
        titular_d = audinot_json.get("titularDespues") or ""
        titular_txt = f"{titular_a} \u2192 {titular_d}"
        if audinot_json.get("titularCambia"):
            titular_txt += "  (cambia)"

        sup_a = attrs.get("sup_a")
        sup_d = attrs.get("sup_d")
        sup_txt = f"{sup_a} m\u00b2 \u2192 {sup_d} m\u00b2  (\u0394 {attrs.get('var_sup')} m\u00b2, {attrs.get('var_sup_pct')}%)"

        perim_txt = f"\u0394 {attrs.get('var_perim')} m   \u00b7   {attrs.get('n_partes_a')} \u2192 {attrs.get('n_partes_d')} partes"

        t24 = dp.build_t24_gml_data(attrs)
        t24_txt = (
            f"supfT24: {t24.sup_t24_a} m\u00b2 \u2192 {t24.sup_t24_d} m\u00b2   "
            f"Superficie GML: {t24.sup_gml_a} m\u00b2 \u2192 {t24.sup_gml_d} m\u00b2\n"
            f"% Validaci\u00f3n (T24 vs. gr\u00e1fica): {t24.val_pct_a.text} \u2192 {t24.val_pct_d.text}   "
            f"% Validaci\u00f3n GML Despu\u00e9s: {t24.val_pct_gml_d.text}"
        )

        notify = dp.build_notify_data(attrs)

        pairs = [
            ("N\u00ba propietario", titular_txt, True),
            ("Superficie", sup_txt, False),
            ("Per\u00edmetro / partes", perim_txt, False),
            ("Validaci\u00f3n T24 / GML", t24_txt, True),
        ]
        f.draw_key_value_grid(pairs)

        # Píldoras "Notifica" en su propia fila (no encajan bien en el
        # sistema de texto puro de draw_key_value_grid porque llevan
        # fondo de color, así que se dibujan aparte).
        row_h = 8.5
        f.ensure_space(row_h)
        col_w = (f.content_w - 6.0) / 2.0
        self._draw_notify_pill_cell("Notifica (param\u00e9trico)", notify.param_text, notify.param_positive, 0.0, col_w)
        self._draw_notify_pill_cell("Notifica (alternativo)", notify.legal_text, notify.legal_positive,
                                     col_w + 6.0, col_w, extra="\u26a0 no coinciden" if notify.diverge else "")
        f.cursor_y += row_h + 2.0

    def _draw_notify_pill_cell(self, label, text, positive, x_mm, w_mm, extra=""):
        f = self.flow
        p = self.painter
        p.setFont(f.font(6.6))
        p.setPen(QPen(geo.qcolor(geo.MUTED_TEXT)))
        p.drawText(f._px_rect(x_mm, f.cursor_y, w_mm, 3.4), Qt.AlignLeft, label.upper())

        bg = geo.PILL_POSITIVE_BG if positive else geo.PILL_NEGATIVE_BG
        fg = geo.PILL_POSITIVE_FG if positive else geo.PILL_NEGATIVE_FG
        f.draw_pill(text, x_mm, f.cursor_y + 3.8, bg, fg)

        if extra:
            p.setFont(f.font(6.6, bold=True))
            p.setPen(QPen(geo.qcolor("#e67e22")))
            p.drawText(f._px_rect(x_mm + 18.0, f.cursor_y + 3.8, w_mm - 18.0, 4.6),
                       Qt.AlignLeft | Qt.AlignVCenter, extra)

    # -----------------------------------------------------------------
    def _draw_conclusion(self, attrs):
        f = self.flow
        paragraphs = dp.build_conclusion_paragraphs(attrs)

        tag_labels = {"param": "\u26a0 Conclusi\u00f3n param\u00e9trica", "legal": "\u2696 Conclusi\u00f3n alternativa"}
        tag_colors = {"param": geo.TAG_PARAM_COLOR, "legal": geo.TAG_LEGAL_COLOR}

        # Altura total (para reservar hueco y dibujar la caja de fondo).
        heights = []
        for para in paragraphs:
            h = 0.0
            if para.tag:
                h += 3.6
            h += f.measure_text(para.text, 8.6, width_mm=f.content_w - 6.0)
            heights.append(h + 2.0)
        total_h = sum(heights) + 4.0
        f.ensure_space(total_h)

        f.draw_box(total_h, bg="#f8fafc", border=geo.BORDER, accent=geo.ACCENT, accent_width_mm=1.0)

        y = f.cursor_y + 2.0
        for para, h in zip(paragraphs, heights):
            x = 4.0
            if para.tag:
                self.painter.setFont(f.font(7.6, bold=True))
                self.painter.setPen(QPen(geo.qcolor(tag_colors[para.tag])))
                self.painter.drawText(f._px_rect(x, y, f.content_w - 6.0, 3.6),
                                       Qt.AlignLeft, tag_labels[para.tag])
                y += 3.6
            color = geo.CONCLUSION_OK_COLOR if not para.tag else geo.PRIMARY
            bold = not para.tag
            text_h = f.measure_text(para.text, 8.6, bold=bold, width_mm=f.content_w - 6.0)
            self.painter.setFont(f.font(8.6, bold=bold))
            self.painter.setPen(QPen(geo.qcolor(color)))
            self.painter.drawText(f._px_rect(x, y, f.content_w - 6.0, text_h + 1.5),
                                   Qt.AlignLeft | Qt.TextWordWrap, para.text)
            y += text_h + 2.0

        f.cursor_y += total_h

    # -----------------------------------------------------------------
    def _draw_adit_section(self, adit_table):
        f = self.flow
        f.draw_section_label(
            f"Auditor\u00eda de aditamentos ({adit_table.alerts} alerta(s) de {adit_table.total})"
        )
        f.cursor_y += 1.0

        headers = ["Elemento", "Antes", "Despu\u00e9s", "Var", "%"]
        col_w = [
            f.content_w * 0.40,
            f.content_w * 0.15,
            f.content_w * 0.15,
            f.content_w * 0.15,
            f.content_w * 0.15,
        ]
        aligns = [Qt.AlignLeft, Qt.AlignRight, Qt.AlignRight, Qt.AlignRight, Qt.AlignRight]

        rows = []
        for r in adit_table.rows:
            var_color = None
            if r.delta_color == "pos":
                var_color = geo.TEXT_POS_COLOR
            elif r.delta_color == "neg":
                var_color = geo.TEXT_NEG_COLOR
            mark = " *" if r.is_alert else ""
            values = [r.label, r.antes, r.despues, r.delta + mark, r.pct]
            colors = [None, None, None, var_color, var_color]
            rows.append((values, colors))

        f.draw_table(headers, rows, col_w, aligns)

    # -----------------------------------------------------------------
    def _draw_revision_section(self, attrs):
        f = self.flow
        f.draw_section_label("\U0001F4DD Revisi\u00f3n de auditor\u00eda")
        f.cursor_y += 1.0

        if attrs.get("revision_desactualizada"):
            warn_h = f.measure_text(
                "\u26a0 Las m\u00e9tricas de esta finca han cambiado desde la \u00faltima revisi\u00f3n. "
                "Comprueba si la decisi\u00f3n anterior sigue siendo v\u00e1lida.",
                8.2, bold=True, width_mm=f.content_w,
            )
            f.ensure_space(warn_h + 2.0)
            self.painter.setFont(f.font(8.2, bold=True))
            self.painter.setPen(QPen(geo.qcolor("#b45309")))
            self.painter.drawText(
                f._px_rect(0, f.cursor_y, f.content_w, warn_h + 1.0), Qt.AlignLeft | Qt.TextWordWrap,
                "\u26a0 Las m\u00e9tricas de esta finca han cambiado desde la \u00faltima revisi\u00f3n. "
                "Comprueba si la decisi\u00f3n anterior sigue siendo v\u00e1lida."
            )
            f.cursor_y += warn_h + 2.0

        decision = dp.build_decision_data(attrs)
        obs_h = f.measure_text(decision.obs, 8.4, width_mm=f.content_w - 8.0)
        total_h = 6.0 + 3.6 + obs_h + 4.0
        f.ensure_space(total_h)

        f.draw_box(total_h, bg=decision.bg, border=geo.BORDER, accent=decision.color, accent_width_mm=1.0)

        p = self.painter
        x = 4.0
        p.setFont(f.font(10.0, bold=True))
        p.setPen(QPen(geo.qcolor(decision.color)))
        p.drawText(f._px_rect(x, f.cursor_y + 2.0, f.content_w * 0.55, 5.5),
                   Qt.AlignLeft | Qt.AlignVCenter, decision.text)

        p.setFont(f.font(8.0))
        p.setPen(QPen(geo.qcolor(geo.MUTED_TEXT)))
        p.drawText(f._px_rect(f.content_w * 0.5, f.cursor_y + 2.0, f.content_w * 0.5 - 4.0, 5.5),
                   Qt.AlignRight | Qt.AlignVCenter, f"({decision.fecha})")

        p.setFont(f.font(6.6))
        p.setPen(QPen(geo.qcolor(geo.MUTED_TEXT)))
        p.drawText(f._px_rect(x, f.cursor_y + 7.6, f.content_w - 2 * x, 3.2),
                   Qt.AlignLeft, "OBSERVACI\u00d3N")

        p.setFont(f.font(8.4))
        p.setPen(QPen(geo.qcolor(geo.PRIMARY)))
        p.drawText(f._px_rect(x, f.cursor_y + 10.6, f.content_w - 2 * x, obs_h + 1.5),
                   Qt.AlignLeft | Qt.TextWordWrap, decision.obs)

        f.cursor_y += total_h
