from qgis.core import QgsProject, QgsGeometry, QgsSpatialIndex
import math
import re
from .islas_service import IslandsService

class MetricsCalculator:
    def __init__(self, union_layer, layer_antes, layer_despues, log_callback=None, settings=None):
        self.union_layer = union_layer
        self.layer_antes = layer_antes
        self.layer_despues = layer_despues
        self.log = log_callback
        self.settings = settings if settings else {}
        self.islas_service = IslandsService(log_callback)
        
        self.metrics = {
            'transition_matrix': [],
            'global_stats': {},
            'parcel_details': [],
            'facades': {} 
        }
        
        # Estandarización de claves de infraestructura (Coherente con TabMapping y ReportService)
        self.infra_keys = ['VIALES', 'CURSOS AGUA', 'EDIFICACIONES', 'EXCLUIDO']
        
        # Recuperar rangos de configuración o usar defaults (Mapeo a infra_keys)
        self.special_ranges = self.settings.get('special_ranges', {
            'VIALES': range(9000, 9999), 
            'CURSOS AGUA': range(8000, 8999),
            'EDIFICACIONES': range(10000, 20000)
        })

    def add_log(self, msg):
        if self.log:
            self.log(msg)

    def _idx_ci(self, fields, name):
        """Busca el índice de un campo por nombre, tolerando que el driver
        Shapefile/OGR haya cambiado mayúsculas/minúsculas al escribir el
        .shp (p.ej. 'xID' guardado como 'XID'). Evita que el cruce de
        identificadores falle en silencio por una simple diferencia de caja."""
        idx = fields.indexFromName(name)
        if idx != -1:
            return idx
        target = name.lower()
        for i, fld in enumerate(fields):
            if fld.name().lower() == target:
                return i
        return -1

    def _parse_supft24(self, val):
        """Parsea el valor bruto del campo SUPFT24 de una feature. Devuelve
        None si el campo no existe/está vacío, o el float correspondiente
        (incluyendo los valores especiales 0 y -1, que el informe interpreta
        de forma particular: -1 = sin dato, 0 = división por cero evitada)."""
        if val is None:
            return None
        s = str(val).strip()
        if s == '' or s.upper() == 'NULL':
            return None
        try:
            return float(val)
        except (TypeError, ValueError):
            return None

    def calculate_all(self):
        """Ejecuta todos los cálculos métricos respetando el orden de dependencia."""
        self.add_log("Iniciando motor de cálculo de métricas avanzadas (Senior 20+ RESTORED)...")
        
        # 1. Generar matriz de transición y detalles base
        self._calculate_matrix() 
        self._calculate_geometric_deltas() # Aquí se crean los objetos detail en parcel_details
        
        # 2. Cálculos espaciales avanzados
        if self.layer_antes and self.layer_despues:
            self._calculate_facades()
            self._calculate_extra_metrics() # Islas, Convexidad, Estabilidad, Perímetros
            self._calculate_neighbor_counts()
            self._calculate_dynamics()
            
        # 3. Vincular flujos
        self._link_flows()

        # Exponer los rangos especiales (VIALES/AGUA/EDIFICACIONES/EXCLUIDO)
        # para que el informe pueda referenciar la categoría de un recinto
        # común en vez de su número de finca individual.
        self.metrics['special_ranges'] = self.special_ranges

        return self.metrics

    def _calculate_dynamics(self):
        self.add_log("Sincronizando métricas de dinámica...")
        pass

    def _link_flows(self):
        details_map = {d['id']: d for d in self.metrics['parcel_details']}
        for d in details_map.values():
            d['inputs'] = []; d['outputs'] = [] 
            
        for flow in self.metrics['transition_matrix']:
            src_id = flow['source']; tgt_id = flow['target']
            if str(src_id).strip() == str(tgt_id).strip(): continue
            if src_id in details_map: details_map[src_id]['outputs'].append(flow)
            if tgt_id in details_map: details_map[tgt_id]['inputs'].append(flow)
                
        for d in details_map.values():
            d['inputs'].sort(key=lambda x: x['area'], reverse=True)
            d['outputs'].sort(key=lambda x: x['area'], reverse=True)

    def _is_special(self, feature, field_name_override=None):
        """Determina si un feature es especial basándose en tipo o rango de REC."""
        idx_tipo = self._idx_ci(feature.fields(), "TIPO")
        if idx_tipo != -1:
            val = feature[idx_tipo]
            if val and str(val) != 'NULL' and str(val).upper() != 'PARCELA':
                t = str(val).upper()
                # Normalización de etiquetas para que coincidan con infra_keys
                if 'VIAL' in t: return 'VIALES'
                if 'AGUA' in t: return 'CURSOS AGUA'
                if 'EDIF' in t: return 'EDIFICACIONES'
                if 'EXCL' in t: return 'EXCLUIDO'
                return t

        idx_rec = -1
        if field_name_override:
            idx = self._idx_ci(feature.fields(), field_name_override)
            if idx != -1: idx_rec = idx
            
        if idx_rec == -1:
            for c in ["REC", "FINCA", "PARCELA", "ID_REC"]:
                idx = self._idx_ci(feature.fields(), c)
                if idx != -1: idx_rec = idx; break
        
        if idx_rec != -1:
            try:
                val_raw = feature[idx_rec]
                if val_raw is not None:
                    rec_val = int(float(str(val_raw)))
                    for label, r in self.special_ranges.items():
                        if rec_val in r: return label
            except: pass
        return None

    def _calculate_matrix(self):
        matrix = {} 
        idx_area = self._idx_ci(self.union_layer.fields(), "AREA_FRAG")
        if idx_area == -1: return
        idx_prop_a = self._idx_ci(self.union_layer.fields(), "PROP")
        idx_prop_d = self._idx_ci(self.union_layer.fields(), "PROP_2")

        for f in self.union_layer.getFeatures():
            id_a = self._get_id(f, ""); id_d = self._get_id(f, "_2")
            if not id_a and not id_d: continue
            key = (id_a, id_d); area = f[idx_area]
            prop_a = str(f[idx_prop_a]) if idx_prop_a != -1 else "DESCONOCIDO"
            prop_d = str(f[idx_prop_d]) if idx_prop_d != -1 else "DESCONOCIDO"

            if key not in matrix:
                matrix[key] = {
                    'source': id_a if id_a else "ALTA (NUEVO)", 'target': id_d if id_d else "BAJA (ELIMINADO)",
                    'prop_source': prop_a if id_a else "-", 'prop_target': prop_d if id_d else "-",
                    'area': 0.0, 'type': self._determine_flow_type(id_a, id_d, prop_a, prop_d),
                    '_frag_geoms': []
                }
            matrix[key]['area'] += area

            # Acumulamos también la geometría del fragmento UNION: es la pieza
            # exacta (ya limpiada/validada) que esta finca cede o recibe frente
            # a la otra. Disolviendo estos fragmentos por flujo evitamos tener
            # que recalcular ninguna intersección/difference más adelante para
            # el croquis del informe.
            gfrag = f.geometry()
            if gfrag and not gfrag.isNull() and not gfrag.isEmpty():
                matrix[key]['_frag_geoms'].append(QgsGeometry(gfrag))

        for fl in matrix.values():
            fl['geom'] = self._dissolve_geoms(fl.pop('_frag_geoms'))

        self.metrics['transition_matrix'] = sorted(matrix.values(), key=lambda x: x['area'], reverse=True)

    def _determine_flow_type(self, id_a, id_d, prop_a, prop_d):
        if not id_a: return "ALTA"
        if not id_d: return "BAJA"
        if id_a == id_d: return "ESTABLE" if prop_a == prop_d else "CAMBIO_TITULAR"
        return "SEGREGACION_AGREGACION"

    def _calculate_geometric_deltas(self):
        """Calcula deltas geométricos agregando fragmentos del Union."""
        self.add_log("Calculando Deltas Geométricos (Área, Gravelius, Propietarios)...")
        parcels_a = {}; parcels_d = {}

        idx_area = self._idx_ci(self.union_layer.fields(), "AREA_FRAG")
        idx_rings_a = self._idx_ci(self.union_layer.fields(), "N_RINGS")
        idx_rings_d = self._idx_ci(self.union_layer.fields(), "N_RINGS_2")
        idx_grav_a = self._idx_ci(self.union_layer.fields(), "K_GRAV")
        idx_grav_d = self._idx_ci(self.union_layer.fields(), "K_GRAV_2")
        idx_tipo_a = self._idx_ci(self.union_layer.fields(), "TIPO")
        idx_tipo_d = self._idx_ci(self.union_layer.fields(), "TIPO_2")
        idx_prop_a = self._idx_ci(self.union_layer.fields(), "PROP")
        idx_prop_d = self._idx_ci(self.union_layer.fields(), "PROP_2")
        idx_supft24_a = self._idx_ci(self.union_layer.fields(), "SUPFT24")
        idx_supft24_d = self._idx_ci(self.union_layer.fields(), "SUPFT24_2")

        for f in self.union_layer.getFeatures():
            id_a = self._get_id(f, ""); id_d = self._get_id(f, "_2")
            area = f[idx_area] if idx_area != -1 else 0.0
            type_a = str(f[idx_tipo_a]) if idx_tipo_a != -1 else "PARCELA"
            type_d = str(f[idx_tipo_d]) if idx_tipo_d != -1 else "PARCELA"

            if id_a:
                if id_a not in parcels_a:
                    parcels_a[id_a] = {
                        'area': 0, 'rings': f[idx_rings_a] if idx_rings_a != -1 else 0,
                        'grav': f[idx_grav_a] if idx_grav_a != -1 else 0,
                        'type': type_a.strip().upper(), 'prop': str(f[idx_prop_a]) if idx_prop_a != -1 else "DESCONOCIDO",
                        # SUPFT24 es un valor de referencia por recinto (no un
                        # fragmento a sumar): se toma una única vez, del primer
                        # fragmento UNION encontrado para este xID, ya que
                        # todos los fragmentos de un mismo recinto heredan el
                        # mismo valor original.
                        'supft24': self._parse_supft24(f[idx_supft24_a]) if idx_supft24_a != -1 else None,
                        'geoms': []
                    }
                parcels_a[id_a]['area'] += area
                g = f.geometry()
                if g and not g.isNull() and not g.isEmpty():
                    parcels_a[id_a]['geoms'].append(QgsGeometry(g))

            if id_d:
                if id_d not in parcels_d:
                    parcels_d[id_d] = {
                        'area': 0, 'rings': f[idx_rings_d] if idx_rings_d != -1 else 0,
                        'grav': f[idx_grav_d] if idx_grav_d != -1 else 0,
                        'type': type_d.strip().upper(), 'prop': str(f[idx_prop_d]) if idx_prop_d != -1 else "DESCONOCIDO",
                        'supft24': self._parse_supft24(f[idx_supft24_d]) if idx_supft24_d != -1 else None,
                        'geoms': []
                    }
                parcels_d[id_d]['area'] += area
                g = f.geometry()
                if g and not g.isNull() and not g.isEmpty():
                    parcels_d[id_d]['geoms'].append(QgsGeometry(g))

        all_ids = set(parcels_a.keys()) | set(parcels_d.keys())
        details = []
        study_ids = self.settings.get('study_ids')

        for pid in all_ids:
            data_a = parcels_a.get(pid); data_d = parcels_d.get(pid)
            t_a = data_a['type'] if data_a else ""; t_d = data_d['type'] if data_d else ""
            if t_a != "PARCELA" and t_d != "PARCELA": continue
            if study_ids is not None and str(pid) not in study_ids: continue
            
            info = {'id': pid}
            info['prop_a'] = data_a['prop'] if data_a else 'N/A'
            info['prop_d'] = data_d['prop'] if data_d else 'N/A'
            info['geom_a'] = self._dissolve_geoms(data_a['geoms']) if data_a else None
            info['geom_d'] = self._dissolve_geoms(data_d['geoms']) if data_d else None
            # Superficie de referencia T24 (comprobación informativa vs. la
            # superficie real GML). None si el recinto no existe en ese
            # estado o si el shapefile no trae el campo.
            info['supft24_a'] = data_a.get('supft24') if data_a else None
            info['supft24_d'] = data_d.get('supft24') if data_d else None
            
            if data_a and data_d:
                info['state'] = 'PERSISTENTE'
                info['delta_area'] = data_d['area'] - data_a['area']
                info['area_final'] = data_d['area']
                info['grav_a'] = data_a['grav']; info['grav_d'] = data_d['grav']
                info['delta_grav'] = info['grav_d'] - info['grav_a']
                info['rings_a'] = data_a['rings']; info['rings_d'] = data_d['rings']
                info['delta_rings'] = info['rings_d'] - info['rings_a']
            elif data_a:
                info['state'] = 'BAJA'; info['area_final'] = 0; info['delta_area'] = -data_a['area']
                info['grav_a'] = data_a['grav']; info['grav_d'] = 0; info['delta_grav'] = -data_a['grav']
            elif data_d:
                info['state'] = 'ALTA'; info['area_final'] = data_d['area']; info['delta_area'] = data_d['area']
                info['grav_a'] = 0; info['grav_d'] = data_d['grav']; info['delta_grav'] = data_d['grav']

            details.append(info)
        self.metrics['parcel_details'] = sorted(details, key=lambda x: str(x['id']))

    def _dissolve_geoms(self, geoms):
        """Disuelve una lista de fragmentos (procedentes de la capa UNION) en la
        geometría completa original del recinto. Se usa para el croquis
        ANTES/DESPUÉS del informe: necesitamos la forma completa de la parcela,
        no un fragmento aislado de la intersección."""
        if not geoms:
            return None
        if len(geoms) == 1:
            return geoms[0]
        try:
            merged = QgsGeometry.unaryUnion(geoms)
            if merged and not merged.isNull() and not merged.isEmpty():
                return merged
        except Exception:
            pass
        # Fallback: union secuencial si unaryUnion falla por topología
        try:
            result = geoms[0]
            for g in geoms[1:]:
                result = result.combine(g)
            return result
        except Exception:
            return geoms[0]

    def _calculate_facades(self):
        """Calcula longitudes de fachada (contacto) con infraestructuras estándar."""
        self.add_log("Analizando fachadas (Vinculación Senior 20+)...")
        results_antes = {}; results_desp = {}

        def process_layer(layer, tag, store):
            if not layer: return
            idx = QgsSpatialIndex(layer.getFeatures())
            feats = {f.id(): f for f in layer.getFeatures()}
            
            for f in layer.getFeatures():
                pid = self._get_id_from_layer(f, tag)
                if not pid or self._is_special(f): continue
                
                if pid not in store: store[pid] = {k:0.0 for k in self.infra_keys}
                
                geom = f.geometry()
                if not geom: continue
                perim_line = self._get_exterior_boundary_geom(geom)
                if not perim_line: continue
                
                for nid in idx.intersects(geom.boundingBox()):
                    if nid == f.id(): continue
                    nf = feats.get(nid)
                    ntype = self._is_special(nf)
                    if ntype and ntype in self.infra_keys:
                        infra_geom = nf.geometry()
                        if not infra_geom: continue
                        buffered_infra = infra_geom.buffer(0.01, 3) 
                        intersection = perim_line.intersection(buffered_infra)
                        if intersection and not intersection.isEmpty():
                            store[pid][ntype] += intersection.length()

        process_layer(self.layer_antes, 'antes', results_antes)
        process_layer(self.layer_despues, 'desp', results_desp)

        linked = 0
        for detail in self.metrics['parcel_details']:
            pid = detail['id']
            has_data = False
            for k in self.infra_keys:
                v_a = results_antes.get(pid, {}).get(k, 0.0)
                v_d = results_desp.get(pid, {}).get(k, 0.0)
                detail[f'facade_antes_{k}'] = v_a
                detail[f'facade_desp_{k}'] = v_d
                if v_a > 0 or v_d > 0: has_data = True
            if has_data: linked += 1
        
        self.add_log(f"Vinculación: {linked} parcelas tienen datos de fachada.")

    def _strip_subrec(self, full_id):
        """Quita el subíndice de subrecinto de un ID tipo POL/MAS[-SMAS]/REC[-SREC],
        dejando POL/MAS[-SMAS]/REC. Se usa para agrupar subrecintos de una misma
        finca/recinto 'común', ya que la variación de linderos entre ANTES y
        DESPUÉS puede deberse simplemente a cómo se reparte internamente esa
        finca, no a un cambio real de lindero exterior."""
        if not full_id:
            return full_id
        parts = str(full_id).split("/")
        if len(parts) < 2:
            return full_id
        parts[-1] = parts[-1].split("-")[0]
        return "/".join(parts)

    def _rec_from_base_id(self, base_id):
        """Extrae el número de REC (entero) de un ID base POL/MAS[-SMAS]/REC."""
        if not base_id:
            return None
        try:
            rec_str = str(base_id).split("/")[-1]
            return int(float(rec_str))
        except Exception:
            return None

    def _common_category(self, rec_val):
        """
        Devuelve la categoría (VIALES, CURSOS AGUA, EDIFICACIONES, EXCLUIDO...)
        a la que pertenece un número de REC según los rangos parametrizados en
        la pestaña '2: Mapeo de Campos' -> 'Identificación por REC (Rangos)',
        o None si no es un recinto 'común'.
        """
        if rec_val is None:
            return None
        for label, r in self.special_ranges.items():
            try:
                if rec_val in r:
                    return label
            except Exception:
                pass
        return None

    def _calculate_extra_metrics(self):
        """Calcula Islas, Convexidad, Estabilidad y Perímetros."""
        self.add_log("Calculando Métricas Avanzadas (Perímetros, Islas, Convexidad, Estabilidad)...")

        # Diagnóstico: confirmar que el campo xID realmente existe (con el
        # nombre que sea, mayúsculas incluidas) en ambas capas de origen, y
        # cuántas features tiene cada una. Si esto sale en rojo, el problema
        # ni siquiera llega a ser de formato: el campo no está donde se espera.
        for lyr, label in ((self.layer_antes, 'ANTES-ok'), (self.layer_despues, 'DESPUES-ok')):
            if not lyr:
                self.add_log(f"<font color='red'>CROQUIS: la capa {label} no está disponible (None).</font>")
                continue
            idx_x = self._idx_ci(lyr.fields(), "xID")
            real_name = lyr.fields()[idx_x].name() if idx_x != -1 else None
            found_txt = ("sí (" + real_name + ")") if real_name else "<font color='red'>NO ENCONTRADO</font>"
            self.add_log(f"CROQUIS: capa {label} -> {lyr.featureCount()} features, campo xID encontrado: {found_txt}.")

        data_a = {}; data_d = {}
        common_pid_to_cat = {'antes': {}, 'desp': {}}
        common_geoms = {'antes': {}, 'desp': {}}
        # Acumulamos TODAS las geometrías por pid (no solo la del último feature
        # leído): un mismo xID puede repartirse en varios features de la capa
        # ANTES-ok/DESPUES-ok (subrecintos/multiparte), y antes se perdían al
        # sobrescribirse en 'store[pid]'. Esto alimenta el contorno completo
        # ANTES/DESPUÉS del croquis del informe.
        full_geoms = {'antes': {}, 'desp': {}}

        def process(layer, tag, store):
            if not layer: return
            for f in layer.getFeatures():
                pid = self._get_id_from_layer(f, tag)
                if not pid: continue
                geom = f.geometry()
                if not geom or geom.isNull(): continue
                full_geoms[tag].setdefault(pid, []).append(QgsGeometry(geom))
                
                # Perímetro Exterior (Importante para el reporte)
                perim_line = self._get_exterior_boundary_geom(geom)
                perim_val = perim_line.length() if perim_line else 0.0
                
                # Centroide para desplazamiento
                centroid = geom.centroid()
                
                store[pid] = {
                    'islands': self.islas_service.analyze_geometry(geom),
                    'convexity': geom.area() / geom.convexHull().area() if geom.convexHull().area() > 0.001 else 1.0,
                    'boundary': perim_line,
                    'perim': perim_val,
                    'parts': len(geom.asMultiPolygon()) if geom.isMultipart() else 1,
                    'centroid': centroid,
                    'geom': QgsGeometry(geom)
                }

                # Agrupación de recintos 'comunes' por CATEGORÍA (REC dentro de
                # los rangos parametrizados VIALES/AGUA/EDIFICACIONES/EXCLUIDO):
                # se acumula la geometría de TODOS los recintos (cualquier REC
                # y SUBREC) que caigan en una misma categoría, para que la
                # estabilidad de linde se evalúe a nivel de esa categoría como
                # un conjunto único. Un VIAL nunca se mezcla con un CURSO DE
                # AGUA ni con otra categoría: solo se agrupan dentro de su
                # propio rango.
                rec_val = self._rec_from_base_id(self._strip_subrec(pid))
                category = self._common_category(rec_val)
                if category:
                    common_pid_to_cat[tag][pid] = category
                    common_geoms[tag].setdefault(category, []).append(geom)

        process(self.layer_antes, 'antes', data_a)
        process(self.layer_despues, 'desp', data_d)

        # Geometría completa (disuelta) de cada finca, directamente desde
        # ANTES-ok/DESPUES-ok, indexada por su xID. Es la fuente única para
        # el contorno ANTES/DESPUÉS del croquis del informe.
        full_geom_a = {pid: self._dissolve_geoms(g) for pid, g in full_geoms['antes'].items()}
        full_geom_d = {pid: self._dissolve_geoms(g) for pid, g in full_geoms['desp'].items()}

        # Se expone para el croquis del informe: contorno de TODOS los
        # recintos DESPUÉS (no solo el de la finca actual), para poder
        # dibujarlos en gris tenue como referencia del entorno.
        self.metrics['context_geoms_despues'] = full_geom_d

        # Fronteras exteriores fusionadas por categoría (VIALES, AGUA, etc.)
        common_boundary = {'antes': {}, 'desp': {}}
        for tag in ('antes', 'desp'):
            for category, geoms in common_geoms[tag].items():
                try:
                    merged = QgsGeometry.unaryUnion(geoms)
                except Exception:
                    merged = None
                if merged and not merged.isNull():
                    common_boundary[tag][category] = self._get_exterior_boundary_geom(merged)

        matched_a = matched_d = missing = 0
        for detail in self.metrics['parcel_details']:
            pid = detail['id']
            # Islas
            detail['islands'] = self.islas_service.calculate_deltas(data_a.get(pid, {}).get('islands'), data_d.get(pid, {}).get('islands'))
            # Geometrías completas (para el croquis ANTES/DESPUÉS del informe).
            # Se toman SIEMPRE directamente de ANTES-ok/DESPUES-ok por xID; el
            # fallback a fragmentos de UNION disueltos (calculado en
            # _calculate_geometric_deltas) solo se mantiene por si el xID no
            # aparece tal cual en la capa de origen.
            refined_geom_a = full_geom_a.get(pid)
            refined_geom_d = full_geom_d.get(pid)
            if refined_geom_a is not None:
                detail['geom_a'] = refined_geom_a
                matched_a += 1
            if refined_geom_d is not None:
                detail['geom_d'] = refined_geom_d
                matched_d += 1
            if refined_geom_a is None and refined_geom_d is None and detail.get('state') == 'PERSISTENTE':
                missing += 1
                self.add_log(f"<font color='orange'>AVISO: no se encontró geometría en ANTES-ok/DESPUES-ok para xID '{pid}' (se usará el fallback de fragmentos UNION si existe).</font>")

            # Perímetros
            detail['perim_a'] = data_a.get(pid, {}).get('perim', 0.0)
            detail['perim_d'] = data_d.get(pid, {}).get('perim', 0.0)
            detail['delta_perim'] = detail['perim_d'] - detail['perim_a']
            # Convexidad
            detail['convex_a'] = data_a.get(pid, {}).get('convexity', 1.0)
            detail['convex_d'] = data_d.get(pid, {}).get('convexity', 1.0)
            # Partes
            detail['parts_a'] = data_a.get(pid, {}).get('parts', 1)
            detail['parts_d'] = data_d.get(pid, {}).get('parts', 1)

            # Estabilidad de Linde: para recintos 'comunes', todos los que
            # pertenecen a la misma categoría (p.ej. todos los VIALES) se
            # tratan como uno solo dentro de esa categoría, porque la
            # variación ANTES/DESPUÉS puede deberse a cómo se reparte
            # internamente esa categoría (distinto REC/SUBREC), no a un
            # cambio real de lindero exterior. Las categorías nunca se
            # mezclan entre sí.
            cat_a = common_pid_to_cat['antes'].get(pid)
            cat_d = common_pid_to_cat['desp'].get(pid)
            category = cat_a or cat_d
            if category and category in common_boundary['antes'] and category in common_boundary['desp']:
                detail['stability_pct'] = self._calculate_boundary_stability(
                    common_boundary['antes'][category], common_boundary['desp'][category]
                )
            else:
                detail['stability_pct'] = self._calculate_boundary_stability(data_a.get(pid, {}).get('boundary'), data_d.get(pid, {}).get('boundary'))
            
            # Desplazamiento
            c_a = data_a.get(pid, {}).get('centroid')
            c_d = data_d.get(pid, {}).get('centroid')
            if c_a and c_d and not c_a.isNull() and not c_d.isNull():
                detail['displacement'] = c_a.distance(c_d)
                detail['displacement_dir'] = self._get_cardinal_direction(c_a, c_d)
            else:
                detail['displacement'] = 0.0
                detail['displacement_dir'] = "-"

        self.add_log(f"Croquis: geometría ANTES enlazada en {matched_a}/{len(full_geom_a)} fincas de origen, "
                      f"DESPUÉS en {matched_d}/{len(full_geom_d)}." +
                      (f" {missing} fincas persistentes sin cruce directo." if missing else ""))

        if missing:
            # Muestra de IDs reales (con repr() para que se vean comillas,
            # espacios, mayúsculas o decimales ocultos) para comparar a ojo
            # el formato de detail['id'] (procedente de UNION) contra el de
            # las claves disponibles en ANTES-ok/DESPUES-ok. Si difieren en
            # algo (p.ej. '12/3/45' vs '12/3/45.0', o mayúsculas), aquí se ve.
            unmatched_ids = [
                d['id'] for d in self.metrics['parcel_details']
                if d.get('state') == 'PERSISTENTE' and full_geom_a.get(d['id']) is None and full_geom_d.get(d['id']) is None
            ][:5]
            sample_a = list(full_geom_a.keys())[:5]
            sample_d = list(full_geom_d.keys())[:5]
            self.add_log(
                "<font color='orange'>CROQUIS - Diagnóstico de formato de xID:<br>"
                f"&nbsp;&nbsp;IDs de UNION sin cruzar (detail['id']): {[repr(x) for x in unmatched_ids]}<br>"
                f"&nbsp;&nbsp;Ejemplo de xID disponibles en ANTES-ok: {[repr(x) for x in sample_a]}<br>"
                f"&nbsp;&nbsp;Ejemplo de xID disponibles en DESPUES-ok: {[repr(x) for x in sample_d]}<br>"
                "Compare el formato exacto (mayúsculas, decimales tipo '.0', espacios, separadores) entre ambas líneas.</font>"
            )

    def _calculate_neighbor_counts(self):
        TOL = 0.05  # tolerancia métrica: detecta contacto real y micro-gaps/solapamientos catastrales
        def count_layer(layer, tag):
            if not layer: return {}
            idx = QgsSpatialIndex(layer.getFeatures())
            res = {}
            for f in layer.getFeatures():
                pid = self._get_id_from_layer(f, tag); geom = f.geometry()
                if not pid or not geom: continue
                if pid in res: continue  # evita doble-conteo si hay features duplicadas por pid
                geom_buf = geom.buffer(TOL, 5)
                neighbors = set()
                for nid in idx.intersects(geom_buf.boundingBox()):
                    if nid == f.id(): continue
                    nf = layer.getFeature(nid)
                    n_id = self._get_id_from_layer(nf, tag)
                    if not n_id or n_id == pid: continue  # excluye la propia parcela
                    ng = nf.geometry()
                    if not ng: continue
                    # Contacto real: el buffer mínimo de la parcela intersecta al vecino,
                    # pero la propia geometría sin buffer NO lo engloba completamente
                    # (descarta solapamientos grandes, que son errores topológicos, no linderos)
                    if geom_buf.intersects(ng) and not geom.contains(ng.centroid()):
                        neighbors.add(n_id)
                res[pid] = len(neighbors)
            return res
        c_a = count_layer(self.layer_antes, 'antes'); c_d = count_layer(self.layer_despues, 'desp')
        for d in self.metrics['parcel_details']:
            d['neighbors_a'] = c_a.get(d['id'], 0); d['neighbors_d'] = c_d.get(d['id'], 0)

    def _calculate_boundary_stability(self, g_a, g_d):
        if not g_a or not g_d: return 100.0 # Por defecto estable si no hay datos para comparar
        try:
            inter = g_a.intersection(g_d.buffer(0.05, 5))
            return (inter.length() / g_a.length() * 100.0) if g_a.length() > 0.001 else 100.0
        except: return 0.0

    def _get_exterior_boundary_geom(self, geom):
        if not geom: return None
        lines = []
        if geom.isMultipart():
            for p in geom.asMultiPolygon(): 
                if p: lines.append(QgsGeometry.fromPolylineXY(p[0]))
        else:
            p = geom.asPolygon()
            if p: lines.append(QgsGeometry.fromPolylineXY(p[0]))
        return QgsGeometry.collectGeometry(lines) if lines else None

    def _get_cardinal_direction(self, c_a, c_d):
        p_a = c_a.asPoint(); p_d = c_d.asPoint()
        dx = p_d.x() - p_a.x(); dy = p_d.y() - p_a.y()
        if abs(dx) < 0.05 and abs(dy) < 0.05: return "-"
        deg = (math.degrees(math.atan2(dy, dx)) + 360) % 360
        arrows = ["→", "↗", "↑", "↖", "←", "↙", "↓", "↘"]
        texts = ["E", "NE", "N", "NO", "O", "SO", "S", "SE"]
        idx = int((deg + 22.5) / 45) % 8
        return texts[idx] # Retornamos la sigla, ReportService pondrá la flecha.

    def _build_unified_id(self, pol, mas, smas, rec, srec):
        def clean(v):
            if v is None or str(v).upper() == 'NULL': return None
            s = str(v).strip()
            if s.endswith('.0'): s = s[:-2]
            return s
        p = clean(pol) or "0"; m = clean(mas); r = clean(rec)
        if not m or not r: return None
        fid = f"{p}/{m}"; sm = clean(smas)
        if sm and sm != "0": fid += f"-{sm}"
        fid += f"/{r}"; sr = clean(srec)
        if sr and sr != "0": fid += f"-{sr}"
        return fid

    def _get_id_from_layer(self, feature, layer_type='antes'):
        idx_xid = self._idx_ci(feature.fields(), "xID")
        if idx_xid != -1 and feature[idx_xid] and str(feature[idx_xid]) != 'NULL':
            return str(feature[idx_xid])
        m = self.settings.get('mapping', {}).get(layer_type, {})
        def g(k):
            idx = self._idx_ci(feature.fields(), m.get(k, ""))
            return feature[idx] if idx != -1 else None
        return self._build_unified_id(g('POL'), g('MASA'), g('SUBMASA'), g('REC'), g('SUBREC'))

    def _get_id(self, feature, suffix=""):
        f_xid = f"xID{suffix}"
        idx = self._idx_ci(self.union_layer.fields(), f_xid)
        if idx != -1 and feature[idx] and str(feature[idx]) != 'NULL':
            return str(feature[idx])
        lt = 'antes' if suffix == "" else 'desp'
        m = self.settings.get('mapping', {}).get(lt, {})
        def g(k):
            fn = m.get(k, "")
            if not fn: return None
            idx = self._idx_ci(self.union_layer.fields(), f"{fn}{suffix}")
            return feature[idx] if idx != -1 else None
        return self._build_unified_id(g('POL'), g('MASA'), g('SUBMASA'), g('REC'), g('SUBREC'))
