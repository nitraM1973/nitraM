from qgis.core import QgsProject, QgsGeometry, QgsSpatialIndex
import math
import re
from .islas_service import IslandsService

class MetricsCalculator:
    def __init__(self, union_layer, layer_antes, layer_despues, log_callback=None, settings=None):
        self.union_layer = union_layer
        self.layer_antes = layer_antes
        self.layer_despues = layer_despues
        self.log = log_callback
        self.settings = settings if settings else {}
        self.islas_service = IslandsService(log_callback)
        
        self.metrics = {
            'transition_matrix': [],
            'global_stats': {},
            'parcel_details': [],
            'facades': {} 
        }
        
        # Estandarización de claves de infraestructura (Coherente con TabMapping y ReportService)
        self.infra_keys = ['VIALES', 'CURSOS AGUA', 'EDIFICACIONES', 'EXCLUIDO']
        
        # Recuperar rangos de configuración o usar defaults (Mapeo a infra_keys)
        self.special_ranges = self.settings.get('special_ranges', {
            'VIALES': range(9000, 9999), 
            'CURSOS AGUA': range(8000, 8999),
            'EDIFICACIONES': range(10000, 20000)
        })

    def add_log(self, msg):
        if self.log:
            self.log(msg)

    def calculate_all(self):
        """Ejecuta todos los cálculos métricos respetando el orden de dependencia."""
        self.add_log("Iniciando motor de cálculo de métricas avanzadas (Senior 20+ RESTORED)...")
        
        # 1. Generar matriz de transición y detalles base
        self._calculate_matrix() 
        self._calculate_geometric_deltas() # Aquí se crean los objetos detail en parcel_details
        
        # 2. Cálculos espaciales avanzados
        if self.layer_antes and self.layer_despues:
            self._calculate_facades()
            self._calculate_extra_metrics() # Islas, Convexidad, Estabilidad, Perímetros
            self._calculate_neighbor_counts()
            self._calculate_dynamics()
            
        # 3. Vincular flujos
        self._link_flows()
            
        return self.metrics

    def _calculate_dynamics(self):
        self.add_log("Sincronizando métricas de dinámica...")
        pass

    def _link_flows(self):
        details_map = {d['id']: d for d in self.metrics['parcel_details']}
        for d in details_map.values():
            d['inputs'] = []; d['outputs'] = [] 
            
        for flow in self.metrics['transition_matrix']:
            src_id = flow['source']; tgt_id = flow['target']
            if str(src_id).strip() == str(tgt_id).strip(): continue
            if src_id in details_map: details_map[src_id]['outputs'].append(flow)
            if tgt_id in details_map: details_map[tgt_id]['inputs'].append(flow)
                
        for d in details_map.values():
            d['inputs'].sort(key=lambda x: x['area'], reverse=True)
            d['outputs'].sort(key=lambda x: x['area'], reverse=True)

    def _is_special(self, feature, field_name_override=None):
        """Determina si un feature es especial basándose en tipo o rango de REC."""
        idx_tipo = feature.fields().indexFromName("TIPO")
        if idx_tipo != -1:
            val = feature[idx_tipo]
            if val and str(val) != 'NULL' and str(val).upper() != 'PARCELA':
                t = str(val).upper()
                # Normalización de etiquetas para que coincidan con infra_keys
                if 'VIAL' in t: return 'VIALES'
                if 'AGUA' in t: return 'CURSOS AGUA'
                if 'EDIF' in t: return 'EDIFICACIONES'
                if 'EXCL' in t: return 'EXCLUIDO'
                return t

        idx_rec = -1
        if field_name_override:
            idx = feature.fields().indexFromName(field_name_override)
            if idx != -1: idx_rec = idx
            
        if idx_rec == -1:
            for c in ["REC", "FINCA", "PARCELA", "ID_REC"]:
                idx = feature.fields().indexFromName(c)
                if idx != -1: idx_rec = idx; break
        
        if idx_rec != -1:
            try:
                val_raw = feature[idx_rec]
                if val_raw is not None:
                    rec_val = int(float(str(val_raw)))
                    for label, r in self.special_ranges.items():
                        if rec_val in r: return label
            except: pass
        return None

    def _calculate_matrix(self):
        matrix = {} 
        idx_area = self.union_layer.fields().indexFromName("AREA_FRAG")
        if idx_area == -1: return
        idx_prop_a = self.union_layer.fields().indexFromName("PROP")
        idx_prop_d = self.union_layer.fields().indexFromName("PROP_2")

        for f in self.union_layer.getFeatures():
            id_a = self._get_id(f, ""); id_d = self._get_id(f, "_2")
            if not id_a and not id_d: continue
            key = (id_a, id_d); area = f[idx_area]
            prop_a = str(f[idx_prop_a]) if idx_prop_a != -1 else "DESCONOCIDO"
            prop_d = str(f[idx_prop_d]) if idx_prop_d != -1 else "DESCONOCIDO"

            if key not in matrix:
                matrix[key] = {
                    'source': id_a if id_a else "ALTA (NUEVO)", 'target': id_d if id_d else "BAJA (ELIMINADO)",
                    'prop_source': prop_a if id_a else "-", 'prop_target': prop_d if id_d else "-",
                    'area': 0.0, 'type': self._determine_flow_type(id_a, id_d, prop_a, prop_d)
                }
            matrix[key]['area'] += area
        self.metrics['transition_matrix'] = sorted(matrix.values(), key=lambda x: x['area'], reverse=True)

    def _determine_flow_type(self, id_a, id_d, prop_a, prop_d):
        if not id_a: return "ALTA"
        if not id_d: return "BAJA"
        if id_a == id_d: return "ESTABLE" if prop_a == prop_d else "CAMBIO_TITULAR"
        return "SEGREGACION_AGREGACION"

    def _calculate_geometric_deltas(self):
        """Calcula deltas geométricos agregando fragmentos del Union."""
        self.add_log("Calculando Deltas Geométricos (Área, Gravelius, Propietarios)...")
        parcels_a = {}; parcels_d = {}

        idx_area = self.union_layer.fields().indexFromName("AREA_FRAG")
        idx_rings_a = self.union_layer.fields().indexFromName("N_RINGS")
        idx_rings_d = self.union_layer.fields().indexFromName("N_RINGS_2")
        idx_grav_a = self.union_layer.fields().indexFromName("K_GRAV")
        idx_grav_d = self.union_layer.fields().indexFromName("K_GRAV_2")
        idx_tipo_a = self.union_layer.fields().indexFromName("TIPO")
        idx_tipo_d = self.union_layer.fields().indexFromName("TIPO_2")
        idx_prop_a = self.union_layer.fields().indexFromName("PROP")
        idx_prop_d = self.union_layer.fields().indexFromName("PROP_2")

        for f in self.union_layer.getFeatures():
            id_a = self._get_id(f, ""); id_d = self._get_id(f, "_2")
            area = f[idx_area] if idx_area != -1 else 0.0
            type_a = str(f[idx_tipo_a]) if idx_tipo_a != -1 else "PARCELA"
            type_d = str(f[idx_tipo_d]) if idx_tipo_d != -1 else "PARCELA"

            if id_a:
                if id_a not in parcels_a:
                    parcels_a[id_a] = {
                        'area': 0, 'rings': f[idx_rings_a] if idx_rings_a != -1 else 0,
                        'grav': f[idx_grav_a] if idx_grav_a != -1 else 0,
                        'type': type_a.strip().upper(), 'prop': str(f[idx_prop_a]) if idx_prop_a != -1 else "DESCONOCIDO",
                        'geom': None
                    }
                parcels_a[id_a]['area'] += area
                if not parcels_a[id_a]['geom']: parcels_a[id_a]['geom'] = f.geometry()

            if id_d:
                if id_d not in parcels_d:
                    parcels_d[id_d] = {
                        'area': 0, 'rings': f[idx_rings_d] if idx_rings_d != -1 else 0,
                        'grav': f[idx_grav_d] if idx_grav_d != -1 else 0,
                        'type': type_d.strip().upper(), 'prop': str(f[idx_prop_d]) if idx_prop_d != -1 else "DESCONOCIDO",
                        'geom': None
                    }
                parcels_d[id_d]['area'] += area
                if not parcels_d[id_d]['geom']: parcels_d[id_d]['geom'] = f.geometry()

        all_ids = set(parcels_a.keys()) | set(parcels_d.keys())
        details = []
        study_ids = self.settings.get('study_ids')

        for pid in all_ids:
            data_a = parcels_a.get(pid); data_d = parcels_d.get(pid)
            t_a = data_a['type'] if data_a else ""; t_d = data_d['type'] if data_d else ""
            if t_a != "PARCELA" and t_d != "PARCELA": continue
            if study_ids is not None and str(pid) not in study_ids: continue
            
            info = {'id': pid}
            info['prop_a'] = data_a['prop'] if data_a else 'N/A'
            info['prop_d'] = data_d['prop'] if data_d else 'N/A'
            
            if data_a and data_d:
                info['state'] = 'PERSISTENTE'
                info['delta_area'] = data_d['area'] - data_a['area']
                info['area_final'] = data_d['area']
                info['grav_a'] = data_a['grav']; info['grav_d'] = data_d['grav']
                info['delta_grav'] = info['grav_d'] - info['grav_a']
                info['rings_a'] = data_a['rings']; info['rings_d'] = data_d['rings']
                info['delta_rings'] = info['rings_d'] - info['rings_a']
            elif data_a:
                info['state'] = 'BAJA'; info['area_final'] = 0; info['delta_area'] = -data_a['area']
                info['grav_a'] = data_a['grav']; info['grav_d'] = 0; info['delta_grav'] = -data_a['grav']
            elif data_d:
                info['state'] = 'ALTA'; info['area_final'] = data_d['area']; info['delta_area'] = data_d['area']
                info['grav_a'] = 0; info['grav_d'] = data_d['grav']; info['delta_grav'] = data_d['grav']

            details.append(info)
        self.metrics['parcel_details'] = sorted(details, key=lambda x: str(x['id']))

    def _calculate_facades(self):
        """Calcula longitudes de fachada (contacto) con infraestructuras estándar."""
        self.add_log("Analizando fachadas (Vinculación Senior 20+)...")
        results_antes = {}; results_desp = {}

        def process_layer(layer, tag, store):
            if not layer: return
            idx = QgsSpatialIndex(layer.getFeatures())
            feats = {f.id(): f for f in layer.getFeatures()}
            
            for f in layer.getFeatures():
                pid = self._get_id_from_layer(f, tag)
                if not pid or self._is_special(f): continue
                
                if pid not in store: store[pid] = {k:0.0 for k in self.infra_keys}
                
                geom = f.geometry()
                if not geom: continue
                perim_line = self._get_exterior_boundary_geom(geom)
                if not perim_line: continue
                
                for nid in idx.intersects(geom.boundingBox()):
                    if nid == f.id(): continue
                    nf = feats.get(nid)
                    ntype = self._is_special(nf)
                    if ntype and ntype in self.infra_keys:
                        infra_geom = nf.geometry()
                        if not infra_geom: continue
                        buffered_infra = infra_geom.buffer(0.01, 3) 
                        intersection = perim_line.intersection(buffered_infra)
                        if intersection and not intersection.isEmpty():
                            store[pid][ntype] += intersection.length()

        process_layer(self.layer_antes, 'antes', results_antes)
        process_layer(self.layer_despues, 'desp', results_desp)

        linked = 0
        for detail in self.metrics['parcel_details']:
            pid = detail['id']
            has_data = False
            for k in self.infra_keys:
                v_a = results_antes.get(pid, {}).get(k, 0.0)
                v_d = results_desp.get(pid, {}).get(k, 0.0)
                detail[f'facade_antes_{k}'] = v_a
                detail[f'facade_desp_{k}'] = v_d
                if v_a > 0 or v_d > 0: has_data = True
            if has_data: linked += 1
        
        self.add_log(f"Vinculación: {linked} parcelas tienen datos de fachada.")

    def _calculate_extra_metrics(self):
        """Calcula Islas, Convexidad, Estabilidad y Perímetros."""
        self.add_log("Calculando Métricas Avanzadas (Perímetros, Islas, Convexidad, Estabilidad)...")
        data_a = {}; data_d = {}

        def process(layer, tag, store):
            if not layer: return
            for f in layer.getFeatures():
                pid = self._get_id_from_layer(f, tag)
                if not pid: continue
                geom = f.geometry()
                if not geom or geom.isNull(): continue
                
                # Perímetro Exterior (Importante para el reporte)
                perim_line = self._get_exterior_boundary_geom(geom)
                perim_val = perim_line.length() if perim_line else 0.0
                
                # Centroide para desplazamiento
                centroid = geom.centroid()
                
                store[pid] = {
                    'islands': self.islas_service.analyze_geometry(geom),
                    'convexity': geom.area() / geom.convexHull().area() if geom.convexHull().area() > 0.001 else 1.0,
                    'boundary': perim_line,
                    'perim': perim_val,
                    'parts': len(geom.asMultiPolygon()) if geom.isMultipart() else 1,
                    'centroid': centroid
                }

        process(self.layer_antes, 'antes', data_a)
        process(self.layer_despues, 'desp', data_d)

        for detail in self.metrics['parcel_details']:
            pid = detail['id']
            # Islas
            detail['islands'] = self.islas_service.calculate_deltas(data_a.get(pid, {}).get('islands'), data_d.get(pid, {}).get('islands'))
            # Perímetros
            detail['perim_a'] = data_a.get(pid, {}).get('perim', 0.0)
            detail['perim_d'] = data_d.get(pid, {}).get('perim', 0.0)
            detail['delta_perim'] = detail['perim_d'] - detail['perim_a']
            # Convexidad
            detail['convex_a'] = data_a.get(pid, {}).get('convexity', 1.0)
            detail['convex_d'] = data_d.get(pid, {}).get('convexity', 1.0)
            # Partes
            detail['parts_a'] = data_a.get(pid, {}).get('parts', 1)
            detail['parts_d'] = data_d.get(pid, {}).get('parts', 1)
            # Estabilidad de Linden
            detail['stability_pct'] = self._calculate_boundary_stability(data_a.get(pid, {}).get('boundary'), data_d.get(pid, {}).get('boundary'))
            
            # Desplazamiento
            c_a = data_a.get(pid, {}).get('centroid')
            c_d = data_d.get(pid, {}).get('centroid')
            if c_a and c_d and not c_a.isNull() and not c_d.isNull():
                detail['displacement'] = c_a.distance(c_d)
                detail['displacement_dir'] = self._get_cardinal_direction(c_a, c_d)
            else:
                detail['displacement'] = 0.0
                detail['displacement_dir'] = "-"

    def _calculate_neighbor_counts(self):
        def count_layer(layer, tag):
            if not layer: return {}
            idx = QgsSpatialIndex(layer.getFeatures())
            res = {}
            for f in layer.getFeatures():
                pid = self._get_id_from_layer(f, tag); geom = f.geometry()
                if not pid or not geom: continue
                neighbors = set()
                for nid in idx.intersects(geom.boundingBox()):
                    if nid == f.id(): continue
                    nf = layer.getFeature(nid)
                    if geom.touches(nf.geometry()):
                         n_id = self._get_id_from_layer(nf, tag)
                         if n_id: neighbors.add(n_id)
                res[pid] = res.get(pid, 0) + len(neighbors)
            return res
        c_a = count_layer(self.layer_antes, 'antes'); c_d = count_layer(self.layer_despues, 'desp')
        for d in self.metrics['parcel_details']:
            d['neighbors_a'] = c_a.get(d['id'], 0); d['neighbors_d'] = c_d.get(d['id'], 0)

    def _calculate_boundary_stability(self, g_a, g_d):
        if not g_a or not g_d: return 100.0 # Por defecto estable si no hay datos para comparar
        try:
            inter = g_a.intersection(g_d.buffer(0.05, 5))
            return (inter.length() / g_a.length() * 100.0) if g_a.length() > 0.001 else 100.0
        except: return 0.0

    def _get_exterior_boundary_geom(self, geom):
        if not geom: return None
        lines = []
        if geom.isMultipart():
            for p in geom.asMultiPolygon(): 
                if p: lines.append(QgsGeometry.fromPolylineXY(p[0]))
        else:
            p = geom.asPolygon()
            if p: lines.append(QgsGeometry.fromPolylineXY(p[0]))
        return QgsGeometry.collectGeometry(lines) if lines else None

    def _get_cardinal_direction(self, c_a, c_d):
        p_a = c_a.asPoint(); p_d = c_d.asPoint()
        dx = p_d.x() - p_a.x(); dy = p_d.y() - p_a.y()
        if abs(dx) < 0.05 and abs(dy) < 0.05: return "-"
        deg = (math.degrees(math.atan2(dy, dx)) + 360) % 360
        arrows = ["→", "↗", "↑", "↖", "←", "↙", "↓", "↘"]
        texts = ["E", "NE", "N", "NO", "O", "SO", "S", "SE"]
        idx = int((deg + 22.5) / 45) % 8
        return texts[idx] # Retornamos la sigla, ReportService pondrá la flecha.

    def _build_unified_id(self, pol, mas, smas, rec, srec):
        def clean(v):
            if v is None or str(v).upper() == 'NULL': return None
            s = str(v).strip()
            if s.endswith('.0'): s = s[:-2]
            return s
        p = clean(pol) or "0"; m = clean(mas); r = clean(rec)
        if not m or not r: return None
        fid = f"{p}/{m}"; sm = clean(smas)
        if sm and sm != "0": fid += f"-{sm}"
        fid += f"/{r}"; sr = clean(srec)
        if sr and sr != "0": fid += f"-{sr}"
        return fid

    def _get_id_from_layer(self, feature, layer_type='antes'):
        idx_xid = feature.fields().indexFromName("xID")
        if idx_xid != -1 and feature[idx_xid] and str(feature[idx_xid]) != 'NULL':
            return str(feature[idx_xid])
        m = self.settings.get('mapping', {}).get(layer_type, {})
        def g(k):
            idx = feature.fields().indexFromName(m.get(k, ""))
            return feature[idx] if idx != -1 else None
        return self._build_unified_id(g('POL'), g('MASA'), g('SUBMASA'), g('REC'), g('SUBREC'))

    def _get_id(self, feature, suffix=""):
        f_xid = f"xID{suffix}"
        idx = self.union_layer.fields().indexFromName(f_xid)
        if idx != -1 and feature[idx] and str(feature[idx]) != 'NULL':
            return str(feature[idx])
        lt = 'antes' if suffix == "" else 'desp'
        m = self.settings.get('mapping', {}).get(lt, {})
        def g(k):
            fn = m.get(k, "")
            if not fn: return None
            idx = self.union_layer.fields().indexFromName(f"{fn}{suffix}")
            return feature[idx] if idx != -1 else None
        return self._build_unified_id(g('POL'), g('MASA'), g('SUBMASA'), g('REC'), g('SUBREC'))
