from qgis.core import QgsProject, QgsGeometry
import math

class MetricsCalculator:
    def __init__(self, union_layer, layer_antes, layer_despues, log_callback=None, settings=None):
        self.union_layer = union_layer
        self.layer_antes = layer_antes
        self.layer_despues = layer_despues
        self.log = log_callback
        self.settings = settings if settings else {}
        self.log(f"DEBUG MAPPING COMPLETO: {self.settings.get('mapping')}")
        
        self.metrics = {
            'transition_matrix': [],
            'global_stats': {},
            'parcel_details': {},
            'facades': {} 
        }
        
        # Recuperar rangos de configuración o usar defaults
        if self.settings.get('special_ranges'):
            self.special_ranges = self.settings['special_ranges']
        else:
            self.special_ranges = {
                'VIAL': range(9000, 9999), 
                'AGUA': range(8000, 8999),
                'EDIF': range(10000, 20000)
            }

    def add_log(self, msg):
        if self.log:
            self.log(msg)

    def calculate_all(self):
        """
        Ejecuta todos los cálculos métricos.
        """
        self.add_log("Calculando matriz de transición y métricas avanzadas...")
        self._calculate_matrix()
        self._calculate_geometric_deltas()
        
        if self.layer_antes and self.layer_despues:
            self._calculate_facades()
            self._calculate_extra_metrics()
            
        self._link_flows()
            
        return self.metrics

    def _link_flows(self):
        """
        Enriquece parcel_details con los flujos de entrada y salida (Inputs/Outputs).
        """
        details_map = {d['id']: d for d in self.metrics['parcel_details']}
        
        for d in details_map.values():
            d['inputs'] = []  
            d['outputs'] = [] 
            
        for flow in self.metrics['transition_matrix']:
            src_id = flow['source']
            tgt_id = flow['target']
            
            # FILTRAR AUTOFAGIA (Self-loops) estricto
            if str(src_id).strip() == str(tgt_id).strip():
                continue

            if src_id in details_map:
                details_map[src_id]['outputs'].append(flow)
                
            if tgt_id in details_map:
                details_map[tgt_id]['inputs'].append(flow)
                
        for d in details_map.values():
            d['inputs'].sort(key=lambda x: x['area'], reverse=True)
            d['outputs'].sort(key=lambda x: x['area'], reverse=True)

    def _is_special(self, feature, field_name_override=None):
        """Determina si un feature es especial. Prioriza campo 'TIPO' si existe."""
        
        # 1. Chequeo directo de campo "TIPO" (generado por AnalysisEngine)
        idx_tipo = feature.fields().indexFromName("TIPO")
        if idx_tipo != -1:
            val = feature[idx_tipo]
            if val and str(val) != 'NULL' and str(val) != 'PARCELA':
                return str(val)

        # 2. Fallback: Chequeo por rango (Legacy / Robustez)
        idx_rec = -1
        if field_name_override:
            idx = feature.fields().indexFromName(field_name_override)
            if idx != -1: idx_rec = idx
            
        if idx_rec == -1:
            candidates = ["REC", "FINCA", "PARCELA", "RECINTO", "RefPac", "ID_REC"]
            for c in candidates:
                idx = feature.fields().indexFromName(c)
                if idx != -1:
                    idx_rec = idx
                    break
        
        if idx_rec != -1:
            try:
                # Conversión robusta: str -> float -> int para manejar "9000.0"
                val_raw = feature[idx_rec]
                if val_raw is not None:
                    rec_val = int(float(str(val_raw)))
                    for label, r in self.special_ranges.items():
                        if rec_val in r:
                            return label
            except:
                pass
                
        return None

    def _calculate_facades(self):
        """
        Calcula longitudes de fachada (contactos) con parcelas especiales.
        Nota: Esto puede ser lento para capas muy grandes (O(n^2) si no se usa índice).
        """
        self.add_log("Analizando fachadas y linderos con tipologías especiales...")
        self.add_log(f"DEBUG RANGES UTILIZADOS: {list(self.special_ranges.keys())}")
        
        # Obtener mapeo específico por capa
        mapping = self.settings.get('mapping', {})
        rec_field_a = mapping.get('antes', {}).get('REC')
        rec_field_d = mapping.get('desp', {}).get('REC')
        
        def process_layer(layer, rec_field, layer_tag):
            if not rec_field:
                return {}
                
            from qgis.core import QgsSpatialIndex
            index = QgsSpatialIndex(layer.getFeatures())
            
            # Cache de especiales y contadores
            specials = {} # id: type
            stats_counts = {} # type: count
            
            for f in layer.getFeatures():
                stype = self._is_special(f, rec_field)
                if stype:
                    specials[f.id()] = stype
                    stats_counts[stype] = stats_counts.get(stype, 0) + 1
            
            # LOG RESUMEN (CRITICO PARA USUARIO)
            summary_parts = [f"{k}: {v}" for k, v in stats_counts.items()]
            self.add_log(f"DEBUG ({layer_tag}): Detectados especiales -> {', '.join(summary_parts) if summary_parts else 'Ninguno'}")
            
            results = {} # id_parcela: { 'VIAL': 0.0, ... }
            
            for f in layer.getFeatures():
                # Si es especial, saltar (no calculamos fachadas de vias a vias... bueno, depende, pero por ahora no)
                if f.id() in specials: continue
                
                pid = self._get_id_from_layer(f) 
                if not pid: continue
                
                if pid not in results: results[pid] = {}
                
                geom = f.geometry()
                neighbor_ids = index.intersects(geom.boundingBox())
                
                for nid in neighbor_ids:
                    if nid == f.id(): continue
                    if nid in specials:
                        stype = specials[nid]
                        neighbor_feat = layer.getFeature(nid)
                        if neighbor_feat.geometry().touches(geom):
                            intersection = geom.intersection(neighbor_feat.geometry())
                            length = intersection.length()
                            if length > 0.05: # Filtro de ruido mínimo
                                results[pid][stype] = results[pid].get(stype, 0.0) + length
            return results

        facades_a = process_layer(self.layer_antes, rec_field_a, "ANTES")
        facades_d = process_layer(self.layer_despues, rec_field_d, "DESPUÉS")
        
        for item in self.metrics['parcel_details']:
            pid = item['id']
            if pid in facades_a:
                for k, v in facades_a[pid].items():
                    item[f'facade_antes_{k}'] = v
            if pid in facades_d:
                for k, v in facades_d[pid].items():
                    item[f'facade_desp_{k}'] = v

    def _get_id_from_layer(self, feature, layer_type='antes'):
        """Reconstruye ID usando el mapeo: POLIGONO/MASA-SBUMASA/FINCA-SUBFINCA."""
        
        mapping = self.settings.get('mapping', {}).get(layer_type, {})
        
        def get_val(key):
            fname = mapping.get(key)
            if fname:
                idx = feature.fields().indexFromName(fname)
                if idx != -1:
                    v = feature[idx]
                    if v is not None and str(v) != 'NULL': return v
            return None

        pol = get_val('POL')
        mas = get_val('MASA')
        smas = get_val('SUBMASA')
        rec = get_val('REC')
        srec = get_val('SUBREC') # Usa clave SUBREC del mapeo
        
        if pol is None or mas is None or rec is None:
            return None
            
        part_masa = str(mas)
        if smas is not None and str(smas) != 'NULL': 
            part_masa += f"-{smas}"
         
        part_rec = str(rec)
        if srec is not None and str(srec) != 'NULL': 
            part_rec += f"-{srec}"
         
        return f"{pol}/{part_masa}/{part_rec}"

    def _get_id(self, feature, suffix=""):
        """
        Recupera el ID desde el campo xID ya calculado en el Union.
        Si no existe (legacy), intenta reconstruirlo.
        """
        # 1. Intentar leer campo xID directo (creado por ShpService)
        fname = f"xID{suffix}"
        idx = self.union_layer.fields().indexFromName(fname)
        if idx != -1:
            val = feature[idx]
            if val and str(val) != 'NULL':
                return str(val)

        # 2. Fallback: Reconstrucción (Legacy logic)
        layer_type = 'desp' if suffix == '_2' else 'antes'
        mapping = self.settings.get('mapping', {})
        map_this = mapping.get(layer_type, {})
        map_antes = mapping.get('antes', {})
        
        def get_val(key):
            fname = map_this.get(key)
            if not fname: return None
            
            candidates = [fname]
            if layer_type == 'desp':
                if fname == map_antes.get(key):
                    candidates = [fname + "_2", fname]
                else:
                    candidates = [fname, fname + "_2"]
            
            for c in candidates:
                idx = self.union_layer.fields().indexFromName(c)
                if idx != -1:
                    v = feature[idx]
                    if v is not None and str(v) != 'NULL': return v
            return None

        pol = get_val('POL')
        mas = get_val('MASA')
        smas = get_val('SUBMASA')
        rec = get_val('REC')
        srec = get_val('SUBREC')
        
        if pol is None or mas is None or rec is None:
             return None

        part_masa = str(mas)
        if smas is not None and str(smas) != 'NULL' and str(smas) != '0': 
            part_masa += f"-{smas}"
        
        part_rec = str(rec)
        if srec is not None and str(srec) != 'NULL' and str(srec) != '0': 
            part_rec += f"-{srec}"
        
        return f"{pol}/{part_masa}/{part_rec}"

    def _calculate_matrix(self):
        """
        Genera la matriz de flujo: Quien da a quien.
        """
        matrix = {} 
        
        idx_area = self.union_layer.fields().indexFromName("AREA_FRAG")
        if idx_area == -1: return

        idx_prop_a = self.union_layer.fields().indexFromName("PROP")
        idx_prop_d = self.union_layer.fields().indexFromName("PROP_2")
        
        # indices para filtrado por TIPO
        idx_tipo_a = self.union_layer.fields().indexFromName("TIPO")
        idx_tipo_d = self.union_layer.fields().indexFromName("TIPO_2")

        for f in self.union_layer.getFeatures():
            # Filtrar si AMBOS son especiales (infraestructura vs infraestructura)
            # Opcional: dependerá de si queremos ver flujo de viales. 
            # De momento, procesamos todo para la matriz y filtramos en el reporte si es necesario.
            
            id_a = self._get_id(f, "")
            id_d = self._get_id(f, "_2")
            
            if not id_a and not id_d: continue

            key = (id_a, id_d)
            area = f[idx_area]
            
            prop_a = f[idx_prop_a] if idx_prop_a != -1 else "DESCONOCIDO"
            prop_d = f[idx_prop_d] if idx_prop_d != -1 else "DESCONOCIDO"

            if key not in matrix:
                matrix[key] = {
                    'source': id_a if id_a else "ALTA (NUEVO)",
                    'target': id_d if id_d else "BAJA (ELIMINADO)",
                    'prop_source': prop_a if id_a else "-",
                    'prop_target': prop_d if id_d else "-",
                    'area': 0.0,
                    'type': self._determine_flow_type(id_a, id_d, prop_a, prop_d)
                }
            
            matrix[key]['area'] += area

        self.metrics['transition_matrix'] = sorted(
            matrix.values(), 
            key=lambda x: x['area'], 
            reverse=True
        )
        
        self.add_log(f"Matriz calculada: {len(self.metrics['transition_matrix'])} flujos detectados.")

    def _determine_flow_type(self, id_a, id_d, prop_a, prop_d):
        if not id_a: return "ALTA"
        if not id_d: return "BAJA"
        if id_a == id_d:
            return "ESTABLE" if prop_a == prop_d else "CAMBIO_TITULAR"
        return "SEGREGACION_AGREGACION"

    def _calculate_extra_metrics(self):
        """
        Calcula métricas adicionales para cada parcela:
        - Superficie de huecos/islas interiores (interior rings)
        """
        self.add_log("Calculando métricas de huecos/islas interiores...")
        
        # Diccionarios para métricas adicionales
        holes_antes = {}; holes_desp = {}
        perims_antes = {}; perims_desp = {}
        parts_antes = {}; parts_desp = {}

        # 2.1. Construir cláusula SQL para proteger infraestructuras (Necesaria para fachadas)
        ranges = self.settings.get('special_ranges', {})
        mapping = self.settings.get('mapping', {})
        
        def get_infra_expr(map_obj):
            f_rec = map_obj.get('REC')
            if not f_rec: return None
            all_vals = [str(v) for r in ranges.values() for v in r]
            if not all_vals: return None
            return f"\"{f_rec}\" IN ({','.join(all_vals)})"

        # Procesar capa ANTES
        if self.layer_antes:
            for feat in self.layer_antes.getFeatures():
                xid = self._get_id_from_layer(feat, 'antes')
                if not xid: continue
                
                geom = feat.geometry()
                if geom and not geom.isNull():
                    hole_area = 0.0
                    parts_count = 0
                    if geom.isMultipart():
                        multi = geom.asMultiPolygon()
                        parts_count = len(multi)
                        for part in multi:
                            for hole_ring in part[1:]:
                                hole_area += QgsGeometry.fromPolygonXY([hole_ring]).area()
                    else:
                        poly = geom.asPolygon()
                        parts_count = 1
                        if len(poly) > 1:
                            for hole_ring in poly[1:]:
                                hole_area += QgsGeometry.fromPolygonXY([hole_ring]).area()
                    
                    holes_antes[xid] = holes_antes.get(xid, 0.0) + hole_area
                    perims_antes[xid] = perims_antes.get(xid, 0.0) + geom.length()
                    parts_antes[xid] = parts_antes.get(xid, 0) + parts_count
        
        # Procesar capa DESPUES
        if self.layer_despues:
            for feat in self.layer_despues.getFeatures():
                xid = self._get_id_from_layer(feat, 'desp')
                if not xid: continue
                
                geom = feat.geometry()
                if geom and not geom.isNull():
                    hole_area = 0.0
                    parts_count = 0
                    if geom.isMultipart():
                        multi = geom.asMultiPolygon()
                        parts_count = len(multi)
                        for part in multi:
                            for hole_ring in part[1:]:
                                hole_area += QgsGeometry.fromPolygonXY([hole_ring]).area()
                    else:
                        poly = geom.asPolygon()
                        parts_count = 1
                        if len(poly) > 1:
                            for hole_ring in poly[1:]:
                                hole_area += QgsGeometry.fromPolygonXY([hole_ring]).area()
                    
                    holes_desp[xid] = holes_desp.get(xid, 0.0) + hole_area
                    perims_desp[xid] = perims_desp.get(xid, 0.0) + geom.length()
                    parts_desp[xid] = parts_desp.get(xid, 0) + parts_count
        
        # Agregar a parcel_details
        for detail in self.metrics['parcel_details']:
            pid = detail['id']
            detail['hole_area_a'] = holes_antes.get(pid, 0.0)
            detail['hole_area_d'] = holes_desp.get(pid, 0.0)
            detail['delta_hole_area'] = detail['hole_area_d'] - detail['hole_area_a']
            
            detail['perim_a'] = perims_antes.get(pid, 0.0)
            detail['perim_d'] = perims_desp.get(pid, 0.0)
            detail['delta_perim'] = detail['perim_d'] - detail['perim_a']
            
            detail['parts_a'] = parts_antes.get(pid, 1)
            detail['parts_d'] = parts_desp.get(pid, 1)
        
        self.add_log(f"Métricas avanzadas (huecos, perímetros, partes) calculadas para {len(self.metrics['parcel_details'])} parcelas.")

    def _calculate_facades(self):
        """
        Calcula longitudes de fachada (contacto) entre parcelas y elementos especiales.
        Solo considera el perímetro EXTERIOR (sin huecos interiores).
        """
        self.add_log("Calculando fachadas (contacto con infraestructuras)...")
        
        from qgis.core import QgsSpatialIndex
        
        # Tipos de infraestructura a analizar (Debe coincidir EXACTAMENTE con TabMapping)
        infra_types = ['VIALES', 'CURSOS AGUA', 'EDIFICACIONES', 'EXCLUIDO']
        
        # Diccionarios para almacenar longitudes de fachada por xID y tipo
        facades_antes = {}  # {xID: {tipo: longitud}}
        facades_desp = {}
        
        self.add_log(f"Iniciando análisis profundo de fachadas sobre {infra_types}")
        
        stats_debug = {t: 0 for t in infra_types}
        stats_debug['NOT_FOUND'] = 0
        stats_debug['PARCELA_NORMAL'] = 0
        
        # Auditoría de tipos presentes en las capas
        def audit_types(layer, name):
            types_found = {}
            for f in layer.getFeatures():
                t = str(f['TIPO']) if 'TIPO' in [field.name() for field in f.fields()] else 'SIN TIPO'
                types_found[t] = types_found.get(t, 0) + 1
            self.add_log(f"Auditoría TIPO en {name}: {types_found}")
        
        audit_types(self.layer_antes, "ANTES-OK")
        audit_types(self.layer_despues, "DESP-OK")
        
        def get_exterior_perimeter(geom):
            """Extrae el perímetro exterior total de un polígono o multipolígono (ignora huecos)"""
            if not geom or geom.isNull():
                return None
            
            perimeters = []
            if geom.isMultipart():
                # Para multipolígonos, cogemos el anillo exterior de cada parte
                for part in geom.asMultiPolygon():
                    if part:
                        # part[0] es siempre el anillo exterior
                        perimeters.append(QgsGeometry.fromPolylineXY(part[0]))
            else:
                # Para polígono simple
                poly = geom.asPolygon()
                if poly:
                    perimeters.append(QgsGeometry.fromPolylineXY(poly[0]))
            
            if not perimeters:
                return None
            
            # Unir todos los perímetros en una sola geometría (MultiLineString)
            if len(perimeters) == 1:
                return perimeters[0]
            else:
                final_geom = perimeters[0]
                for i in range(1, len(perimeters)):
                    final_geom = final_geom.combine(perimeters[i])
                return final_geom

        def calculate_contact_length(parcel_geom, infra_geom):
            """
            Calcula la longitud de colindancia física entre el perímetro exterior de la parcela
            y el recinto especial (infraestructura).
            """
            try:
                # 1. Obtener perímetro exterior de la parcela
                parcel_perim = get_exterior_perimeter(parcel_geom)
                if not parcel_perim:
                    return 0.0
                
                # 2. Intersección del perímetro con la infraestructura
                # Senior 20+ Tip: Las topologías CAD suelen tener huecos de micras. 
                # Usamos un pequeñísimo buffer de precisión para capturar el contacto real.
                infra_poly = infra_geom.buffer(0.005, 3) 
                
                intersection = parcel_perim.intersection(infra_poly)
                if intersection and not intersection.isEmpty():
                    return intersection.length()
                
                return 0.0
            except Exception as e:
                return 0.0
        
        def process_layer(layer, layer_type, facades_dict):
            """Procesa una capa para calcular fachadas"""
            if not layer:
                return
            
            # Crear índice espacial
            index = QgsSpatialIndex()
            features_by_id = {}
            
            # Indexar todas las features
            for feat in layer.getFeatures():
                index.addFeature(feat)
                features_by_id[feat.id()] = feat
            
            # Para cada parcela, buscar infraestructuras cercanas
            for feat in layer.getFeatures():
                xid = self._get_id_from_layer(feat, layer_type)
                if not xid:
                    continue
                
                # Verificar si es una parcela normal (no infraestructura)
                idx_tipo = feat.fields().indexFromName("TIPO")
                if idx_tipo != -1:
                    tipo_f = feat[idx_tipo]
                    if tipo_f in infra_types:
                        continue  # Saltar infraestructuras
                
                stats_debug['PARCELA_NORMAL'] += 1
                
                parcel_geom = feat.geometry()
                if not parcel_geom or parcel_geom.isNull():
                    continue
                
                # Inicializar diccionario para esta parcela
                if xid not in facades_dict:
                    facades_dict[xid] = {t: 0.0 for t in infra_types}
                
                # Buscar features cercanas usando índice espacial
                bbox = parcel_geom.boundingBox()
                nearby_ids = index.intersects(bbox)
                
                for nearby_id in nearby_ids:
                    if nearby_id == feat.id():
                        continue  # Saltar la misma feature
                    
                    nearby_feat = features_by_id.get(nearby_id)
                    if not nearby_feat:
                        continue
                    
                    # Verificar tipo de infraestructura
                    nearby_tipo = None
                    if idx_tipo != -1:
                        val_raw = nearby_feat[idx_tipo]
                        if val_raw and str(val_raw) != 'NULL':
                            nearby_tipo = str(val_raw).strip().upper()
                    
                    if not nearby_tipo:
                        stats_debug['NOT_FOUND'] += 1
                        continue

                    # Mapeo de sinónimos/alias para máxima robustez (Dato -> Tipo Informe)
                    infra_aliases = {
                        'VIAL': 'VIALES', 'VIALES': 'VIALES',
                        'AGUA': 'CURSOS AGUA', 'AGUAS': 'CURSOS AGUA', 'CURSOS AGUA': 'CURSOS AGUA',
                        'EDIF': 'EDIFICACIONES', 'EDIFICACION': 'EDIFICACIONES', 'EDIFICACIONES': 'EDIFICACIONES',
                        'EXCLUIDO': 'EXCLUIDO', 'EXCL': 'EXCLUIDO'
                    }
                    
                    found_match = infra_aliases.get(nearby_tipo)
                    
                    if not found_match or found_match not in infra_types:
                        continue  # Solo nos interesan infraestructuras definidas en infra_types
                    
                    stats_debug[found_match] += 1
                    
                    # Calcular longitud de contacto
                    nearby_geom = nearby_feat.geometry()
                    if nearby_geom and not nearby_geom.isNull():
                        # Senior 20+ Tip: Buffer de colindancia de 1cm para CAD ruidoso
                        contact_length = calculate_contact_length(parcel_geom, nearby_geom)
                        if contact_length > 0.05: # Umbral mínimo de 5cm para evitar ruidos de vértices
                            facades_dict[xid][found_match] += contact_length
                            if xid in ['1/10/50', '2/20/100']: # Ejemplo log específico si el usuario sospecha de estas
                                 self.add_log(f"  [DEBUG CONTACTO] ID:{xid} toca con {found_match} ({contact_length:.2f}m)")
        
            # Resumen final de la capa
            self.add_log(f"Resumen Fachadas {layer_type.upper()}: {stats_debug}")
            if stats_debug['PARCELA_NORMAL'] == 0:
                 self.add_log(f"  <font color='red'>ADVERTENCIA: No se han encontrado parcelas normales en capa {layer_type}</font>")
            if sum(stats_debug[t] for t in infra_types) == 0:
                 self.add_log(f"  <font color='orange'>AVISO: No se han encontrado infraestructuras especiales en capa {layer_type}</font>")        
        # Procesar ambas capas
        process_layer(self.layer_antes, 'antes', facades_antes)
        self.add_log(f"DEBUG FACADES (Antes): {stats_debug}")
        
        # Reset debug stats for second pass
        for t in stats_debug: stats_debug[t] = 0
        
        process_layer(self.layer_despues, 'desp', facades_desp)
        self.add_log(f"DEBUG FACADES (Desp): {stats_debug}")
        
        # Agregar a parcel_details
        linked_count = 0
        for detail in self.metrics['parcel_details']:
            pid = detail['id']
            
            # Fachadas ANTES
            found_antes = False
            for tipo in infra_types:
                key = f'facade_antes_{tipo}'
                val = facades_antes.get(pid, {}).get(tipo, 0.0)
                detail[key] = val
                if val > 0: found_antes = True
            
            # Fachadas DESPUES
            found_desp = False
            for tipo in infra_types:
                key = f'facade_desp_{tipo}'
                val = facades_desp.get(pid, {}).get(tipo, 0.0)
                detail[key] = val
                if val > 0: found_desp = True
            
            if found_antes or found_desp:
                linked_count += 1
        
        self.add_log(f"Vinculación: {linked_count} parcelas del informe tienen datos de fachada vinculados.")
        if linked_count == 0 and sum(stats_debug.values()) > 0:
             self.add_log("<font color='red'>ERROR CRÍTICO: Se calcularon fachadas pero no coinciden los IDs con el informe.</font>")

    def _calculate_islands_implementation(self):
        """Método legacy - ya no se usa, reemplazado por _calculate_extra_metrics"""
        pass


    def _build_unified_id(self, pol, mas, smas, rec, srec):
        """Genera ID unificado estándar: POL/MASA[-SMAS]/REC[-SREC]"""
        def clean(v):
            if v is None or str(v).upper() == 'NULL': return None
            s = str(v).strip()
            # Si es .0 (float coming from CAD), quitarlo
            if s.endswith('.0'): s = s[:-2]
            return s
            
        p = clean(pol) or "0"
        m = clean(mas)
        r = clean(rec)
        sm = clean(smas)
        sr = clean(srec)
        
        if not m or not r: return None
        
        part_masa = m
        if sm and sm != "0": part_masa += f"-{sm}"
        
        part_rec = r
        if sr and sr != "0": part_rec += f"-{sr}"
        
        return f"{p}/{part_masa}/{part_rec}"

    def _get_id_from_layer(self, feature, layer_type='antes'):
        """Recupera ID desde campo xID si existe, sino reconstruye."""
        idx_xid = feature.fields().indexFromName("xID")
        if idx_xid != -1:
            val = feature[idx_xid]
            if val and str(val) != 'NULL':
                return str(val)
            
        # Fallback reconstrucción
        mapping = self.settings.get('mapping', {}).get(layer_type, {})
        def get_val(key):
            fname = mapping.get(key)
            if fname:
                idx = feature.fields().indexFromName(fname)
                if idx != -1:
                    v = feature[idx]
                    if v is not None and str(v) != 'NULL': return v
            return None

        return self._build_unified_id(
            get_val('POL'), get_val('MASA'), get_val('SUBMASA'),
            get_val('REC'), get_val('SUBREC')
        )

    def _get_id(self, feature, suffix=""):
        """
        Extrae el ID de una feature de la capa UNION.
        """
        # Intentar leer xID directo
        xid_field = f"xID{suffix}"
        idx_xid = self.union_layer.fields().indexFromName(xid_field)
        if idx_xid != -1:
            val = feature[idx_xid]
            if val and str(val) != 'NULL':
                return str(val)
        
        # Fallback: reconstruir
        layer_type = 'antes' if suffix == "" else 'desp'
        mapping = self.settings.get('mapping', {}).get(layer_type, {})
        
        def get_val(key):
            fname = mapping.get(key)
            if fname:
                union_field = f"{fname}{suffix}"
                idx = self.union_layer.fields().indexFromName(union_field)
                if idx != -1:
                    v = feature[idx]
                    if v is not None and str(v) != 'NULL': return v
            return None
        
        return self._build_unified_id(
            get_val('POL'), get_val('MASA'), get_val('SUBMASA'),
            get_val('REC'), get_val('SUBREC')
        )

    def _calculate_geometric_deltas(self):
        """
        Calcula deltas geométricos agregando fragmentos.
        """
        self.add_log("Calculando Deltas Geométricos...")
        parcels_a = {}
        parcels_d = {}

        idx_area = self.union_layer.fields().indexFromName("AREA_FRAG")
        idx_rings_a = self.union_layer.fields().indexFromName("N_RINGS")
        idx_rings_d = self.union_layer.fields().indexFromName("N_RINGS_2")
        idx_grav_a = self.union_layer.fields().indexFromName("K_GRAV")
        idx_grav_d = self.union_layer.fields().indexFromName("K_GRAV_2")
        
        # Indices TIPO para filtrado
        idx_tipo_a = self.union_layer.fields().indexFromName("TIPO")
        idx_tipo_d = self.union_layer.fields().indexFromName("TIPO_2")
        
        # Indices PROP para detectar cambios de propietario
        idx_prop_a = self.union_layer.fields().indexFromName("PROP")
        idx_prop_d = self.union_layer.fields().indexFromName("PROP_2")

        def get_num(feat, idx, is_int=False):
            if idx == -1: return 0
            val = feat[idx]
            if val is None: return 0
            try: return int(val) if is_int else float(val)
            except: return 0
        
        def get_str(feat, idx, default=""):
            if idx == -1: return default
            val = feat[idx]
            if val is None or str(val) == 'NULL': return default
            return str(val)

        # Contadores Debug
        total_feats = 0
        valid_ids = 0
        filtered_special = 0

        for f in self.union_layer.getFeatures():
            total_feats += 1
            id_a = self._get_id(f, "")
            id_d = self._get_id(f, "_2")
            area = get_num(f, idx_area)
            
            # FILTRADO ROBUSTO POR TIPO
            type_a = f[idx_tipo_a] if idx_tipo_a != -1 else "PARCELA"
            type_d = f[idx_tipo_d] if idx_tipo_d != -1 else "PARCELA"
            
            # Normalizar: Si es NULL o vacío, es PARCELA
            if not type_a or str(type_a) == 'NULL': type_a = "PARCELA"
            if not type_d or str(type_d) == 'NULL': type_d = "PARCELA"
            
            # Extraer propietarios
            prop_a = get_str(f, idx_prop_a, "DESCONOCIDO")
            prop_d = get_str(f, idx_prop_d, "DESCONOCIDO")

            if id_a or id_d:
                valid_ids += 1

            if id_a:
                if id_a not in parcels_a:
                    parcels_a[id_a] = {
                        'area': 0, 
                        'rings': get_num(f, idx_rings_a, True), 
                        'grav': get_num(f, idx_grav_a, False),
                        'type': type_a,
                        'prop': prop_a
                    }
                parcels_a[id_a]['area'] += area
            
            if id_d:
                if id_d not in parcels_d:
                    parcels_d[id_d] = {
                        'area': 0, 
                        'rings': get_num(f, idx_rings_d, True), 
                        'grav': get_num(f, idx_grav_d, False),
                        'type': type_d,
                        'prop': prop_d
                    }
                parcels_d[id_d]['area'] += area

        self.add_log(f"DEBUG MATRIX: UnionFeats={total_feats}, ValidIDs={valid_ids}")

        # Comparar existencias
        all_ids = set(parcels_a.keys()) | set(parcels_d.keys())
        
        details = []
        for pid in all_ids:
            data_a = parcels_a.get(pid)
            data_d = parcels_d.get(pid)
            
            # Filtrar: SOLO reportamos 'PARCELA' en la ficha principal y resumen.
            # (VIAL, AGUA, EDIF, EXCLUIDO, etc. solo se usan para el cálculo de fachadas)
            t_a = data_a['type'] if data_a else None
            t_d = data_d['type'] if data_d else None

            def is_parcel(t):
                if not t: return False
                return str(t).strip().upper() == "PARCELA"
            
            if not is_parcel(t_a) and not is_parcel(t_d):
                filtered_special += 1
                continue
            
            # FILTRADO DE REPORTE (Aislamiento Quirúrgico)
            # Solo mostramos en el informe lo que el usuario pidió explícitamente (Semillas)
            # Los vecinos de contexto (buffer 50m) se usaron para el cálculo pero se ocultan del reporte final.
            study_ids = self.settings.get('study_ids')
            if study_ids is not None:
                # El ID puede estar como string o numero, normalizamos
                if str(pid) not in study_ids:
                    continue  # Es un vecino de contexto, no se reporta card propia
            
            # (El filtro de propietario ya está implícito en study_ids si se activó en AnalysisEngine)
            
            info = {'id': pid}
            info['grav_a'] = data_a['grav'] if data_a else 0
            info['grav_d'] = data_d['grav'] if data_d else 0
            info['rings_a'] = data_a['rings'] if data_a else 0
            info['rings_d'] = data_d['rings'] if data_d else 0
            
            # Información de propietarios
            info['prop_a'] = data_a.get('prop', 'DESCONOCIDO') if data_a else 'N/A'
            info['prop_d'] = data_d.get('prop', 'DESCONOCIDO') if data_d else 'N/A'
            
            # Detectar cambio de propietario (solo para parcelas PERSISTENTES)
            if data_a and data_d:
                info['owner_changed'] = (info['prop_a'] != info['prop_d'])
            else:
                info['owner_changed'] = False
            
            # ... (Lógica de estado igual) ...
            if data_a and data_d:
                info['state'] = 'PERSISTENTE'
                info['delta_area'] = data_d['area'] - data_a['area']
                info['delta_rings'] = info['rings_d'] - info['rings_a']
                info['delta_grav'] = info['grav_d'] - info['grav_a']
                info['area_final'] = data_d['area']
            elif data_a:
                info['state'] = 'BAJA'
                info['area_final'] = 0
                info['delta_area'] = -data_a['area']
            elif data_d:
                info['state'] = 'ALTA'
                info['area_final'] = data_d['area']
                info['delta_area'] = data_d['area']

            details.append(info)
            
        self.add_log(f"DEBUG DETAILS: Total Parcels={len(details)}, Filtered Special={filtered_special}")
        self.metrics['parcel_details'] = sorted(details, key=lambda x: x['id'])


    def _is_id_special(self, pid_str):
        """
        Verifica si un ID de parcela (e.g. '123-45-678') contiene algún componente 
        que caiga dentro de los rangos especiales (Vial, Agua, etc).
        """
        if not pid_str: return False
        try:
            # El ID suele ser MAS-REC-SMAS-SREC o similar.
            # Buscamos números en las partes
            import re
            parts = re.findall(r'\d+', pid_str)
            for p in parts:
                val = int(p)
                for r in self.special_ranges.values():
                    if val in r:
                        return True
        except:
            pass
        return False
