import os
from qgis.core import (
    QgsVectorLayer, 
    QgsSpatialIndex, 
    QgsGeometry,
    QgsWkbTypes,
    QgsProject
)

class AditService:
    def __init__(self, iface, log_callback=None):
        self.iface = iface
        self.log = log_callback
        self.adit_layers = {} # {key: QgsVectorLayer}

    def add_log(self, msg):
        if self.log:
            self.log(msg)

    def load_layers(self, adit_paths):
        """Carga las capas de aditamentos a memoria para análisis rápido."""
        # Quitamos self.adit_layers = {} para no borrar lo que venga de DXF
        for key, path in adit_paths.items():
            if not path or not os.path.exists(path):
                continue
                
            layer = QgsVectorLayer(path, f"ADIT_TEMP_{key}", "ogr")
            if layer.isValid():
                self.adit_layers[key] = layer
                self.add_log(f"AditService: Capa {key} cargada ({layer.featureCount()} elementos).")
            else:
                self.add_log(f"<font color='orange'>AVISO: No se pudo cargar la capa de aditamentos: {path}</font>")

    def add_loaded_layer(self, key, layer):
        """Añade una capa que ya está cargada en memoria (ej. desde DXF)."""
        if layer and layer.isValid():
            self.adit_layers[key] = layer
            self.add_log(f"AditService: Capa externa {key} vinculada ({layer.featureCount()} elementos).")

    def calculate_metrics(self, layer_antes, layer_desp, config):
        """
        Calcula el cruce espacial: 
        - ANTES-ok contra Aditamentos ANTES
        - DESPUES-ok contra Aditamentos DESPUES
        
        @param layer_antes: Capa ANTES-ok
        @param layer_desp: Capa DESPUES-ok
        @param config: dict con 'elemento_field', 'mapping', etc.
        @return dict { parcel_id: { elemento_name: { 'a': {c, l, a}, 'd': {c, l, a} } } }
        """
        field_elemento = config.get('elemento_field', 'layer')
        mapping = config.get('mapping', {})
        results = {}

        # 1. Preparar índices y datos
        adit_data = {}
        for key, layer in self.adit_layers.items():
            self.add_log(f"AditService: Indexando {key}...")
            idx = QgsSpatialIndex(layer.getFeatures())
            feats = {f.id(): f for f in layer.getFeatures()}
            gtype = layer.geometryType()
            
            # Búsqueda Case-Insensitive del campo
            f_idx = -1
            fnames = layer.fields().names()
            for i, name in enumerate(fnames):
                if name.lower() == field_elemento.lower():
                    f_idx = i
                    break
            
            adit_data[key] = {
                'index': idx,
                'features': feats,
                'type': gtype,
                'field_idx': f_idx
            }

        # 2. Función auxiliar de proceso por estado
        def process_state(parcels_layer, prefix, state_key):
            if not parcels_layer: return
            
            self.add_log(f"AditService: Analizando estado {state_key.upper()} ({parcels_layer.featureCount()} parcelas)...")
            
            for p_feat in parcels_layer.getFeatures():
                p_geom = p_feat.geometry()
                if not p_geom or p_geom.isNull(): continue
                
                pid = p_feat['xID'] if 'xID' in p_feat.fields().names() else self._simple_id(p_feat, mapping.get('antes' if state_key=='a' else 'desp', {}))
                if not pid: continue

                if pid not in results: results[pid] = {}

                # Filtrar capas de aditamentos correspondientes al estado
                for key, data in adit_data.items():
                    if prefix not in key: continue
                    
                    candidates = data['index'].intersects(p_geom.boundingBox())
                    for cid in candidates:
                        a_feat = data['features'][cid]
                        a_geom = a_feat.geometry()
                        if not a_geom or a_geom.isNull(): continue
                        
                        if p_geom.intersects(a_geom):
                            el_name = "DESCONOCIDO"
                            if data['field_idx'] != -1:
                                val = a_feat[data['field_idx']]
                                if val and str(val) != 'NULL': el_name = str(val).strip()
                            
                            if el_name not in results[pid]:
                                results[pid][el_name] = {
                                    'a': {'count': 0, 'len': 0.0, 'area': 0.0},
                                    'd': {'count': 0, 'len': 0.0, 'area': 0.0}
                                }
                            
                            target = results[pid][el_name][state_key]
                            if data['type'] == QgsWkbTypes.PointGeometry:
                                if p_geom.contains(a_geom.asPoint()): target['count'] += 1
                            elif data['type'] == QgsWkbTypes.LineGeometry:
                                inter = p_geom.intersection(a_geom)
                                if not inter.isEmpty(): target['len'] += inter.length()
                            elif data['type'] == QgsWkbTypes.PolygonGeometry:
                                inter = p_geom.intersection(a_geom)
                                if not inter.isEmpty():
                                    target['count'] += 1
                                    target['area'] += inter.area()

        # 3. Ejecutar ambos pases
        process_state(layer_antes, "_A_", 'a')
        process_state(layer_desp, "_D_", 'd')

        return results

    def _simple_id(self, feat, map_antes):
        """Reconstrucción básica de ID."""
        parts = []
        for key in ['POL', 'MASA', 'SUBMASA', 'REC', 'SUBREC']:
            fname = map_antes.get(key)
            if fname and fname in feat.fields().names():
                val = feat[fname]
                if val is not None and str(val) != 'NULL':
                    parts.append(str(val))
        return "/".join(parts) if parts else None
