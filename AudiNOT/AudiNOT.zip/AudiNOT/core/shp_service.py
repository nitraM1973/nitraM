import os
from qgis.core import (
    QgsVectorLayer, 
    QgsProject, 
    QgsMessageLog, 
    Qgis,
    QgsVectorFileWriter,
    QgsField,
    QgsExpression,
    QgsExpressionContext,
    QgsExpressionContextUtils
)
from PyQt5.QtCore import QVariant
import processing

class ShpService:
    def __init__(self, iface, log_callback=None):
        self.iface = iface
        self.log = log_callback

    def add_log(self, message):
        if self.log:
            self.log(message)
        else:
            print(f"AudiNOT: {message}")

    def prepare_input_layer(self, layer, label, output_path=None):
        """
        Realiza la corrección de una capa de entrada (SHP/GPKG).
        Limpia geometrías y asegura persistencia.
        Asigna el SRC del proyecto si la capa no tiene uno válido.
        """
        if not layer or not layer.isValid():
            self.add_log(f"<font color='red'>ERROR: Capa {label} no válida para procesamiento.</font>")
            return None

        self.add_log(f"<b>Iniciando corrección de geometrías para {label}...</b>")
        
        # Determinar el SRC del proyecto
        project_crs = QgsProject.instance().crs()
        
        if not layer.crs().isValid():
            layer.setCrs(project_crs)
        elif layer.crs() != project_crs:
            pass

        try:
            # 1. Ejecutar Reparación de Geometrías (Fix Geometries)
            # Primero a memoria para filtrar vacíos
            fix_params = {
                'INPUT': layer,
                'OUTPUT': 'memory:fixed'
            }
            res_fix = processing.run("native:fixgeometries", fix_params)
            fixed_layer = res_fix['OUTPUT']
            
            # 2. Eliminar geometrías vacías mediante filtro de selección
            # Usamos extractbyexpression para ser más robustos que subsetStrings
            clean_params = {
                'INPUT': fixed_layer,
                'EXPRESSION': 'NOT is_empty($geometry) AND $geometry IS NOT NULL',
                'OUTPUT': 'memory:clean'
            }
            res_clean = processing.run("native:extractbyexpression", clean_params)
            clean_layer = res_clean['OUTPUT']
            
            if not clean_layer or clean_layer.featureCount() == 0:
                self.add_log(f"<font color='orange'>AVISO: La capa {label} no tiene geometrías válidas tras corrección.</font>")
                return None

            # 3. Guardar a disco si se requiere
            final_layer = None
            if output_path:
                self.add_log(f"Exportando {label} a: {os.path.basename(output_path)}...")
                
                export_params = {
                    'INPUT': clean_layer,
                    'OUTPUT': output_path
                }
                # native:savefeatures es excelente para exportar a cualquier formato OGR
                processing.run("native:savefeatures", export_params)
                
                # Cargar la capa resultante desde disco
                final_layer = QgsVectorLayer(output_path, f"{label}-ok", "ogr")
            else:
                final_layer = clean_layer
                final_layer.setName(f"{label}-ok")

            if final_layer and final_layer.isValid():
                # Asegurar que la capa final tenga el SRC del proyecto
                if not final_layer.crs().isValid() or final_layer.crs() != project_crs:
                    final_layer.setCrs(project_crs)
                
                # 4. Añadir al proyecto QGIS
                QgsProject.instance().addMapLayer(final_layer)
                return final_layer
            else:
                self.add_log(f"<font color='red'>ERROR: No se pudo generar la capa corregida final.</font>")
                return None

        except Exception as e:
            self.add_log(f"<font color='red'>Error crítico en ShpService ({label}): {str(e)}</font>")
            import traceback
            print(traceback.format_exc())
            return None

    def save_memory_layer(self, layer, output_path, label=None):
        """
        Guarda una capa de memoria a disco (SHP) y la carga.
        """
        if not layer or not layer.isValid():
            return None
            
        try:
            name = label or layer.name()
            export_params = {
                'INPUT': layer,
                'OUTPUT': output_path
            }
            import processing
            processing.run("native:savefeatures", export_params)
            
            new_layer = QgsVectorLayer(output_path, name, "ogr")
            if new_layer.isValid():
                QgsProject.instance().addMapLayer(new_layer)
                return new_layer
        except Exception as e:
            self.add_log(f"Error guardando capa {output_path}: {str(e)}")
        return None

    def _get_best_field(self, layer, candidates):
        """Busca el primer campo que coincida con la lista de candidatos (case-insensitive)"""
        fields = [f.name().lower() for f in layer.fields()]
        field_map = {f.name().lower(): f.name() for f in layer.fields()}
        
        for cand in candidates:
            if cand.lower() in fields:
                return field_map[cand.lower()]
        return None

    def standardize_layer_fields(self, layer, label):
        """
        Estandariza los campos de la capa según el mapa definido por el usuario:
        POLIGONO -> POL
        MASA -> MAS
        SUBMASA -> SMAS
        FINCA -> REC
        SUBFINCA -> SREC
        PROPIETARIO/TITULAR -> PROP
        
        Calcula AREA y borra el resto.
        """
        self.add_log(f"Estandarizando campos para {label}...")
        
        # 1. Crear capa en memoria (Clonamos para no afectar el original)
        # Usamos extractbyexpression "1=1" que es una forma robusta de clonar a memoria
        params = {
            'INPUT': layer, 
            'EXPRESSION': '1=1',
            'OUTPUT': 'memory:'
        }
        res = processing.run("native:extractbyexpression", params)
        mem_layer = res['OUTPUT']
        
        # Mapa de equivalencias (Nombre estandar -> Posibles candidatos)
        # Prioridad por orden de lista
        mappings = {
            'POL': ['POLIGONO', 'POL', 'POLYGON'],
            'MAS': ['MASA', 'MAS', 'MASA_PARCELA'],
            'SMAS': ['SUBMASA', 'SMAS', 'SUB_MASA'],
            'REC': ['FINCA', 'REC', 'PARCELA', 'RECINTO'],
            'SREC': ['SUBFINCA', 'SREC', 'SUB_FINCA', 'SUBPARCELA'],
            'PROP': ['PROPIETARIO', 'PROP', 'TITULAR', 'NOMBRE', 'OWNER'],
            # Superficie de referencia T24 (valor "real" que debería tener el
            # recinto). Se detecta de forma tolerante a mayúsculas/variantes
            # de nombre y se estandariza a 'SUPFT24' para poder localizarla
            # después en la capa UNION (donde DESPUÉS recibe sufijo '_2').
            'SUPFT24': ['supfT24', 'SUPFT24', 'SUP_T24', 'SUPFT_24', 'SUPERFICIE_T24']
        }
        
        # Metricas topológicas que queremos preservar (aunque con nombre estandarizado corto)
        # Calculamos num_rings y gravelius antes de borrar todo
        provider = mem_layer.dataProvider()
        provider.addAttributes([
            QgsField("AREA", QVariant.Double),
            QgsField("N_RINGS", QVariant.Int),
            QgsField("K_GRAV", QVariant.Double)
        ])
        mem_layer.updateFields()
        
        idx_area = mem_layer.fields().indexFromName("AREA")
        idx_rings = mem_layer.fields().indexFromName("N_RINGS")
        idx_grav = mem_layer.fields().indexFromName("K_GRAV")
        
        context = QgsExpressionContext()
        context.appendScope(QgsExpressionContextUtils.globalScope())
        context.appendScope(QgsExpressionContextUtils.projectScope(QgsProject.instance()))
        context.appendScope(QgsExpressionContextUtils.layerScope(mem_layer))
        
        exp_rings = QgsExpression("num_interior_rings($geometry)")
        exp_grav = QgsExpression("0.28 * perimeter($geometry) / sqrt(area($geometry))")
        
        mem_layer.startEditing()
        for f in mem_layer.getFeatures():
            geom = f.geometry()
            if geom and not geom.isNull():
                area = geom.area()
                context.setFeature(f)
                rings = exp_rings.evaluate(context)
                grav = exp_grav.evaluate(context)
                
                mem_layer.changeAttributeValue(f.id(), idx_area, area)
                mem_layer.changeAttributeValue(f.id(), idx_rings, rings if rings else 0)
                mem_layer.changeAttributeValue(f.id(), idx_grav, grav if grav else 0.0)
        mem_layer.commitChanges()
        
        # Renombrar campos encontrados
        rename_map = {} # old_name -> new_name
        
        for std_name, candidates in mappings.items():
            found = self._get_best_field(mem_layer, candidates)
            if found:
                rename_map[found] = std_name
                self.add_log(f"  - Mapeado {found} -> {std_name}")
            else:
                pass 
                # self.add_log(f"  - <font color='orange'>Falta campo para {std_name}</font>")

        if rename_map:
            mem_layer.startEditing()
            for old_name, new_name in rename_map.items():
                idx = mem_layer.fields().indexFromName(old_name)
                if idx != -1:
                    mem_layer.renameAttribute(idx, new_name)
            mem_layer.commitChanges()
            mem_layer.updateFields()
            
        # Borrar campos NO estandarizados (limpieza)
        # Campos a mantener:
        # - PROP: Para detectar cambios de propietario
        # - xID: Identificador único de parcela (contiene POL/MASA-SUBMASA/REC-SUBREC)
        # - TIPO: Clasificación de parcela (PARCELA, VIAL, AGUA, etc.)
        # - Métricas calculadas: AREA, N_RINGS, K_GRAV
        # - SUPFT24: superficie de referencia T24, informativa (comprobación
        #   de superficie declarada vs. superficie real GML)
        # NOTA: POL, MAS, SMAS, REC, SREC son redundantes porque ya están en xID
        keep_fields = ['PROP', 'xID', 'TIPO', 'AREA', 'N_RINGS', 'K_GRAV', 'SUPFT24']
        fields_to_delete = []
        for field in mem_layer.fields():
            if field.name() not in keep_fields:
                fields_to_delete.append(mem_layer.fields().indexFromName(field.name()))
        
        if fields_to_delete:
            mem_layer.dataProvider().deleteAttributes(fields_to_delete)
            mem_layer.updateFields()
            self.add_log(f"  - Limpieza: {len(fields_to_delete)} campos eliminados.")

        return mem_layer

    def create_union(self, layer_antes_ok, layer_desp_ok, output_path=None):
        """
        Crea la capa UNION con campos estandarizados (POL, MAS, SMAS, REC, SREC, PROP).
        Los campos de DESPUES tendrán sufijo automático '_2'.
        """
        if not layer_antes_ok or not layer_desp_ok:
            self.add_log("<font color='red'>ERROR: Faltan capas para UNION.</font>")
            return None
        
        self.add_log("<b>Iniciando Análisis Avanzado UNION (Estandarizado)...</b>")
        project_crs = QgsProject.instance().crs()
        
        try:
            # 1. Estandarizar Capas
            std_antes = self.standardize_layer_fields(layer_antes_ok, "ANTES")
            std_desp = self.standardize_layer_fields(layer_desp_ok, "DESPUÉS")
            
            # 2. Ejecutar UNION
            # native:union mantiene nombres de INPUT y añade sufijo _2 a OVERLAY si hay colisión
            self.add_log("Ejecutando UNION...")
            union_params = {
                'INPUT': std_antes,
                'OVERLAY': std_desp,
                'OUTPUT': 'memory:'
            }
            union_result = processing.run("native:union", union_params)
            union_layer = union_result['OUTPUT']
            
            # 3. Corregir geometrías post-unión
            self.add_log("Limpiando geometrías del UNION...")
            fix_params = {'INPUT': union_layer, 'OUTPUT': 'memory:'}
            fixed_union = processing.run("native:fixgeometries", fix_params)['OUTPUT']
            
            # 4. Calcular Métricas Post-Unión y Clasificación
            self.add_log("Calculando métricas y clasificando cambios...")
            
            provider = fixed_union.dataProvider()
            provider.addAttributes([
                QgsField("AREA_FRAG", QVariant.Double),
                QgsField("TIPO_CAMBIO", QVariant.String, len=100),
                QgsField("VAR_ISLAS", QVariant.Int)
            ])
            fixed_union.updateFields()
            
            idx_frag = fixed_union.fields().indexFromName("AREA_FRAG")
            idx_tipo = fixed_union.fields().indexFromName("TIPO_CAMBIO")
            idx_var = fixed_union.fields().indexFromName("VAR_ISLAS")
            
            # Índices de campos (Antes vs Despues_2)
            f_prop = "PROP"
            f_prop_2 = "PROP_2"
            
            # Para identidad usamos la combinación de claves catastrales
            # Asumimos que si no existe campo (ej. no había SREC), es None
            keys = ['MAS', 'SMAS', 'REC', 'SREC'] 
            
            fixed_union.startEditing()
            features_to_delete = []
            
            stats = {
                'estable': 0, 'nueva': 0, 'baja': 0, 'cambio_prop': 0, 
                'alteracion': 0
            }
            # Auxiliar para Gravelius agregado
            kpi_grav = {'antes_sum': 0.0, 'despu_sum': 0.0, 'count_a': 0, 'count_d': 0}
            
            # Pre-resolver indices para velocidad
            idx_map = {}
            for k in keys + [f_prop, "N_RINGS", "K_GRAV"]:
                idx_map[k] = fixed_union.fields().indexFromName(k)
                idx_map[f"{k}_2"] = fixed_union.fields().indexFromName(f"{k}_2")
            
            for f in fixed_union.getFeatures():
                geom = f.geometry()
                if not geom or geom.isNull():
                    features_to_delete.append(f.id())
                    continue
                    
                area_frag = geom.area()
                
                # Filtrado de Ruido (Sliver Polygons)
                if area_frag < 0.5:
                    features_to_delete.append(f.id())
                    continue
                
                fixed_union.changeAttributeValue(f.id(), idx_frag, area_frag)
                
                # Extraer Valores ANTES
                vals_a = {}
                exists_a = False
                for k in keys:
                    idx = idx_map[k]
                    val = f[idx] if idx != -1 else None
                    vals_a[k] = val
                    if val is not None: exists_a = True
                    
                prop_a = f[idx_map[f_prop]] if idx_map[f_prop] != -1 else None
                rings_a = f[idx_map["N_RINGS"]] if idx_map["N_RINGS"] != -1 else 0
                grav_a = f[idx_map["K_GRAV"]] if idx_map["K_GRAV"] != -1 else 0
                
                # Extraer Valores DESPUES
                vals_d = {}
                exists_d = False
                for k in keys:
                    idx = idx_map[f"{k}_2"]
                    val = f[idx] if idx != -1 else None
                    vals_d[k] = val
                    if val is not None: exists_d = True
                    
                prop_d = f[idx_map[f_prop_2]] if idx_map[f_prop_2] != -1 else None
                rings_d = f[idx_map["N_RINGS_2"]] if idx_map["N_RINGS_2"] != -1 else 0
                grav_d = f[idx_map["K_GRAV_2"]] if idx_map["K_GRAV_2"] != -1 else 0

                # Identidad: Coinciden todas las claves catastrales
                same_id = True
                if not exists_a or not exists_d:
                    same_id = False
                else:
                    for k in keys:
                        if vals_a[k] != vals_d[k]:
                            same_id = False
                            break
                
                # Analisis de Islas
                # Si rings_a y rings_d son NULL (p.ej. altas/bajas), asumir 0
                r_a = rings_a if rings_a else 0
                r_d = rings_d if rings_d else 0
                var_islas = r_d - r_a
                
                # Acumular Gravelius (solo si existe la entidad original)
                if exists_a and grav_a:
                    kpi_grav['antes_sum'] += grav_a
                    kpi_grav['count_a'] += 1
                if exists_d and grav_d:
                    kpi_grav['despu_sum'] += grav_d
                    kpi_grav['count_d'] += 1

                # Clasificación
                tipo = "Revisión Manual"
                
                # ALTA: No existía antes (ID nulo o campos clave vacíos)
                if not exists_a: 
                    tipo = 'Alta (Nuevo Recinto)'
                    stats['nueva'] += area_frag
                    
                # BAJA: No existe después
                elif not exists_d:
                    tipo = 'Baja (Recinto Eliminado)'
                    stats['baja'] += area_frag
                    
                # PERSISTENTE
                elif same_id:
                    if prop_a == prop_d:
                        tipo = 'Persistente (Sin cambios)'
                        stats['estable'] += area_frag
                    else:
                        tipo = 'Cambio de Propiedad'
                        stats['cambio_prop'] += area_frag
                        
                # ALTERACIÓN GEOMÉTRICA (IDs distintos pero existen ambos -> Solape/Desplazamiento)
                else:
                    tipo = 'Alteración Geométrica'
                    stats['alteracion'] += area_frag

                fixed_union.changeAttributeValue(f.id(), idx_tipo, tipo)
                fixed_union.changeAttributeValue(f.id(), idx_var, var_islas)
            
            # Borrar slivers
            if features_to_delete:
                fixed_union.deleteFeatures(features_to_delete)
                self.add_log(f"Eliminados {len(features_to_delete)} slivers (< 0.5 m²).")
                
            fixed_union.commitChanges()
            
            # Reportar KPIs
            total_area = sum(stats.values())
            if total_area > 0:
                self.add_log("<b>=== REPORTE AUDITORÍA GEOMÉTRICA (v2 Estandarizada) ===</b>")
                self.add_log(f"Estable: {stats['estable']:.2f} m² ({(stats['estable']/total_area)*100:.1f}%)")
                self.add_log(f"Cambio Propiedad: {stats['cambio_prop']:.2f} m² ({(stats['cambio_prop']/total_area)*100:.1f}%)")
                self.add_log(f"Alteración: {stats['alteracion']:.2f} m² ({(stats['alteracion']/total_area)*100:.1f}%)")
                self.add_log(f"Nuevas: {stats['nueva']:.2f} m²")
                self.add_log(f"Bajas: {stats['baja']:.2f} m²")
                
                k_a = kpi_grav['antes_sum']/kpi_grav['count_a'] if kpi_grav['count_a'] else 0
                k_d = kpi_grav['despu_sum']/kpi_grav['count_d'] if kpi_grav['count_d'] else 0
                self.add_log(f"Indice Gravelius: {k_a:.3f} (Antes) -> {k_d:.3f} (Despues)")

            # Finalizar
            fixed_union.setCrs(project_crs)
            fixed_union.setName("UNION_ANALISIS")
            
            if output_path:
                self.add_log(f"Exportando UNION a: {output_path}")
                processing.run("native:savefeatures", {'INPUT': fixed_union, 'OUTPUT': output_path})
                final_layer = QgsVectorLayer(output_path, "UNION", "ogr")
            else:
                final_layer = fixed_union
                
            if final_layer and final_layer.isValid():
                QgsProject.instance().addMapLayer(final_layer)
                return final_layer
            
            return None

        except Exception as e:
            self.add_log(f"<font color='red'>Error crítico en UNION Standard: {str(e)}</font>")
            import traceback
            print(traceback.format_exc())
            return None

    def detect_duplicate_ids(self, layer, mapping, tag):
        """
        Detecta tres tipos de anomalia en una capa corregida geometricamente:
          1. ID duplicado     - mismo xID catastral en mas de una feature
          2. Geometria identica - mismo area + centroide con tolerancia (contorno dibujado dos veces)
          3. Solapamiento significativo - interseccion > umbral del area de la menor de las dos
        Devuelve dict: {'id_dups': [...], 'geom_dups': [...], 'overlaps': [...]}
        Cada elemento: {'ids': [...], 'desc': str}
        """
        if not layer or not layer.isValid():
            return {'id_dups': [], 'geom_dups': [], 'overlaps': []}

        from collections import defaultdict
        from math import sqrt

        OVERLAP_THRESHOLD = 0.85   # solapamiento > 85% del area de la menor -> anomalia
        CENTROID_TOL_M    = 0.10   # 10 cm: coincidencia de centroide para geom identica

        # --- Construir xID desde fields o desde mapping ---
        def _build_id(f):
            idx_xid = f.fields().indexFromName('xID')
            if idx_xid != -1:
                v = f['xID']
                if v and str(v) not in ('NULL', 'None', ''):
                    return str(v).strip()
            def gv(key):
                fname = mapping.get(tag, {}).get(key, '')
                if not fname: return None
                idx = f.fields().indexFromName(fname)
                if idx == -1: return None
                v = f[idx]
                if v is None or str(v) in ('NULL', 'None', ''): return None
                s = str(v).strip()
                if s.endswith('.0'): s = s[:-2]
                return s
            pol = gv('POL') or '0'
            mas = gv('MASA'); smas = gv('SUBMASA')
            rec = gv('REC'); srec = gv('SUBREC')
            if not mas or not rec: return None
            def csub(v): return v if (v and v not in ('0','0.0')) else None
            pm = mas + (f'-{csub(smas)}' if csub(smas) else '')
            pr = rec + (f'-{csub(srec)}' if csub(srec) else '')
            return f'{pol}/{pm}/{pr}'

        # --- Recopilar datos de todas las features ---
        features_data = []  # (fid, xid, geom, area, cx, cy)
        for f in layer.getFeatures():
            g = f.geometry()
            if not g or g.isEmpty(): continue
            area = g.area()
            c = g.centroid().asPoint()
            xid = _build_id(f)
            features_data.append((f.id(), xid or f'FID:{f.id()}', g, area, c.x(), c.y()))

        # --- 1. ID duplicados ---
        id_map = defaultdict(list)
        for fid, xid, g, area, cx, cy in features_data:
            if not xid.startswith('FID:'):  # solo IDs reales
                id_map[xid].append(fid)
        id_dups = [
            {'ids': [xid] + [f'fid={f}' for f in fids],
             'xid': xid, 'count': len(fids),
             'desc': f'{xid}  \u2192  {len(fids)} features con el mismo ID'}
            for xid, fids in id_map.items() if len(fids) > 1
        ]
        id_dups.sort(key=lambda x: x['xid'])

        # --- 2 & 3. Geometria identica + solapamiento significativo ---
        # Usamos indice espacial para no hacer O(n^2) completo
        from qgis.core import QgsSpatialIndex, QgsFeature, QgsGeometry
        idx = QgsSpatialIndex(layer.getFeatures())

        geom_dups = []   # geometrias practicamente identicas
        overlaps  = []   # solapamientos significativos
        checked   = set()

        fdata_by_fid = {row[0]: row for row in features_data}

        for fid_a, xid_a, g_a, area_a, cx_a, cy_a in features_data:
            if area_a <= 0: continue
            candidates = idx.intersects(g_a.boundingBox())
            for fid_b in candidates:
                if fid_b <= fid_a: continue          # evita pares duplicados
                pair = (fid_a, fid_b)
                if pair in checked: continue
                checked.add(pair)

                row_b = fdata_by_fid.get(fid_b)
                if not row_b: continue
                fid_b, xid_b, g_b, area_b, cx_b, cy_b = row_b
                if area_b <= 0: continue

                # Calcular interseccion
                try:
                    inter = g_a.intersection(g_b)
                    inter_area = inter.area() if inter and not inter.isEmpty() else 0.0
                except:
                    continue
                if inter_area <= 0: continue

                min_area = min(area_a, area_b)
                overlap_ratio = inter_area / min_area

                # Test geometria identica: solapamiento ~100% + centroide casi identico
                dist_c = sqrt((cx_a - cx_b)**2 + (cy_a - cy_b)**2)
                if overlap_ratio >= 0.98 and dist_c <= CENTROID_TOL_M:
                    geom_dups.append({
                        'ids': [xid_a, xid_b],
                        'desc': f'{xid_a}  vs  {xid_b}  \u2014  geometr\u00eda pr\u00e1cticamente id\u00e9ntica ({overlap_ratio*100:.1f}% solapamiento)'
                    })
                elif overlap_ratio >= OVERLAP_THRESHOLD:
                    overlaps.append({
                        'ids': [xid_a, xid_b],
                        'desc': f'{xid_a}  vs  {xid_b}  \u2014  solapamiento {overlap_ratio*100:.1f}% del \u00e1rea menor'
                    })

        return {'id_dups': id_dups, 'geom_dups': geom_dups, 'overlaps': overlaps}

    def build_duplicates_html(self, res_antes, res_desp):
        """
        Genera informe HTML con los tres tipos de anomalia para ambas capas.
        res_antes / res_desp: dict {'id_dups':[], 'geom_dups':[], 'overlaps':[]}
        """
        def _section(items, title, color):
            if not items: return ''
            rows = ''.join(
                f'<tr><td style="font-family:monospace;padding:2px 10px;font-size:12px">{i["desc"]}</td></tr>'
                for i in items
            )
            return (
                f'<p style="margin:8px 0 2px 0"><b style="color:{color}">{title} ({len(items)})</b></p>'
                f'<table border="0" cellspacing="0" style="margin-left:10px;border-left:3px solid {color};width:95%">'
                f'{rows}</table>'
            )

        def _layer_block(res, label):
            total = len(res['id_dups']) + len(res['geom_dups']) + len(res['overlaps'])
            if total == 0:
                return f'<p style="color:#27ae60"><b>{label}:</b> Sin anomal&#237;as detectadas.</p>'
            html = f'<h4 style="margin:12px 0 4px 0;color:#2c3e50">{label}: <span style="color:#c0392b">{total} anomal&#237;a(s)</span></h4>'
            html += _section(res['id_dups'],   '&#128273; IDs duplicados',               '#c0392b')
            html += _section(res['geom_dups'], '&#128257; Geometr&#237;as id&#233;nticas', '#e67e22')
            html += _section(res['overlaps'],  '&#9888; Solapamientos significativos',    '#e67e22')
            return html

        total_a = sum(len(res_antes[k]) for k in res_antes)
        total_d = sum(len(res_desp[k])  for k in res_desp)
        grand_total = total_a + total_d

        html = (
            '<html><body style="font-family:sans-serif;font-size:13px;padding:10px">'
            f'<h3 style="color:#c0392b">&#9888; Anomal&#237;as detectadas en capas de entrada ({grand_total} total)</h3>'
            '<p style="color:#555;margin-bottom:10px">'
            'Se han encontrado <b>ID duplicados</b>, <b>geometr&#237;as id&#233;nticas</b> o '
            '<b>solapamientos significativos</b> (&gt;85% del &#225;rea de la parcela menor).<br>'
            'Estos contornos duplicados provienen habitualmente del CAD y pueden provocar '
            'conteos err&#243;neos de colindantes y otras m&#233;tricas.<br>'
            '<b>Se recomienda corregir en origen antes de continuar.</b></p>'
            + _layer_block(res_antes, 'Capa ANTES')
            + _layer_block(res_desp,  'Capa DESPU&#201;S')
            + '</body></html>'
        )
        return html

    def enrich_layer(self, layer, mapping, special_ranges):
        """
        Añade campos 'TIPO' y 'xID' a la capa.
        
        Args:
            layer (QgsVectorLayer): La capa a enriquecer.
            mapping (dict): Mapeo de campos para esta capa (pol, mas, rec...).
            special_ranges (dict): Diccionario {Label: range(min, max)}.
        Returns:
            bool: True si hubo éxito.
        """
        if not layer or not layer.isValid(): return False
        
        self.add_log(f"Enriqueciendo capa {layer.name()} con TIPO y xID...")
        
        provider = layer.dataProvider()
        
        # 1. Asegurar campos TIPO y xID
        new_fields = []
        if layer.fields().indexFromName("TIPO") == -1:
            new_fields.append(QgsField("TIPO", QVariant.String, len=50))
        if layer.fields().indexFromName("xID") == -1:
            new_fields.append(QgsField("xID", QVariant.String, len=50))
            
        if new_fields:
            provider.addAttributes(new_fields)
            layer.updateFields()
            
        idx_tipo = layer.fields().indexFromName("TIPO")
        idx_xid = layer.fields().indexFromName("xID")
        
        # 2. Mapeo de indices
        rec_field = mapping.get('REC')
        idx_rec = layer.fields().indexFromName(rec_field) if rec_field else -1
        
        # Mapeo para xID: POL/MAS-SMAS/REC-SREC
        def get_idx(key):
            fname = mapping.get(key)
            return layer.fields().indexFromName(fname) if fname else -1

        idx_pol = get_idx('POL')
        idx_mas = get_idx('MASA')
        idx_smas = get_idx('SUBMASA')
        idx_srec = get_idx('SUBREC') # Usa clave SUBREC del mapeo
        
        # 3. Iterar
        layer.startEditing()
        count_special = 0
        
        for f in layer.getFeatures():
            # A) TIPO
            tipo = "PARCELA" # Default
            if idx_rec != -1:
                val_raw = f[idx_rec]
                val_int = None
                try:
                    if val_raw is not None:
                        val_int = int(float(str(val_raw)))
                except:
                    pass
                
                if val_int is not None:
                    for label, r in special_ranges.items():
                        if val_int in r:
                            tipo = label
                            count_special += 1
                            break
            
            layer.changeAttributeValue(f.id(), idx_tipo, tipo)
            
            # B) xID
            # Construir xID robusto
            try:
                def process_val(idx, is_rec=False):
                    if idx == -1: return None
                    v = f[idx]
                    if v is None or str(v) == 'NULL': return None
                    return str(v).strip()

                pol = process_val(idx_pol)
                if pol is None: pol = "0"
                
                mas = process_val(idx_mas)
                smas = process_val(idx_smas)
                rec = process_val(idx_rec)
                srec = process_val(idx_srec)
                
                if mas and rec:
                    # Construcción xID: POL/MAS[-SMAS]/REC[-SREC]
                    def clean_sub(v):
                        if v is None or str(v) == 'NULL': return None
                        s = str(v).strip()
                        if s == "0" or s == "0.0": return None
                        if s.endswith('.0'): s = s[:-2]
                        return s

                    sm = clean_sub(smas)
                    sr = clean_sub(srec)
                    
                    part_masa = str(mas)
                    if sm: part_masa += f"-{sm}"
                    
                    part_rec = str(rec)
                    if sr: part_rec += f"-{sr}"
                    
                    xid = f"{pol}/{part_masa}/{part_rec}"
                    layer.changeAttributeValue(f.id(), idx_xid, xid)
                else:
                    # Si faltan datos clave (MAS o REC), xID queda NULL
                    pass
            except Exception as e:
                pass

        layer.commitChanges()
        self.add_log(f"Enriquecido completado: {count_special} elementos especiales en {layer.name()}.")
        return True


