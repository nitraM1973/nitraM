import os
import shutil
from qgis.core import QgsProject, QgsGeometry, QgsVectorLayer, Qgis, QgsMessageLog
from .shp_service import ShpService
from .dxf_service import DxfService
from .adit_service import AditService

class AnalysisEngine:
    def __init__(self, iface, settings, log_callback):
        self.iface = iface
        self.settings = settings
        self.log = log_callback
        self.output_dir = settings.get('output_dir')
        self.restart_all = settings.get('restart_all', True)
        self.current_process_dir = None
        self.shp_service = ShpService(self.iface, self.log)
        self.dxf_service = DxfService(self.iface, self.log)
        self.adit_service = AditService(self.iface, self.log)

    def run(self):
        """
        Punto de entrada del proceso de análisis.
        """
        self.log("<b>--- INICIANDO ANÁLISIS ---</b>")
        
        # 1. Gestionar carpetas de salida (Crear carpeta Proceso_X limpia)
        self.current_process_dir = self.manage_folders()
        if not self.current_process_dir:
            self.log("<font color='red'>ERROR: No se pudo establecer la carpeta de salida.</font>")
            return

        # 2. Referencia a capas originales y limpieza de proyecto
        layer_antes = self.settings.get('layer_antes')
        layer_desp = self.settings.get('layer_desp')
        orig_antes = layer_antes 
        orig_desp = layer_desp
        mapping = self.settings.get('mapping', {})
        
        if not layer_antes or not layer_desp:
            self.log("<font color='red'>ERROR: Faltan capas de entrada ANTES o DESPUÉS.</font>")
            return

        self.log("Limpiando proyecto y preparando entorno de trabajo...")
        self.cleanup_generated_layers(orig_antes, orig_desp)

        # 3. FASE 1: CORRECCIÓN GLOBAL DE GEOMETRÍAS (Requerido para robustez)
        self.log("<b>Fase 1: Corrección de geometrías (Proceso Global para Robustez)...</b>")
        
        path_antes_ok = os.path.join(self.current_process_dir, "ANTES-raw-ok.shp")
        path_desp_ok = os.path.join(self.current_process_dir, "DESPUES-raw-ok.shp")

        # Corregir geometrías de las capas completas para evitar errores en pasos posteriores
        ok_antes_global = self.shp_service.prepare_input_layer(layer_antes, "ANTES (Carga)", path_antes_ok)
        ok_desp_global = self.shp_service.prepare_input_layer(layer_desp, "DESPUÉS (Carga)", path_desp_ok)

        if not ok_antes_global or not ok_desp_global:
            self.log("<font color='red'>ERROR CRÍTICO: No se han podido corregir las geometrías base.</font>")
            return

        # 4. DEFINICIÓN DEL FILTRO DE ESTUDIO (Aislamiento Quirúrgico)
        # Ahora que las capas están limpias, podemos recortar sin miedo a errores de topología.
        study_mask_expr = None
        owner_f = self.settings.get('owner_filter', {})
        only_selected = self.settings.get('only_selected', False)
        study_ids = []

        if only_selected:
            self.log("Identificando selección del usuario...")
            # Capturamos la identidad de la selección original para buscarla en la capa corregida (Phase 1)
            selected = list(orig_antes.selectedFeatures())
            if not selected:
                self.log("<font color='orange'>AVISO: Modo selección activo pero no hay nada seleccionado en la capa ANTES original.</font>")
                return
            
            expr_parts = []
            for f in selected:
                conds = []
                for key in ['POL', 'MASA', 'SUBMASA', 'REC', 'SUBREC']:
                    fname = mapping.get('antes', {}).get(key)
                    if not fname: continue
                    val = f[fname]
                    if val is None or str(val).upper() in ['NULL', 'NONE']:
                        conds.append(f"\"{fname}\" IS NULL")
                    else:
                        sval = str(val).strip()
                        if sval.endswith('.0'): sval = sval[:-2] # Limpiar .0 de números
                        conds.append(f"\"{fname}\" = '{sval}'")
                if conds:
                    expr_parts.append("(" + " AND ".join(conds) + ")")
            
            if expr_parts:
                study_mask_expr = " OR ".join(expr_parts)
            else:
                self.log("<font color='red'>ERROR: No se han podido extraer campos identificadores de la selección.</font>")
                return

        elif owner_f.get('owner_active') and owner_f.get('owner_id'):
            owner_id = owner_f.get('owner_id')
            f_prop_a = mapping.get('antes', {}).get('PROP')
            if f_prop_a:
                is_num = False
                try: float(owner_id); is_num = True
                except: pass
                val_expr = f"'{owner_id}'" if not is_num else owner_id
                study_mask_expr = f"\"{f_prop_a}\" = {val_expr}"
                self.log(f"Identificando parcelas del propietario {owner_id}...")
            else:
                self.log("<font color='orange'>AVISO: No se puede filtrar por dueño (campo PROP no mapeado).</font>")

        layer_antes = ok_antes_global
        layer_desp = ok_desp_global

        if study_mask_expr:
            try:
                import processing
                # 1. Extraer las "Semillas" de la capa ya corregida
                self.log("Extrayendo recintos de estudio (Semillas)...")
                res_seeds = processing.run("native:extractbyexpression", {
                    'INPUT': layer_antes,
                    'EXPRESSION': study_mask_expr,
                    'OUTPUT': 'memory:seeds'
                })
                seeds_layer = res_seeds['OUTPUT']
                
                if seeds_layer.featureCount() == 0:
                    self.log("<font color='orange'>AVISO: No se han encontrado recintos con los criterios especificados.</font>")
                    # Si no hay semillas, seguimos con la capa completa o paramos?
                    # Por consistencia con el filtro, mejor parar o avisar.
                    return
                
                # Guardar IDs de las semillas para el informe
                def get_clean_val(feat, key):
                    fname = mapping.get('antes', {}).get(key)
                    if not fname: return None
                    idx = feat.fields().indexFromName(fname)
                    if idx == -1: return None
                    v = feat[idx]
                    if v is None or str(v).upper() == 'NULL': return None
                    s = str(v).strip()
                    if s.endswith('.0'): s = s[:-2]
                    return s

                for f in seeds_layer.getFeatures():
                    pol = get_clean_val(f, 'POL') or "0"
                    mas = get_clean_val(f, 'MASA')
                    sm = get_clean_val(f, 'SUBMASA')
                    rec = get_clean_val(f, 'REC')
                    sr = get_clean_val(f, 'SUBREC')
                    if mas and rec:
                        sm_part = f"-{sm}" if sm and str(sm) not in ["0", "0.0"] else ""
                        sr_part = f"-{sr}" if sr and str(sr) not in ["0", "0.0"] else ""
                        study_ids.append(f"{pol}/{mas}{sm_part}/{rec}{sr_part}")
                
                self.settings['study_ids'] = study_ids

                # 2. Buffer y Recorte Espacial (Contexto 50m)
                self.log("Cálculo de entorno quirúrgico (50 metros)...")
                res_buffer = processing.run("native:buffer", {
                    'INPUT': seeds_layer,
                    'DISTANCE': 50.0,
                    'DISSOLVE': True,
                    'OUTPUT': 'memory:study_buffer'
                })
                buffer_layer = res_buffer['OUTPUT']
                
                # Recortar capas corregidas al entorno
                res_a = processing.run("native:extractbylocation", {
                    'INPUT': ok_antes_global,
                    'PREDICATE': [0],
                    'INTERSECT': buffer_layer,
                    'OUTPUT': 'memory:subset_antes'
                })
                layer_antes = res_a['OUTPUT']
                
                res_d = processing.run("native:extractbylocation", {
                    'INPUT': ok_desp_global,
                    'PREDICATE': [0],
                    'INTERSECT': buffer_layer,
                    'OUTPUT': 'memory:subset_desp'
                })
                layer_desp = res_d['OUTPUT']
                
                self.log(f"Universo acotado con éxito: {layer_antes.featureCount()} elementos.")
                
            except Exception as e:
                self.log(f"<font color='red'>Fallo en optimización quirúrgica: {str(e)}</font>")
                return

        # 5. Exportar capas de trabajo definitivas (Preparadas para Fase 3+)
        self.log("Preparando capas de trabajo definitivas...")
        path_antes_final = os.path.join(self.current_process_dir, "ANTES-ok.shp")
        path_desp_final = os.path.join(self.current_process_dir, "DESPUES-ok.shp")
        
        # Guardar en disco para que Fase 3+ trabaje sobre archivos físicos si es necesario
        ok_antes = self.shp_service.save_memory_layer(layer_antes, path_antes_final)
        ok_despues = self.shp_service.save_memory_layer(layer_desp, path_desp_final)
        
        # 6. Procesar DXF (si hay)
        self.log("<b>Fase 2: Procesamiento de capas auxiliares (DXF)...</b>")
        
        if not ok_antes or not ok_despues:
            self.log("<font color='red'>ERROR en corrección de geometrías.</font>")
            return
            
        # 5. Fase 2: Procesar DXF (si hay)
        dxf_antes_path = self.settings.get('dxf_antes_path')
        dxf_desp_path = self.settings.get('dxf_desp_path')
        
        # REQUERIMIENTO: Si falta uno, usar el otro por defecto para comparación
        if dxf_antes_path and not dxf_desp_path:
            self.log("AVISO: Usando DXF ANTES por defecto para DESPUÉS (Base comparativa).")
            dxf_desp_path = dxf_antes_path
        elif dxf_desp_path and not dxf_antes_path:
            self.log("AVISO: Usando DXF DESPUÉS por defecto para ANTES (Base comparativa).")
            dxf_antes_path = dxf_desp_path
        
        if dxf_antes_path or dxf_desp_path:
            self.log("<b>Fase 2: Procesando archivos DXF y Aditamentos...</b>")
            
            if dxf_antes_path:
                layers_a = self.dxf_service.process_dxf(dxf_antes_path, "DXF_ANTES")
                for l in layers_a:
                    gtype = l.geometryType()
                    suffix = "P" if gtype == 0 else "L" if gtype == 1 else "G"
                    self.adit_service.add_loaded_layer(f"ADIT_A_{suffix}", l)
            
            if dxf_desp_path:
                layers_d = self.dxf_service.process_dxf(dxf_desp_path, "DXF_DESPUÉS")
                for l in layers_d:
                    gtype = l.geometryType()
                    suffix = "P" if gtype == 0 else "L" if gtype == 1 else "G"
                    self.adit_service.add_loaded_layer(f"ADIT_D_{suffix}", l)
            
            self.log("<b>--- Fase 2 completada ---</b>")
        
        # 6. Fase 3: Enriquecer con TIPO y xID
        self.log("<b>Fase 3: Clasificación y Enriquecimiento (xID, TIPO)...</b>")
        mapping = self.settings.get('mapping', {})
        ranges = self.settings.get('special_ranges', {})
        
        map_antes = mapping.get('antes', {})
        map_desp = mapping.get('desp', {})
        
        if map_antes and map_antes.get('REC'):
            self.shp_service.enrich_layer(ok_antes, map_antes, ranges)
        else:
            self.log("AVISO: Mapeo incompleto para ANTES. Enriquecimiento omitido.")
            
        if map_desp and map_desp.get('REC'):
            self.shp_service.enrich_layer(ok_despues, map_desp, ranges)
        else:
            self.log("AVISO: Mapeo incompleto para DESPUÉS. Enriquecimiento omitido.")

        # 7. Fase 4: Crear UNION
        self.log("<b>Fase 4: Creando capa UNION...</b>")
        path_union = os.path.join(self.current_process_dir, "UNION.shp")
        union_layer = self.shp_service.create_union(ok_antes, ok_despues, path_union)
        
        if union_layer:
            # 7. Fase 4: Métricas y Reportes
            self.log("<b>Fase 4: Generando Informe Profesional con Métricas Avanzadas...</b>")
            from .metrics_calculation import MetricsCalculator
            from .report_service import ReportService
            
            try:
                # Calcular Métricas (pasando capas originales y settings para rangos)
                metrics_engine = MetricsCalculator(union_layer, ok_antes, ok_despues, self.log, self.settings)
                metrics_data = metrics_engine.calculate_all()
                
                # Inyectar metadatos de archivos para el encabezado
                metrics_data['input_files'] = {
                    'antes': self.settings.get('layer_antes').source() if self.settings.get('layer_antes') else "N/A",
                    'despues': self.settings.get('layer_desp').source() if self.settings.get('layer_desp') else "N/A"
                }
                
                # Inyectar propietarios especiales para marcado en informe
                metrics_data['special_owners'] = self.settings.get('special_owners', {})
                
                # 8. Fase 5: Análisis de Aditamentos (Technical Elements Audit)
                adit_paths = self.settings.get('adit_paths', {})
                # REQUERIMIENTO: Disparar si hay paths manuales O si ya se cargaron desde DXF en Fase 2
                if adit_paths or len(self.adit_service.adit_layers) > 0:
                    self.log("<b>Fase 5: Análisis de Aditamentos / Elementos Técnicos...</b>")
                    
                    # Cargar capas manuales (SHP) si las hay
                    if adit_paths:
                        self.adit_service.load_layers(adit_paths)
                    
                    adit_config = {
                        'elemento_field': self.settings.get('adit_mapping_field', 'layer'),
                        'mapping': self.settings.get('mapping', {})
                    }
                    adit_results = self.adit_service.calculate_metrics(ok_antes, ok_despues, adit_config)
                    
                    # Inyectar resultados en parcel_details
                    for detail in metrics_data.get('parcel_details', []):
                        pid = detail['id']
                        if pid in adit_results:
                            detail['aditamentos'] = adit_results[pid]
                        else:
                            detail['aditamentos'] = {}
                
                # Generar Informe
                report_service = ReportService(self.current_process_dir)
                thresholds = self.settings.get('thresholds', {})
                path_html = report_service.generate_html(metrics_data, "Informe_Auditoria.html", thresholds)
                
                self.log(f"<b>=== ANÁLISIS FINALIZADO CON ÉXITO ===</b>")
                self.log(f"Informe disponible en: <a href='{path_html}'>{path_html}</a>")
                
                # Intentar abrir el informe automáticamente (opcional)
                import webbrowser
                from PyQt5.QtCore import QUrl
                from PyQt5.QtGui import QDesktopServices
                QDesktopServices.openUrl(QUrl.fromLocalFile(path_html))
                
            except Exception as e:
                import traceback
                self.log(f"<font color='red'>Error generando informe: {str(e)}</font>")
                self.log(f"<pre>{traceback.format_exc()}</pre>")
                import traceback
                print(traceback.format_exc())
        else:
            self.log("<font color='red'>ERROR en creación de UNION.</font>")

    def manage_folders(self):
        """
        Lógica de carpetas Proceso_X e Informe.
        """
        if not self.output_dir or not os.path.isdir(self.output_dir):
            return None

        if self.restart_all:
            # Buscar el siguiente Proceso_X
            idx = 1
            while os.path.exists(os.path.join(self.output_dir, f"Proceso_{idx}")):
                idx += 1
            path = os.path.join(self.output_dir, f"Proceso_{idx}")
            self.log(f"Creando carpeta: Proceso_{idx}")
        else:
            # Usar el último Proceso_X existente o el 1 si no hay nada
            idx = 1
            while os.path.exists(os.path.join(self.output_dir, f"Proceso_{idx+1}")):
                idx += 1
            path = os.path.join(self.output_dir, f"Proceso_{idx}")
            
            # Si no es REINICIAR TODO, borrar contenidos previos excepto informe
            if os.path.exists(path):
                self.log(f"Limpiando archivos previos en Proceso_{idx}...")
                for item in os.listdir(path):
                    item_path = os.path.join(path, item)
                    if os.path.isfile(item_path):
                        os.remove(item_path)
                    elif os.path.isdir(item_path) and item != "informes":
                        shutil.rmtree(item_path)

        os.makedirs(os.path.join(path, "informes"), exist_ok=True)
        return path

    def cleanup_generated_layers(self, layer_antes, layer_desp):
        """
        Elimina todas las capas del proyecto EXCEPTO ANTES y DESPUÉS originales.
        """
        project = QgsProject.instance()
        
        layers_to_remove = []
        for layer_id, layer in project.mapLayers().items():
            # Mantener solo las capas originales ANTES y DESPUÉS
            if layer != layer_antes and layer != layer_desp:
                layers_to_remove.append(layer_id)
        
        if layers_to_remove:
            project.removeMapLayers(layers_to_remove)
            self.log(f"Eliminadas {len(layers_to_remove)} capas generadas previamente.")
