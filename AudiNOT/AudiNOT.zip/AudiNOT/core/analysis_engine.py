import os
import shutil
import time
import uuid
from qgis.core import QgsProject, QgsGeometry, QgsVectorLayer, Qgis, QgsMessageLog
from .shp_service import ShpService
from .dxf_service import DxfService
from .adit_service import AditService

class AnalysisEngine:
    def __init__(self, iface, settings, log_callback, progress_callback=None, confirm_callback=None):
        self.iface = iface
        self.settings = settings
        self.log = log_callback
        # Callback opcional: progress_callback(pct:int, texto:str). Permite
        # que la UI muestre una barra de progreso / estado sin acoplar este
        # motor a ningún widget concreto.
        self.progress_callback = progress_callback
        # Callback opcional: confirm_callback(pregunta:str) -> bool. Mismo
        # principio que progress_callback: el motor no sabe nada de
        # QMessageBox ni de Qt, solo pide confirmación cuando la necesita
        # (ver check_survival más abajo) y deja que la UI decida cómo
        # preguntarlo. Sin callback (headless / tests) nunca bloquea: se
        # asume confirmado.
        self.confirm_callback = confirm_callback
        self.output_dir = settings.get('output_dir')
        # Carpeta RAÍZ del proyecto (donde ya están los shapes/DXF, un
        # nivel por encima de "RESULTADO" -que es self.output_dir-). El
        # GeoPackage de auditoría (AudiNOT_Auditoria.gpkg) se crea AQUÍ,
        # no dentro de "RESULTADO", para que al compartir/abrir el .gpkg
        # en otro sitio no dependa de dónde esté "RESULTADO" respecto a
        # él. Si no se pasa (compatibilidad / uso headless), cae de
        # vuelta a output_dir, comportamiento previo a este cambio.
        self.project_root = settings.get('project_root') or self.output_dir
        self.restart_all = settings.get('restart_all', True)
        self.current_process_dir = None
        # Expuestos tras run() para que el dock_manager pueda refrescar la
        # Ficha "4: Auditoría" sin volver a calcular nada (ver bloque
        # aislado al final de run()).
        self.last_audit_gpkg_path = None
        self.last_output_dir = None
        self.shp_service = ShpService(self.iface, self.log)
        self.dxf_service = DxfService(self.iface, self.log)
        self.adit_service = AditService(self.iface, self.log)

    def _progress(self, pct, text=""):
        if self.progress_callback:
            try:
                self.progress_callback(pct, text)
            except Exception:
                pass

    def _confirm(self, question):
        """Pide confirmación a través de confirm_callback si lo hay; si no
        hay callback (o falla), no bloquea el análisis -- se asume
        confirmado, igual que progress_callback es opcional y silencioso."""
        if self.confirm_callback:
            try:
                return bool(self.confirm_callback(question))
            except Exception:
                return True
        return True


    def run(self):
        """
        Punto de entrada del proceso de análisis.
        """
        self.log("<b>--- INICIANDO ANÁLISIS ---</b>")
        self._progress(2, "Iniciando análisis...")
        
        # 1. Gestionar carpetas de salida (Crear carpeta Proceso_X limpia)
        self.current_process_dir = self.manage_folders()
        if not self.current_process_dir:
            self.log("<font color='red'>ERROR: No se pudo establecer la carpeta de salida.</font>")
            return

        # 2. Referencia a capas originales y limpieza de proyecto
        layer_antes = self.settings.get('layer_antes')
        layer_desp = self.settings.get('layer_desp')
        orig_antes = layer_antes 
        orig_desp = layer_desp
        mapping = self.settings.get('mapping', {})
        
        if not layer_antes or not layer_desp:
            self.log("<font color='red'>ERROR: Faltan capas de entrada ANTES o DESPUÉS.</font>")
            return

        self.log("Limpiando proyecto y preparando entorno de trabajo...")
        self.cleanup_generated_layers(orig_antes, orig_desp)

        # 3. FASE 1: CORRECCIÓN GLOBAL DE GEOMETRÍAS (Requerido para robustez)
        self.log("<b>Fase 1: Corrección de geometrías (Proceso Global para Robustez)...</b>")
        self._progress(10, "Fase 1: corrigiendo geometrías...")
        
        path_antes_ok = os.path.join(self.current_process_dir, "ANTES-raw-ok.shp")
        path_desp_ok = os.path.join(self.current_process_dir, "DESPUES-raw-ok.shp")

        # Corregir geometrías de las capas completas para evitar errores en pasos posteriores
        ok_antes_global = self.shp_service.prepare_input_layer(layer_antes, "ANTES (Carga)", path_antes_ok)
        ok_desp_global = self.shp_service.prepare_input_layer(layer_desp, "DESPUÉS (Carga)", path_desp_ok)

        if not ok_antes_global or not ok_desp_global:
            self.log("<font color='red'>ERROR CRÍTICO: No se han podido corregir las geometrías base.</font>")
            return

        # 3b. VALIDACION DE DUPLICADOS EN LAS CAPAS CORREGIDAS
        self.log("<b>Fase 1b: Validando unicidad de IDs de parcela...</b>")
        self._progress(25, "Fase 1b: validando IDs de parcela...")
        mapping = self.settings.get('mapping', {})
        dups_antes = self.shp_service.detect_duplicate_ids(ok_antes_global, mapping, 'antes')
        dups_desp  = self.shp_service.detect_duplicate_ids(ok_desp_global,  mapping, 'desp')

        total_antes = sum(len(dups_antes[k]) for k in dups_antes)
        total_desp  = sum(len(dups_desp[k])  for k in dups_desp)
        if total_antes > 0 or total_desp > 0:
            grand_total = total_antes + total_desp
            self.log(f"<font color='orange'>AVISO: Se han detectado {grand_total} anomal\u00eda(s) en las capas de entrada (IDs duplicados, geometr\u00edas id\u00e9nticas o solapamientos).</font>")

            # Mostrar dialogo con informe HTML
            from PyQt5.QtWidgets import QDialog, QVBoxLayout, QTextBrowser, QDialogButtonBox, QLabel
            from PyQt5.QtCore import Qt

            html_report = self.shp_service.build_duplicates_html(dups_antes, dups_desp)

            dlg = QDialog(self.iface.mainWindow())
            dlg.setWindowTitle("\u26a0 AudiNOT \u2014 Duplicados detectados")
            dlg.setMinimumSize(520, 400)
            dlg.setWindowFlags(dlg.windowFlags() | Qt.WindowStaysOnTopHint)

            layout = QVBoxLayout(dlg)

            browser = QTextBrowser()
            browser.setHtml(html_report)
            browser.setOpenExternalLinks(False)
            layout.addWidget(browser)

            btn_box = QDialogButtonBox()
            btn_continuar = btn_box.addButton("Continuar de todas formas", QDialogButtonBox.AcceptRole)
            btn_abortar   = btn_box.addButton("Abortar y corregir",        QDialogButtonBox.RejectRole)
            btn_abortar.setStyleSheet("background:#c0392b; color:white; font-weight:bold; padding:4px 12px;")
            btn_continuar.setStyleSheet("padding:4px 12px;")
            btn_box.accepted.connect(dlg.accept)
            btn_box.rejected.connect(dlg.reject)
            layout.addWidget(btn_box)

            result = dlg.exec_()
            if result != QDialog.Accepted:
                self.log("<font color='red'>An\u00e1lisis ABORTADO por el usuario. Corrija los duplicados en origen antes de continuar.</font>")
                return
            else:
                self.log("<font color='orange'>AVISO: El usuario ha elegido continuar con duplicados. Los resultados pueden ser inexactos.</font>")
        else:
            self.log("<font color='green'>Validaci\u00f3n de IDs: sin duplicados detectados.</font>")

        # 4. DEFINICIÓN DEL FILTRO DE ESTUDIO (Aislamiento Quirúrgico)
        # Ahora que las capas están limpias, podemos recortar sin miedo a errores de topología.
        study_mask_expr = None
        owner_f = self.settings.get('owner_filter', {})
        only_selected = self.settings.get('only_selected', False)
        study_ids = []

        if only_selected:
            self.log("Identificando selección del usuario...")
            # Capturamos la identidad de la selección original para buscarla en la capa corregida (Phase 1)
            selected = list(orig_antes.selectedFeatures())
            if not selected:
                self.log("<font color='orange'>AVISO: Modo selección activo pero no hay nada seleccionado en la capa ANTES original.</font>")
                return
            
            expr_parts = []
            for f in selected:
                conds = []
                for key in ['POL', 'MASA', 'SUBMASA', 'REC', 'SUBREC']:
                    fname = mapping.get('antes', {}).get(key)
                    if not fname: continue
                    val = f[fname]
                    if val is None or str(val).upper() in ['NULL', 'NONE']:
                        conds.append(f"\"{fname}\" IS NULL")
                    else:
                        sval = str(val).strip()
                        if sval.endswith('.0'): sval = sval[:-2] # Limpiar .0 de números
                        conds.append(f"\"{fname}\" = '{sval}'")
                if conds:
                    expr_parts.append("(" + " AND ".join(conds) + ")")
            
            if expr_parts:
                study_mask_expr = " OR ".join(expr_parts)
            else:
                self.log("<font color='red'>ERROR: No se han podido extraer campos identificadores de la selección.</font>")
                return

        elif owner_f.get('owner_active') and owner_f.get('owner_id'):
            owner_id = owner_f.get('owner_id')
            f_prop_a = mapping.get('antes', {}).get('PROP')
            if f_prop_a:
                is_num = False
                try: float(owner_id); is_num = True
                except: pass
                val_expr = f"'{owner_id}'" if not is_num else owner_id
                study_mask_expr = f"\"{f_prop_a}\" = {val_expr}"
                self.log(f"Identificando parcelas del propietario {owner_id}...")
            else:
                self.log("<font color='orange'>AVISO: No se puede filtrar por dueño (campo PROP no mapeado).</font>")

        layer_antes = ok_antes_global
        layer_desp = ok_desp_global

        if study_mask_expr:
            try:
                import processing
                # 1. Extraer las "Semillas" de la capa ya corregida
                res_seeds = processing.run("native:extractbyexpression", {
                    'INPUT': layer_antes,
                    'EXPRESSION': study_mask_expr,
                    'OUTPUT': 'memory:seeds'
                })
                seeds_layer = res_seeds['OUTPUT']
                
                if seeds_layer.featureCount() == 0:
                    self.log("<font color='orange'>AVISO: No se han encontrado recintos con los criterios especificados.</font>")
                    return
                
                # Guardar IDs de las semillas para el informe
                def get_clean_val(feat, key):
                    fname = mapping.get('antes', {}).get(key)
                    if not fname: return None
                    idx = feat.fields().indexFromName(fname)
                    if idx == -1: return None
                    v = feat[idx]
                    if v is None or str(v).upper() == 'NULL': return None
                    s = str(v).strip()
                    if s.endswith('.0'): s = s[:-2]
                    return s

                for f in seeds_layer.getFeatures():
                    pol = get_clean_val(f, 'POL') or "0"
                    mas = get_clean_val(f, 'MASA')
                    sm = get_clean_val(f, 'SUBMASA')
                    rec = get_clean_val(f, 'REC')
                    sr = get_clean_val(f, 'SUBREC')
                    if mas and rec:
                        sm_part = f"-{sm}" if sm and str(sm) not in ["0", "0.0"] else ""
                        sr_part = f"-{sr}" if sr and str(sr) not in ["0", "0.0"] else ""
                        study_ids.append(f"{pol}/{mas}{sm_part}/{rec}{sr_part}")
                
                self.settings['study_ids'] = study_ids

                # 2. Buffer y Recorte Espacial (Contexto 50m)
                res_buffer = processing.run("native:buffer", {
                    'INPUT': seeds_layer,
                    'DISTANCE': 50.0,
                    'DISSOLVE': True,
                    'OUTPUT': 'memory:study_buffer'
                })
                buffer_layer = res_buffer['OUTPUT']
                
                # Recortar capas corregidas al entorno
                res_a = processing.run("native:extractbylocation", {
                    'INPUT': ok_antes_global,
                    'PREDICATE': [0],
                    'INTERSECT': buffer_layer,
                    'OUTPUT': 'memory:subset_antes'
                })
                layer_antes = res_a['OUTPUT']
                
                res_d = processing.run("native:extractbylocation", {
                    'INPUT': ok_desp_global,
                    'PREDICATE': [0],
                    'INTERSECT': buffer_layer,
                    'OUTPUT': 'memory:subset_desp'
                })
                layer_desp = res_d['OUTPUT']
                
            except Exception as e:
                self.log(f"<font color='red'>Fallo en optimización quirúrgica: {str(e)}</font>")
                return

        # 5. Exportación de capas (Movido a Fase 3.5 para optimización)
        # Se realizará tras el enriquecimiento y dissolve para que los archivos finales estén limpios.
        
        # 6. Fase 2: Procesar DXF (si hay)
        dxf_antes_path = self.settings.get('dxf_antes_path')
        dxf_desp_path = self.settings.get('dxf_desp_path')
        
        # REQUERIMIENTO: Si falta uno, usar el otro por defecto para comparación
        if dxf_antes_path and not dxf_desp_path:
            self.log("AVISO: Usando DXF ANTES por defecto para DESPUÉS (Base comparativa).")
            dxf_desp_path = dxf_antes_path
        elif dxf_desp_path and not dxf_antes_path:
            self.log("AVISO: Usando DXF DESPUÉS por defecto para ANTES (Base comparativa).")
            dxf_antes_path = dxf_desp_path

        if dxf_antes_path or dxf_desp_path:
            self.log("<b>Fase 2: Procesando archivos DXF y Aditamentos...</b>")
            self._progress(35, "Fase 2: procesando DXF y aditamentos...")
            
            if dxf_antes_path:
                layers_a = self.dxf_service.process_dxf(dxf_antes_path, "DXF_ANTES")
                for l in layers_a:
                    gtype = l.geometryType()
                    suffix = "P" if gtype == 0 else "L" if gtype == 1 else "G"
                    self.adit_service.add_loaded_layer(f"ADIT_A_{suffix}", l)
            
            if dxf_desp_path:
                layers_d = self.dxf_service.process_dxf(dxf_desp_path, "DXF_DESPUÉS")
                for l in layers_d:
                    gtype = l.geometryType()
                    suffix = "P" if gtype == 0 else "L" if gtype == 1 else "G"
                    self.adit_service.add_loaded_layer(f"ADIT_D_{suffix}", l)
            
            self.log("<b>--- Fase 2 completada ---</b>")
        
        # 6. Fase 3: Enriquecer con TIPO y xID (Sobre capas en MEMORIA)
        self.log("<b>Fase 3: Clasificación y Enriquecimiento (xID, TIPO)...</b>")
        self._progress(50, "Fase 3: clasificando recintos...")
        mapping = self.settings.get('mapping', {})
        ranges = self.settings.get('special_ranges', {})
        
        map_antes = mapping.get('antes', {})
        map_desp = mapping.get('desp', {})
        
        if map_antes and map_antes.get('REC'):
            self.shp_service.enrich_layer(layer_antes, map_antes, ranges)
        if map_desp and map_desp.get('REC'):
            self.shp_service.enrich_layer(layer_desp, map_desp, ranges)

        # Enriquecer TAMBIÉN las capas globales SIN recortar (idénticas a
        # layer_antes/layer_desp cuando no se ha aplicado el recorte de
        # "aislamiento quirúrgico" de 50 m). Esto asegura que el xID que
        # identifica cada recinto se calcule con el mismo criterio en ambas
        # versiones de la capa, de forma que el contexto del croquis (que si
        # hay recorte se construye a partir de estas capas globales) y los
        # aditamentos de fincas vecinas usen exactamente los mismos
        # identificadores que el resto del informe.
        if ok_antes_global is not layer_antes and map_antes and map_antes.get('REC'):
            self.shp_service.enrich_layer(ok_antes_global, map_antes, ranges)
        if ok_desp_global is not layer_desp and map_desp and map_desp.get('REC'):
            self.shp_service.enrich_layer(ok_desp_global, map_desp, ranges)

        # 7. Exportar capas de trabajo definitivas (Preparadas para Fase 4+)
        self.log("Guardando capas de trabajo en disco...")
        path_antes_final = os.path.join(self.current_process_dir, "ANTES-ok.shp")
        path_desp_final = os.path.join(self.current_process_dir, "DESPUES-ok.shp")
        
        ok_antes = self.shp_service.save_memory_layer(layer_antes, path_antes_final)
        ok_despues = self.shp_service.save_memory_layer(layer_desp, path_desp_final)
        
        if not ok_antes or not ok_despues:
            self.log("<font color='red'>ERROR en persistencia de capas de trabajo.</font>")
            return

        # 7. Fase 4: Crear UNION
        self.log("<b>Fase 4: Creando capa UNION...</b>")
        self._progress(68, "Fase 4: creando capa unión...")
        path_union = os.path.join(self.current_process_dir, "UNION.shp")
        union_layer = self.shp_service.create_union(ok_antes, ok_despues, path_union)
        
        if union_layer:
            # 7. Fase 4: Métricas y Reportes
            self.log("<b>Fase 4: Generando Informe Profesional con Métricas Avanzadas...</b>")
            self._progress(78, "Fase 4: calculando métricas...")
            from .metrics_calculation import MetricsCalculator
            from .report_service import ReportService
            
            try:
                # Calcular Métricas (pasando capas originales y settings para rangos)
                metrics_engine = MetricsCalculator(
                    union_layer, ok_antes, ok_despues, self.log, self.settings,
                    context_layer_antes=ok_antes_global, context_layer_despues=ok_desp_global
                )
                _t_metrics0 = time.time()
                metrics_data = metrics_engine.calculate_all()
                self.log(f"TIEMPOS: cálculo de métricas (Fase 4) = {time.time() - _t_metrics0:.1f}s.")
                
                # Inyectar metadatos de archivos para el encabezado
                metrics_data['input_files'] = {
                    'antes': self.settings.get('layer_antes').source() if self.settings.get('layer_antes') else "N/A",
                    'despues': self.settings.get('layer_desp').source() if self.settings.get('layer_desp') else "N/A"
                }
                
                # Inyectar propietarios especiales para marcado en informe
                metrics_data['special_owners'] = self.settings.get('special_owners', {})
                
                # 8. Fase 5: Análisis de Aditamentos (Technical Elements Audit)
                adit_paths = self.settings.get('adit_paths', {})
                # REQUERIMIENTO: Disparar si hay paths manuales O si ya se cargaron desde DXF en Fase 2
                if adit_paths or len(self.adit_service.adit_layers) > 0:
                    self.log("<b>Fase 5: Análisis de Aditamentos / Elementos Técnicos...</b>")
                    self._progress(85, "Fase 5: analizando aditamentos...")
                    
                    # Cargar capas manuales (SHP) si las hay
                    if adit_paths:
                        self.adit_service.load_layers(adit_paths)
                    
                    adit_config = {
                        'elemento_field': self.settings.get('adit_mapping_field', 'layer'),
                        'mapping': self.settings.get('mapping', {})
                    }
                    # Se calcula sobre las capas GLOBALES sin recortar
                    # (ok_antes_global/ok_desp_global) y no sobre el subset
                    # recortado al buffer de 50 m de estudio: así, un
                    # vallado/piscina/porche de una finca VECINA que quede
                    # dentro del recuadro del croquis pero fuera de ese
                    # buffer también se calcula, y no falta en la
                    # "instantánea" cuando se dibuje como contexto.
                    _t_adit0 = time.time()
                    adit_results = self.adit_service.calculate_metrics(ok_antes_global, ok_desp_global, adit_config)
                    self.log(f"TIEMPOS: cálculo de aditamentos (Fase 5) = {time.time() - _t_adit0:.1f}s.")
                    
                    # Inyectar resultados en parcel_details
                    for detail in metrics_data.get('parcel_details', []):
                        pid = detail['id']
                        if pid in adit_results:
                            detail['aditamentos'] = adit_results[pid]
                        else:
                            detail['aditamentos'] = {}

                    # Se expone el diccionario COMPLETO (todas las fincas,
                    # no solo las de estudio) para que el croquis pueda
                    # dibujar también los aditamentos de las fincas de
                    # contexto (vecinas) visibles en el mismo recuadro.
                    metrics_data['context_aditamentos'] = adit_results
                
                # Generar Informe
                self._progress(92, "Generando informe HTML ampliado...")
                report_service = ReportService(self.current_process_dir, self.log)
                thresholds = self.settings.get('thresholds', {})
                # Ambos informes (ampliado y resumen) describen la misma
                # auditoría, así que comparten un único report_id: lo que
                # el usuario cubra/anote en uno se recupera también en el
                # otro al recargarlo en el mismo navegador (mismo registro
                # de autoguardado en IndexedDB).
                shared_report_id = str(uuid.uuid4())
                path_html = report_service.generate_html(metrics_data, "Informe_Auditoria.html", thresholds, report_id=shared_report_id)

                # Generar Informe RESUMEN (presentación): mismo contenido
                # identificativo, sin métricas detalladas, croquis + las dos
                # interpretaciones (paramétrica / alternativa) en rejilla.
                self._progress(96, "Generando informe HTML resumen...")
                path_html_resumen = report_service.generate_html_summary(
                    metrics_data, "Informe_Auditoria_Resumen.html", thresholds, report_id=shared_report_id
                )

                self._progress(100, "Completado")

                self.log(f"<b>=== ANÁLISIS FINALIZADO CON ÉXITO ===</b>")
                self.log(f"Informe disponible en: <a href='{path_html}'>{path_html}</a>")
                self.log(f"Informe resumen disponible en: <a href='{path_html_resumen}'>{path_html_resumen}</a>")

                # Intentar abrir los informes automáticamente (opcional)
                import webbrowser
                from PyQt5.QtCore import QUrl
                from PyQt5.QtGui import QDesktopServices
                QDesktopServices.openUrl(QUrl.fromLocalFile(path_html))
                QDesktopServices.openUrl(QUrl.fromLocalFile(path_html_resumen))

                # --- Ficha "4: Auditoría" ---------------------------------
                # Bloque AISLADO y ADITIVO: exporta/fusiona los mismos datos
                # ya calculados a la capa GeoPackage de auditoría. Va en su
                # propio try/except para que, si algo falla aquí, el informe
                # HTML (ya generado con éxito arriba) no se vea afectado en
                # absoluto. Se guarda en self.project_root (carpeta RAÍZ
                # del proyecto, ESTABLE, elegida por el usuario -- no en
                # self.output_dir/"RESULTADO" ni en self.current_process_dir
                # (que cambia en cada "Proceso_X")), precisamente para que
                # la fusión/upsert entre ejecuciones sucesivas encuentre
                # siempre el mismo fichero y no empiece de cero cada vez, y
                # para que el .gpkg no dependa de la ubicación de
                # "RESULTADO" si se comparte o se mueve por separado.
                try:
                    self._progress(99, "Actualizando capa de auditoría (Ficha 4)...")
                    from .audit_service import AuditService
                    audit_records = report_service.build_audit_records(metrics_data, thresholds)
                    # Recintos de DESPUÉS mapeados como infraestructura fija
                    # (Identificación por REC/Rangos: VIALES, CURSOS AGUA,
                    # EDIFICACIONES, EXCLUIDO), excluidos a propósito de
                    # metrics_data/parcel_details porque no son fincas a
                    # notificar -- pero que la Ficha 4 necesita ver igual.
                    # Se toman de 'ok_despues': la capa DESPUÉS ya corregida
                    # Y enriquecida con TIPO/xID (Fase 3), no la original.
                    infra_records = report_service.build_infra_records(ok_despues)
                    if infra_records:
                        self.log(f"Auditoría: incluyendo {len(infra_records)} recinto(s) de infraestructura fija "
                                 f"(VIALES/CURSOS AGUA/EDIFICACIONES/EXCLUIDO) de DESPUÉS.")
                    audit_service = AuditService(self.project_root, self.log)

                    # Comprobación de continuidad: si de las fincas activas
                    # de la auditoría anterior sobrevive muy pocas en este
                    # cálculo, lo más probable es que ANTES/DESPUÉS se hayan
                    # sustituido por shapes que no tienen que ver con el
                    # expediente (proyecto equivocado, ANTES/DESPUÉS
                    # intercambiados...). No es un error -- puede ser
                    # intencionado (expediente nuevo de verdad) -- así que
                    # solo se pide confirmación, no se bloquea en automático.
                    proceed_with_audit_update = True
                    survival = audit_service.check_survival(audit_records)
                    if survival is not None:
                        n_antes, m_ahora = survival
                        UMBRAL_SUPERVIVENCIA = 0.5
                        if n_antes > 0 and (m_ahora / n_antes) < UMBRAL_SUPERVIVENCIA:
                            pct_txt = round(100 * m_ahora / n_antes)
                            pregunta = (
                                f"De las {n_antes} fincas activas en la auditoría anterior, "
                                f"solo {m_ahora} ({pct_txt}%) siguen presentes en este cálculo.\n\n"
                                "Esto es normal si has cambiado deliberadamente de expediente/shapes, "
                                "pero también puede significar que ANTES/DESPUÉS no son los ficheros "
                                "correctos (p.ej. intercambiados o de otro proyecto).\n\n"
                                "¿Deseas continuar y actualizar la auditoría (AudiNOT_Auditoria / "
                                "AudiNOT_Historial) con estos datos?"
                            )
                            if not self._confirm(pregunta):
                                proceed_with_audit_update = False
                                self.log(
                                    "<font color='orange'>Actualización de AudiNOT_Auditoria / "
                                    "AudiNOT_Historial cancelada por el usuario tras la comprobación "
                                    f"de continuidad ({m_ahora}/{n_antes} fincas coinciden). El informe "
                                    "HTML ya generado no se ve afectado.</font>"
                                )

                    if proceed_with_audit_update:
                        audit_gpkg_path = audit_service.export_or_update(
                            audit_records + infra_records, layer_desp=self.settings.get('layer_desp'), report_id=shared_report_id,
                            # Capas de referencia complementarias: se añaden como
                            # capas EXTRA dentro del mismo .gpkg (no se mezclan
                            # con la capa de auditoría), para que el usuario
                            # tenga ANTES-ok, DESPUES-ok y los aditamentos
                            # usados en este cálculo sin salir del GeoPackage.
                            layer_antes=ok_antes, layer_despues=ok_despues,
                            adit_layers=self.adit_service.adit_layers,
                            # Snapshot de los parámetros (Umbrales/Rangos REC/
                            # Propietarios Especiales) usados en este cálculo,
                            # mismo formato que el .anot -- ver
                            # AuditService._write_parameters_table.
                            parametros=self.settings.get('parametros_anot')
                        )
                        self.log(f"Capa de auditoría actualizada en: {audit_gpkg_path}")

                        # Datos expuestos para que el dock_manager pueda refrescar
                        # la Ficha 4 sin tener que recalcular nada. Apunta a
                        # project_root (donde vive el .gpkg ahora), no a
                        # output_dir/"RESULTADO".
                        self.last_audit_gpkg_path = audit_gpkg_path
                        self.last_output_dir = self.project_root
                except Exception as e:
                    import traceback
                    self.log(f"<font color='orange'>AVISO: no se pudo actualizar la capa de auditoría (Ficha 4): {str(e)}</font>")
                    self.log(f"<pre>{traceback.format_exc()}</pre>")

            except Exception as e:
                import traceback
                self.log(f"<font color='red'>Error generando informe: {str(e)}</font>")
                self.log(f"<pre>{traceback.format_exc()}</pre>")
                import traceback
                print(traceback.format_exc())
                self._progress(100, "Error")
        else:
            self.log("<font color='red'>ERROR en creación de UNION.</font>")
            self._progress(100, "Error")

    def manage_folders(self):
        """
        Lógica de carpetas Proceso_X e Informe.
        """
        if not self.output_dir or not os.path.isdir(self.output_dir):
            return None

        if self.restart_all:
            # Buscar el siguiente Proceso_X
            idx = 1
            while os.path.exists(os.path.join(self.output_dir, f"Proceso_{idx}")):
                idx += 1
            path = os.path.join(self.output_dir, f"Proceso_{idx}")
            self.log(f"Creando carpeta: Proceso_{idx}")
        else:
            # Usar el último Proceso_X existente o el 1 si no hay nada
            idx = 1
            while os.path.exists(os.path.join(self.output_dir, f"Proceso_{idx+1}")):
                idx += 1
            path = os.path.join(self.output_dir, f"Proceso_{idx}")
            
            # Si no es REINICIAR TODO, borrar contenidos previos excepto informe
            if os.path.exists(path):
                self.log(f"Limpiando archivos previos en Proceso_{idx}...")
                for item in os.listdir(path):
                    item_path = os.path.join(path, item)
                    if os.path.isfile(item_path):
                        os.remove(item_path)
                    elif os.path.isdir(item_path) and item != "informes":
                        shutil.rmtree(item_path)

        os.makedirs(os.path.join(path, "informes"), exist_ok=True)
        return path

    def cleanup_generated_layers(self, layer_antes, layer_desp):
        """
        Elimina todas las capas del proyecto EXCEPTO ANTES y DESPUÉS originales.
        """
        project = QgsProject.instance()
        
        layers_to_remove = []
        for layer_id, layer in project.mapLayers().items():
            # Mantener solo las capas originales ANTES y DESPUÉS
            if layer != layer_antes and layer != layer_desp:
                layers_to_remove.append(layer_id)
        
        if layers_to_remove:
            project.removeMapLayers(layers_to_remove)
            self.log(f"Eliminadas {len(layers_to_remove)} capas generadas previamente.")
