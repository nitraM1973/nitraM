# -*- coding: utf-8 -*-
"""
PlanosService -- lógica de la Pestaña "6: Planos".

Implementa la especificación `spec_pestana_7_planos.md`:
  - Análisis de plantillas .qpt (QgsPrintLayout) -> campos de texto editables.
  - Listado de fincas a partir de la capa ANTES (TIPO == 'PARCELA', que ya
    excluye VIALES/CURSOS AGUA/EDIFICACIONES/EXCLUIDO calculados por
    ShpService.enrich_layer con los rangos de REC de la Ficha "2: Mapeo de
    Campos" -- NO se duplican los rangos aquí, se reutiliza el campo TIPO
    que ya los aplicó en el momento del análisis).
  - Cruce con NOTIFICAR: se reutiliza el AuditService/capa de auditoría de
    la Ficha "4: Auditoría" (campo `revision_estado` == 'si'), NO se
    inventa un campo NOTIFICAR nuevo -- ver docstring de `notificar_map`.
  - Escala normalizada única para el lote + encuadre centrado en cada
    finca, reutilizando el MISMO QgsLayoutItemMap para ANTES y DESPUÉS.
  - Simbología: borde reforzado de la finca actual (no destructivo -- se
    parte del renderer YA existente en la capa vía
    QgsRuleBasedRenderer.convertFromRenderer, y se restaura al terminar),
    relleno rayado rojo opcional para "construcciones", y renderizado
    categorizado opcional para aditamentos por el campo configurado en la
    Ficha 2 (`get_adit_mapping()`).

Decisiones tomadas para las preguntas abiertas del punto 10 de la spec
(documentadas también en la UI, ver tab_planos.py):
  1. Rangos de REC "elemento común": se leen indirectamente vía el campo
     TIPO ya calculado por ShpService.enrich_layer sobre ANTES_ok/DESPUES_ok
     (que a su vez usa TabMapping.get_defined_ranges()). No hace falta
     releer los QSpinBox de la Ficha 2 aquí.
  2. Campo NOTIFICAR: se asume que es el campo de decisión humana
     `revision_estado` ('si'/'no'/'rev'/'') de AUDIT_LAYER_NAME
     (AudiNOT_Auditoria.gpkg), cruzado por xID == audinot_id. Si no hay
     capa/servicio de auditoría cargado, la columna "Notificar" queda
     vacía y el filtro "Solo notificar" se deshabilita (no se bloquea el
     resto de la pestaña).
  3. Campos automáticos por finca: configurable fila a fila (checkbox
     "Auto" en la tabla de la UI), con una preselección heurística por
     nombre de campo (rec/plano/escala/fecha/data).
  4. Formato de salida: PDF y/o PNG (casillas independientes, PDF por
     defecto). Nombre de fichero: se reutiliza
     ReportService.parcel_export_filename() (mismo convenio ya usado por
     las fichas HTML/PDF de la Ficha 4: poligono-masa-submasa-finca-
     subfinca con ceros a la izquierda), con sufijo _ANTES/_DESPUES.
  5. Escala normalizada: ambas opciones ofrecidas -- automática (a partir
     de la finca de mayor superficie del lote, con margen configurable,
     ajustada a la escala "bonita" superior de una escalera estándar) o
     manual (desplegable con escalera estándar).
  6. Construcciones: capa configurable por el usuario (QgsMapLayerComboBox
     en la UI), no se asume ningún nombre de capa fijo.
  7. Paleta layer -> símbolo de aditamentos: no se ha encontrado ninguna
     tabla de correspondencias previa en el proyecto/plugin, así que se
     genera automáticamente con una rampa de color (QgsCategorizedSymbolRenderer),
     igual que el resto de simbología del plugin en ausencia de una paleta
     dada.
"""

import os
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QColor
from qgis.PyQt.QtXml import QDomDocument
from qgis.core import (
    QgsProject, QgsPrintLayout, QgsReadWriteContext, QgsLayoutItemLabel,
    QgsLayoutItemMap, QgsLayoutExporter, QgsRectangle, QgsGeometry,
    QgsRuleBasedRenderer, QgsSymbol, QgsSimpleFillSymbolLayer,
    QgsCategorizedSymbolRenderer, QgsRendererCategory, QgsWkbTypes,
    QgsSingleSymbolRenderer,
)

# Escalera de escalas "bonitas" habituales en planimetría catastral,
# de menor a mayor denominador (mayor detalle -> menor detalle).
STANDARD_SCALES = [200, 250, 500, 1000, 1500, 2000, 2500, 5000, 10000]

# Prefijos de convención de nombres del punto 3.2 de la spec:
#   fijo_* / logo_* -> no editable (decorativo / marco de logo)
#   var_*           -> editable por el usuario
NON_EDITABLE_PREFIXES = ("logo_", "fijo_")

# Heurística de preselección de "Auto" (punto 3.1): nombres de campo que
# habitualmente se recalculan por finca en vez de quedar fijos para todo
# el lote.
AUTO_HINT_SUBSTRINGS = ("rec", "plano", "escala", "fecha", "data")


class PlanosService:
    def __init__(self, log_callback=None):
        self.log_callback = log_callback

    def _log(self, msg):
        if self.log_callback:
            self.log_callback(msg)

    # ------------------------------------------------------------------
    # 3. Análisis de la plantilla .qpt
    # ------------------------------------------------------------------
    def analyze_template(self, qpt_path):
        """Carga el .qpt y devuelve (layout, campos).

        `layout` es un QgsPrintLayout ya inicializado con el contenido de
        la plantilla (reutilizable directamente para la generación,
        evitando parsear el XML dos veces).

        `campos` es una lista de dicts:
            {'id': str, 'texto': str, 'editable': bool, 'auto_sugerido': bool}
        ordenada según aparecen los QgsLayoutItemLabel en el layout.
        """
        if not qpt_path or not os.path.exists(qpt_path):
            raise FileNotFoundError(f"No existe la plantilla: {qpt_path}")

        with open(qpt_path, 'r', encoding='utf-8') as f:
            content = f.read()

        doc = QDomDocument()
        ok, err_msg, err_line, err_col = doc.setContent(content, True)
        if not ok:
            raise RuntimeError(
                f"El .qpt no es un XML válido ({err_msg}, línea {err_line})")

        layout = QgsPrintLayout(QgsProject.instance())
        layout.initializeDefaults()
        context = QgsReadWriteContext()
        context.setPathResolver(QgsProject.instance().pathResolver())

        # loadFromTemplate añade los items directamente sobre `layout`.
        layout.loadFromTemplate(doc, context)

        campos = []
        for item in layout.items():
            if not isinstance(item, QgsLayoutItemLabel):
                continue
            item_id = item.id() or ""
            editable = not item_id.lower().startswith(NON_EDITABLE_PREFIXES)
            auto_hint = any(h in item_id.lower() for h in AUTO_HINT_SUBSTRINGS)
            campos.append({
                'id': item_id,
                'texto': item.text(),
                'editable': editable,
                'auto_sugerido': editable and auto_hint,
            })

        n_maps = sum(1 for it in layout.items() if isinstance(it, QgsLayoutItemMap))
        if n_maps == 0:
            self._log("<font color='orange'>AVISO: la plantilla no contiene ningún "
                       "QgsLayoutItemMap (elemento de mapa); no se podrá generar el "
                       "encuadre gráfico.</font>")
        elif n_maps > 1:
            self._log(f"<font color='orange'>AVISO: la plantilla tiene {n_maps} elementos "
                       f"de mapa; se usará el primero encontrado para el encuadre.</font>")

        self._log(f"Planos: plantilla analizada -- {len(campos)} etiqueta(s) de texto "
                   f"({sum(1 for c in campos if c['editable'])} editable(s)).")
        return layout, campos

    # ------------------------------------------------------------------
    # 4. Listado de fincas (excluye elementos comunes vía campo TIPO)
    # ------------------------------------------------------------------
    def list_parcels(self, layer_antes, xid_field="xID", tipo_field="TIPO"):
        """Devuelve [{'xid': str, 'fid': int, 'titular': str|None}] para
        todas las features con TIPO == 'PARCELA' (o NULL, capas migradas
        de una versión sin este campo) de la capa ANTES. Excluye de forma
        implícita VIALES/CURSOS AGUA/EDIFICACIONES/EXCLUIDO, que ya vienen
        marcados así por ShpService.enrich_layer usando los rangos de REC
        de la Ficha 2."""
        if layer_antes is None:
            return []

        fields = layer_antes.fields()
        idx_xid = fields.indexOf(xid_field)
        idx_tipo = fields.indexOf(tipo_field)
        idx_prop = fields.indexOf("PROP")

        if idx_xid == -1:
            raise ValueError(
                f"La capa '{layer_antes.name()}' no tiene el campo '{xid_field}'. "
                "¿Es realmente la capa ANTES-ok generada por AudiNOT (Ficha 1)?")

        out = []
        for feat in layer_antes.getFeatures():
            tipo = feat[idx_tipo] if idx_tipo != -1 else None
            if tipo not in (None, "NULL", "PARCELA"):
                continue
            xid = feat[idx_xid]
            if xid in (None, "NULL", ""):
                continue
            titular = feat[idx_prop] if idx_prop != -1 else None
            out.append({'xid': str(xid), 'fid': feat.id(),
                        'titular': None if titular in (None, "NULL") else str(titular)})
        return out

    def notificar_map(self, audit_service, audit_layer=None):
        """Devuelve {xid: 'si'|'no'|'rev'|''} leyendo `revision_estado` de
        la capa de auditoría (AUDIT_LAYER_NAME), keyed por `audinot_id`
        (que usa el MISMO formato que xID -- ver ShpService.enrich_layer
        y ReportService.parcel_export_filename). Si no hay servicio/capa
        de auditoría disponible, devuelve {} (la pestaña no bloquea: el
        filtro "Solo notificar" simplemente queda sin datos)."""
        result = {}
        layer = audit_layer
        if layer is None and audit_service is not None:
            try:
                layer = audit_service.load_layer(add_to_project=False)
            except Exception as e:
                self._log(f"<font color='orange'>AVISO: no se pudo leer NOTIFICAR desde "
                           f"la capa de auditoría: {e}</font>")
                return result
        if layer is None:
            return result

        fields = layer.fields()
        idx_id = fields.indexOf("audinot_id")
        idx_est = fields.indexOf("revision_estado")
        if idx_id == -1 or idx_est == -1:
            return result
        for feat in layer.getFeatures():
            aid = feat[idx_id]
            if aid in (None, "NULL", ""):
                continue
            result[str(aid)] = feat[idx_est] or ''
        return result

    # ------------------------------------------------------------------
    # 7.1 Escala normalizada
    # ------------------------------------------------------------------
    def compute_auto_scale(self, layer_antes, xids, map_item, layer_despues=None,
                            xid_field="xID", margin_pct=15):
        """Calcula la escala 'bonita' más pequeña (de STANDARD_SCALES) que
        permite que la finca de mayor bounding box del lote seleccionado
        quepa, con un margen `margin_pct` %, dentro del área gráfica del
        elemento de mapa de la plantilla.

        IMPORTANTE (corrección de la falla nº1 detectada en revisión):
        antes solo se miraba el bounding box de la capa ANTES. Si una
        finca crece, se agrupa o se desplaza en el DESPUÉS -- justo el
        tipo de cambio que esta herramienta existe para auditar-- la
        escala del lote podía quedarse corta y el plano de DESPUÉS salía
        con la parcela recortada por el marco. Ahora se recorren AMBAS
        capas (si se proporciona `layer_despues`) y se toma el máximo
        ancho/alto encontrado en cualquiera de las dos."""
        if not xids or layer_antes is None or map_item is None:
            return STANDARD_SCALES[0]

        xid_set = set(xids)
        max_w = max_h = 0.0
        for layer in (layer_antes, layer_despues):
            if layer is None:
                continue
            idx_xid = layer.fields().indexOf(xid_field)
            if idx_xid == -1:
                continue
            for feat in layer.getFeatures():
                xid = feat[idx_xid]
                if xid is None or str(xid) not in xid_set:
                    continue
                geom = feat.geometry()
                if not geom or geom.isEmpty():
                    continue
                bbox = geom.boundingBox()
                max_w = max(max_w, bbox.width())
                max_h = max(max_h, bbox.height())

        if max_w <= 0 and max_h <= 0:
            return STANDARD_SCALES[0]

        margin_factor = 1.0 + (margin_pct / 100.0)
        needed_w = max_w * margin_factor
        needed_h = max_h * margin_factor

        # Tamaño del elemento de mapa en mm -> tamaño real en metros que
        # representa el área gráfica a una escala 1:S dada.
        map_w_mm = map_item.sizeWithUnits().width()
        map_h_mm = map_item.sizeWithUnits().height()
        if map_w_mm <= 0 or map_h_mm <= 0:
            map_w_mm, map_h_mm = 297.0, 210.0  # A4 apaisado, fallback razonable

        for scale in STANDARD_SCALES:
            avail_w_m = (map_w_mm / 1000.0) * scale
            avail_h_m = (map_h_mm / 1000.0) * scale
            if avail_w_m >= needed_w and avail_h_m >= needed_h:
                return scale
        return STANDARD_SCALES[-1]

    # ------------------------------------------------------------------
    # 7.2 / 7.3 / 9. Simbología (no destructiva: se restaura al terminar)
    # ------------------------------------------------------------------
    def prepare_highlight_renderer(self, layer, xid_field="xID"):
        """Convierte el renderer ACTUAL de la capa en un QgsRuleBasedRenderer
        que conserva ese mismo símbolo como regla ELSE, y añade delante una
        regla para la finca "actual" (variable de proyecto
        `planos_finca_actual`) con borde más ancho. Devuelve el renderer
        original (clon) para poder restaurarlo con `restore_renderer`."""
        original = layer.renderer().clone() if layer.renderer() else None

        base = QgsRuleBasedRenderer.convertFromRenderer(layer.renderer())
        if base is None:
            base = QgsRuleBasedRenderer(QgsSymbol.defaultSymbol(layer.geometryType()))
        root = base.rootRule()

        # Símbolo de la finca actual: reutiliza el símbolo por defecto de
        # geometría, solo se reescribe el ancho/color del contorno.
        symbol = QgsSymbol.defaultSymbol(layer.geometryType())
        outline = symbol.symbolLayer(0)
        if outline is not None:
            try:
                outline.setStrokeWidth(1.2)
                outline.setStrokeColor(QColor('#000000'))
            except Exception:
                pass
        rule = QgsRuleBasedRenderer.Rule(
            symbol,
            filterExp=f'"{xid_field}" = @planos_finca_actual',
            label="Finca actual")
        root.insertChild(0, rule)

        layer.setRenderer(base)
        layer.triggerRepaint()
        return original

    def restore_renderer(self, layer, original_renderer):
        if layer is not None and original_renderer is not None:
            layer.setRenderer(original_renderer)
            layer.triggerRepaint()

    def apply_construction_hatch(self, layer):
        """Punto 7.3: borde rojo algo más grueso + relleno rayado (no
        sólido) para la capa de construcciones. Devuelve el renderer
        original para restaurarlo después."""
        original = layer.renderer().clone() if layer.renderer() else None
        symbol = QgsSymbol.defaultSymbol(layer.geometryType())
        if layer.geometryType() == QgsWkbTypes.PolygonGeometry:
            base_layer = symbol.symbolLayer(0)
            base_layer.setBrushStyle(Qt.NoBrush)
            base_layer.setStrokeColor(QColor('#e53935'))
            base_layer.setStrokeWidth(0.6)
            hatch_layer = QgsSimpleFillSymbolLayer(QColor('#e53935'))
            hatch_layer.setBrushStyle(Qt.BDiagPattern)
            hatch_layer.setStrokeStyle(Qt.NoPen)
            symbol.appendSymbolLayer(hatch_layer)
        else:
            symbol.setColor(QColor('#e53935'))
        layer.setRenderer(QgsSingleSymbolRenderer(symbol))
        layer.triggerRepaint()
        return original

    def apply_categorized_adit_renderer(self, layer, field_name):
        """Punto 9: renderizado categorizado por el campo configurado en
        la Ficha 2 (por defecto 'layer'). No hay paleta layer->símbolo
        previa en el proyecto (ver cabecera del módulo), así que se
        genera con la rampa de color por defecto de QGIS. Devuelve el
        renderer original para restaurarlo."""
        if not field_name or layer.fields().indexOf(field_name) == -1:
            self._log(f"<font color='orange'>AVISO: la capa '{layer.name()}' no tiene el "
                       f"campo '{field_name}' para categorizar aditamentos; se deja su "
                       f"simbología actual.</font>")
            return None
        original = layer.renderer().clone() if layer.renderer() else None
        categories = []
        values = sorted({str(v) for v in layer.uniqueValues(layer.fields().indexOf(field_name))
                          if v not in (None, "NULL", "")})
        renderer = QgsCategorizedSymbolRenderer(field_name, categories)
        renderer.updateCategories([
            QgsRendererCategory(v, QgsSymbol.defaultSymbol(layer.geometryType()), v)
            for v in values
        ])
        # deja que QGIS asigne colores de la rampa por defecto
        try:
            from qgis.core import QgsStyle
            ramp = QgsStyle.defaultStyle().colorRamp('Spectral')
            if ramp:
                renderer.updateColorRamp(ramp)
        except Exception:
            pass
        layer.setRenderer(renderer)
        layer.triggerRepaint()
        return original

    # ------------------------------------------------------------------
    # 3.1 / 6. Relleno de campos de texto del cajetín
    # ------------------------------------------------------------------
    def build_extra_auto_values(self, campos_config, scale):
        """Calcula los valores REALES de los campos marcados «Auto» cuyo
        Id contiene 'escala' (-> "1:<escala del lote>") o 'fecha'/'data'
        (-> fecha de hoy, dd/mm/aaaa), para pasarlos como
        `extra_auto_values` a `fill_labels()`.

        Antes de esto, `fill_labels()` no recibía nunca este diccionario
        desde ninguno de sus 4 puntos de llamada (generación normal x2,
        vista previa x2), así que CUALQUIER campo «Auto» -- fuera
        rec_finca, escala_txt o fecha_emision -- se rellenaba siempre con
        el xID de la finca. El preseleccionado automático de la casilla
        (ver AUTO_HINT_SUBSTRINGS) sugiere qué campos SUELEN variar
        finca a finca, pero solo el de identificación (REC/xID) tenía
        implementado el cálculo real; escala y fecha "heredaban" el
        mismo comportamiento sin que fuera lo que su nombre prometía.

        Los campos «Auto» cuyo Id no contenga 'escala'/'fecha'/'data'
        (típicamente el de REC/identificación) NO se incluyen en el
        diccionario devuelto -- `fill_labels()` sigue rellenándolos con
        el xID de la finca, como hasta ahora."""
        from datetime import date
        fecha_txt = date.today().strftime('%d/%m/%Y')
        escala_txt = f"1:{scale}"
        extra = {}
        for cfg in campos_config:
            if not cfg.get('auto'):
                continue
            campo_id = cfg['id'].lower()
            if 'escala' in campo_id:
                extra[cfg['id']] = escala_txt
            elif 'fecha' in campo_id or 'data' in campo_id:
                extra[cfg['id']] = fecha_txt
        return extra

    def fill_labels(self, layout, campos_config, xid, extra_auto_values=None):
        """`campos_config`: lista de dicts {'id', 'valor', 'auto'} (el
        estado ACTUAL de la tabla de la UI en el momento de generar).
        `extra_auto_values`: dict opcional {id: valor} con overrides para
        campos automáticos concretos (p.ej. escala/fecha ya formateadas)
        calculados por el llamante; si un id automático no está en este
        dict, se usa `xid` como valor (caso REC/identificación)."""
        extra_auto_values = extra_auto_values or {}
        for cfg in campos_config:
            if not cfg.get('editable', True):
                continue
            item = layout.itemById(cfg['id'])
            if item is None or not isinstance(item, QgsLayoutItemLabel):
                continue
            if cfg.get('auto'):
                valor = extra_auto_values.get(cfg['id'], xid)
            else:
                valor = cfg.get('valor', '')
            item.setText(valor)

    # ------------------------------------------------------------------
    # 6. Generación
    # ------------------------------------------------------------------
    def build_output_basename(self, xid):
        """Reutiliza EXACTAMENTE el convenio de nombre de fichero que ya
        usan las fichas HTML/PDF de la Ficha 4 (ReportService), para que
        el listado de "RESULTADO" quede ordenado igual en toda la
        herramienta."""
        from .report_service import ReportService
        html_name = ReportService.parcel_export_filename(xid)
        return os.path.splitext(html_name)[0]

    def export_layout(self, layout, out_path, fmt='pdf'):
        exporter = QgsLayoutExporter(layout)
        if fmt == 'pdf':
            settings = QgsLayoutExporter.PdfExportSettings()
            result = exporter.exportToPdf(out_path, settings)
        else:
            settings = QgsLayoutExporter.ImageExportSettings()
            result = exporter.exportToImage(out_path, settings)
        return result == QgsLayoutExporter.Success

    def frame_map_item(self, map_item, geom_antes, geom_despues, scale):
        """Punto 7.1: centra el elemento de mapa y fija la escala
        normalizada exacta -- exactamente como describe la spec:
        zoomToExtent() para centrar, setScale() para fijar la escala
        final.

        IMPORTANTE (corrección de la falla nº1 detectada en revisión):
        antes se centraba solo sobre la geometría de ANTES (o la de
        DESPUÉS si la de ANTES no existía), nunca sobre la unión de
        ambas. Si la finca cambia de posición/forma entre ANTES y
        DESPUÉS, el encuadre (calculado una sola vez y reutilizado para
        los dos planos, para que sean comparables) podía dejar la
        parcela recortada por el marco en uno de los dos planos sin que
        se notara hasta abrir el PDF. Ahora se calcula el bounding box
        que contiene AMBAS geometrías (la que exista de cada una) y se
        encuadra sobre esa unión."""
        bbox = None
        for geom in (geom_antes, geom_despues):
            if geom is None or geom.isEmpty():
                continue
            b = geom.boundingBox()
            if bbox is None:
                bbox = QgsRectangle(b)
            else:
                bbox.combineExtentWith(b)

        if bbox is None:
            # Ninguna de las dos geometrías es válida: nada que encuadrar.
            # El llamante ya debería haber comprobado esto antes de
            # llegar aquí (ver on_generate/_selected_xids), pero se deja
            # como salvaguarda silenciosa en vez de lanzar una excepción
            # a mitad de un lote.
            return

        if bbox.width() == 0 and bbox.height() == 0:
            # Geometría degenerada (punto): da un pequeño margen artificial
            # para que zoomToExtent no falle con un rectángulo nulo.
            c = bbox.center()
            bbox = QgsRectangle(c.x() - 1, c.y() - 1, c.x() + 1, c.y() + 1)
        map_item.zoomToExtent(bbox)
        map_item.setScale(scale)
