from qgis.core import QgsGeometry, QgsPointXY
import math

class IslandsService:
    """
    Servicio especializado en el análisis de anillos interiores (huecos/islas).
    Arquitectura Senior 15+ para desacoplamiento de métricas.
    """
    
    def __init__(self, log_callback=None):
        self.log = log_callback

    def analyze_geometry(self, geom):
        """
        Extrae métricas agregadas de todos los anillos interiores de una geometría.
        """
        if not geom or geom.isNull():
            return None
            
        total_area = 0.0
        total_perim = 0.0
        hole_geoms = []
        
        # Procesar MultiPolygon o Polygon
        if geom.isMultipart():
            for part in geom.asMultiPolygon():
                # part[0] es el exterior, part[1:] son huecos
                for hole_ring in part[1:]:
                    h_geom = QgsGeometry.fromPolygonXY([hole_ring])
                    total_area += h_geom.area()
                    total_perim += h_geom.length()
                    hole_geoms.append(h_geom)
        else:
            poly = geom.asPolygon()
            if len(poly) > 1:
                for hole_ring in poly[1:]:
                    h_geom = QgsGeometry.fromPolygonXY([hole_ring])
                    total_area += h_geom.area()
                    total_perim += h_geom.length()
                    hole_geoms.append(h_geom)
                    
        if not hole_geoms:
            return None
            
        # Calcular centroide agregado (Centro de Gravedad de todos los huecos)
        combined_geom = hole_geoms[0]
        for i in range(1, len(hole_geoms)):
            combined_geom = combined_geom.combine(hole_geoms[i])
            
        centroid = combined_geom.centroid()
        
        return {
            'area': total_area,
            'perimeter': total_perim,
            'count': len(hole_geoms),
            'centroid': centroid,
            'is_valid': True
        }

    def calculate_deltas(self, data_a, data_d):
        """
        Calcula variaciones y desplazamientos entre el estado Antes y Después.
        """
        if not data_a and not data_d:
            return None
            
        res = {
            'area_a': data_a['area'] if data_a else 0.0,
            'area_d': data_d['area'] if data_d else 0.0,
            'perim_a': data_a['perimeter'] if data_a else 0.0,
            'perim_d': data_d['perimeter'] if data_d else 0.0,
            'count_a': data_a['count'] if data_a else 0,
            'count_d': data_d['count'] if data_d else 0,
            'displacement': 0.0,
            'displacement_dir': "-"
        }
        
        res['delta_area'] = res['area_d'] - res['area_a']
        res['delta_perim'] = res['perim_d'] - res['perim_a']
        res['delta_count'] = res['count_d'] - res['count_a']
        
        # Calcular desplazamiento de centroide si existen ambos
        if data_a and data_d:
            c_a = data_a['centroid']
            c_d = data_d['centroid']
            if not c_a.isNull() and not c_d.isNull():
                res['displacement'] = c_a.distance(c_d)
                res['displacement_dir'] = self._get_cardinal_direction(c_a, c_d)
                
        return res

    def _get_cardinal_direction(self, c_a, c_d):
        """Calcula dirección cardinal desde c_a hacia c_d"""
        p_a = c_a.asPoint()
        p_d = c_d.asPoint()
        dx = p_d.x() - p_a.x()
        dy = p_d.y() - p_a.y()
        
        if abs(dx) < 0.01 and abs(dy) < 0.01:
            return "-"
            
        angle = math.atan2(dy, dx)
        degrees = math.degrees(angle)
        if degrees < 0: degrees += 360
        
        if (degrees >= 337.5) or (degrees < 22.5): return "E"
        if (degrees >= 22.5) and (degrees < 67.5): return "NE"
        if (degrees >= 67.5) and (degrees < 112.5): return "N"
        if (degrees >= 112.5) and (degrees < 157.5): return "NO"
        if (degrees >= 157.5) and (degrees < 202.5): return "O"
        if (degrees >= 202.5) and (degrees < 247.5): return "SO"
        if (degrees >= 247.5) and (degrees < 292.5): return "S"
        if (degrees >= 292.5) and (degrees < 337.5): return "SE"
        return "-"
