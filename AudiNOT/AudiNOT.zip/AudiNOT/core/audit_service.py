"""
AuditService
============

Módulo NUEVO y AISLADO para la Ficha "4: Auditoría".

No modifica ni depende de forma acoplada de ningún otro módulo del
plugin salvo para leer los `records` ya calculados por
`ReportService.build_audit_records()`. Su única responsabilidad es:

  1. Crear (o actualizar) una capa GeoPackage de auditoría, copia de la
     capa DESPUÉS (Carga), con los campos calculados + los campos de
     revisión humana (revision_estado / revision_obs / revision_fecha).
  2. En re-ejecuciones del análisis, FUSIONAR (upsert) por `audinot_id`
     en vez de sobrescribir: una finca ya revisada conserva su
     revisión salvo que sus métricas hayan cambiado desde entonces
     (en cuyo caso se marca `revision_desactualizada=True` en vez de
     perder silenciosamente el trabajo humano ya hecho).
  3. Dejar la capa con una simbología categorizada por
     `revision_estado`, para que el estado de la auditoría se vea "de
     un vistazo" directamente en el lienzo de QGIS.
  4. Opcionalmente, añadir al MISMO fichero .gpkg (como capas extra,
     dentro del mismo contenedor) copias de referencia de ANTES-ok,
     DESPUES-ok y de las capas de aditamentos usadas en el cálculo, para
     que el usuario tenga toda la información de contexto en un único
     GeoPackage sin tener que ir a buscar los shapefiles sueltos. Estas
     capas de referencia son un espejo de solo lectura del último
     cálculo (se SOBRESCRIBEN en cada ejecución, sin fusión ni datos de
     revisión que preservar); la capa auditable de verdad sigue siendo
     únicamente AUDIT_LAYER_NAME.

Este fichero es la ÚNICA pieza del plugin que sabe escribir en el
GeoPackage de auditoría. La Ficha 4 (ui/components/tab_audit.py) solo
lee/edita la capa ya creada; no reimplementa nada de esto.
"""

import os
import re
import sqlite3
from datetime import datetime

from qgis.core import (
    QgsVectorLayer, QgsField, QgsFields, QgsFeature, QgsGeometry,
    QgsProject, QgsVectorFileWriter, QgsCoordinateTransformContext,
    QgsCategorizedSymbolRenderer, QgsRendererCategory, QgsSymbol,
    QgsSymbolLayer, QgsProperty, QgsRuleBasedRenderer, QgsSimpleFillSymbolLayer,
    QgsWkbTypes, edit, NULL as QGIS_NULL, QgsFeatureRequest,
    QgsCoordinateReferenceSystem
)
from qgis.PyQt.QtCore import QVariant, Qt
from qgis.PyQt.QtGui import QColor

AUDIT_LAYER_NAME = "AudiNOT_Auditoria"
AUDIT_GPKG_FILENAME = "AudiNOT_Auditoria.gpkg"

# Tabla de historial (sin geometría), dentro del MISMO .gpkg que
# AUDIT_LAYER_NAME. Ver diseno_historial_ficha4.md para el diseño
# completo; este módulo es el único que sabe escribir/leer en ella,
# igual que ya es el único que sabe escribir en AUDIT_LAYER_NAME.
HISTORIAL_LAYER_NAME = "AudiNOT_Historial"

# Un único campo 'detalle' en vez de una fila por campo cambiado (ver
# diseno_historial_ficha4.md, punto 2): un evento de recálculo = una
# fila del historial.
HISTORIAL_FIELDS = [
    ("audinot_id", QVariant.String, 254),
    ("fecha", QVariant.String, 32),
    ("usuario", QVariant.String, 254),
    ("origen", QVariant.String, 32),
    ("report_id", QVariant.String, 64),
    ("estado_anterior", QVariant.String, 4),
    ("estado_nuevo", QVariant.String, 4),
    ("obs_anterior", QVariant.String, -1),
    ("obs_nueva", QVariant.String, -1),
    ("detalle", QVariant.String, -1),
]

# Campos calculados (se sobrescriben siempre con el último cálculo).
CALC_FIELDS = [
    ("audinot_id", QVariant.String, 254),
    ("estado", QVariant.String, 20),
    # 'PARCELA' para las fincas normales (las únicas que build_audit_records
    # analiza); 'VIALES'/'CURSOS AGUA'/'EDIFICACIONES'/'EXCLUIDO' para los
    # recintos de infraestructura fija de DESPUÉS que añade
    # build_infra_records (Identificación por REC/Rangos, Ficha 3). Se usa
    # para la simbología de la capa (apply_symbology).
    ("tipo_recinto", QVariant.String, 20),
    ("titular_a", QVariant.String, 254),
    ("titular_d", QVariant.String, 254),
    ("titular_cambia", QVariant.Bool, None),
    ("sup_a", QVariant.Double, None),
    ("sup_d", QVariant.Double, None),
    ("var_sup", QVariant.Double, None),
    ("var_sup_pct", QVariant.Double, None),
    ("var_perim", QVariant.Double, None),
    ("n_partes_a", QVariant.Int, None),
    ("n_partes_d", QVariant.Int, None),
    ("n_islas_delta", QVariant.Int, None),
    ("notifica_param", QVariant.Bool, None),
    ("notifica_legal", QVariant.Bool, None),
    ("notif_divergen", QVariant.Bool, None),
    ("n_alertas", QVariant.Int, None),
    # Superficies de referencia T24 (registral) y GML (fórmula de Gauss
    # truncada a 2 decimales por vértice, igual que exige la
    # especificación GML de parcela catastral), Antes y Después, más los
    # % de desviación de supfT24 frente a cada una. "sup_a"/"sup_d" (más
    # arriba) son la superficie GRÁFICA real del recinto (área de la
    # geometría); estas son las otras dos referencias con las que se
    # compara supfT24 en la ficha de Auditoría.
    ("sup_t24_a", QVariant.Double, None),
    ("sup_t24_d", QVariant.Double, None),
    ("sup_gml_a", QVariant.Double, None),
    ("sup_gml_d", QVariant.Double, None),
    ("val_pct_a", QVariant.Double, None),
    ("val_pct_d", QVariant.Double, None),
    ("val_pct_gml_a", QVariant.Double, None),
    ("val_pct_gml_d", QVariant.Double, None),
    # True si |val_pct_gml_d| supera el "% Validación" de la Ficha 3 en
    # el momento del cálculo. Se usa tanto para resaltar la capa
    # (apply_symbology) como para poder filtrar/consultar en la tabla de
    # atributos sin tener que repetir el cálculo del umbral.
    ("val_gml_d_supera", QVariant.Bool, None),
    # Umbral '% Validación' (Ficha 3) vigente en el momento de este
    # cálculo. Se guarda como campo plano (en vez de recalcular el
    # umbral en la Ficha 4, que no tiene acceso directo a Ficha 3) para
    # poder replicar en la Ficha 4, mediante expresiones QGIS sobre
    # val_pct_a/val_pct_d/val_pct_gml_a/val_pct_gml_d, los mismos
    # filtros de precisión T24 y de validación GML que ya ofrece el
    # informe HTML (facetas "Precisión de superficie" y "Validación").
    ("val_limite_pct", QVariant.Double, None),
    ("conclusion_param", QVariant.String, -1),
    ("conclusion_legal", QVariant.String, -1),
    ("croquis_svg", QVariant.String, -1),
    ("audinot_json", QVariant.String, -1),
    ("report_id", QVariant.String, 64),
    ("fecha_calculo", QVariant.String, 32),
]

# Campos de revisión humana (se PRESERVAN al fusionar, salvo que la
# finca se marque como desactualizada).
REVIEW_FIELDS = [
    ("revision_estado", QVariant.String, 4),       # '', 'si', 'no', 'rev'
    ("revision_obs", QVariant.String, -1),
    ("revision_fecha", QVariant.String, 32),
    ("revision_desactualizada", QVariant.Bool, None),
    # True cuando esta finca NO apareció en el último cálculo (p.ej. por
    # cambios de filtro/selección, no por baja urbanística real -- eso
    # ya se audita como estado 'BAJA'). Es el "último estado conocido"
    # persistido en el propio feature que usa _merge_into_gpkg para
    # decidir si una aparición/desaparición es una transición real o
    # una mera continuidad (ver diseno_historial_ficha4.md, punto 6).
    ("no_presente_ultimo_calculo", QVariant.Bool, None),
]

ALL_FIELDS = CALC_FIELDS + REVIEW_FIELDS


class AuditService:
    def __init__(self, output_dir, log_callback=None):
        self.output_dir = output_dir
        self.gpkg_path = os.path.join(output_dir, AUDIT_GPKG_FILENAME)
        self.log_callback = log_callback

    def _log(self, msg):
        if self.log_callback:
            try:
                self.log_callback(msg)
            except Exception:
                pass

    # ------------------------------------------------------------------
    # Construcción de QgsFields a partir de ALL_FIELDS
    # ------------------------------------------------------------------
    def _build_fields(self):
        fields = QgsFields()
        for name, qtype, length in ALL_FIELDS:
            f = QgsField(name, qtype)
            if length and length > 0:
                f.setLength(length)
            fields.append(f)
        return fields

    # ------------------------------------------------------------------
    # Punto de entrada principal: crea o fusiona
    # ------------------------------------------------------------------
    def export_or_update(self, records, layer_desp, report_id, thresholds_changed_note=None,
                          layer_antes=None, layer_despues=None, adit_layers=None):
        """
        records: lista de dicts devuelta por ReportService.build_audit_records()
        layer_desp: QgsVectorLayer de la capa DESPUÉS (Carga), para tomar
                    el CRS de referencia.
        report_id: UUID del informe HTML que originó este cálculo (se
                   guarda por finca, útil para trazabilidad).
        layer_antes / layer_despues: QgsVectorLayer de ANTES-ok/DESPUES-ok
                    (las capas ya corregidas y enriquecidas, las mismas que
                    usa MetricsCalculator). Si se proporcionan, se añaden
                    como capas de referencia adicionales DENTRO del mismo
                    GeoPackage ('ANTES_ok'/'DESPUES_ok'), para que el
                    usuario tenga toda la información de contexto sin salir
                    del .gpkg. Opcional: si no se pasan, el gpkg se
                    comporta exactamente como antes (solo AUDIT_LAYER_NAME).
        adit_layers: dict opcional {clave: QgsVectorLayer} de las capas de
                    aditamentos/elementos técnicos usadas en el cálculo
                    (p.ej. AditService.adit_layers). Cada una se añade como
                    capa adicional 'ADIT_<clave>' en el mismo GeoPackage.

        Devuelve la ruta del GeoPackage resultante.
        """
        crs = layer_desp.crs() if layer_desp else None

        if not os.path.exists(self.gpkg_path):
            self._log(f"AudiNOT: creando capa de auditoría nueva en {self.gpkg_path}")
            self._create_gpkg(records, crs, report_id)
        else:
            self._log(f"AudiNOT: fusionando cálculo con la capa de auditoría existente en {self.gpkg_path}")
            self._merge_into_gpkg(records, crs, report_id)

        # Capas de referencia complementarias (ANTES-ok, DESPUES-ok,
        # aditamentos): copias de solo lectura de las capas de origen tal
        # como se usaron en ESTE cálculo, añadidas al MISMO fichero .gpkg
        # como capas independientes (no se mezclan ni se fusionan con
        # AUDIT_LAYER_NAME). No llevan datos de revisión humana que
        # preservar, así que simplemente se sobrescriben en cada ejecución
        # para reflejar siempre el último cálculo.
        self._write_reference_layers(layer_antes, layer_despues, adit_layers)

        return self.gpkg_path

    # ------------------------------------------------------------------
    # Comprobación de continuidad ("¿son los shapes que tocan?")
    # ------------------------------------------------------------------
    def check_survival(self, records):
        """Compara, ANTES de fusionar nada, las fincas 'activas' de la
        auditoría YA EXISTENTE (las que no estaban ya marcadas como
        `no_presente_ultimo_calculo`) contra los `audinot_id` de este
        nuevo cálculo (`records`).

        Pensado para detectar el caso "el usuario ha apuntado ANTES/
        DESPUÉS a shapes que no tienen casi nada que ver con la
        auditoría anterior" (proyecto equivocado, ANTES/DESPUÉS
        intercambiados, etc.) ANTES de escribir nada en el .gpkg -- no
        sustituye la validación humana, solo da un número con el que
        decidir si conviene confirmar antes de seguir.

        Devuelve (n_antes, m_ahora):
          - n_antes: nº de fincas activas en la auditoría existente.
          - m_ahora: cuántas de esas siguen presentes en `records`.
        Devuelve None si todavía no hay GeoPackage de auditoría (primera
        ejecución: no hay nada anterior con qué comparar).
        """
        if not os.path.exists(self.gpkg_path):
            return None

        layer = QgsVectorLayer(f"{self.gpkg_path}|layername={AUDIT_LAYER_NAME}", AUDIT_LAYER_NAME, "ogr")
        if not layer.isValid():
            return None

        new_ids = {str(r['audinot_id']) for r in records}

        # El campo puede no existir todavía si el .gpkg lo creó una
        # versión anterior del plugin y la migración de esquema (que
        # normalmente se dispara en _merge_into_gpkg) todavía no se ha
        # ejecutado en este punto -- check_survival() se llama ANTES de
        # export_or_update()/_merge_into_gpkg(). Ausente -> se trata como
        # False (ninguna finca "ya se sabía ausente"), igual que hace
        # _safe_bool_field() en tab_audit.py.
        idx_no_presente = layer.fields().indexFromName('no_presente_ultimo_calculo')
        # 'records' aquí es siempre audit_records (fincas reales), NUNCA
        # incluye infra_records (VIALES/CURSOS AGUA/EDIFICACIONES/
        # EXCLUIDO) -- ver AnalysisEngine.run(), que solo añade
        # infra_records más adelante, al llamar a export_or_update(). Si
        # no se excluyen aquí también los recintos de infraestructura ya
        # existentes en el .gpkg, nunca podrían "seguir presentes" en
        # `new_ids` y falsearían a la baja el porcentaje de continuidad.
        idx_estado = layer.fields().indexFromName('estado')

        n_antes = 0
        m_ahora = 0
        for f in layer.getFeatures():
            if idx_estado != -1 and f.attribute(idx_estado) == 'INFRAESTRUCTURA':
                continue
            no_presente = self._bool_field(f.attribute(idx_no_presente)) if idx_no_presente != -1 else False
            if no_presente:
                continue  # ya se sabía ausente de antes; no cuenta para esta comprobación
            n_antes += 1
            if str(f['audinot_id']) in new_ids:
                m_ahora += 1

        return (n_antes, m_ahora)

    # ------------------------------------------------------------------
    # Creación desde cero
    # ------------------------------------------------------------------
    def _create_gpkg(self, records, crs, report_id):
        fields = self._build_fields()
        writer = QgsVectorFileWriter.create(
            self.gpkg_path,
            fields,
            QgsWkbTypes.MultiPolygon,
            crs,
            QgsCoordinateTransformContext(),
            QgsVectorFileWriter.SaveVectorOptions()
        )
        if writer.hasError() != QgsVectorFileWriter.NoError:
            raise RuntimeError(f"No se pudo crear el GeoPackage de auditoría: {writer.errorMessage()}")

        now_iso = datetime.now().isoformat(timespec='seconds')
        for rec in records:
            feat = QgsFeature(fields)
            geom = rec.get('geom_d') or rec.get('geom_a')
            if geom is not None:
                feat.setGeometry(QgsGeometry(geom))
            self._fill_feature_attrs(feat, fields, rec, report_id, now_iso, preserve_review=None)
            writer.addFeature(feat)

        del writer  # fuerza el flush/cierre del fichero

    # ------------------------------------------------------------------
    # Capas de referencia complementarias (ANTES-ok, DESPUES-ok, aditamentos)
    # ------------------------------------------------------------------
    def _write_reference_layers(self, layer_antes, layer_despues, adit_layers):
        """Añade, dentro del MISMO fichero .gpkg que AUDIT_LAYER_NAME, una
        copia de referencia de cada capa de origen que se le pase. Cada una
        aterriza como una capa independiente y consultable (tabla GPKG
        distinta), no como features adicionales de la capa de auditoría.
        Todo el bloque es aislado: si alguna capa falla al escribirse, se
        avisa por log y se continúa con las demás, sin afectar nunca a
        AUDIT_LAYER_NAME (que ya se ha creado/fusionado antes de llegar
        aquí)."""
        refs = []
        if layer_antes is not None:
            refs.append((layer_antes, "ANTES_ok"))
        if layer_despues is not None:
            refs.append((layer_despues, "DESPUES_ok"))
        if adit_layers:
            for key, lyr in adit_layers.items():
                refs.append((lyr, f"ADIT_{self._sanitize_layer_name(key)}"))

        if not refs:
            return

        for source_layer, layer_name in refs:
            try:
                self._write_layer_copy(source_layer, layer_name)
            except Exception as e:
                self._log(f"<font color='orange'>AVISO: no se pudo añadir la capa de referencia "
                           f"'{layer_name}' al GeoPackage de auditoría: {e}</font>")

    def _write_layer_copy(self, source_layer, layer_name):
        """Escribe (crea o sobrescribe) UNA capa dentro del GeoPackage de
        auditoría ya existente, sin tocar el resto de capas del fichero
        (CreateOrOverwriteLayer). Devuelve True/False según el resultado."""
        if not source_layer or not source_layer.isValid():
            self._log(f"<font color='orange'>AVISO: la capa de referencia '{layer_name}' no está "
                       f"disponible o no es válida; se omite.</font>")
            return False

        if not os.path.exists(self.gpkg_path):
            # No debería ocurrir: _create_gpkg/_merge_into_gpkg ya han
            # creado el fichero con AUDIT_LAYER_NAME antes de llegar aquí.
            # Por seguridad, nunca se crea el .gpkg partiendo de una capa
            # de referencia (podría dejar el fichero sin la capa
            # principal de auditoría).
            self._log(f"<font color='orange'>AVISO: no existe aún el GeoPackage de auditoría; "
                       f"se omite la capa de referencia '{layer_name}'.</font>")
            return False

        options = QgsVectorFileWriter.SaveVectorOptions()
        options.driverName = "GPKG"
        options.layerName = layer_name
        # CreateOrOverwriteLayer: sustituye SOLO esta tabla dentro del
        # .gpkg si ya existía (p.ej. de una ejecución anterior), dejando
        # intactas AUDIT_LAYER_NAME y el resto de capas de referencia.
        options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteLayer

        result = QgsVectorFileWriter.writeAsVectorFormatV2(
            source_layer, self.gpkg_path, QgsCoordinateTransformContext(), options
        )
        # El código de error puede venir como int suelto o como primer
        # elemento de una tupla (error, mensaje[, ...]) según la versión de
        # QGIS: se maneja de forma tolerante para no depender de una firma
        # exacta.
        error_code = result[0] if isinstance(result, (tuple, list)) else result
        if error_code != QgsVectorFileWriter.NoError:
            error_msg = result[1] if isinstance(result, (tuple, list)) and len(result) > 1 else "motivo desconocido"
            self._log(f"<font color='orange'>AVISO: fallo al escribir la capa de referencia "
                       f"'{layer_name}' en el GeoPackage de auditoría ({error_msg}).</font>")
            return False

        self._log(f"AudiNOT: capa de referencia '{layer_name}' actualizada en el GeoPackage de "
                   f"auditoría ({source_layer.featureCount()} elemento(s)).")
        return True

    @staticmethod
    def _sanitize_layer_name(name):
        """Normaliza una clave de capa (p.ej. de AditService.adit_layers)
        a un nombre válido de tabla GeoPackage: solo alfanuméricos y
        guion bajo. Evita nombres vacíos o con caracteres que algunos
        clientes GPKG/SQLite no manejan bien sin escapar."""
        s = re.sub(r'[^0-9A-Za-z_]+', '_', str(name)).strip('_')
        return s or "SIN_NOMBRE"

    # ------------------------------------------------------------------
    # Fusión (upsert) preservando revisión humana
    # ------------------------------------------------------------------
    def _merge_into_gpkg(self, records, crs, report_id):
        layer = QgsVectorLayer(f"{self.gpkg_path}|layername={AUDIT_LAYER_NAME}", AUDIT_LAYER_NAME, "ogr")
        if not layer.isValid():
            # Nombre de capa por defecto distinto al esperado (p.ej. el
            # fichero se creó con otra herramienta): cae de vuelta al
            # gpkg sin indicar layername.
            layer = QgsVectorLayer(self.gpkg_path, AUDIT_LAYER_NAME, "ogr")
        if not layer.isValid():
            raise RuntimeError("No se pudo abrir el GeoPackage de auditoría existente para fusionar.")

        migrated = self._migrate_schema(layer)
        if migrated:
            # Reabrir la capa desde cero: el proveedor OGR/GeoPackage deja
            # sentencias SQL preparadas con el esquema ANTERIOR al ALTER
            # TABLE que acaba de ejecutar _migrate_schema. Si se sigue
            # usando esta misma instancia de capa para el commit de abajo,
            # los parámetros de la sentencia UPDATE quedan desalineados y
            # GDAL interpreta el desplazamiento como un intento de cambiar
            # el fid de cada feature (error "No está permitido cambiar la
            # ID de objeto..." repetido para TODAS las fincas). Abrir una
            # instancia nueva fuerza a OGR a releer la definición de
            # columnas ya actualizada antes de tocar ningún atributo.
            layer = QgsVectorLayer(f"{self.gpkg_path}|layername={AUDIT_LAYER_NAME}", AUDIT_LAYER_NAME, "ogr")
            if not layer.isValid():
                layer = QgsVectorLayer(self.gpkg_path, AUDIT_LAYER_NAME, "ogr")
            if not layer.isValid():
                raise RuntimeError("No se pudo reabrir el GeoPackage de auditoría tras migrar su esquema.")

        fields = layer.fields()
        now_iso = datetime.now().isoformat(timespec='seconds')

        # Cualquier campo llamado 'fid' que el proveedor GeoPackage/OGR
        # exponga en layer.fields() es, en realidad, la clave primaria de
        # la tabla, no un atributo de datos normal. NUNCA debe formar
        # parte de un cambio de atributos: si se "reescribe" (aunque sea
        # sin querer, al reconstruir la feature entera y dejarlo a NULL
        # porque ALL_FIELDS no lo define) GDAL lo interpreta como un
        # intento de cambiar el ID de objeto y rechaza el commit entero
        # con el error 'No está permitido cambiar la ID de objeto...'
        # -- para TODAS las features del lote, que es justo lo que se
        # observaba. Se evita del todo cambiando SOLO los atributos de
        # datos (uno a uno, por índice) y la geometría, sin tocar nunca
        # este campo ni reconstruir la feature completa.
        fid_idx = fields.indexFromName('fid')
        idx_no_presente = fields.indexFromName('no_presente_ultimo_calculo')

        # Índice de features existentes por audinot_id
        existing_by_id = {}
        for f in layer.getFeatures():
            existing_by_id[str(f['audinot_id'])] = f

        new_ids = {str(r['audinot_id']) for r in records}

        # Entradas de AudiNOT_Historial generadas por ESTE recálculo
        # (recalculo_metricas / aparicion / desaparicion). Se acumulan
        # aquí y se escriben en la tabla de historial DESPUÉS de cerrar
        # la sesión de edición de AUDIT_LAYER_NAME (add_historial_entries
        # abre su propia conexión a la misma tabla .gpkg; hacerlo
        # secuencialmente, no anidado, evita pisarse con el `with edit`
        # de arriba).
        historial_entries = []
        usuario = self._current_user()

        with edit(layer):
            for rec in records:
                aid = str(rec['audinot_id'])
                geom = rec.get('geom_d') or rec.get('geom_a')

                if aid in existing_by_id:
                    old_feat = existing_by_id[aid]
                    fid = old_feat.id()
                    prev_state = old_feat['revision_estado'] or ''
                    changed = self._metrics_changed(old_feat, rec)

                    preserve = {
                        'revision_estado': prev_state,
                        'revision_obs': old_feat['revision_obs'] or '',
                        'revision_fecha': old_feat['revision_fecha'],
                    }
                    attrs = self._record_to_attrs(fields, rec, report_id, now_iso, preserve_review=preserve)

                    # Si ya estaba revisada y las métricas relevantes
                    # cambiaron desde la última revisión, NO se borra la
                    # revisión (evita perder trabajo humano por
                    # sorpresa) pero se marca como desactualizada para
                    # que la Ficha 4 la resalte y el usuario decida si
                    # la vuelve a mirar.
                    idx_desact = fields.indexFromName('revision_desactualizada')
                    if idx_desact != -1 and idx_desact != fid_idx:
                        if prev_state and changed:
                            attrs[idx_desact] = True
                        elif not changed:
                            attrs[idx_desact] = False

                    # Changelog de historial ("recalculo_metricas"): SOLO
                    # para fincas que ya tenían una revisión humana (regla
                    # de ruido cerrada, ver diseno_historial_ficha4.md
                    # punto 5) -- para fincas sin revisar, el cambio de
                    # métricas entre ejecuciones es esperable. Usa un
                    # conjunto de campos "con sentido para el usuario"
                    # deliberadamente distinto (más amplio) que el que usa
                    # _metrics_changed para el aviso de desactualizada.
                    if prev_state:
                        diffs = self._diff_metrics(old_feat, rec)
                        if diffs:
                            # Un salto de línea real por campo cambiado (antes
                            # "; " todo en una sola línea): con varios campos a
                            # la vez, HistorialDialog._detalle_lines lo parte
                            # en pantalla/PDF como una línea por apartado en
                            # vez de un párrafo corrido. HistorialDialog
                            # también reconoce el "; " antiguo como fallback,
                            # así que el historial ya guardado con versiones
                            # previas del plugin se sigue mostrando bien.
                            detalle = "\n".join(f"{label}: {before} → {after}" for label, before, after in diffs)
                            historial_entries.append({
                                'audinot_id': aid, 'origen': 'recalculo_metricas',
                                'report_id': report_id, 'detalle': detalle, 'usuario': usuario,
                            })

                    # Aparición/desaparición (independiente de si hay
                    # revisión humana previa, a diferencia de lo anterior):
                    # solo por TRANSICIÓN respecto al último estado
                    # conocido persistido en el propio feature, no por
                    # comparación puntual contra la ejecución anterior --
                    # así una finca que sigue ausente (o sigue presente)
                    # varias ejecuciones seguidas no genera una entrada
                    # nueva cada vez (ver punto 9 del diseño).
                    if idx_no_presente != -1 and idx_no_presente != fid_idx:
                        old_no_presente = self._bool_field(old_feat['no_presente_ultimo_calculo'])
                        if old_no_presente:
                            attrs[idx_no_presente] = False
                            historial_entries.append({
                                'audinot_id': aid, 'origen': 'aparicion', 'report_id': report_id,
                                'detalle': 'Finca incorporada de nuevo al cálculo tras haber estado ausente.',
                                'usuario': usuario,
                            })

                    for idx, value in attrs.items():
                        if idx == fid_idx:
                            continue
                        layer.changeAttributeValue(fid, idx, value)

                    if geom is not None:
                        layer.changeGeometry(fid, QgsGeometry(geom))
                else:
                    new_feat = QgsFeature(fields)
                    if geom is not None:
                        new_feat.setGeometry(QgsGeometry(geom))
                    self._fill_feature_attrs(new_feat, fields, rec, report_id, now_iso, preserve_review=None)
                    layer.addFeature(new_feat)
                    # Alta nueva real (primera vez que se audita esta
                    # finca): no genera entrada de 'aparicion' -- eso
                    # queda reservado para una REAPARICIÓN tras haber
                    # estado ausente (rama de arriba).

            # Fincas que existían en la capa de auditoría pero ya no
            # aparecen en este cálculo (p.ej. cambiaron los filtros de
            # entrada): se conservan tal cual, no se borran nunca en
            # automático -- borrarlas sería destructivo para el
            # histórico de auditoría. Si se quiere depurar la capa, es
            # una acción manual del usuario desde QGIS. Aquí, además, se
            # detectan las que TRANSICIONAN a "ausente" por primera vez.
            #
            # Los recintos de infraestructura fija (estado ==
            # 'INFRAESTRUCTURA': VIALES/CURSOS AGUA/EDIFICACIONES/
            # EXCLUIDO, ver build_infra_records) quedan FUERA de esta
            # comprobación de continuidad: no son fincas que se den de
            # alta/baja entre ANTES y DESPUÉS, son recintos definidos por
            # rangos de nº de finca (Ficha 2/3) que pueden cambiar de
            # cálculo a cálculo (renumeración, cambio de rangos, etc.)
            # sin que eso sea una "baja" real que auditar. Su xID puede
            # incluso no coincidir de una ejecución a otra. Se limitan,
            # pues, a reflejar SIEMPRE el estado de DESPUÉS de ESTE
            # cálculo (arriba, en el upsert): si un xID de infraestructura
            # no reaparece, simplemente se deja de tocar (sin marcarlo
            # ausente ni generar entrada de historial).
            idx_estado = fields.indexFromName('estado')
            if idx_no_presente != -1 and idx_no_presente != fid_idx:
                for aid, old_feat in existing_by_id.items():
                    if aid in new_ids:
                        continue  # sigue presente, ya tratado arriba
                    if idx_estado != -1 and old_feat.attribute(idx_estado) == 'INFRAESTRUCTURA':
                        continue  # infraestructura fija: no se audita su desaparición
                    old_no_presente = self._bool_field(old_feat['no_presente_ultimo_calculo'])
                    if old_no_presente:
                        continue  # ya se registró la desaparición en una ejecución anterior
                    fid = old_feat.id()
                    layer.changeAttributeValue(fid, idx_no_presente, True)
                    historial_entries.append({
                        'audinot_id': aid, 'origen': 'desaparicion', 'report_id': report_id,
                        'detalle': 'Finca no incluida en el último cálculo.',
                        'usuario': usuario,
                    })

        layer = None  # cierra el datasource

        if historial_entries:
            try:
                self.add_historial_entries(historial_entries)
            except Exception as e:
                self._log(f"<font color='orange'>AVISO: no se pudo escribir el historial de este "
                           f"recálculo ({len(historial_entries)} entrada(s) perdida(s)): {e}</font>")

    def _migrate_schema(self, layer):
        """Añade a una capa de auditoría YA EXISTENTE (creada por una
        versión anterior del plugin) cualquier campo de ALL_FIELDS que
        todavía no tenga, sin tocar los que ya existen ni sus datos.

        Necesario porque `_merge_into_gpkg` hace upsert sobre el
        GeoPackage tal cual lo encuentra en disco: si simplemente se
        añaden columnas nuevas a ALL_FIELDS (p.ej. las superficies
        T24/GML) sin esta migración, `_fill_feature_attrs` las
        ignoraría en silencio (`fields.indexFromName` devolvería -1)
        en cualquier GeoPackage generado antes del cambio."""
        existing_names = set(layer.fields().names())
        missing = [(name, qtype, length) for name, qtype, length in ALL_FIELDS if name not in existing_names]
        if not missing:
            return False
        self._log(f"AudiNOT: migrando capa de auditoría existente, añadiendo {len(missing)} campo(s) nuevo(s): "
                   f"{', '.join(n for n, _, _ in missing)}")
        new_fields = []
        for name, qtype, length in missing:
            f = QgsField(name, qtype)
            if length and length > 0:
                f.setLength(length)
            new_fields.append(f)
        provider = layer.dataProvider()
        if not provider.addAttributes(new_fields):
            self._log("AVISO: no se pudieron añadir los campos nuevos al GeoPackage de auditoría existente "
                       f"({provider.lastError().message() if provider.lastError() else 'motivo desconocido'}).")
            layer.updateFields()
            return False
        layer.updateFields()
        return True

    def _metrics_changed(self, old_feat, rec):
        """Compara un pequeño subconjunto de campos "sensibles" para
        decidir si una finca ya revisada debe marcarse como
        desactualizada. No comparamos el JSON completo (cualquier
        redondeo distinto lo dispararía sin motivo real)."""
        keys = ['sup_d', 'var_sup', 'var_perim', 'notifica_param', 'notifica_legal', 'estado', 'val_gml_d_supera', 'val_limite_pct']
        for k in keys:
            old_v = old_feat[k]
            new_v = rec.get(k)
            if isinstance(old_v, float) and isinstance(new_v, float):
                if abs(old_v - new_v) > 0.005:
                    return True
            elif old_v != new_v:
                return True
        return False

    # Conjunto curado de campos "con sentido para el usuario" para el
    # changelog de historial (recalculo_metricas). Deliberadamente más
    # amplio y distinto del que usa _metrics_changed (ese solo decide si
    # avisar de "desactualizada"; este decide qué contar en el
    # historial). Se excluyen a propósito croquis_svg/audinot_json (se
    # regeneran siempre; compararlos generaría ruido en cada ejecución)
    # y metadatos como fecha_calculo/report_id. Ver
    # diseno_historial_ficha4.md, punto 5.
    _DIFF_METRIC_FIELDS = [
        ('titular_a', 'Titular Antes'), ('titular_d', 'Titular Después'),
        ('sup_a', 'Superficie Antes (m²)'), ('sup_d', 'Superficie Después (m²)'),
        ('var_sup', 'Δ Superficie (m²)'), ('var_perim', 'Δ Perímetro (m)'),
        ('n_partes_a', 'Nº partes Antes'), ('n_partes_d', 'Nº partes Después'),
        ('n_islas_delta', 'Δ islas/huecos'),
        ('notifica_param', 'Notifica (paramétrico)'), ('notifica_legal', 'Notifica (alternativo)'),
        ('val_pct_gml_a', '% Validación GML Antes'), ('val_pct_gml_d', '% Validación GML Después'),
        ('tipo_recinto', 'Tipo de recinto'), ('estado', 'Estado'),
        ('conclusion_param', 'Conclusión paramétrica'), ('conclusion_legal', 'Conclusión alternativa'),
    ]

    def _diff_metrics(self, old_feat, rec):
        """Versión "changelog" de _metrics_changed: en vez de un booleano,
        devuelve la lista de campos de _DIFF_METRIC_FIELDS que realmente
        cambiaron entre old_feat (lo que había antes de este cálculo) y
        rec (lo recién calculado), como tuplas (etiqueta, antes, después)
        ya formateadas como texto legible. Para floats se usa la misma
        tolerancia que _metrics_changed, para no disparar por
        redondeos de las operaciones de solape del motor GIS."""
        changes = []
        for field_name, label in self._DIFF_METRIC_FIELDS:
            old_v = old_feat[field_name]
            old_v = None if old_v == QGIS_NULL else old_v
            new_v = rec.get(field_name)

            if isinstance(old_v, float) or isinstance(new_v, float):
                try:
                    old_f = float(old_v) if old_v is not None else None
                    new_f = float(new_v) if new_v is not None else None
                except (TypeError, ValueError):
                    old_f, new_f = old_v, new_v
                if old_f is None and new_f is None:
                    continue
                if old_f is not None and new_f is not None and abs(old_f - new_f) <= 0.005:
                    continue
            elif old_v == new_v:
                continue

            changes.append((label, self._fmt_diff_value(old_v), self._fmt_diff_value(new_v)))
        return changes

    @staticmethod
    def _fmt_diff_value(v):
        if v is None or v == QGIS_NULL:
            return '?'
        if isinstance(v, bool):
            return 'SÍ' if v else 'NO'
        if isinstance(v, float):
            return f"{v:g}"
        return str(v)

    def _record_to_attrs(self, fields, rec, report_id, now_iso, preserve_review):
        """Traduce un `rec` (dict de ReportService) a un diccionario
        {índice_de_campo: valor}, resuelto por nombre contra `fields`
        (así que si un campo no existe en `fields` -p.ej. un GeoPackage
        antiguo sin migrar aún- simplemente se omite). Deliberadamente
        NUNCA incluye un posible campo 'fid': quien llame a esto para
        actualizar una feature existente debe descartar ese índice antes
        de aplicar los cambios (ver comentario en _merge_into_gpkg)."""
        attrs = {}

        def setf(name, value):
            idx = fields.indexFromName(name)
            if idx != -1 and fields.field(idx).name().lower() != 'fid':
                attrs[idx] = value

        setf('audinot_id', rec.get('audinot_id'))
        setf('estado', rec.get('estado'))
        setf('tipo_recinto', rec.get('tipo_recinto', 'PARCELA'))
        setf('titular_a', rec.get('titular_a'))
        setf('titular_d', rec.get('titular_d'))
        setf('titular_cambia', bool(rec.get('titular_cambia')))
        setf('sup_a', rec.get('sup_a'))
        setf('sup_d', rec.get('sup_d'))
        setf('var_sup', rec.get('var_sup'))
        setf('var_sup_pct', rec.get('var_sup_pct'))
        setf('var_perim', rec.get('var_perim'))
        setf('n_partes_a', rec.get('n_partes_a'))
        setf('n_partes_d', rec.get('n_partes_d'))
        setf('n_islas_delta', rec.get('n_islas_delta'))
        setf('notifica_param', bool(rec.get('notifica_param')))
        setf('notifica_legal', bool(rec.get('notifica_legal')))
        setf('notif_divergen', bool(rec.get('notif_divergen')))
        setf('n_alertas', rec.get('n_alertas'))
        setf('sup_t24_a', rec.get('sup_t24_a'))
        setf('sup_t24_d', rec.get('sup_t24_d'))
        setf('sup_gml_a', rec.get('sup_gml_a'))
        setf('sup_gml_d', rec.get('sup_gml_d'))
        setf('val_pct_a', rec.get('val_pct_a'))
        setf('val_pct_d', rec.get('val_pct_d'))
        setf('val_pct_gml_a', rec.get('val_pct_gml_a'))
        setf('val_pct_gml_d', rec.get('val_pct_gml_d'))
        setf('val_gml_d_supera', bool(rec.get('val_gml_d_supera')))
        setf('val_limite_pct', rec.get('val_limite_pct'))
        setf('conclusion_param', rec.get('conclusion_param'))
        setf('conclusion_legal', rec.get('conclusion_legal'))
        setf('croquis_svg', rec.get('croquis_svg'))
        setf('audinot_json', rec.get('audinot_json'))
        setf('report_id', report_id)
        setf('fecha_calculo', now_iso)

        if preserve_review:
            setf('revision_estado', preserve_review.get('revision_estado', ''))
            setf('revision_obs', preserve_review.get('revision_obs', ''))
            setf('revision_fecha', preserve_review.get('revision_fecha'))
        else:
            setf('revision_estado', rec.get('revision_estado', ''))
            setf('revision_obs', rec.get('revision_obs', ''))
            setf('revision_fecha', rec.get('revision_fecha'))
            setf('revision_desactualizada', False)
            # Finca nueva: por definición está presente en ESTE cálculo.
            setf('no_presente_ultimo_calculo', False)

        return attrs

    def _fill_feature_attrs(self, feat, fields, rec, report_id, now_iso, preserve_review):
        """Variante para features NUEVAS (INSERT, vía QgsFeature +
        addFeature/writer.addFeature): aquí sí es seguro fijar todos los
        atributos sobre el objeto QgsFeature de una vez, porque no hay
        ninguna feature previa en el proveedor cuyo fid pueda
        confundirse con un cambio de ID."""
        attrs = self._record_to_attrs(fields, rec, report_id, now_iso, preserve_review)
        for idx, value in attrs.items():
            feat.setAttribute(idx, value)

    # ------------------------------------------------------------------
    # Carga de la capa (para la Ficha 4) + simbología "de un vistazo"
    # ------------------------------------------------------------------
    def load_layer(self, add_to_project=True):
        if not os.path.exists(self.gpkg_path):
            return None
        layer = QgsVectorLayer(f"{self.gpkg_path}|layername={AUDIT_LAYER_NAME}", AUDIT_LAYER_NAME, "ogr")
        if not layer.isValid():
            layer = QgsVectorLayer(self.gpkg_path, AUDIT_LAYER_NAME, "ogr")
        if not layer.isValid():
            return None

        # Migración de esquema TAMBIÉN aquí, no solo dentro de
        # _merge_into_gpkg: antes esto solo se ejecutaba al re-ejecutar el
        # análisis, así que un .gpkg generado con una versión anterior del
        # plugin y simplemente RE-ABIERTO (proyecto guardado, nueva sesión
        # de QGIS, sin recalcular nada) se quedaba sin los campos nuevos
        # (p.ej. no_presente_ultimo_calculo) y cualquier acceso a ellos
        # reventaba con KeyError en vez de migrarse solo. Ver
        # _migrate_schema: no hace nada si ya está al día.
        self._migrate_schema(layer)

        # Igual razón que la migración de arriba: si el historial todavía
        # no existe en este .gpkg, se crea (y se siembra con las
        # revisiones ya existentes, ver _seed_historial_from_existing_reviews)
        # en cuanto se ABRE la capa, no solo cuando el usuario guarda la
        # primera revisión nueva -- así "Ver historial" ya muestra algo
        # útil desde la primera vez que se abre con esta versión.
        try:
            self._ensure_historial_layer()
        except Exception as e:
            self._log(f"<font color='orange'>AVISO: no se pudo preparar la tabla de historial: {e}</font>")

        self.apply_symbology(layer)

        if add_to_project:
            existing = QgsProject.instance().mapLayersByName(layer.name())
            if existing:
                # Evita acumular instancias duplicadas/obsoletas de la
                # misma capa en el proyecto entre recargas sucesivas (cada
                # una mantiene su propia conexión GDAL abierta al mismo
                # .gpkg, lo que en GeoPackage/SQLite -especialmente en
                # Windows- puede acabar bloqueando el fichero hasta
                # cerrar QGIS). Se retiran las anteriores antes de añadir
                # la recién abierta y ya migrada.
                QgsProject.instance().removeMapLayers([lyr.id() for lyr in existing])
            QgsProject.instance().addMapLayer(layer)

        return layer

    def _list_gpkg_layers(self):
        """Enumera todas las tablas de features del GeoPackage de auditoría
        consultando directamente su metadato interno 'gpkg_contents' (todo
        GeoPackage es, por especificación, un SQLite normal). Se prefiere a
        cualquier API de sub-capas de QGIS/OGR porque el formato exacto de
        esas cadenas varía entre versiones de QGIS; leer 'gpkg_contents' es
        estable y no depende de la versión del plugin OGR instalado."""
        if not os.path.exists(self.gpkg_path):
            return []
        try:
            conn = sqlite3.connect(self.gpkg_path)
            try:
                cur = conn.cursor()
                cur.execute("SELECT table_name FROM gpkg_contents WHERE data_type = 'features'")
                return [row[0] for row in cur.fetchall()]
            finally:
                conn.close()
        except Exception as e:
            self._log(f"<font color='orange'>AVISO: no se pudo enumerar las capas del GeoPackage de "
                       f"auditoría: {e}</font>")
            return []

    def load_historial_layer(self, add_to_project=True):
        """Abre -y, si add_to_project, añade al proyecto- la tabla
        AudiNOT_Historial como una tabla más de QGIS. Al no tener
        geometría aparece en el panel de Capas con icono de tabla de
        atributos (no en el lienzo), y es editable a mano desde QGIS
        igual que cualquier tabla de un GeoPackage (activar edición,
        tocar una celda, guardar) por si alguna vez hace falta corregir
        o completar algo a mano.

        Crea la tabla (y la siembra con las revisiones ya existentes, ver
        _seed_historial_from_existing_reviews) si todavía no existe --
        llamar a esto es lo que la hace visible en el panel de Capas
        aunque el usuario no haya guardado ninguna revisión todavía en
        esta sesión. Devuelve None si no se pudo crear/abrir."""
        try:
            self._ensure_historial_layer()
        except Exception as e:
            self._log(f"<font color='orange'>AVISO: no se pudo preparar la tabla de historial: {e}</font>")
            return None

        layer = QgsVectorLayer(f"{self.gpkg_path}|layername={HISTORIAL_LAYER_NAME}", HISTORIAL_LAYER_NAME, "ogr")
        if not layer.isValid():
            return None

        if add_to_project:
            existing = QgsProject.instance().mapLayersByName(layer.name())
            if existing:
                # Igual razón que en load_layer(): evita acumular
                # instancias duplicadas de la misma tabla entre recargas.
                QgsProject.instance().removeMapLayers([lyr.id() for lyr in existing])
            QgsProject.instance().addMapLayer(layer)

        return layer

    def load_reference_layers(self, add_to_project=True, keep_audit_layer_on_top=True):
        """Carga en el proyecto TODAS las capas de referencia complementarias
        presentes en el GeoPackage de auditoría (ANTES_ok, DESPUES_ok,
        ADIT_*...), es decir, todas las tablas del .gpkg salvo
        AUDIT_LAYER_NAME. Pensado para llamarse justo después de
        load_layer(), de modo que la Ficha 4 muestre en el lienzo tanto la
        capa auditable como todo su contexto, sin que el usuario tenga que
        ir a buscar los shapefiles sueltos ni añadir las capas a mano.

        Si keep_audit_layer_on_top es True (por defecto), al terminar se
        sube AUDIT_LAYER_NAME a la cima del árbol de capas: es la que lleva
        la simbología de semáforo de revisión y debe verse siempre por
        encima de sus capas de referencia, no taparse por ellas.

        Devuelve la lista de QgsVectorLayer cargadas (puede estar vacía si
        no hay capas de referencia en este GeoPackage)."""
        names = [n for n in self._list_gpkg_layers() if n != AUDIT_LAYER_NAME]
        loaded = []
        for name in names:
            try:
                layer = QgsVectorLayer(f"{self.gpkg_path}|layername={name}", name, "ogr")
                if not layer.isValid():
                    self._log(f"<font color='orange'>AVISO: no se pudo abrir la capa de referencia "
                               f"'{name}' del GeoPackage de auditoría.</font>")
                    continue
                if add_to_project:
                    # Igual criterio que load_layer(): si ya había una
                    # instancia de esta capa en el proyecto (p.ej. de una
                    # recarga anterior, o porque el usuario le tocó el
                    # estilo/leyenda a mano desde Propiedades de la capa),
                    # se retira ANTES de añadir la recién abierta. Así
                    # "↻ Recargar" siempre deja las capas de referencia con
                    # su estado tal cual viene del GeoPackage, deshaciendo
                    # cualquier cambio de simbología que se le haya hecho
                    # en el lienzo -- no solo releyendo los datos.
                    existing = QgsProject.instance().mapLayersByName(layer.name())
                    if existing:
                        QgsProject.instance().removeMapLayers([lyr.id() for lyr in existing])
                    QgsProject.instance().addMapLayer(layer)
                loaded.append(layer)
            except Exception as e:
                self._log(f"<font color='orange'>AVISO: fallo al cargar la capa de referencia "
                           f"'{name}' del GeoPackage de auditoría: {e}</font>")

        if add_to_project and keep_audit_layer_on_top:
            self._raise_audit_layer_to_top()

        return loaded

    def _raise_audit_layer_to_top(self):
        """Mueve AUDIT_LAYER_NAME a la cima del árbol de capas del proyecto,
        por encima de las capas de referencia recién cargadas, para que su
        simbología de semáforo de revisión no quede tapada por ellas."""
        try:
            existing = QgsProject.instance().mapLayersByName(AUDIT_LAYER_NAME)
            if not existing:
                return
            root = QgsProject.instance().layerTreeRoot()
            node = root.findLayer(existing[0].id())
            if node is None or node.parent() is None:
                return
            parent = node.parent()
            clone = node.clone()
            parent.insertChildNode(0, clone)
            parent.removeChildNode(node)
        except Exception:
            pass

    def apply_symbology(self, layer):
        """Renderer por reglas con dos grupos:

        1. Recintos de infraestructura fija de DESPUÉS ('tipo_recinto' de
           build_infra_records: VIALES/CURSOS AGUA/EDIFICACIONES/EXCLUIDO,
           Identificación por REC/Rangos de la Ficha 3), cada uno con su
           color fijo -- no dependen de revisión humana, son contexto, no
           fincas a auditar:
             - VIALES: gris claro, relleno sólido.
             - CURSOS AGUA: cian, relleno sólido.
             - EDIFICACIONES: fondo hueco (sin relleno de base) con
               rayado diagonal en rojo claro.
             - EXCLUIDO: gris oscuro, relleno sólido.

        2. Fincas ('tipo_recinto' = 'PARCELA', o NULL en una capa migrada
           desde una versión anterior sin este campo): el semáforo de
           siempre por 'revision_estado' (gris/rojo/verde), con el mismo
           BORDE grueso data-defined que ya resaltaba el error de
           validación %GML de Después ('val_gml_d_supera'/
           'val_pct_gml_d'): naranja si el error es positivo, morado si
           es negativo, borde fino normal si no supera el umbral.
        """
        root_rule = QgsRuleBasedRenderer.Rule(None)

        # --- 1. Infraestructura fija --------------------------------------
        infra_specs = [
            ('VIALES', "\"tipo_recinto\" = 'VIALES'", '#d9d9d9', None),
            ('CURSOS AGUA', "\"tipo_recinto\" = 'CURSOS AGUA'", '#00bcd4', None),
            ('EDIFICACIONES', "\"tipo_recinto\" = 'EDIFICACIONES'", None, '#ff8a80'),
            ('EXCLUIDO', "\"tipo_recinto\" = 'EXCLUIDO'", '#616161', None),
        ]
        for label, expr, fill_color, hatch_color in infra_specs:
            symbol = QgsSymbol.defaultSymbol(layer.geometryType())
            if hatch_color:
                # Fondo hueco: la capa de relleno base se deja sin brocha
                # (NoBrush) para que no rellene de color; se le añade
                # encima una segunda capa con el patrón rayado diagonal,
                # sin borde propio (para no duplicar el contorno de la
                # capa base).
                base_layer = symbol.symbolLayer(0)
                base_layer.setBrushStyle(Qt.NoBrush)
                hatch_layer = QgsSimpleFillSymbolLayer(QColor(hatch_color))
                hatch_layer.setBrushStyle(Qt.BDiagPattern)
                hatch_layer.setStrokeStyle(Qt.NoPen)
                symbol.appendSymbolLayer(hatch_layer)
            else:
                symbol.setColor(QColor(fill_color))
                symbol.setOpacity(0.75)
            rule = QgsRuleBasedRenderer.Rule(symbol, filterExp=expr, label=label)
            root_rule.appendChild(rule)

        # --- 2. Fincas: semáforo de revisión + resaltado %GML --------------
        outline_color_expr = (
            "CASE "
            "WHEN \"val_gml_d_supera\" AND \"val_pct_gml_d\" > 0 THEN '#e67e22' "
            "WHEN \"val_gml_d_supera\" AND \"val_pct_gml_d\" < 0 THEN '#8e44ad' "
            "ELSE '#000000' "
            "END"
        )
        outline_width_expr = 'CASE WHEN "val_gml_d_supera" THEN 1.4 ELSE 0.26 END'
        parcela_filter = "\"tipo_recinto\" IS NULL OR \"tipo_recinto\" = 'PARCELA'"

        specs = [
            ('', 'Sin revisar', '#9e9e9e'),
            ('rev', 'Marcada para revisar', '#2980b9'),
            ('si', 'Notifica', '#c0392b'),
            ('no', 'No notifica', '#27ae60'),
        ]
        for value, label, color in specs:
            symbol = QgsSymbol.defaultSymbol(layer.geometryType())
            symbol.setColor(QColor(color))
            symbol.setOpacity(0.55)
            outline_layer = symbol.symbolLayer(0)
            if outline_layer is not None:
                outline_layer.setDataDefinedProperty(
                    QgsSymbolLayer.PropertyStrokeColor, QgsProperty.fromExpression(outline_color_expr))
                outline_layer.setDataDefinedProperty(
                    QgsSymbolLayer.PropertyStrokeWidth, QgsProperty.fromExpression(outline_width_expr))
            expr = f'({parcela_filter}) AND "revision_estado" = \'{value}\''
            rule = QgsRuleBasedRenderer.Rule(symbol, filterExp=expr, label=label)
            root_rule.appendChild(rule)

        renderer = QgsRuleBasedRenderer(root_rule)
        layer.setRenderer(renderer)
        layer.triggerRepaint()

    # ------------------------------------------------------------------
    # Identidad de usuario (historial)
    # ------------------------------------------------------------------
    @staticmethod
    def _bool_field(value):
        """Interpreta un valor de campo booleano de PyQGIS (que puede ser
        el sentinel NULL, no el None de Python) como bool de Python."""
        if value is None or value == QGIS_NULL:
            return False
        return bool(value)

    @staticmethod
    def _current_user():
        """`usuario/equipo`, sin ajuste configurable (ver
        diseno_historial_ficha4.md, punto 3): en teletrabajo una persona
        puede tener el mismo nombre de usuario en su equipo personal y en
        el del trabajo, y sin el nombre de equipo esas dos identidades
        serían indistinguibles en el historial."""
        import getpass
        import socket
        try:
            return f"{getpass.getuser()}/{socket.gethostname()}"
        except Exception:
            return "desconocido/desconocido"

    # ------------------------------------------------------------------
    # Tabla de historial (AudiNOT_Historial): creación perezosa + escritura
    # ------------------------------------------------------------------
    def _gpkg_has_layer(self, name):
        """Comprueba si el .gpkg de auditoría ya contiene una tabla con
        ese nombre (de cualquier data_type: 'features' o 'attributes'),
        consultando 'gpkg_contents' directamente -- igual razón que
        _list_gpkg_layers: estable frente a variaciones de versión de
        QGIS/GDAL."""
        if not os.path.exists(self.gpkg_path):
            return False
        try:
            conn = sqlite3.connect(self.gpkg_path)
            try:
                cur = conn.cursor()
                cur.execute("SELECT 1 FROM gpkg_contents WHERE table_name = ?", (name,))
                return cur.fetchone() is not None
            finally:
                conn.close()
        except Exception:
            return False

    def _ensure_historial_layer(self):
        """Crea la tabla AudiNOT_Historial (sin geometría, tabla de
        atributos pura del GeoPackage) la primera vez que se necesita
        escribir en ella. Si ya existe, no hace nada. El historial
        "empieza a existir" a partir de la primera revisión/recálculo
        hecho con esta versión del plugin; no hay entradas retroactivas
        (ver diseno_historial_ficha4.md, punto 8)."""
        if self._gpkg_has_layer(HISTORIAL_LAYER_NAME):
            return

        fields = QgsFields()
        for name, qtype, length in HISTORIAL_FIELDS:
            f = QgsField(name, qtype)
            if length and length > 0:
                f.setLength(length)
            fields.append(f)

        options = QgsVectorFileWriter.SaveVectorOptions()
        options.driverName = "GPKG"
        options.layerName = HISTORIAL_LAYER_NAME
        if os.path.exists(self.gpkg_path):
            options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteLayer

        writer = QgsVectorFileWriter.create(
            self.gpkg_path, fields, QgsWkbTypes.NoGeometry, QgsCoordinateReferenceSystem(),
            QgsCoordinateTransformContext(), options
        )
        if writer is None or writer.hasError() != QgsVectorFileWriter.NoError:
            err = writer.errorMessage() if writer is not None else "motivo desconocido"
            raise RuntimeError(f"No se pudo crear la tabla de historial '{HISTORIAL_LAYER_NAME}': {err}")
        del writer  # fuerza el flush/cierre

        self._seed_historial_from_existing_reviews()

    def _seed_historial_from_existing_reviews(self):
        """Se ejecuta UNA sola vez, justo al crear AudiNOT_Historial por
        primera vez sobre un .gpkg que ya traía revisiones humanas hechas
        con una versión del plugin anterior al historial. Por cada finca
        que ya tuviera una decisión tomada (revision_estado no vacío),
        añade una entrada 'semilla' con el estado actual y CUÁNDO se
        guardó por última vez (revision_fecha, que sí existía ya).

        Deliberadamente NO puede reconstruir ni quién lo hizo (no se
        guardaba usuario/equipo antes de esto) ni el estado anterior a
        esa revisión (el sistema antiguo solo guardaba el último valor,
        no una secuencia de cambios) -- por eso queda marcada con su
        propio origen ('migracion_inicial') y usuario
        'desconocido/desconocido' explícito, para que nunca se confunda
        con una revisión real trazada con el historial ya activo."""
        if not self._gpkg_has_layer(AUDIT_LAYER_NAME):
            return
        layer = QgsVectorLayer(f"{self.gpkg_path}|layername={AUDIT_LAYER_NAME}", AUDIT_LAYER_NAME, "ogr")
        if not layer.isValid():
            return

        req = QgsFeatureRequest().setFilterExpression("revision_estado IS NOT NULL AND revision_estado != ''")
        seed_entries = []
        for f in layer.getFeatures(req):
            seed_entries.append({
                'audinot_id': f['audinot_id'],
                'fecha': f['revision_fecha'] or '',
                'usuario': 'desconocido/desconocido',
                'origen': 'migracion_inicial',
                'report_id': None,
                'estado_anterior': '',
                'estado_nuevo': f['revision_estado'] or '',
                'obs_anterior': '',
                'obs_nueva': f['revision_obs'] or '',
                'detalle': 'Estado capturado al activar el historial: revisión hecha con una '
                           'versión anterior del plugin, sin usuario ni secuencia de cambios '
                           'disponibles.',
            })
        layer = None

        if seed_entries:
            self._log(f"AudiNOT: historial activado -- se han capturado {len(seed_entries)} "
                       f"revisión(es) previa(s) ya existente(s) como estado inicial.")
            self.add_historial_entries(seed_entries)

    def add_historial_entries(self, entries):
        """Añade VARIAS filas a AudiNOT_Historial de una sola vez (abre la
        tabla una única vez y hace un único commit), pensado para
        acciones masivas que tocan muchas fincas de golpe sin penalizar
        con N aperturas/commits del datasource. `entries`: lista de
        dicts con claves de HISTORIAL_FIELDS (todas opcionales salvo
        'audinot_id' y 'origen'); 'usuario' por defecto es el usuario/
        equipo actual si no se indica."""
        if not entries:
            return
        self._ensure_historial_layer()

        layer = QgsVectorLayer(f"{self.gpkg_path}|layername={HISTORIAL_LAYER_NAME}", HISTORIAL_LAYER_NAME, "ogr")
        if not layer.isValid():
            raise RuntimeError("No se pudo abrir la tabla de historial para escribir en ella.")

        fields = layer.fields()
        now_iso = datetime.now().isoformat(timespec='seconds')
        default_user = self._current_user()

        was_editable = layer.isEditable()
        if not was_editable:
            layer.startEditing()

        for entry in entries:
            feat = QgsFeature(fields)
            values = {
                'audinot_id': str(entry.get('audinot_id', '')),
                'fecha': entry.get('fecha') or now_iso,
                'usuario': entry.get('usuario') or default_user,
                'origen': entry.get('origen', ''),
                'report_id': entry.get('report_id') or '',
                'estado_anterior': entry.get('estado_anterior') or '',
                'estado_nuevo': entry.get('estado_nuevo') or '',
                'obs_anterior': entry.get('obs_anterior') or '',
                'obs_nueva': entry.get('obs_nueva') or '',
                'detalle': entry.get('detalle') or '',
            }
            for name, value in values.items():
                idx = fields.indexFromName(name)
                if idx != -1:
                    feat.setAttribute(idx, value)
            layer.addFeature(feat)

        layer.commitChanges()
        if was_editable:
            layer.startEditing()
        layer = None

    def add_historial_entry(self, **kwargs):
        """Variante para UNA sola entrada; ver add_historial_entries."""
        self.add_historial_entries([kwargs])

    def get_historial_for_finca(self, audinot_id):
        """Devuelve todas las entradas de AudiNOT_Historial de una finca,
        como lista de dicts (claves de HISTORIAL_FIELDS), ordenadas por
        fecha descendente (más reciente primero). Devuelve [] si la
        tabla de historial todavía no existe (p.ej. .gpkg migrado desde
        una versión anterior del plugin, sin revisiones/recálculos aún
        hechos con la versión nueva)."""
        if not self._gpkg_has_layer(HISTORIAL_LAYER_NAME):
            return []
        layer = QgsVectorLayer(f"{self.gpkg_path}|layername={HISTORIAL_LAYER_NAME}", HISTORIAL_LAYER_NAME, "ogr")
        if not layer.isValid():
            return []

        field_names = [name for name, _, _ in HISTORIAL_FIELDS]
        target = str(audinot_id)
        entries = []
        for f in layer.getFeatures():
            if str(f['audinot_id']) != target:
                continue
            entries.append({name: (f[name] if f[name] != QGIS_NULL else '') for name in field_names})
        entries.sort(key=lambda e: e.get('fecha') or '', reverse=True)
        return entries

    def get_last_recalculo_detalle(self, audinot_id):
        """Detalle textual del último evento 'recalculo_metricas'
        registrado para una finca, o '' si no hay ninguno todavía (usado
        por el icono ⚠ de la Ficha 4, ver btn_desact_warning /
        _show_desact_warning en tab_audit.py)."""
        for entry in self.get_historial_for_finca(audinot_id):
            if entry.get('origen') == 'recalculo_metricas':
                return entry.get('detalle') or ''
        return ''

    # ------------------------------------------------------------------
    # Guardar una decisión de revisión (llamado desde la Ficha 4) -- punto
    # de entrada ÚNICO para toda revisión humana, para que quede siempre
    # trazada en AudiNOT_Historial (ver diseno_historial_ficha4.md, punto 4)
    # ------------------------------------------------------------------
    def save_review_with_history(self, layer, feature_id, estado_nuevo, obs_nueva, origen):
        """estado_nuevo: '', 'si', 'no', 'rev'. origen: 'panel' /
        'doble_clic' (llamadas individuales desde la Ficha 4). Si ni el
        estado ni la observación cambian de verdad respecto a lo que ya
        había, no se toca la capa ni se genera entrada de historial
        (evita ruido si el usuario guarda sin cambiar nada). Devuelve
        True si se aplicó el cambio, False si no había nada que
        guardar."""
        feat = layer.getFeature(feature_id)
        estado_anterior = feat['revision_estado'] or ''
        obs_anterior = feat['revision_obs'] or ''
        obs_nueva = obs_nueva or ''

        if estado_anterior == estado_nuevo and obs_anterior.strip() == obs_nueva.strip():
            return False

        fields = layer.fields()
        idx_estado = fields.indexFromName('revision_estado')
        idx_obs = fields.indexFromName('revision_obs')
        idx_fecha = fields.indexFromName('revision_fecha')
        idx_desact = fields.indexFromName('revision_desactualizada')

        now_iso = datetime.now().isoformat(timespec='seconds')

        was_editable = layer.isEditable()
        if not was_editable:
            layer.startEditing()

        layer.changeAttributeValue(feature_id, idx_estado, estado_nuevo)
        layer.changeAttributeValue(feature_id, idx_obs, obs_nueva)
        layer.changeAttributeValue(feature_id, idx_fecha, now_iso)
        if idx_desact != -1:
            layer.changeAttributeValue(feature_id, idx_desact, False)

        layer.commitChanges()
        if was_editable:
            layer.startEditing()

        # report_id=None: NULL en revisión humana (solo se guarda para
        # eventos de recálculo/aparición/desaparición, ver esquema).
        self.add_historial_entry(
            audinot_id=feat['audinot_id'], origen=origen, report_id=None,
            estado_anterior=estado_anterior, estado_nuevo=estado_nuevo,
            obs_anterior=obs_anterior, obs_nueva=obs_nueva,
        )
        return True

    # ------------------------------------------------------------------
    # Acciones masivas (botones sobre la lista de recintos de la Ficha 4)
    # ------------------------------------------------------------------
    def bulk_mark_pending_no_notificar(self, layer, observacion):
        """Marca como NO NOTIFICAR (con la observación automática que se
        le pase) todas las fincas que sigan 'Sin revisar'
        (revision_estado vacío o NULL). No toca las que ya tengan una
        decisión (NOTIFICAR o NO NOTIFICAR) tomada por el usuario.
        Genera UNA entrada de historial POR FINCA tocada (no una entrada
        agregada), para no perder trazabilidad individual. Devuelve el
        número de fincas modificadas."""
        parcela_filter = "(tipo_recinto IS NULL OR tipo_recinto = 'PARCELA')"
        fields = layer.fields()
        idx_estado = fields.indexFromName('revision_estado')
        idx_obs = fields.indexFromName('revision_obs')
        idx_fecha = fields.indexFromName('revision_fecha')
        idx_desact = fields.indexFromName('revision_desactualizada')

        req = QgsFeatureRequest().setFilterExpression(
            f"{parcela_filter} AND (revision_estado IS NULL OR revision_estado = '')"
        )
        # NoGeometry: solo hacen falta los atributos (audinot_id,
        # revision_estado, revision_obs) para el cambio y el historial.
        req.setFlags(QgsFeatureRequest.NoGeometry)
        targets = list(layer.getFeatures(req))
        if not targets:
            return 0

        now_iso = datetime.now().isoformat(timespec='seconds')
        usuario = self._current_user()
        was_editable = layer.isEditable()
        if not was_editable:
            layer.startEditing()

        historial_entries = []
        for f in targets:
            fid = f.id()
            estado_anterior = f['revision_estado'] or ''
            obs_anterior = f['revision_obs'] or ''
            layer.changeAttributeValue(fid, idx_estado, 'no')
            layer.changeAttributeValue(fid, idx_obs, observacion)
            layer.changeAttributeValue(fid, idx_fecha, now_iso)
            if idx_desact != -1:
                layer.changeAttributeValue(fid, idx_desact, False)
            historial_entries.append({
                'audinot_id': f['audinot_id'], 'origen': 'bulk_no_notificar', 'report_id': None,
                'estado_anterior': estado_anterior, 'estado_nuevo': 'no',
                'obs_anterior': obs_anterior, 'obs_nueva': observacion, 'usuario': usuario,
            })

        layer.commitChanges()
        if was_editable:
            layer.startEditing()

        self.add_historial_entries(historial_entries)
        return len(historial_entries)

    def bulk_reset_all_to_sin_revisar(self, layer):
        """Pone TODAS las fincas en estado 'Sin revisar', borrando
        revision_estado / revision_obs / revision_fecha /
        revision_desactualizada de cada una (pierde por completo
        cualquier decisión y observación tomada hasta ahora). Genera UNA
        entrada de historial POR FINCA que de verdad tuviera algo que
        perder (regla de ruido: sin cambio real, sin entrada) -- las que
        ya estaban 'Sin revisar' no generan entrada aunque se les
        reescriban los mismos valores en blanco. Devuelve el número de
        fincas TOCADAS (igual semántica que antes de tener historial)."""
        parcela_filter = "(tipo_recinto IS NULL OR tipo_recinto = 'PARCELA')"
        fields = layer.fields()
        idx_estado = fields.indexFromName('revision_estado')
        idx_obs = fields.indexFromName('revision_obs')
        idx_fecha = fields.indexFromName('revision_fecha')
        idx_desact = fields.indexFromName('revision_desactualizada')

        req = QgsFeatureRequest().setFilterExpression(parcela_filter)
        req.setFlags(QgsFeatureRequest.NoGeometry)
        targets = list(layer.getFeatures(req))
        if not targets:
            return 0

        usuario = self._current_user()
        was_editable = layer.isEditable()
        if not was_editable:
            layer.startEditing()

        historial_entries = []
        for f in targets:
            fid = f.id()
            estado_anterior = f['revision_estado'] or ''
            obs_anterior = f['revision_obs'] or ''
            layer.changeAttributeValue(fid, idx_estado, '')
            layer.changeAttributeValue(fid, idx_obs, '')
            layer.changeAttributeValue(fid, idx_fecha, None)
            if idx_desact != -1:
                layer.changeAttributeValue(fid, idx_desact, False)
            if estado_anterior != '' or obs_anterior.strip() != '':
                historial_entries.append({
                    'audinot_id': f['audinot_id'], 'origen': 'bulk_reset', 'report_id': None,
                    'estado_anterior': estado_anterior, 'estado_nuevo': '',
                    'obs_anterior': obs_anterior, 'obs_nueva': '', 'usuario': usuario,
                })

        layer.commitChanges()
        if was_editable:
            layer.startEditing()

        self.add_historial_entries(historial_entries)
        return len(targets)

    def bulk_verify_desactualizadas(self, layer):
        """Da por buenas (retira el aviso de "desactualizada") todas las
        fincas que ya tienen una decisión tomada (revision_estado != '')
        pero cuya geometría/métricas cambiaron desde esa revisión
        (revision_desactualizada = 1). NO toca revision_estado ni
        revision_obs: solo baja el flag de aviso, asumiendo la decisión
        ya tomada como válida frente a los datos actuales. Genera UNA
        entrada de historial POR FINCA tocada (mismo estado antes y
        después; el cambio real se deja constancia en 'detalle').
        Devuelve el número de fincas tocadas."""
        parcela_filter = "(tipo_recinto IS NULL OR tipo_recinto = 'PARCELA')"
        fields = layer.fields()
        idx_desact = fields.indexFromName('revision_desactualizada')
        if idx_desact == -1:
            return 0

        req = QgsFeatureRequest().setFilterExpression(
            f"{parcela_filter} AND revision_desactualizada = 1 AND revision_estado != ''"
        )
        req.setFlags(QgsFeatureRequest.NoGeometry)
        targets = list(layer.getFeatures(req))
        if not targets:
            return 0

        usuario = self._current_user()
        was_editable = layer.isEditable()
        if not was_editable:
            layer.startEditing()

        historial_entries = []
        for f in targets:
            fid = f.id()
            layer.changeAttributeValue(fid, idx_desact, False)
            estado = f['revision_estado'] or ''
            obs = f['revision_obs'] or ''
            historial_entries.append({
                'audinot_id': f['audinot_id'], 'origen': 'bulk_verificar_desactualizadas',
                'report_id': None, 'estado_anterior': estado, 'estado_nuevo': estado,
                'obs_anterior': obs, 'obs_nueva': obs, 'usuario': usuario,
                'detalle': 'Verificada: se retira el aviso de "desactualizada" sin cambiar la decisión ya tomada.',
            })

        layer.commitChanges()
        if was_editable:
            layer.startEditing()

        self.add_historial_entries(historial_entries)
        return len(historial_entries)

    @staticmethod
    def progress_counts(layer):
        """Cuenta rápida para el indicador "de un vistazo" de la
        cabecera de la Ficha 4. Solo cuenta fincas ('tipo_recinto' =
        'PARCELA' o NULL en una capa migrada): los recintos de
        infraestructura fija (VIALES/CURSOS AGUA/EDIFICACIONES/EXCLUIDO)
        están en la capa para verse en el lienzo, pero no son fincas
        pendientes de revisión."""
        from qgis.core import QgsFeatureRequest

        parcela_filter = "(tipo_recinto IS NULL OR tipo_recinto = 'PARCELA')"

        def _count(expr):
            req = QgsFeatureRequest().setFilterExpression(f"{parcela_filter} AND ({expr})")
            req.setFlags(QgsFeatureRequest.NoGeometry)
            return sum(1 for _ in layer.getFeatures(req))

        total = _count("1=1")
        si = _count("revision_estado = 'si'")
        no = _count("revision_estado = 'no'")
        revisar = _count("revision_estado = 'rev'")
        pendientes = total - si - no - revisar
        desact = _count("revision_desactualizada = 1 AND revision_estado != ''")
        return {
            'total': total, 'si': si, 'no': no, 'revisar': revisar,
            'pendientes': pendientes, 'desactualizadas': desact,
        }
