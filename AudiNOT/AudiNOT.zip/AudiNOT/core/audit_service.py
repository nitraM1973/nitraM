"""
AuditService
============

Módulo NUEVO y AISLADO para la Ficha "4: Auditoría".

No modifica ni depende de forma acoplada de ningún otro módulo del
plugin salvo para leer los `records` ya calculados por
`ReportService.build_audit_records()`. Su única responsabilidad es:

  1. Crear (o actualizar) una capa GeoPackage de auditoría, copia de la
     capa DESPUÉS (Carga), con los campos calculados + los campos de
     revisión humana (revision_estado / revision_obs / revision_fecha).
  2. En re-ejecuciones del análisis, FUSIONAR (upsert) por `audinot_id`
     en vez de sobrescribir: una finca ya revisada conserva su
     revisión salvo que sus métricas hayan cambiado desde entonces
     (en cuyo caso se marca `revision_desactualizada=True` en vez de
     perder silenciosamente el trabajo humano ya hecho).
  3. Dejar la capa con una simbología categorizada por
     `revision_estado`, para que el estado de la auditoría se vea "de
     un vistazo" directamente en el lienzo de QGIS.

Este fichero es la ÚNICA pieza del plugin que sabe escribir en el
GeoPackage de auditoría. La Ficha 4 (ui/components/tab_audit.py) solo
lee/edita la capa ya creada; no reimplementa nada de esto.
"""

import os
from datetime import datetime

from qgis.core import (
    QgsVectorLayer, QgsField, QgsFields, QgsFeature, QgsGeometry,
    QgsProject, QgsVectorFileWriter, QgsCoordinateTransformContext,
    QgsCategorizedSymbolRenderer, QgsRendererCategory, QgsSymbol,
    QgsSymbolLayer, QgsProperty, QgsRuleBasedRenderer, QgsSimpleFillSymbolLayer,
    QgsWkbTypes, edit
)
from qgis.PyQt.QtCore import QVariant, Qt
from qgis.PyQt.QtGui import QColor

AUDIT_LAYER_NAME = "AudiNOT_Auditoria"
AUDIT_GPKG_FILENAME = "AudiNOT_Auditoria.gpkg"

# Campos calculados (se sobrescriben siempre con el último cálculo).
CALC_FIELDS = [
    ("audinot_id", QVariant.String, 254),
    ("estado", QVariant.String, 20),
    # 'PARCELA' para las fincas normales (las únicas que build_audit_records
    # analiza); 'VIALES'/'CURSOS AGUA'/'EDIFICACIONES'/'EXCLUIDO' para los
    # recintos de infraestructura fija de DESPUÉS que añade
    # build_infra_records (Identificación por REC/Rangos, Ficha 3). Se usa
    # para la simbología de la capa (apply_symbology).
    ("tipo_recinto", QVariant.String, 20),
    ("titular_a", QVariant.String, 254),
    ("titular_d", QVariant.String, 254),
    ("titular_cambia", QVariant.Bool, None),
    ("sup_a", QVariant.Double, None),
    ("sup_d", QVariant.Double, None),
    ("var_sup", QVariant.Double, None),
    ("var_sup_pct", QVariant.Double, None),
    ("var_perim", QVariant.Double, None),
    ("n_partes_a", QVariant.Int, None),
    ("n_partes_d", QVariant.Int, None),
    ("n_islas_delta", QVariant.Int, None),
    ("notifica_param", QVariant.Bool, None),
    ("notifica_legal", QVariant.Bool, None),
    ("notif_divergen", QVariant.Bool, None),
    ("n_alertas", QVariant.Int, None),
    # Superficies de referencia T24 (registral) y GML (fórmula de Gauss
    # truncada a 2 decimales por vértice, igual que exige la
    # especificación GML de parcela catastral), Antes y Después, más los
    # % de desviación de supfT24 frente a cada una. "sup_a"/"sup_d" (más
    # arriba) son la superficie GRÁFICA real del recinto (área de la
    # geometría); estas son las otras dos referencias con las que se
    # compara supfT24 en la ficha de Auditoría.
    ("sup_t24_a", QVariant.Double, None),
    ("sup_t24_d", QVariant.Double, None),
    ("sup_gml_a", QVariant.Double, None),
    ("sup_gml_d", QVariant.Double, None),
    ("val_pct_a", QVariant.Double, None),
    ("val_pct_d", QVariant.Double, None),
    ("val_pct_gml_a", QVariant.Double, None),
    ("val_pct_gml_d", QVariant.Double, None),
    # True si |val_pct_gml_d| supera el "% Validación" de la Ficha 3 en
    # el momento del cálculo. Se usa tanto para resaltar la capa
    # (apply_symbology) como para poder filtrar/consultar en la tabla de
    # atributos sin tener que repetir el cálculo del umbral.
    ("val_gml_d_supera", QVariant.Bool, None),
    # Umbral '% Validación' (Ficha 3) vigente en el momento de este
    # cálculo. Se guarda como campo plano (en vez de recalcular el
    # umbral en la Ficha 4, que no tiene acceso directo a Ficha 3) para
    # poder replicar en la Ficha 4, mediante expresiones QGIS sobre
    # val_pct_a/val_pct_d/val_pct_gml_a/val_pct_gml_d, los mismos
    # filtros de precisión T24 y de validación GML que ya ofrece el
    # informe HTML (facetas "Precisión de superficie" y "Validación").
    ("val_limite_pct", QVariant.Double, None),
    ("conclusion_param", QVariant.String, -1),
    ("conclusion_legal", QVariant.String, -1),
    ("croquis_svg", QVariant.String, -1),
    ("audinot_json", QVariant.String, -1),
    ("report_id", QVariant.String, 64),
    ("fecha_calculo", QVariant.String, 32),
]

# Campos de revisión humana (se PRESERVAN al fusionar, salvo que la
# finca se marque como desactualizada).
REVIEW_FIELDS = [
    ("revision_estado", QVariant.String, 4),       # '', 'si', 'no', 'rev'
    ("revision_obs", QVariant.String, -1),
    ("revision_fecha", QVariant.String, 32),
    ("revision_desactualizada", QVariant.Bool, None),
]

ALL_FIELDS = CALC_FIELDS + REVIEW_FIELDS


class AuditService:
    def __init__(self, output_dir, log_callback=None):
        self.output_dir = output_dir
        self.gpkg_path = os.path.join(output_dir, AUDIT_GPKG_FILENAME)
        self.log_callback = log_callback

    def _log(self, msg):
        if self.log_callback:
            try:
                self.log_callback(msg)
            except Exception:
                pass

    # ------------------------------------------------------------------
    # Construcción de QgsFields a partir de ALL_FIELDS
    # ------------------------------------------------------------------
    def _build_fields(self):
        fields = QgsFields()
        for name, qtype, length in ALL_FIELDS:
            f = QgsField(name, qtype)
            if length and length > 0:
                f.setLength(length)
            fields.append(f)
        return fields

    # ------------------------------------------------------------------
    # Punto de entrada principal: crea o fusiona
    # ------------------------------------------------------------------
    def export_or_update(self, records, layer_desp, report_id, thresholds_changed_note=None):
        """
        records: lista de dicts devuelta por ReportService.build_audit_records()
        layer_desp: QgsVectorLayer de la capa DESPUÉS (Carga), para tomar
                    el CRS de referencia.
        report_id: UUID del informe HTML que originó este cálculo (se
                   guarda por finca, útil para trazabilidad).

        Devuelve la ruta del GeoPackage resultante.
        """
        crs = layer_desp.crs() if layer_desp else None

        if not os.path.exists(self.gpkg_path):
            self._log(f"AudiNOT: creando capa de auditoría nueva en {self.gpkg_path}")
            self._create_gpkg(records, crs, report_id)
        else:
            self._log(f"AudiNOT: fusionando cálculo con la capa de auditoría existente en {self.gpkg_path}")
            self._merge_into_gpkg(records, crs, report_id)

        return self.gpkg_path

    # ------------------------------------------------------------------
    # Creación desde cero
    # ------------------------------------------------------------------
    def _create_gpkg(self, records, crs, report_id):
        fields = self._build_fields()
        writer = QgsVectorFileWriter.create(
            self.gpkg_path,
            fields,
            QgsWkbTypes.MultiPolygon,
            crs,
            QgsCoordinateTransformContext(),
            QgsVectorFileWriter.SaveVectorOptions()
        )
        if writer.hasError() != QgsVectorFileWriter.NoError:
            raise RuntimeError(f"No se pudo crear el GeoPackage de auditoría: {writer.errorMessage()}")

        now_iso = datetime.now().isoformat(timespec='seconds')
        for rec in records:
            feat = QgsFeature(fields)
            geom = rec.get('geom_d') or rec.get('geom_a')
            if geom is not None:
                feat.setGeometry(QgsGeometry(geom))
            self._fill_feature_attrs(feat, fields, rec, report_id, now_iso, preserve_review=None)
            writer.addFeature(feat)

        del writer  # fuerza el flush/cierre del fichero

    # ------------------------------------------------------------------
    # Fusión (upsert) preservando revisión humana
    # ------------------------------------------------------------------
    def _merge_into_gpkg(self, records, crs, report_id):
        layer = QgsVectorLayer(f"{self.gpkg_path}|layername={AUDIT_LAYER_NAME}", AUDIT_LAYER_NAME, "ogr")
        if not layer.isValid():
            # Nombre de capa por defecto distinto al esperado (p.ej. el
            # fichero se creó con otra herramienta): cae de vuelta al
            # gpkg sin indicar layername.
            layer = QgsVectorLayer(self.gpkg_path, AUDIT_LAYER_NAME, "ogr")
        if not layer.isValid():
            raise RuntimeError("No se pudo abrir el GeoPackage de auditoría existente para fusionar.")

        migrated = self._migrate_schema(layer)
        if migrated:
            # Reabrir la capa desde cero: el proveedor OGR/GeoPackage deja
            # sentencias SQL preparadas con el esquema ANTERIOR al ALTER
            # TABLE que acaba de ejecutar _migrate_schema. Si se sigue
            # usando esta misma instancia de capa para el commit de abajo,
            # los parámetros de la sentencia UPDATE quedan desalineados y
            # GDAL interpreta el desplazamiento como un intento de cambiar
            # el fid de cada feature (error "No está permitido cambiar la
            # ID de objeto..." repetido para TODAS las fincas). Abrir una
            # instancia nueva fuerza a OGR a releer la definición de
            # columnas ya actualizada antes de tocar ningún atributo.
            layer = QgsVectorLayer(f"{self.gpkg_path}|layername={AUDIT_LAYER_NAME}", AUDIT_LAYER_NAME, "ogr")
            if not layer.isValid():
                layer = QgsVectorLayer(self.gpkg_path, AUDIT_LAYER_NAME, "ogr")
            if not layer.isValid():
                raise RuntimeError("No se pudo reabrir el GeoPackage de auditoría tras migrar su esquema.")

        fields = layer.fields()
        now_iso = datetime.now().isoformat(timespec='seconds')

        # Cualquier campo llamado 'fid' que el proveedor GeoPackage/OGR
        # exponga en layer.fields() es, en realidad, la clave primaria de
        # la tabla, no un atributo de datos normal. NUNCA debe formar
        # parte de un cambio de atributos: si se "reescribe" (aunque sea
        # sin querer, al reconstruir la feature entera y dejarlo a NULL
        # porque ALL_FIELDS no lo define) GDAL lo interpreta como un
        # intento de cambiar el ID de objeto y rechaza el commit entero
        # con el error 'No está permitido cambiar la ID de objeto...'
        # -- para TODAS las features del lote, que es justo lo que se
        # observaba. Se evita del todo cambiando SOLO los atributos de
        # datos (uno a uno, por índice) y la geometría, sin tocar nunca
        # este campo ni reconstruir la feature completa.
        fid_idx = fields.indexFromName('fid')

        # Índice de features existentes por audinot_id
        existing_by_id = {}
        for f in layer.getFeatures():
            existing_by_id[str(f['audinot_id'])] = f

        new_ids = {str(r['audinot_id']) for r in records}

        with edit(layer):
            for rec in records:
                aid = str(rec['audinot_id'])
                geom = rec.get('geom_d') or rec.get('geom_a')

                if aid in existing_by_id:
                    old_feat = existing_by_id[aid]
                    fid = old_feat.id()
                    prev_state = old_feat['revision_estado'] or ''
                    changed = self._metrics_changed(old_feat, rec)

                    preserve = {
                        'revision_estado': prev_state,
                        'revision_obs': old_feat['revision_obs'] or '',
                        'revision_fecha': old_feat['revision_fecha'],
                    }
                    attrs = self._record_to_attrs(fields, rec, report_id, now_iso, preserve_review=preserve)

                    # Si ya estaba revisada y las métricas relevantes
                    # cambiaron desde la última revisión, NO se borra la
                    # revisión (evita perder trabajo humano por
                    # sorpresa) pero se marca como desactualizada para
                    # que la Ficha 4 la resalte y el usuario decida si
                    # la vuelve a mirar.
                    idx_desact = fields.indexFromName('revision_desactualizada')
                    if idx_desact != -1 and idx_desact != fid_idx:
                        if prev_state and changed:
                            attrs[idx_desact] = True
                        elif not changed:
                            attrs[idx_desact] = False

                    for idx, value in attrs.items():
                        if idx == fid_idx:
                            continue
                        layer.changeAttributeValue(fid, idx, value)

                    if geom is not None:
                        layer.changeGeometry(fid, QgsGeometry(geom))
                else:
                    new_feat = QgsFeature(fields)
                    if geom is not None:
                        new_feat.setGeometry(QgsGeometry(geom))
                    self._fill_feature_attrs(new_feat, fields, rec, report_id, now_iso, preserve_review=None)
                    layer.addFeature(new_feat)

            # Fincas que existían en la capa de auditoría pero ya no
            # aparecen en este cálculo (p.ej. cambiaron los filtros de
            # entrada): se conservan tal cual, no se borran nunca en
            # automático -- borrarlas sería destructivo para el
            # histórico de auditoría. Si se quiere depurar la capa, es
            # una acción manual del usuario desde QGIS.
            _ = new_ids  # (reservado por si se añade un modo "podar" explícito más adelante)

        layer = None  # cierra el datasource

    def _migrate_schema(self, layer):
        """Añade a una capa de auditoría YA EXISTENTE (creada por una
        versión anterior del plugin) cualquier campo de ALL_FIELDS que
        todavía no tenga, sin tocar los que ya existen ni sus datos.

        Necesario porque `_merge_into_gpkg` hace upsert sobre el
        GeoPackage tal cual lo encuentra en disco: si simplemente se
        añaden columnas nuevas a ALL_FIELDS (p.ej. las superficies
        T24/GML) sin esta migración, `_fill_feature_attrs` las
        ignoraría en silencio (`fields.indexFromName` devolvería -1)
        en cualquier GeoPackage generado antes del cambio."""
        existing_names = set(layer.fields().names())
        missing = [(name, qtype, length) for name, qtype, length in ALL_FIELDS if name not in existing_names]
        if not missing:
            return False
        self._log(f"AudiNOT: migrando capa de auditoría existente, añadiendo {len(missing)} campo(s) nuevo(s): "
                   f"{', '.join(n for n, _, _ in missing)}")
        new_fields = []
        for name, qtype, length in missing:
            f = QgsField(name, qtype)
            if length and length > 0:
                f.setLength(length)
            new_fields.append(f)
        provider = layer.dataProvider()
        if not provider.addAttributes(new_fields):
            self._log("AVISO: no se pudieron añadir los campos nuevos al GeoPackage de auditoría existente "
                       f"({provider.lastError().message() if provider.lastError() else 'motivo desconocido'}).")
            layer.updateFields()
            return False
        layer.updateFields()
        return True

    def _metrics_changed(self, old_feat, rec):
        """Compara un pequeño subconjunto de campos "sensibles" para
        decidir si una finca ya revisada debe marcarse como
        desactualizada. No comparamos el JSON completo (cualquier
        redondeo distinto lo dispararía sin motivo real)."""
        keys = ['sup_d', 'var_sup', 'var_perim', 'notifica_param', 'notifica_legal', 'estado', 'val_gml_d_supera', 'val_limite_pct']
        for k in keys:
            old_v = old_feat[k]
            new_v = rec.get(k)
            if isinstance(old_v, float) and isinstance(new_v, float):
                if abs(old_v - new_v) > 0.005:
                    return True
            elif old_v != new_v:
                return True
        return False

    def _record_to_attrs(self, fields, rec, report_id, now_iso, preserve_review):
        """Traduce un `rec` (dict de ReportService) a un diccionario
        {índice_de_campo: valor}, resuelto por nombre contra `fields`
        (así que si un campo no existe en `fields` -p.ej. un GeoPackage
        antiguo sin migrar aún- simplemente se omite). Deliberadamente
        NUNCA incluye un posible campo 'fid': quien llame a esto para
        actualizar una feature existente debe descartar ese índice antes
        de aplicar los cambios (ver comentario en _merge_into_gpkg)."""
        attrs = {}

        def setf(name, value):
            idx = fields.indexFromName(name)
            if idx != -1 and fields.field(idx).name().lower() != 'fid':
                attrs[idx] = value

        setf('audinot_id', rec.get('audinot_id'))
        setf('estado', rec.get('estado'))
        setf('tipo_recinto', rec.get('tipo_recinto', 'PARCELA'))
        setf('titular_a', rec.get('titular_a'))
        setf('titular_d', rec.get('titular_d'))
        setf('titular_cambia', bool(rec.get('titular_cambia')))
        setf('sup_a', rec.get('sup_a'))
        setf('sup_d', rec.get('sup_d'))
        setf('var_sup', rec.get('var_sup'))
        setf('var_sup_pct', rec.get('var_sup_pct'))
        setf('var_perim', rec.get('var_perim'))
        setf('n_partes_a', rec.get('n_partes_a'))
        setf('n_partes_d', rec.get('n_partes_d'))
        setf('n_islas_delta', rec.get('n_islas_delta'))
        setf('notifica_param', bool(rec.get('notifica_param')))
        setf('notifica_legal', bool(rec.get('notifica_legal')))
        setf('notif_divergen', bool(rec.get('notif_divergen')))
        setf('n_alertas', rec.get('n_alertas'))
        setf('sup_t24_a', rec.get('sup_t24_a'))
        setf('sup_t24_d', rec.get('sup_t24_d'))
        setf('sup_gml_a', rec.get('sup_gml_a'))
        setf('sup_gml_d', rec.get('sup_gml_d'))
        setf('val_pct_a', rec.get('val_pct_a'))
        setf('val_pct_d', rec.get('val_pct_d'))
        setf('val_pct_gml_a', rec.get('val_pct_gml_a'))
        setf('val_pct_gml_d', rec.get('val_pct_gml_d'))
        setf('val_gml_d_supera', bool(rec.get('val_gml_d_supera')))
        setf('val_limite_pct', rec.get('val_limite_pct'))
        setf('conclusion_param', rec.get('conclusion_param'))
        setf('conclusion_legal', rec.get('conclusion_legal'))
        setf('croquis_svg', rec.get('croquis_svg'))
        setf('audinot_json', rec.get('audinot_json'))
        setf('report_id', report_id)
        setf('fecha_calculo', now_iso)

        if preserve_review:
            setf('revision_estado', preserve_review.get('revision_estado', ''))
            setf('revision_obs', preserve_review.get('revision_obs', ''))
            setf('revision_fecha', preserve_review.get('revision_fecha'))
        else:
            setf('revision_estado', rec.get('revision_estado', ''))
            setf('revision_obs', rec.get('revision_obs', ''))
            setf('revision_fecha', rec.get('revision_fecha'))
            setf('revision_desactualizada', False)

        return attrs

    def _fill_feature_attrs(self, feat, fields, rec, report_id, now_iso, preserve_review):
        """Variante para features NUEVAS (INSERT, vía QgsFeature +
        addFeature/writer.addFeature): aquí sí es seguro fijar todos los
        atributos sobre el objeto QgsFeature de una vez, porque no hay
        ninguna feature previa en el proveedor cuyo fid pueda
        confundirse con un cambio de ID."""
        attrs = self._record_to_attrs(fields, rec, report_id, now_iso, preserve_review)
        for idx, value in attrs.items():
            feat.setAttribute(idx, value)

    # ------------------------------------------------------------------
    # Carga de la capa (para la Ficha 4) + simbología "de un vistazo"
    # ------------------------------------------------------------------
    def load_layer(self, add_to_project=True):
        if not os.path.exists(self.gpkg_path):
            return None
        layer = QgsVectorLayer(f"{self.gpkg_path}|layername={AUDIT_LAYER_NAME}", AUDIT_LAYER_NAME, "ogr")
        if not layer.isValid():
            layer = QgsVectorLayer(self.gpkg_path, AUDIT_LAYER_NAME, "ogr")
        if not layer.isValid():
            return None

        self.apply_symbology(layer)

        if add_to_project and not QgsProject.instance().mapLayersByName(layer.name()):
            QgsProject.instance().addMapLayer(layer)

        return layer

    def apply_symbology(self, layer):
        """Renderer por reglas con dos grupos:

        1. Recintos de infraestructura fija de DESPUÉS ('tipo_recinto' de
           build_infra_records: VIALES/CURSOS AGUA/EDIFICACIONES/EXCLUIDO,
           Identificación por REC/Rangos de la Ficha 3), cada uno con su
           color fijo -- no dependen de revisión humana, son contexto, no
           fincas a auditar:
             - VIALES: gris claro, relleno sólido.
             - CURSOS AGUA: cian, relleno sólido.
             - EDIFICACIONES: fondo hueco (sin relleno de base) con
               rayado diagonal en rojo claro.
             - EXCLUIDO: gris oscuro, relleno sólido.

        2. Fincas ('tipo_recinto' = 'PARCELA', o NULL en una capa migrada
           desde una versión anterior sin este campo): el semáforo de
           siempre por 'revision_estado' (gris/rojo/verde), con el mismo
           BORDE grueso data-defined que ya resaltaba el error de
           validación %GML de Después ('val_gml_d_supera'/
           'val_pct_gml_d'): naranja si el error es positivo, morado si
           es negativo, borde fino normal si no supera el umbral.
        """
        root_rule = QgsRuleBasedRenderer.Rule(None)

        # --- 1. Infraestructura fija --------------------------------------
        infra_specs = [
            ('VIALES', "\"tipo_recinto\" = 'VIALES'", '#d9d9d9', None),
            ('CURSOS AGUA', "\"tipo_recinto\" = 'CURSOS AGUA'", '#00bcd4', None),
            ('EDIFICACIONES', "\"tipo_recinto\" = 'EDIFICACIONES'", None, '#ff8a80'),
            ('EXCLUIDO', "\"tipo_recinto\" = 'EXCLUIDO'", '#616161', None),
        ]
        for label, expr, fill_color, hatch_color in infra_specs:
            symbol = QgsSymbol.defaultSymbol(layer.geometryType())
            if hatch_color:
                # Fondo hueco: la capa de relleno base se deja sin brocha
                # (NoBrush) para que no rellene de color; se le añade
                # encima una segunda capa con el patrón rayado diagonal,
                # sin borde propio (para no duplicar el contorno de la
                # capa base).
                base_layer = symbol.symbolLayer(0)
                base_layer.setBrushStyle(Qt.NoBrush)
                hatch_layer = QgsSimpleFillSymbolLayer(QColor(hatch_color))
                hatch_layer.setBrushStyle(Qt.BDiagPattern)
                hatch_layer.setStrokeStyle(Qt.NoPen)
                symbol.appendSymbolLayer(hatch_layer)
            else:
                symbol.setColor(QColor(fill_color))
                symbol.setOpacity(0.75)
            rule = QgsRuleBasedRenderer.Rule(symbol, filterExp=expr, label=label)
            root_rule.appendChild(rule)

        # --- 2. Fincas: semáforo de revisión + resaltado %GML --------------
        outline_color_expr = (
            "CASE "
            "WHEN \"val_gml_d_supera\" AND \"val_pct_gml_d\" > 0 THEN '#e67e22' "
            "WHEN \"val_gml_d_supera\" AND \"val_pct_gml_d\" < 0 THEN '#8e44ad' "
            "ELSE '#000000' "
            "END"
        )
        outline_width_expr = 'CASE WHEN "val_gml_d_supera" THEN 1.4 ELSE 0.26 END'
        parcela_filter = "\"tipo_recinto\" IS NULL OR \"tipo_recinto\" = 'PARCELA'"

        specs = [
            ('', 'Sin revisar', '#9e9e9e'),
            ('rev', 'Marcada para revisar', '#2980b9'),
            ('si', 'Notifica', '#c0392b'),
            ('no', 'No notifica', '#27ae60'),
        ]
        for value, label, color in specs:
            symbol = QgsSymbol.defaultSymbol(layer.geometryType())
            symbol.setColor(QColor(color))
            symbol.setOpacity(0.55)
            outline_layer = symbol.symbolLayer(0)
            if outline_layer is not None:
                outline_layer.setDataDefinedProperty(
                    QgsSymbolLayer.PropertyStrokeColor, QgsProperty.fromExpression(outline_color_expr))
                outline_layer.setDataDefinedProperty(
                    QgsSymbolLayer.PropertyStrokeWidth, QgsProperty.fromExpression(outline_width_expr))
            expr = f'({parcela_filter}) AND "revision_estado" = \'{value}\''
            rule = QgsRuleBasedRenderer.Rule(symbol, filterExp=expr, label=label)
            root_rule.appendChild(rule)

        renderer = QgsRuleBasedRenderer(root_rule)
        layer.setRenderer(renderer)
        layer.triggerRepaint()

    # ------------------------------------------------------------------
    # Guardar una decisión de revisión (llamado desde la Ficha 4)
    # ------------------------------------------------------------------
    @staticmethod
    def save_review(layer, feature_id, estado, observacion):
        """estado: '', 'si', 'no', 'rev'. Escribe directamente en la capa
        mediante una sesión de edición normal de QGIS (deshacer/rehacer
        estándar incluido) y hace commit inmediato para que quede
        permanente sin depender de que el usuario guarde ediciones
        pendientes al cerrar QGIS."""
        fields = layer.fields()
        idx_estado = fields.indexFromName('revision_estado')
        idx_obs = fields.indexFromName('revision_obs')
        idx_fecha = fields.indexFromName('revision_fecha')
        idx_desact = fields.indexFromName('revision_desactualizada')

        now_iso = datetime.now().isoformat(timespec='seconds')

        was_editable = layer.isEditable()
        if not was_editable:
            layer.startEditing()

        layer.changeAttributeValue(feature_id, idx_estado, estado)
        layer.changeAttributeValue(feature_id, idx_obs, observacion)
        layer.changeAttributeValue(feature_id, idx_fecha, now_iso)
        if idx_desact != -1:
            layer.changeAttributeValue(feature_id, idx_desact, False)

        layer.commitChanges()
        if was_editable:
            layer.startEditing()

    # ------------------------------------------------------------------
    # Acciones masivas (botones sobre la lista de recintos de la Ficha 4)
    # ------------------------------------------------------------------
    @staticmethod
    def bulk_mark_pending_no_notificar(layer, observacion):
        """Marca como NO NOTIFICAR (con la observación automática que se
        le pase) todas las fincas que sigan 'Sin revisar'
        (revision_estado vacío o NULL). No toca las que ya tengan una
        decisión (NOTIFICAR o NO NOTIFICAR) tomada por el usuario.
        Devuelve el número de fincas modificadas."""
        from qgis.core import QgsFeatureRequest

        parcela_filter = "(tipo_recinto IS NULL OR tipo_recinto = 'PARCELA')"
        fields = layer.fields()
        idx_estado = fields.indexFromName('revision_estado')
        idx_obs = fields.indexFromName('revision_obs')
        idx_fecha = fields.indexFromName('revision_fecha')
        idx_desact = fields.indexFromName('revision_desactualizada')

        req = QgsFeatureRequest().setFilterExpression(
            f"{parcela_filter} AND (revision_estado IS NULL OR revision_estado = '')"
        )
        req.setFlags(QgsFeatureRequest.NoGeometry)
        ids = [f.id() for f in layer.getFeatures(req)]
        if not ids:
            return 0

        now_iso = datetime.now().isoformat(timespec='seconds')
        was_editable = layer.isEditable()
        if not was_editable:
            layer.startEditing()

        for fid in ids:
            layer.changeAttributeValue(fid, idx_estado, 'no')
            layer.changeAttributeValue(fid, idx_obs, observacion)
            layer.changeAttributeValue(fid, idx_fecha, now_iso)
            if idx_desact != -1:
                layer.changeAttributeValue(fid, idx_desact, False)

        layer.commitChanges()
        if was_editable:
            layer.startEditing()
        return len(ids)

    @staticmethod
    def bulk_reset_all_to_sin_revisar(layer):
        """Pone TODAS las fincas en estado 'Sin revisar', borrando
        revision_estado / revision_obs / revision_fecha /
        revision_desactualizada de cada una (pierde por completo
        cualquier decisión y observación tomada hasta ahora). Devuelve
        el número de fincas modificadas."""
        from qgis.core import QgsFeatureRequest

        parcela_filter = "(tipo_recinto IS NULL OR tipo_recinto = 'PARCELA')"
        fields = layer.fields()
        idx_estado = fields.indexFromName('revision_estado')
        idx_obs = fields.indexFromName('revision_obs')
        idx_fecha = fields.indexFromName('revision_fecha')
        idx_desact = fields.indexFromName('revision_desactualizada')

        req = QgsFeatureRequest().setFilterExpression(parcela_filter)
        req.setFlags(QgsFeatureRequest.NoGeometry)
        ids = [f.id() for f in layer.getFeatures(req)]
        if not ids:
            return 0

        was_editable = layer.isEditable()
        if not was_editable:
            layer.startEditing()

        for fid in ids:
            layer.changeAttributeValue(fid, idx_estado, '')
            layer.changeAttributeValue(fid, idx_obs, '')
            layer.changeAttributeValue(fid, idx_fecha, None)
            if idx_desact != -1:
                layer.changeAttributeValue(fid, idx_desact, False)

        layer.commitChanges()
        if was_editable:
            layer.startEditing()
        return len(ids)

    @staticmethod
    def progress_counts(layer):
        """Cuenta rápida para el indicador "de un vistazo" de la
        cabecera de la Ficha 4. Solo cuenta fincas ('tipo_recinto' =
        'PARCELA' o NULL en una capa migrada): los recintos de
        infraestructura fija (VIALES/CURSOS AGUA/EDIFICACIONES/EXCLUIDO)
        están en la capa para verse en el lienzo, pero no son fincas
        pendientes de revisión."""
        from qgis.core import QgsFeatureRequest

        parcela_filter = "(tipo_recinto IS NULL OR tipo_recinto = 'PARCELA')"

        def _count(expr):
            req = QgsFeatureRequest().setFilterExpression(f"{parcela_filter} AND ({expr})")
            req.setFlags(QgsFeatureRequest.NoGeometry)
            return sum(1 for _ in layer.getFeatures(req))

        total = _count("1=1")
        si = _count("revision_estado = 'si'")
        no = _count("revision_estado = 'no'")
        revisar = _count("revision_estado = 'rev'")
        pendientes = total - si - no - revisar
        desact = _count("revision_desactualizada = 1 AND revision_estado != ''")
        return {
            'total': total, 'si': si, 'no': no, 'revisar': revisar,
            'pendientes': pendientes, 'desactualizadas': desact,
        }
