def classFactory(iface):
    from .mainPlugin import TopoCADGIS
    return TopoCADGIS(iface)
