from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction
from .form_dialog import TopoCADGISDockWidget
import os.path

class TopoCADGIS:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.dock = None
        self.action = None
        self.toolbar = None

    def initGui(self):
        from qgis.PyQt.QtCore import QSize
        from qgis.PyQt.QtWidgets import QToolBar
        
        icon_path = os.path.join(self.plugin_dir, 'appicon.svg')
        icon = QIcon(icon_path)
        
        self.action = QAction(icon, 'ValGIS', self.iface.mainWindow())
        self.action.setObjectName("ValGISAction")
        self.action.setToolTip("ValGIS")
        self.action.triggered.connect(self.run)
        
        # 3. & 4. Añadir al menú de Plugins (submenú ValCAD)
        # addPluginToMenu crea automáticamente el menú si no existe
        self.iface.addPluginToMenu('ValCAD', self.action)
        
        # 1. & 2. Lógica de la barra de herramientas
        self.toolbar = None
        self.toolbar_created = False
        
        # Verificar si la barra 'ValCAD' ya existe
        toolbars = self.iface.mainWindow().findChildren(QToolBar)
        for tb in toolbars:
            if tb.windowTitle() == 'ValCAD':
                self.toolbar = tb
                break
        
        # Si no existe, crearla
        if not self.toolbar:
            self.toolbar = self.iface.addToolBar("ValCAD")
            self.toolbar.setObjectName("ValCADToolBar")
            self.toolbar_created = True
        
        self.toolbar.setIconSize(QSize(32, 32))
        self.toolbar.addAction(self.action)

    def unload(self):
        if self.dock:
            self.iface.removeDockWidget(self.dock)
        
        # Eliminar del menú ValCAD
        self.iface.removePluginMenu('ValCAD', self.action)
        
        # Eliminar de la barra de herramientas
        if self.toolbar:
            self.toolbar.removeAction(self.action)
            # Solo eliminar la barra si NOSOTROS la creamos
            if self.toolbar_created:
                del self.toolbar
        
    def run(self):
        if not self.dock:
            self.dock = TopoCADGISDockWidget(self.iface)
            self.iface.addDockWidget(Qt.RightDockWidgetArea, self.dock)
        
        self.dock.show()
