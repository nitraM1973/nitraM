# Reglas de Oro de ValGIS

Este documento contiene las normas de cumplimiento OBLIGATORIO para todos los agentes involucrados en el desarrollo del plugin. Ignorar estas reglas se considera un fallo crítico en la arquitectura.

## 1. Soberanía de la Interfaz de Usuario (UI)
*   **PROHIBICIÓN**: Nunca utilices valores hardcodeados para parámetros que tengan un control correspondiente en la UI (SpinBoxes, CheckBoxes, etc.).
*   **VINCULACIÓN**: Toda lógica de procesamiento debe consultar el estado actual de los widgets de `TopoCADGISDockWidget` (ej: `sbTolerance`, `chkAutoFix`).
*   **RESPETO AL USUARIO**: Si la casilla "Corrección Automática" (`chkAutoFix`) está desactivada, el agente NO debe realizar cambios permanentes en la geometría, solo reportar errores.

## 2. Estándares de Precisión
*   **COORDENADAS**: La precisión estándar de trabajo es de **5 decimales** (0.01mm). 
*   **CONSISTENCIA**: Cualquier nuevo algoritmo de limpieza o normalización debe adherirse a esta precisión para evitar derivas métricas.

## 3. Gobernanza de Tolerancias
*   **ANÁLISIS DE CAMBIOS**: La tolerancia para la comparación original vs final se mantiene en **0.001 (1mm)** por instrucción directa senior.
*   **FALLBACKS**: Si un parámetro de la UI es 0 y el algoritmo requiere un valor positivo, utiliza un micro-threshold (ej: `1e-6`) y REGÍSTRALO en el log de acciones.

## 4. Estabilidad Topológica
*   **UUIDs**: No alterar la lógica de generación/regeneración de UUIDs sin una revisión de arquitectura senior previa.

## 5. Homogeneidad en Firmas de Procesamiento
*   **CALLBACKS OBLIGATORIOS**: Todos los métodos `run(...)` de cualquier paso de procesamiento (ej: `StepGeneratePolygons`, `StepVerifySlivers`) DEBEN aceptar en su firma `callback=None` e incluirlo en las llamadas, independientemente de si reportan o no progreso interno. Esto asegura que la orquestación general pueda conectar la UI siempre.

## 6. Persistencia de la Barra de Progreso
*   **VISIBILIDAD**: La barra de progreso de la interfaz principal (`progressBar`) DEBE permanecer siempre visible. No se utilizará `setVisible(False)` al terminar un paso ni se mostrará/ocultará dinámicamente; únicamente se reiniciará su valor a `0` (estado inactivo/vacío).

---
> "El código es la realización técnica de la voluntad del usuario en la interfaz."
