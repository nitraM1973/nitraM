# Protocolo de Interacción de Agentes PyQGIS

Para un flujo de trabajo óptimo en el desarrollo de este plugin, se recomienda seguir este orden de interacción:

0. **Reglas de Oro y Coordinación (Obligatorio)**:
   - Consulta SIEMPRE las [Reglas de Oro](./REGLAS_DE_ORO.md) antes de proponer cambios en la lógica o UI.
   - El **Coordinador** (tú como IA) DEBE verificar activamente que NINGÚN agente olvide las directrices de homogeneidad térmica y de UI, coordinándolos de forma estricta para evitar regresiones.

1. **Estructura (Core Architect)**:
   - Define la lógica del procesamiento, optimización de geometrías y manejo de hilos.
   - Referencia: [PyQGIS_Core_Architect.md](./PyQGIS_Core_Architect.md)

2. **Interfaz (UX/UI Expert)**:
   - Crea el contenedor visual (diálogos, paneles) basándose en los requisitos lógicos.
   - Referencia: [UX_UI_Designer_for_Plugins.md](./UX_UI_Designer_for_Plugins.md)

3. **Validación (Workflow Specialist)**:
   - Revisa la integridad topológica, precisión de datos e integración con el ecosistema QGIS.
   - Referencia: [QGIS_Workflow_Analysis_Specialist.md](./QGIS_Workflow_Analysis_Specialist.md)
