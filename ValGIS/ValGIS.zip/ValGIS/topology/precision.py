# Precisión única para todo el pipeline topológico.
#
# ANTES: cada step redondeaba coordenadas con su propio número de
# decimales (6, 8, 5, 4 o 12 según el archivo). Esto provocaba que un
# mismo par de vértices se considerase "el mismo nodo" en una fase del
# flujo y "nodos distintos" en la siguiente, generando grafos
# topológicos inconsistentes entre pasos del mismo procesamiento.
#
# AHORA: una sola constante, usada por TODOS los módulos que construyen
# un Graph() o comparan vértices para detectar coincidencia.
#
# 6 decimales en metros = 1 micrómetro de precisión. Es más que
# suficiente para cualquier levantamiento catastral (muy por debajo del
# error de medición de campo) y se mantiene con margen respecto al techo
# de precisión de un float64 para coordenadas proyectadas típicas
# (6-7 dígitos enteros + 6 decimales ≈ 12-13 dígitos significativos,
# dentro del límite de ~15-17 de un double). Usar más decimales (p. ej.
# 12) no aporta precisión real y sí aumenta el riesgo de que dos
# vértices matemáticamente iguales no coincidan por ruido de
# representación en punto flotante.
TOPO_PRECISION = 6


def node_key(x, y, precision=TOPO_PRECISION):
    """Clave de nodo consistente para construir/consultar el Graph."""
    return (round(x, precision), round(y, precision))
