class Graph:
    def __init__(self):
        self.nodes = {}
        self.edges = []

    def add_edge(self, u, v, data=None):
        if u not in self.nodes:
            self.nodes[u] = []
        if v not in self.nodes:
            self.nodes[v] = []
        
        self.nodes[u].append(v)
        self.nodes[v].append(u)
        self.edges.append((u, v, data))

    def get_degree(self, node):
        return len(self.nodes.get(node, []))

    def get_dangles(self):
        """Returns nodes with degree 1."""
        return [n for n, neighbors in self.nodes.items() if len(neighbors) == 1]
