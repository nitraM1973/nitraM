class Graph:
    def __init__(self):
        self.nodes = {}
        self.edges = []

    def add_edge(self, u, v, data=None):
        if u not in self.nodes:
            self.nodes[u] = []
        if v not in self.nodes:
            self.nodes[v] = []

        # FIX: el grado topológico real de un nodo es su número de ARISTAS
        # incidentes, no su número de vecinos DISTINTOS. Si dos segmentos
        # distintos conectan el mismo par de nodos (líneas duplicadas —muy
        # común al importar DXF/CAD—), antes se contaba como grado 1 y ese
        # nodo se trataba como un dangle real, aunque en realidad estaba
        # doblemente conectado. Ahora se permite un vecino repetido por
        # cada arista, de forma que len(self.nodes[node]) == grado real.
        self.nodes[u].append(v)
        self.nodes[v].append(u)
        self.edges.append((u, v, data))

    def get_degree(self, node):
        return len(self.nodes.get(node, []))

    def get_unique_neighbors(self, node):
        """Devuelve los vecinos DISTINTOS de un nodo (sin contar multiplicidad)."""
        seen = []
        for n in self.nodes.get(node, []):
            if n not in seen:
                seen.append(n)
        return seen

    def get_dangles(self):
        """Returns nodes with degree 1 (una sola arista incidente, real)."""
        return [n for n, neighbors in self.nodes.items() if len(neighbors) == 1]
