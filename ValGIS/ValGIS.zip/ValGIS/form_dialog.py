import os
import time
import re
import json
from datetime import datetime
from qgis.PyQt import uic
from qgis.PyQt.QtWidgets import QDockWidget, QMessageBox, QApplication, QTableWidgetItem, QFileDialog, QProgressBar, QListWidgetItem, QStyle
from qgis.PyQt.QtCore import QTimer, Qt
from qgis.PyQt.QtGui import QColor, QTextCursor
from qgis.core import QgsProject, QgsRectangle, QgsGeometry, QgsPointXY, QgsFeature, QgsVectorLayer, QgsFeatureRequest, QgsWkbTypes
from qgis.gui import QgsHighlight

from .steps.step_load import StepLoad
from .steps.step_simplify import StepSimplify
from .steps.step_detect_shorts import StepDetectShorts
from .steps.step_detect_duplicates import StepDetectDuplicates
from .steps.step_detect_dangles import StepDetectDangles
from .steps.step_normalize_coordinates import StepNormalizeCoordinates

from .steps.step_join_collinear import StepJoinCollinear
from .steps.step_split_intersections import StepSplitIntersections
from .steps.step_advanced_shorts import StepAdvancedShorts
from .steps.step_check_validity import StepCheckValidity
from .steps.step_open_enclosures import StepOpenEnclosures
from .steps.step_generate_polygons import StepGeneratePolygons
from .steps.step_validate_polygons import StepValidatePolygons
from .steps.step_analyze_changes import StepAnalyzeChanges
from .steps.step_final_check import StepFinalCheck
from .steps.step_fix_islands import StepFixIslands
from .steps.step_verify_polygon_topology import StepVerifyPolygonTopology
from .steps.step_generate_viales import StepGenerateViales
from .topology.graph import Graph

from .helpers.layer_utils import clean_and_save_layer
from .helpers.log_helper import LogHelper
from .helpers.naming_convention import get_step_filename
from .helpers.summary_report import create_summary_html, update_step_status

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'ui', 'dock_widget.ui'))

class TopoCADGISDockWidget(QDockWidget, FORM_CLASS):
    def __init__(self, iface, parent=None):
        super(TopoCADGISDockWidget, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_timer_label)
        self.start_time = 0
        self.estimated_duration = 10.0
        self.current_step = 0
        self.created_layers = []
        self.highlights = []
        self.log_helper = LogHelper()
        self.analysis_done = False # Flag for two-stage analysis confirmation
        self.analysis_errors = [] # Store errors for restoration
        self.lines_layer_for_dxf = None # Store lines layer for final DXF export
        self.dxf_name = "" # Store DXF name for HTML summary
        self.working_layer = None # Initialize working layer
        self.output_dir = None # Initialize output directory
        self.poly_recintos = None # Polygon layer for Recintos
        self.poly_clases = None # Polygon layer for Clases
        self.poly_viales = None # Polygon layer for Viales (Herramienta Satélite)
        self.lines_cierres = None # Lines layer for Cierres (Herramienta Satélite)
        self._dup_version = 0 # Track duplicates step iteration
        self.step_17_iter = 0 # Contador de iteraciones para evitar bloqueos WinError 32
        # Inicializar Pasos - Flujo de trabajo topológico profesional
        self.steps = [
            self.step_load_logic,              # 0 - Cargar DXF
            self.step_fix_geometries_logic,    # 1 - Reparar geometrías inválidas
            self.step_normalize_coordinates_logic, # 2 - Normalizar coordenadas (NUEVO)
            self.step_detect_duplicates_logic, # 3 - Detectar duplicados
            self.step_smart_snap_logic,        # 4 - Snap inteligente (MOVIDO AQUÍ)
            self.step_join_collinear_logic,    # 5 - Unir colineales (1er pase, SIN snap)
            self.step_join_collinear_2_logic,  # 6 - Re-unir colineales (2do pase, SIN snap)
            self.step_split_intersections_logic,# 7 - Cortar intersecciones
            self.step_detect_dangles_logic,    # 8 - Detectar dangles
            self.step_extend_dangles_logic,    # 9 - Extender dangles
            self.step_split_intersections_2_logic,# 10 - Re-cortar después de extender
            self.step_simplify_logic_3,        # 11 - Simplificar (protegido)
            self.step_check_validity_logic,    # 12 - Validar errores
            self.step_verify_enclosures_logic, # 13 - Verificar áreas cerradas
            self.step_verify_slivers_logic,    # 14 - Verificar astillas (NUEVO)
            self.step_analyze_changes_logic,   # 15 - Analizar cambios geométricos
            self.step_generate_polygons_logic, # 16 - Generar polígonos
            self.step_validate_polygons_logic, # 17 - Validar polígonos
            self.step_verify_polygon_topology_logic, # 18 - Verificar Topología (NUEVO)
            self.step_export_dxf_logic         # 19 - Exportar DXF Final
        ]

        self.step_info = [
            ("Cargar DXF", "Carga el archivo DXF y crea una copia de trabajo."),
            ("Reparar Geometrías", "Corrige geometrías inválidas del DXF."),
            ("Normalizar Coordenadas", "Redondea coordenadas a 5 decimales (0.01mm)."),
            ("Detectar Duplicados", "Elimina líneas duplicadas o contenidas."),
            ("Snap Inteligente", "Conecta vértices cercanos (Snap)."),
            ("Unir Colineales", "Fusiona líneas consecutivas."),
            ("Re-unir Colineales", "Segunda pasada de fusión."),
            ("Cortar Intersecciones", "Crea nodos en intersecciones."),
            ("Detectar Dangles", "Identifica líneas colgadas."),
            ("Extender Dangles", "Extiende líneas cortas."),
            ("Re-cortar", "Corta nuevas intersecciones."),
            ("Simplificar", "Elimina vértices redundantes."),
            ("Validar Errores", "Chequeo final de validez."),
            ("Verificar Áreas", "Asegura cierre de polígonos."),
            ("Verificar Astillas", "Detecta polígonos extraños o muy pequeños."),
            ("Analizar Cambios", "Compara geometría original vs final."),
            ("Generar Polígonos", "Crea polígonos finales."),
            ("Validar Polígonos", "Detecta solapes, huecos y astillas."),
            ("Verificar Topología", "Detecta nodos duplicados en contornos cerrados."),
            ("Exportar DXF", "Genera archivo final para CAD.")
        ]
        
        # Conectar interfaz de usuario
        self.btnNext.clicked.connect(lambda: self.go_next(manual=True))
        self.btnPrevious.clicked.connect(self.go_previous)
        self.tableErrors.itemSelectionChanged.connect(self.update_button_state)
        self.tableErrors.itemClicked.connect(self.zoom_to_error)
        self.tableErrors.itemDoubleClicked.connect(self.zoom_to_error_table)
        self.btnZoom.clicked.connect(self.zoom_to_error)
        self.btnFix.clicked.connect(self.fix_action)
        self.btnReset.clicked.connect(self.reset_plugin)
        self.btnSaveProject.clicked.connect(self.save_project)
        self.btnOpenProject.clicked.connect(self.open_project)
        self.btnExportCurrentDXF.clicked.connect(self.export_current_layer_to_dxf)
        
        # Configurar botón de ayuda
        self.btnHelp.setIcon(self.style().standardIcon(QStyle.SP_TitleBarContextHelpButton))
        self.btnHelp.clicked.connect(self.open_help)

        # Estado inicial
        self.lblWorking.setText("")
        self.lblWorking.setVisible(True) 
        self.lblTimer.setText("Estimado: 00:00.00")
        
        self.update_ui()
        
        # Conectar nuevos elementos de UI
        self.btnRefreshLayers.clicked.connect(self.populate_layers)
        
        # Conectar interacciones de listas
        self.listAllLayers.itemDoubleClicked.connect(self.add_layer_to_target)
        self.listRecintos.itemDoubleClicked.connect(self.remove_layer_from_recintos)
        self.listClases.itemDoubleClicked.connect(self.remove_layer_from_clases)
        
        # Conectar cambio de pestaña a validación
        self.tabWidget.currentChanged.connect(self.check_tab_access)
        
        # Conectar botones de acciones masivas
        self.btnAddAllRecintos.clicked.connect(self.add_all_to_recintos)
        self.btnAddAllClases.clicked.connect(self.add_all_to_clases)
        self.btnClearRecintos.clicked.connect(self.clear_recintos)
        self.btnClearClases.clicked.connect(self.clear_clases)
        self.btnImportConfig.clicked.connect(self.import_config)
        
        # Población inicial si el proyecto está cargado
        self.populate_layers()
        self.validate_layers()
        
        # --- Configuración de la pestaña Viales (Herramientas Pro) ---
        self.setup_viales_tab()
        
    def setup_viales_tab(self):
        """Configura dinámicamente la pestaña de Viales."""
        from qgis.PyQt.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QTextEdit, QLabel, QFrame, QDoubleSpinBox
        from qgis.PyQt.QtGui import QFont
        
        self.tabViales = QWidget()
        layout = QVBoxLayout(self.tabViales)
        
        # Título
        lblTitle = QLabel("Generador de Estructura Viaria")
        font = QFont()
        font.setBold(True)
        font.setPointSize(10)
        lblTitle.setFont(font)
        layout.addWidget(lblTitle)
        
        # Línea separadora
        line = QFrame()
        line.setFrameShape(QFrame.HLine)
        line.setFrameShadow(QFrame.Sunken)
        layout.addWidget(line)
        
        # Parámetro de Densificación
        layout_dens = QHBoxLayout()
        lblDens = QLabel("Densificación (m):")
        self.sbDensificacion = QDoubleSpinBox()
        self.sbDensificacion.setRange(0.01, 100.0)
        self.sbDensificacion.setSingleStep(0.1)
        self.sbDensificacion.setValue(1.0)
        self.sbDensificacion.setDecimals(2)
        self.sbDensificacion.setToolTip("Distancia máxima entre puntos de fachada para Voronoi. Valores bajos = Más precisión y lentitud.")
        layout_dens.addWidget(lblDens)
        layout_dens.addWidget(self.sbDensificacion)
        layout_dens.addStretch()
        layout.addLayout(layout_dens)
        
        # Botón Principal
        self.btnGenerateViales = QPushButton("Generar Polígonos de Vial y Cruces")
        self.btnGenerateViales.setMinimumHeight(45)
        self.btnGenerateViales.setStyleSheet("background-color: #3f51b5; color: white; font-weight: bold; border-radius: 4px;")
        self.btnGenerateViales.clicked.connect(self.step_generate_viales_logic)
        layout.addWidget(self.btnGenerateViales)
        
        # Log independiente
        layout.addWidget(QLabel("Log de Viales:"))
        self.txtLogViales = QTextEdit()
        self.txtLogViales.setReadOnly(True)
        self.txtLogViales.setStyleSheet("background-color: #f5f5f5; font-family: 'Courier New'; font-size: 9pt;")
        layout.addWidget(self.txtLogViales)
        
        # Barra de progreso dedicada
        self.progressViales = QProgressBar()
        self.progressViales.setRange(0, 100)
        self.progressViales.setValue(0)
        self.progressViales.setTextVisible(True)
        self.progressViales.setFormat("Progreso: %p%")
        self.progressViales.setStyleSheet("""
            QProgressBar {
                border: 1px solid #ccc;
                border-radius: 5px;
                text-align: center;
                height: 20px;
            }
            QProgressBar::chunk {
                background-color: #3f51b5;
            }
        """)
        layout.addWidget(self.progressViales)
        
        # Añadir al TabWidget
        self.tabWidget.addTab(self.tabViales, "Viales")
        
    def log_viales(self, message):
        timestamp = time.strftime("[%H:%M:%S]")
        self.txtLogViales.append(f"<b>{timestamp}</b> {message}")
        self.txtLogViales.moveCursor(QTextCursor.End)
        QApplication.processEvents()

    def log(self, message, indent=False):
        import re
        
        # Convertir rutas de archivo a enlaces de carpeta clicables
        def make_path_clickable(text):
            # Coincidir rutas de Windows (ej: C:\ruta\a\archivo.ext)
            path_pattern = r'([A-Z]:\\[^<>\s]+\.\w+)'
            
            def replace_path(match):
                full_path = match.group(1)
                folder_path = os.path.dirname(full_path)
                filename = os.path.basename(full_path)
                # Crear una URL file:/// que abre la carpeta
                folder_url = f"file:///{folder_path.replace(os.sep, '/')}"
                return f'<a href="{folder_url}">{full_path}</a>'
            
            return re.sub(path_pattern, replace_path, text)
        
        if indent:
            processed_message = make_path_clickable(message)
            self.txtLog.append(f" - {processed_message}")
        else:
            timestamp = time.strftime("[%Y-%m-%d %H:%M:%S]")
            processed_message = make_path_clickable(message)
            # Usar HTML para timestamp en negrita
            self.txtLog.append(f"<b>{timestamp}</b> {processed_message}")
            
        # Forzar Scroll al final
        self.txtLog.moveCursor(QTextCursor.End)

    def get_feature_by_uuid(self, uuid_value, layer=None):
        """Buscar feature por UUID en una capa específica o en la capa de trabajo."""
        target_layer = layer if layer else self.working_layer
        if not target_layer or not uuid_value:
            return None
        
        # Verificar si el campo UUID existe
        has_uuid = False
        for field in target_layer.fields():
            if field.name() == 'UUID':
                has_uuid = True
                break
        
        if not has_uuid:
            return None
        
        # Buscar feature con UUID coincidente
        for feat in target_layer.getFeatures():
            if feat['UUID'] == uuid_value:
                return feat
        
        return None

    def update_button_state(self):
        has_selection = len(self.tableErrors.selectedRanges()) > 0
        self.btnZoom.setEnabled(has_selection)
        self.btnFix.setEnabled(has_selection)

    def handle_errors(self, errors, default_layer=None):
        """
        Manejar errores devueltos por los pasos.
        Puebla la tabla de errores y devuelve False si hay errores, True en caso contrario.
        """
        if not errors:
            return True
            
        # Inyectar layer_id si falta para facilitar el zoom/selección
        if default_layer:
            for err in errors:
                if 'layer_id' not in err:
                    err['layer_id'] = default_layer.id()

        self.current_errors = errors
        self.tableErrors.setRowCount(len(errors))
        
        for i, error in enumerate(errors):
            msg = error.get('msg', 'Error desconocido')
            # Añadir a la tabla
            item_msg = QTableWidgetItem(msg)
            self.tableErrors.setItem(i, 0, item_msg)
            
        self.label_errors.setText(f"Errores Detectados: ({len(errors)})")
        self.log(f"Se encontraron {len(errors)} errores/advertencias.", indent=True)
        
        return False

    def update_ui(self):
        if self.current_step < len(self.step_info):
            name, desc = self.step_info[self.current_step]
            self.lblStep.setText(f"Paso {self.current_step + 1} de {len(self.steps)}: {name}")
            self.lblDescription.setText(desc)
        
        self.btnPrevious.setEnabled(self.current_step > 0)
        if self.current_step == len(self.steps) - 1:
            self.btnNext.setText("Finalizar")
        else:
            self.btnNext.setText("Siguiente")
        
        self.update_button_state()

    def update_timer_label(self):
        # Obsoleto: Lógica del temporizador eliminada en favor de etiqueta simple TRABAJANDO
        pass

    def progress_callback(self, current=None, total=None):
        """Llamado por pasos de larga duración para actualizar la barra y mantener la UI activa."""
        if current is not None and total is not None:
            if total > 0:
                self.progressBar.setMaximum(total)
                self.progressBar.setValue(current)
            else:
                self.progressBar.setMaximum(0)
                self.progressBar.setValue(0)
        elif current is not None:
            # Si solo llega el actual, asumimos que el total ya estaba configurado
            self.progressBar.setValue(current)

        QApplication.processEvents()

    def get_processing_feedback(self):
        """Devuelve un objeto de feedback conectado a la barra de progreso del plugin."""
        from qgis.core import QgsProcessingFeedback
        
        class PluginFeedback(QgsProcessingFeedback):
            def __init__(self, callback):
                super().__init__()
                self.callback = callback
            def setProgress(self, progress):
                if self.callback:
                    # QGIS entrega progreso en 0-100
                    self.callback(int(progress), 100)
                    
        return PluginFeedback(self.progress_callback)

    def reset_plugin(self, force=False):
        if not force:
            reply = QMessageBox.question(self, "Confirmar Reinicio", 
                "¿Está seguro de que desea reiniciar el plugin?\nSe eliminarán todas las capas generadas del proyecto y se restablecerán los parámetros.",
                QMessageBox.Yes | QMessageBox.No)
            if reply == QMessageBox.No: return

        project = QgsProject.instance()
        
        layers_to_remove = []
        for layer_id in self.created_layers:
            layers_to_remove.append(layer_id)
            
        for layer_id, layer in project.mapLayers().items():
            name = layer.name()
            # Eliminar capas numeradas (ej: 01_00_Carga.shp)
            if re.match(r'^\d{2}_\d{2}_', name):
                layers_to_remove.append(layer_id)
            # Eliminar capa LOG
            elif name == "LOG":
                layers_to_remove.append(layer_id)
            # Eliminar capas del directorio de salida ValGIS
            elif "ValGIS_Output" in layer.source():
                 layers_to_remove.append(layer_id)

        layers_to_remove = list(set(layers_to_remove))
        if layers_to_remove:
            project.removeMapLayers(layers_to_remove)
            
        self.created_layers = []
        
        # Reiniciar log_helper
        self.log_helper = LogHelper()
        
        # Reiniciar parámetros
        self.sbTolerance.setValue(0.025)
        self.sbExtensionTolerance.setValue(0.025)
        self.sbAngleTolerance.setValue(15.0)
        self.sbMinLength.setValue(0.025)
        self.sbSagitta.setValue(0.001)
        self.sbArcLength.setValue(0.30)
        self.clear_highlights()
        
        # Reiniciar al paso 1
        self.current_step = 0
        self.working_layer = None
        self.output_dir = None
        self._dup_version = 0
        self.current_errors = []
        self.tableErrors.setRowCount(0)
        self.label_errors.setText("Errores Detectados: (0)")
        
        # Limpiar etiqueta de trabajo (puede quedar en "TRABAJANDO" si se reinicia durante proceso)
        self.lblTimer.setText("")
        self.lblTimer.setStyleSheet("")
        self.progressBar.setValue(0)
        
        # Limpiar texto del log
        self.txtLog.clear()
        
        self.log("Plugin reiniciado y parámetros restablecidos.")
        
        # Restaurar visibilidad de capas restantes (DXF Original)
        root = project.layerTreeRoot()
        for child in root.children():
            child.setItemVisibilityChecked(True)
        
        # Zoom a extensión completa
        self.iface.mapCanvas().refresh()
        self.iface.mapCanvas().zoomToFullExtent()
        
        self.update_ui()

    def restart_topology_loop(self):
        """
        Reiniciar el bucle de topología desde el paso 7 (Cortar Intersecciones) después de correcciones manuales.
        Esto guarda el estado actual, limpia archivos intermedios y prepara para re-ejecución.
        """
        import os
        import shutil
        from qgis.core import QgsProject, QgsVectorLayer
        
        self.log("Reiniciando bucle de topología desde 'Cortar Intersecciones'...")
        
        # 1. Guardar capa de trabajo actual al nombre esperado para el paso 7
        target_filename = "04_00_Unido2.shp"
        target_path = os.path.join(self.output_dir, target_filename)
        
        # Eliminar archivo antiguo si existe
        if os.path.exists(target_path):
            for ext in ['.shp', '.shx', '.dbf', '.prj', '.cpg', '.qpj']:
                file_to_remove = target_path.replace('.shp', ext)
                if os.path.exists(file_to_remove):
                    try:
                        os.remove(file_to_remove)
                    except Exception as e:
                        self.log(f"  Advertencia: No se pudo eliminar {file_to_remove}: {e}", indent=True)
        
        # Guardar estado actual a la ruta destino
        from .helpers.layer_utils import clean_and_save_layer
        self.working_layer, _ = clean_and_save_layer(self.working_layer, target_path)
        self.log(f"  Estado actual guardado como: {target_filename}", indent=True)
        
        # 2. Eliminar capas intermedias del proyecto QGIS
        project = QgsProject.instance()
        layers_to_remove = []
        
        # Identificar capas de los pasos 7-10 por sus nombres de archivo
        intermediate_files = [
            "05_00_Cortado.shp",
            "08_00_Recortado.shp"
        ]
        
        for layer_id in list(self.created_layers):
            layer = project.mapLayer(layer_id)
            if layer:
                source = layer.source()
                for intermediate_file in intermediate_files:
                    if intermediate_file in source:
                        layers_to_remove.append(layer_id)
                        self.created_layers.remove(layer_id)
                        break
        
        if layers_to_remove:
            project.removeMapLayers(layers_to_remove)
            self.log(f"  Eliminadas {len(layers_to_remove)} capas intermedias del proyecto.", indent=True)
        
        # 3. Eliminar shapefiles intermedios del disco
        for intermediate_file in intermediate_files:
            file_path = os.path.join(self.output_dir, intermediate_file)
            if os.path.exists(file_path):
                for ext in ['.shp', '.shx', '.dbf', '.prj', '.cpg', '.qpj']:
                    file_to_remove = file_path.replace('.shp', ext)
                    if os.path.exists(file_to_remove):
                        try:
                            os.remove(file_to_remove)
                        except Exception as e:
                            self.log(f"  Advertencia: No se pudo eliminar {file_to_remove}: {e}", indent=True)
                self.log(f"  Eliminado archivo intermedio: {intermediate_file}", indent=True)
        
        # 4. Añadir la capa renombrada al proyecto (será usada por el paso 7)
        self.add_layer_to_project(self.working_layer)
        self.created_layers.append(self.working_layer.id())
        
        # 5. Reiniciar la bandera del bucle
        self.changes_made_in_loop = False
        
        self.log("  Bucle de topología reiniciado. Continuando desde paso 7...", indent=True)

    def clear_highlights(self):
        for h in self.highlights:
            h.hide()
            del h
        self.highlights = []

    def update_layer_visibility(self):
        if not self.working_layer: return
        
        root = QgsProject.instance().layerTreeRoot()
        for child in root.children():
            if child.layerId() == self.working_layer.id():
                child.setItemVisibilityChecked(True)
            else:
                child.setItemVisibilityChecked(False)
        
        self.iface.mapCanvas().refresh()

    def go_next(self, manual=False):
        try:
            # Bloquear UI para evitar procesamiento concurrente
            self.btnNext.setEnabled(False)
            self.btnPrevious.setEnabled(False)
            QApplication.processEvents()
            
            result = False
            # Excluimos los pasos que son estrictamente bloqueantes y DEBEN auto-reevaluarse: Pasos < 8 y Paso 14 [índice 13]
            # Excluimos los pasos que son estrictamente bloqueantes y DEBEN auto-reevaluarse: Pasos < 8 y Paso 14 [índice 13]
            if manual and self.current_step >= 8 and self.current_step != 13 and self.tableErrors.rowCount() > 0:
                # Paso 17 (Generar Polígonos - Índice 16)
                if self.current_step == 16:
                    reply = QMessageBox.question(self, "Fugas Detectadas", 
                        f"Se han detectado {self.tableErrors.rowCount()} posibles fugas (líneas interiores).\n\n"
                        "¿Desea ignorarlas y avanzar al siguiente paso (SÍ) o prefiere re-ejecutar el paso tras corregir las líneas (NO)?",
                        QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
                    
                    if reply == QMessageBox.Yes:
                        self.log("   Usuario ignora fugas. Avanzando...", indent=True)
                        
                        self.tableErrors.setRowCount(0)
                        self.current_errors = []
                        result = True 
                    else:
                        self.log("   Usuario decidió re-ejecutar el Paso 17.", indent=True)
                        
                        # Limpiar tabla para permitir re-ejecución
                        self.tableErrors.setRowCount(0)
                        self.current_errors = []
                        
                        # Refresco visual
                        self.lblTimer.setText("TRABAJANDO")
                        self.lblTimer.setStyleSheet("color: red; font-weight: bold;")
                        self.lblTimer.repaint()
                        QApplication.processEvents()
                        
                        # El propio step_generate_polygons_logic se encargará de limpiar las capas viejas
                        result = self.steps[self.current_step]()
                        
                        self.lblTimer.setText("")
                        self.progressBar.setValue(0)
                        
                        if self.tableErrors.rowCount() > 0:
                            self.log(f"   Paso {self.current_step+1} finalizado con incidencias tras re-ejecución.", indent=True)
                            self.apply_group_styles()
                            return 
                        
                        # Si tras re-ejecutar no hay errores, permitimos avance
                        self.log(f"   Paso {self.current_step+1} completado sin errores.", indent=True)
                        result = True 
                else:
                    # Lógica estándar de Decisión (Yes/No) para otros pasos
                    title = "Incidencias Pendientes"
                    msg = f"Se han detectado {self.tableErrors.rowCount()} incidencias.\n\n¿Desea continuar al siguiente paso ignorando estos errores o prefiere re-ejecutar el Paso {self.current_step+1}?"
                    
                    if self.current_step == 8:
                        title = "Colgados Detectados"
                        msg = f"Se han detectado {self.tableErrors.rowCount()} colgados.\n\n¿Desea avanzar al Paso 10 para intentar auto-corregirlos o prefiere resolverlos manualmente aquí?"
                    elif self.current_step == 14:
                        title = "Astillas Detectadas"
                        msg = f"Se han detectado {self.tableErrors.rowCount()} posibles astillas o polígonos excesivamente finos.\n\n¿Desea ignorar estas alertas y continuar con el análisis de cambios?"
                    elif self.current_step == 15:
                        title = "Confirmar Cambios Geométricos"
                        msg = f"Se han detectado y listado {self.tableErrors.rowCount()} cambios geométricos significativos en la topología.\n\n¿Ha revisado estos cambios y está de acuerdo en continuar al siguiente paso?"
                    elif self.current_step == 17:
                        title = "Validación de Polígonos"
                        msg = f"Se han detectado {self.tableErrors.rowCount()} errores de topología en polígonos.\n\n¿Desea ignorarlos y proceder a la exportación DXF?"
                    else:
                        # Otros pasos no previstos
                        self.log(f"Paso {self.current_step+1} bloqueado por incidencias. Corrija y vuelva a intentar.", indent=True)
                        self.apply_group_styles()
                        return

                    reply = QMessageBox.question(self, title, msg, QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
                    
                    if reply == QMessageBox.Yes:
                        if self.current_step == 15:
                            self.log("   Usuario aprueba los cambios geométricos. Avanzando...", indent=True)
                        else:
                            self.log(f"   Usuario decidió avanzar al siguiente paso ignorando errores del Paso {self.current_step+1}.", indent=True)
                        # Limpiar tabla para permitir el avance al final de la funcion
                        self.tableErrors.setRowCount(0)
                        self.current_errors = []
                        result = True
                    else:
                        if self.current_step == 15:
                            self.log("   Usuario requiere más tiempo para revisar los cambios. Proceso pausado.", indent=True)
                            self.apply_group_styles()
                            return # Pausa sin re-ejecutar nada
                        else:
                            self.log(f"   Usuario decidió re-ejecutar el Paso {self.current_step+1}.", indent=True)
                            
                            # Feedback visual de procesamiento
                            self.tableErrors.setRowCount(0)
                            self.current_errors = []
                            self.lblTimer.setText("TRABAJANDO")
                            self.lblTimer.setStyleSheet("color: red; font-weight: bold;")
                            self.lblTimer.repaint()
                            QApplication.processEvents()
                            
                            result = self.steps[self.current_step]()
                            
                            self.lblTimer.setText("") # Limpiar etiqueta
                            self.progressBar.setValue(0)
                            
                            if self.tableErrors.rowCount() > 0:
                                self.log(f"   Paso {self.current_step+1} sigue con incidencias tras refresco. Detenido.", indent=True)
                                self.apply_group_styles()
                                return 
                            result = True # Refresco exitoso, permitir avance
            else:
                # --- Ejecución Estándar (Flujo automático o sin errores previos) ---
                # Limpiar tabla de errores al inicio
                self.tableErrors.setRowCount(0)
                self.current_errors = []
                self.label_errors.setText("Errores Detectados: (0)")
                
                if self.current_step > 0:
                    if not self.working_layer or not self.working_layer.isValid():
                        QMessageBox.warning(self, "Capa no encontrada", "Capa inválida.")
                        return

                self.log(f"Ejecutando Paso {self.current_step + 1}: {self.step_info[self.current_step][0]}...")
                
                self.start_time = time.time()
                self.lblTimer.setText("TRABAJANDO")
                self.lblTimer.setStyleSheet("color: red; font-weight: bold;")
                self.lblTimer.repaint()
                QApplication.processEvents()
                
                if self.current_step == 4: 
                    self.changes_made_in_loop = False
                
                # Añadir campo ESTADO antes de iniciar procesamiento (Paso 1)
                if self.current_step == 1:
                    self.add_state_field()
                    
                result = self.steps[self.current_step]()
                
                self.lblTimer.setText("") # Limpiar etiqueta de trabajo
                self.progressBar.setValue(0)
                
                elapsed = time.time() - self.start_time
                self.log(f"Completado en {elapsed:.2f} segundos.", indent=True)
                
                if result:
                    self.update_layer_visibility()

            # --- Verificación de Errores Post-Ejecución ---
            if self.tableErrors.rowCount() > 0:
                # Caso Bloqueante: Pasos iniciales (P1-P8), Verificación Áreas (P14 / Índice 13), y Generar Polígonos (P17 / Índice 16)
                if self.current_step < 8 or self.current_step == 13 or self.current_step == 16:
                    self.log(f"   Paso {self.current_step+1} detenido: Se han detectado {self.tableErrors.rowCount()} incidencias que requieren revisión.", indent=True)
                    self.apply_group_styles()
                    return # Detener avance para interacción
                
                # Caso Dangles (Paso 9 / Índice 8): Parada informativa
                elif self.current_step == 8:
                    self.log(f"Paso 9 detenido: Se detectaron {self.tableErrors.rowCount()} colgados. Pulse 'Siguiente' para decidir si avanzar al Paso 10 (Auto-Arreglo).", indent=True)
                    self.apply_group_styles()
                    return
                    
                # Otros pasos con manejo especial (Slivers, Validar Poligonos)
                # Manejo Especial: Validación Polígonos (Paso 18 / Índice 17)
                elif self.current_step == 17:
                    reply = QMessageBox.question(self, "Topología Polígonos", "¿Desea ignorar los fallos y generar el DXF final?", QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
                    if reply != QMessageBox.Yes:
                        self.steps[self.current_step]()
                        return
                elif self.auto_fix_enabled():
                    # Parada silenciosa por seguridad en modo auto para otros pasos
                    self.log(f"Parada Automática: Errores en Paso {self.current_step+1}.", indent=True)
                    self.apply_group_styles()
                    return
                else:
                    self.log(f"Hay {self.tableErrors.rowCount()} errores. Detenido.", indent=True)
                    self.apply_group_styles()
                    return

            # --- Incremento y Avance al siguiente ---
            if self.current_step < len(self.steps) - 1:
                # Caso Especial: Paso 17 finalizado con éxito (con o sin errores ignorados)
                # Consolidamos los archivos temporales a los nombres definitivos.
                if self.current_step == 16:
                    self.finalize_step_17()
                    
                self.current_step += 1
                self.update_ui()
                
                # AVANCE AL SIGUIENTE PASO
                # 1. Si Auto-Mode está ON -> Ejecutar siguiente paso automáticamente.
                # 2. Si Manual-Mode pero forzamos avance (SÍ o NO exitoso) en Dangles -> Ejecutar Paso 10.
                if self.auto_fix_enabled() or (manual and self.current_step == 9):
                     self.log(f"Iniciando Paso {self.current_step+1}...", indent=True)
                     # Usar QTimer para evitar desbordamiento de pila (recursión)
                     from qgis.PyQt.QtCore import QTimer
                     QTimer.singleShot(10, lambda: self.go_next(manual=manual))
            else:
                self.log("Proceso finalizado.")

        except Exception as e:
            if hasattr(self, 'timer'): self.timer.stop()
            self.lblWorking.setText("")
            self.log(f"Error en Paso {self.current_step + 1}: {str(e)}")
            QMessageBox.critical(self, "Error", f"Fallo en Paso {self.current_step + 1} ({self.step_info[self.current_step][0]}):\n{str(e)}")
        finally:
            # Rehabilitar UI al finalizar (exista error o no)
            self.btnNext.setEnabled(True)
            self.btnPrevious.setEnabled(True)
            self.update_button_state()

    def go_previous(self):
        # Limpiar tabla de errores al retroceder
        self.tableErrors.setRowCount(0)
        self.current_errors = []
        self.label_errors.setText("Errores Detectados: (0)")
        
        if self.current_step > 0:
            self.current_step -= 1
            self.update_ui()

    def zoom_to_error(self, item=None):
        # Limpiar cualquier resaltado previo primero
        self.clear_highlights()
        
        # Deseleccionar cualquier objeto seleccionado en todas las capas del proyecto
        for layer in QgsProject.instance().mapLayers().values():
            if isinstance(layer, QgsVectorLayer):
                layer.removeSelection()
        
        if not item:
            row = self.tableErrors.currentRow()
        else:
            row = item.row()
        
        if row < 0 or row >= len(self.current_errors): 
            return
            
        err = self.current_errors[row]
        
        # 1. IDENTIFICAR Y ACTIVAR LA CAPA CORRECTA
        layer_id = err.get('layer_id')
        target_layer = QgsProject.instance().mapLayer(layer_id) if layer_id else self.working_layer
        
        if target_layer:
            self.iface.setActiveLayer(target_layer)
            
            # 2. SELECCIÓN Y RESALTADO DE FEATURE EN LA CAPA DESTINO
            feat = None
            if 'uuid' in err:
                feat = self.get_feature_by_uuid(err['uuid'], target_layer)
            elif 'id' in err:
                feat = target_layer.getFeature(err['id'])
            
            if feat and feat.isValid():
                # Selección estándar de QGIS (normalmente amarillo)
                target_layer.selectByIds([feat.id()])
            
        # 3. ZOOM DINÁMICO
        pt = err.get('point')
        bbox = err.get('bbox')
        
        if bbox:
            # Si hay una caja (ej: polígono fugado), hacemos zoom a la extensión completa
            self.iface.mapCanvas().setExtent(bbox)
            self.iface.mapCanvas().zoomByFactor(1.3) # Margen de cortesía
            self.iface.mapCanvas().refresh()
        elif pt:
            # Si solo hay un punto (ej: dangle), zoom centrado de 2x2 metros
            rect = QgsRectangle(pt.x() - 1, pt.y() - 1, pt.x() + 1, pt.y() + 1)
            self.iface.mapCanvas().setExtent(rect)
            self.iface.mapCanvas().refresh()

    def zoom_to_error_table(self, item):
        """Manejar doble-clic en elemento de tabla."""
        if item:
            self.zoom_to_error(item)


    def apply_fix(self, error_data):
        success = False
        err_type = error_data.get('type', '')
        
        # Helper function to get feature from error_data
        def get_feature_from_error(error_data):
            """Get feature using UUID if available, otherwise FID"""
            if 'uuid' in error_data:
                return self.get_feature_by_uuid(error_data['uuid'])
            elif 'id' in error_data:
                return self.working_layer.getFeature(error_data['id'])
            return None
        
        if err_type == 'dangle':
            if error_data.get('can_snap') and error_data.get('snap_point'):
                pt = error_data['point']
                snap_pt = error_data['snap_point']
                rect = QgsRectangle(pt.x()-0.001, pt.y()-0.001, pt.x()+0.001, pt.y()+0.001)
                req = self.working_layer.getFeatures(rect)
                
                for feat in req:
                    geom = feat.geometry()
                    
                    if geom.isMultipart():
                        parts = geom.asMultiPolyline()
                    else:
                        parts = [geom.asPolyline()]
                    
                    modified_feat = False
                    new_parts = []
                    
                    for poly in parts:
                        if not poly: 
                            new_parts.append(poly)
                            continue
                        
                        new_poly = list(poly)
                        modified_poly = False
                        
                        if QgsPointXY(poly[0]).distance(pt) < 0.001:
                            new_poly[0] = snap_pt
                            modified_poly = True
                        elif QgsPointXY(poly[-1]).distance(pt) < 0.001:
                            new_poly[-1] = snap_pt
                            modified_poly = True
                        
                        new_parts.append(new_poly)
                        if modified_poly:
                            modified_feat = True
                    
                    if modified_feat:
                        if geom.isMultipart():
                            new_geom = QgsGeometry.fromMultiPolylineXY(new_parts)
                        else:
                            if len(new_parts) > 0:
                                new_geom = QgsGeometry.fromPolylineXY(new_parts[0])
                            else:
                                new_geom = None # Should not happen if original was valid
                        
                        if new_geom:
                            self.working_layer.changeGeometry(feat.id(), new_geom)
                            success = True
                            self.changes_made_in_loop = True
                    
                    if not parts:
                        self.working_layer.deleteFeature(feat.id())
                    else:
                        if len(parts) == 1 and not geom.isMultipart():
                             new_geom = QgsGeometry.fromPolylineXY(parts[0])
                        else:
                             new_geom = QgsGeometry.fromMultiPolylineXY(parts)
                             
                        self.working_layer.changeGeometry(feat.id(), new_geom)
                    
                    success = True
                    self.changes_made_in_loop = True

        elif err_type == 'open_area':
            # Open area errors (from step 14) - analyze why auto-fix failed
            self.log(f"Error 'Área no cerrada': Analizando por qué no se pudo corregir automáticamente...", indent=True)
            
            pt = error_data.get('point')
            if not pt:
                self.log(f"  ✗ No se pudo obtener la ubicación del dangle.", indent=True)
                return False
            
            # Get tolerance
            tol = self.sbTolerance.value()
            
            # Build spatial index
            from qgis.core import QgsSpatialIndex, QgsRectangle
            index = QgsSpatialIndex(self.working_layer.getFeatures())
            
            # Search for nearby features
            search_rect = QgsRectangle(
                pt.x() - tol,
                pt.y() - tol,
                pt.x() + tol,
                pt.y() + tol
            )
            
            candidate_fids = index.intersects(search_rect)
            
            self.log(f"  📍 Dangle en: ({pt.x():.3f}, {pt.y():.3f})", indent=True)
            self.log(f"  🔍 Buscando segmentos dentro de {tol}m...", indent=True)
            
            found_candidates = 0
            closest_segment_dist = float('inf')
            diagnostics = []
            
            for fid in candidate_fids:
                feat = self.working_layer.getFeature(fid)
                if not feat.isValid():
                    continue
                
                geom = feat.geometry()
                if geom.isMultipart():
                    parts = geom.asMultiPolyline()
                else:
                    parts = [geom.asPolyline()]
                
                # Check if this is the dangle's own feature
                is_dangle_feature = False
                for part in parts:
                    if len(part) >= 2:
                        start = QgsPointXY(part[0])
                        end = QgsPointXY(part[-1])
                        if start.distance(pt) < 0.001 or end.distance(pt) < 0.001:
                            is_dangle_feature = True
                            break
                
                if is_dangle_feature:
                    continue
                
                # Analyze each segment
                for part_idx, part in enumerate(parts):
                    if len(part) < 2:
                        continue
                    
                    for seg_idx in range(len(part) - 1):
                        seg_start = QgsPointXY(part[seg_idx])
                        seg_end = QgsPointXY(part[seg_idx + 1])
                        
                        # Calculate projection
                        dx = seg_end.x() - seg_start.x()
                        dy = seg_end.y() - seg_start.y()
                        
                        if abs(dx) < 1e-10 and abs(dy) < 1e-10:
                            continue  # Degenerate segment
                        
                        t = ((pt.x() - seg_start.x()) * dx + (pt.y() - seg_start.y()) * dy) / (dx * dx + dy * dy)
                        
                        # Calculate projection point
                        proj_x = seg_start.x() + t * dx
                        proj_y = seg_start.y() + t * dy
                        projection = QgsPointXY(proj_x, proj_y)
                        
                        dist = pt.distance(projection)
                        
                        if dist < tol:
                            found_candidates += 1
                            closest_segment_dist = min(closest_segment_dist, dist)
                            
                            # Diagnose why it failed
                            reason = []
                            if t < 0:
                                reason.append(f"proyección antes del inicio (t={t:.3f})")
                            elif t > 1:
                                reason.append(f"proyección después del fin (t={t:.3f})")
                            
                            if projection.distance(seg_start) < 0.001:
                                reason.append(f"muy cerca del vértice inicial ({projection.distance(seg_start)*1000:.1f}mm)")
                            if projection.distance(seg_end) < 0.001:
                                reason.append(f"muy cerca del vértice final ({projection.distance(seg_end)*1000:.1f}mm)")
                            
                            if reason:
                                diagnostics.append(f"    • Segmento FID={fid}, dist={dist*100:.1f}cm: {', '.join(reason)}")
            
            if found_candidates == 0:
                self.log(f"  ✗ No se encontraron segmentos cercanos dentro de {tol}m", indent=True)
                self.log(f"  💡 Solución: Aumente la tolerancia de snap o conecte manualmente la línea.", indent=True)
            else:
                self.log(f"  ℹ️ Se encontraron {found_candidates} segmentos cercanos, pero ninguno válido para auto-corrección:", indent=True)
                for diag in diagnostics[:5]:  # Show max 5
                    self.log(diag, indent=True)
                if len(diagnostics) > 5:
                    self.log(f"    ... y {len(diagnostics) - 5} más.", indent=True)
                self.log(f"  💡 Solución: Use las herramientas de edición de QGIS para extender/conectar manualmente.", indent=True)
            
            return False

        elif err_type == 'island':
            step = StepFixIslands()
            if step.fix(self.working_layer, error_data.get('id'), error_data):
                success = True
                self.changes_made_in_loop = True
                self.log(f"  ✓ Isla corregida (corte aplicado).", indent=True)
            else:
                self.log(f"  ✗ No se pudo corregir la isla automáticamente.", indent=True)

        else:
            # Generic delete for other error types
            feat = get_feature_from_error(error_data)
            if feat and feat.isValid():
                success = self.working_layer.deleteFeature(feat.id())
                self.changes_made_in_loop = True
            else:
                self.log(f"Error tipo '{err_type}': No se pudo encontrar la feature para eliminar.", indent=True)
             
        return success

    def fix_action(self):
        selected_rows = set()
        for item in self.tableErrors.selectedItems():
            selected_rows.add(item.row())
        
        if not selected_rows: return
        
        if len(selected_rows) > 1:
            reply = QMessageBox.question(self, "Confirmar Corrección Múltiple", 
                f"¿Desea corregir los {len(selected_rows)} elementos seleccionados?",
                QMessageBox.Yes | QMessageBox.No)
            if reply == QMessageBox.No: return
            
        self.working_layer.startEditing()
        fixed_indices = []
        
        indices = sorted(list(selected_rows), reverse=True)
        
        count = 0
        for idx in indices:
            if idx < len(self.current_errors):
                error_data = self.current_errors[idx]
                try:
                    if self.apply_fix(error_data):
                        fixed_indices.append(idx)
                        count += 1
                except Exception as e:
                    self.log(f"Error corrigiendo ítem {idx}: {str(e)}", indent=True)
        
        if count > 0:
            self.working_layer.commitChanges()
            self.working_layer.triggerRepaint()
            
            for idx in fixed_indices:
                self.tableErrors.removeRow(idx)
                self.current_errors.pop(idx)
            
            self.log(f"Corregidos {count} errores.", indent=True)
            
            self.label_errors.setText(f"Errores Detectados: ({self.tableErrors.rowCount()})")
            
            self.update_ui()
            
            if self.tableErrors.rowCount() == 0:
                QMessageBox.information(self, "Info", "Errores corregidos. Avanzando...")
                self.go_next()
        else:
            self.working_layer.rollBack()
            self.log("No se pudo corregir la selección.", indent=True)

    # --- Step Logic ---

    def add_layer_to_project(self, layer):
        """
        Adds a layer to the project, ensuring it is placed below the LOG layer if it exists.
        """
        project = QgsProject.instance()
        root = project.layerTreeRoot()
        
        # Check if LOG layer exists
        log_layer_node = None
        for child in root.children():
            if child.name() == "LOG":
                log_layer_node = child
                break
        
        project.addMapLayer(layer, False) # Add to registry but not to tree yet
        
        if log_layer_node:
            # Insert below LOG layer
            # We need the index of the LOG node
            idx = root.children().index(log_layer_node)
            root.insertLayer(idx + 1, layer)
        else:
            # Add to top if LOG doesn't exist
            root.insertLayer(0, layer)
            
        return layer

    def step_load_logic(self):
        start_time = time.time()
        layer = self.iface.activeLayer()
        if not layer: raise ValueError("Seleccione capa.")
        
        source_source = layer.source()
        file_path = source_source.split("|")[0]
        if not os.path.exists(file_path):
             file_path = os.path.join(os.path.expanduser("~"), "temp.dxf")
        dir_name = os.path.dirname(file_path)
        
        # Capture DXF metadata for HTML summary and relativization
        self.dxf_name = os.path.basename(file_path)
        self.dxf_source = source_source # Full path with |layername=...
        self.dxf_crs = layer.crs().authid() # e.g., 'EPSG:25830'
        
        i = 1
        while True:
            folder_name = f"ValGIS_Output_{i:03d}"
            full_path = os.path.join(dir_name, folder_name)
            if not os.path.exists(full_path):
                os.makedirs(full_path)
                self.output_dir = full_path
                break
            i += 1
        
        self.log(f"Directorio de salida: {self.output_dir}", indent=True)

        step = StepLoad()
        # Step 1: Use structured naming convention
        filename = get_step_filename(1)
        self.working_layer, errors = step.run(
            layer, 
            self.output_dir, 
            filename=filename,
            log_callback=lambda m: self.log(m, indent=True),
            callback=self.progress_callback
        )
        
        # Create HTML summary report
        create_summary_html(self.output_dir, self.dxf_name)
        self.log(f"Resumen HTML creado: RESUMEN_PROCESO.html", indent=True)
        
        # Create LOG layer FIRST so it's at the top
        self.log_helper.create_log_layer(self.output_dir, self.working_layer.crs())
        if self.log_helper.get_layer():
            self.created_layers.append(self.log_helper.get_layer().id())
            self.log("Capa LOG creada.", indent=True)
            
        # Now add the working layer (it will go below LOG)
        self.add_layer_to_project(self.working_layer)
        self.created_layers.append(self.working_layer.id()) # Track layer
            
        self.log("Capa cargada.", indent=True)
        
        # Update HTML summary with step 1 completion
        feature_count = self.working_layer.featureCount()
        duration = time.time() - start_time
        update_step_status(
            self.output_dir,
            step_number=1,
            status='completed',
            features=feature_count,
            time_seconds=duration,
            errors=len(errors),
            dxf_name=self.dxf_name
        )
        
        # Report any geometries that were filtered during DXF->SHP conversion
        if errors:
            return self.handle_errors(errors)
        
        return True

    def step_simplify_logic_3(self):
        # Post-Split simplification: Use Flecha (Sagitta) value from UI
        filename = get_step_filename(12)
        return self._run_simplify(filename)

    def _run_simplify(self, filename, override_tol=None):
        start_time = time.time()
        if override_tol is not None:
            tol = override_tol
        else:
            tol = self.sbSagitta.value()
            
        step = StepSimplify()
        self.working_layer = step.run(self.working_layer, tol, self.output_dir, filename=filename, callback=self.progress_callback, log_callback=lambda m: self.log(m, indent=True))
        self.add_layer_to_project(self.working_layer)
        self.created_layers.append(self.working_layer.id()) # Track layer
        
        # Ensure ESTADO field exists and is populated
        if self.working_layer.fields().indexOf('ESTADO') == -1:
            self.log("Campo ESTADO no encontrado en capa simplificada, añadiendo...", indent=True)
            self.add_state_field()
        
        # Apply group styles to the simplified layer
        self.apply_group_styles()
        
        # Update HTML summary (Step 12 is simplification)
        duration = time.time() - start_time
        update_step_status(
            self.output_dir,
            step_number=12,
            status='completed',
            features=self.working_layer.featureCount(),
            time_seconds=duration,
            errors=0,
            dxf_name=self.dxf_name
        )
        
        self.log(f"Simplificación completada ({filename}).", indent=True)
        return True

    def auto_fix_enabled(self):
        """Check if auto-fix checkbox is enabled."""
        return self.chkAutoFix.isChecked()

    def step_detect_shorts_logic(self):
        min_len = self.sbMinLength.value()
        tol = self.sbTolerance.value()
        step = StepDetectShorts()
        
        if self.auto_fix_enabled():
            # Auto mode: fix everything automatically
            errors, fixed_count = step.run(self.working_layer, min_len, tol, callback=self.progress_callback, log_helper=self.log_helper, log_callback=lambda m: self.log(m, indent=True))
            
            if fixed_count > 0:
                self.log(f"Se eliminaron automáticamente {fixed_count} objetos cortos.", indent=True)
                self.changes_made_in_loop = True
            
            # In auto mode, only stop if there are unfixable errors
            # If all were fixed, continue automatically
            return self.handle_errors(errors)
        else:
            # Manual mode: detect all without auto-fixing and stop for user correction
            errors = []
            for feature in self.working_layer.getFeatures():
                geom = feature.geometry()
                length = geom.length()
                
                if length < min_len:
                    errors.append({
                        'id': feature.id(),
                        'msg': f"Objeto corto (Long: {length:.4f})",
                        'type': 'short_feature',
                        'point': geom.centroid().asPoint()
                    })
            
            return self.handle_errors(errors)

    def step_normalize_coordinates_logic(self):
        """Normalize coordinates to 5 decimal places with validation check"""
        start_time = time.time()
        from .steps.step_normalize_coordinates import StepNormalizeCoordinates
        step = StepNormalizeCoordinates()
        
        # Run normalization and collect potential validation errors
        errors = step.run(self.working_layer, precision=5, log_callback=lambda m: self.log(m, indent=True), log_helper=self.log_helper, callback=self.progress_callback)
        
        # Save
        filename = get_step_filename(3)
        output_path = os.path.join(self.output_dir, filename)
        from .helpers.layer_utils import clean_and_save_layer
        self.working_layer, _ = clean_and_save_layer(self.working_layer, output_path)
        
        self.add_layer_to_project(self.working_layer)
        self.created_layers.append(self.working_layer.id())
        
        # Update HTML summary
        duration = time.time() - start_time
        update_step_status(
            self.output_dir,
            step_number=3,
            status='completed',
            features=self.working_layer.featureCount(),
            time_seconds=duration,
            errors=len(errors),
            dxf_name=self.dxf_name
        )
        
        self.log(f"Normalización completada (Precisión: 5 decimales).", indent=True)
        
        # Handle errors if any (this will stop the automatic flow and show the error table)
        return self.handle_errors(errors)

    def step_detect_duplicates_logic(self):
        """Detect and remove duplicates with consistent layer traceability and versioning"""
        start_time = time.time()
        from .steps.step_detect_duplicates import StepDetectDuplicates
        from .helpers.naming_convention import get_step_versioned_filename
        from .helpers.layer_utils import clean_and_save_layer
        
        step = StepDetectDuplicates()
        
        # 1. Incrementar versión iterativa
        self._dup_version += 1
        
        # 2. Ejecutar detección (usando el motor optimizado)
        auto_fix = self.auto_fix_enabled()
        errors, fixed_count = step.run(
            self.working_layer, 
            auto_fix=auto_fix,
            callback=self.progress_callback, 
            log_helper=self.log_helper, 
            log_callback=lambda m: self.log(m, indent=True)
        )
        
        # 3. Guardar nueva versión ANTES de eliminar la anterior (Prevenir Access Violation)
        versioned_filename = get_step_versioned_filename(4, self._dup_version)
        output_path = os.path.join(self.output_dir, versioned_filename)
        
        # Primero guardamos
        new_layer, _ = clean_and_save_layer(self.working_layer, output_path)
        
        # Una vez guardada la nueva, podemos eliminar la vieja del proyecto con seguridad
        old_layer_id = self.working_layer.id()
        QgsProject.instance().removeMapLayer(old_layer_id)
        if old_layer_id in self.created_layers:
            self.created_layers.remove(old_layer_id)
            
        # Actualizar handle a la nueva capa
        self.working_layer = new_layer
        
        self.add_layer_to_project(self.working_layer)
        self.created_layers.append(self.working_layer.id())
        
        # 4. Actualizar resumen HTML
        duration = time.time() - start_time
        update_step_status(
            self.output_dir,
            step_number=4,
            status='completed',
            features=self.working_layer.featureCount(),
            time_seconds=duration,
            errors=len(errors),
            dxf_name=self.dxf_name
        )
        
        if fixed_count > 0:
            self.log(f"Limpieza automática: {fixed_count} objetos eliminados.", indent=True)
            self.changes_made_in_loop = True

        # 5. Gestionar errores
        has_errors = not self.handle_errors(errors)
        
        # 6. Consolidación automática si no hay errores
        if not has_errors:
            self._consolidate_step4()
            
        return not has_errors

    def _consolidate_step4(self):
        """Consolida el último 04_XY -> 04_00 y limpia intermedios del proyecto y disco."""
        canonical = get_step_filename(4)  # "04_00_Sin_Duplicados.shp"
        canonical_path = os.path.join(self.output_dir, canonical)
        
        self.log("Consolidando versión sin duplicados (04_00)...", indent=True)
        
        from .helpers.layer_utils import clean_and_save_layer
        
        # 1. Copiar último versionado al nombre canónico ANTES de destruirlo de QGIS
        new_layer, _ = clean_and_save_layer(self.working_layer, canonical_path)
        
        # 2. Desconectar working_layer actual (04_XY) del proyecto
        old_id = self.working_layer.id()
        QgsProject.instance().removeMapLayer(old_id)
        if old_id in self.created_layers:
            self.created_layers.remove(old_id)
            
        # 3. Asignar la nueva capa canonizada a la variable principal
        self.working_layer = new_layer
        
        # 3. Limpiar TODOS los intermedios 04_01, 04_02... del proyecto QGIS y disco
        self._cleanup_step4_intermediates()
        
        # 4. Añadir la capa canónica al proyecto
        self.add_layer_to_project(self.working_layer)
        self.created_layers.append(self.working_layer.id())
        
        # 5. Resetear contador
        self._dup_version = 0

    def _cleanup_step4_intermediates(self):
        """Elimina archivos y capas intermedias 04_01, 04_02... del proyecto y disco."""
        import re
        import glob
        project = QgsProject.instance()
        
        # Eliminar del proyecto QGIS
        for layer_id, layer in list(project.mapLayers().items()):
            if re.match(r'^04_(?!00)\d{2}_', layer.name()):
                project.removeMapLayer(layer_id)
                if layer_id in self.created_layers:
                    self.created_layers.remove(layer_id)
        
        # Eliminar del disco (buscar archivos que comiencen por 04_XX donde XX != 00)
        pattern = os.path.join(self.output_dir, "04_[0-9][0-9]_*")
        for f in glob.glob(pattern):
            basename = os.path.basename(f)
            # Asegurarse de no borrar el 04_00
            if not basename.startswith("04_00_"):
                try:
                    os.remove(f)
                except Exception:
                    # Fallo silencioso: Si el shapefile sigue bloqueado por los demonios
                    # de QGIS/Windows, lo dejamos estar y no ensuciamos el LOG.
                    pass

    def step_fix_geometries_logic(self):
        """Repair invalid geometries from DXF import - True Nitro Version"""
        start_time = time.time()
        import processing
        from .helpers.layer_utils import save_layer_nitro
        
        # 1. Capturar estado inicial
        initial_count = self.working_layer.featureCount()
        tol = self.sbSagitta.value()
        if tol <= 0: tol = 1e-6
            
        self.log(f"Iniciando flujo True Nitro (Reparación + Validación Nativa)...", indent=True)
        
        try:
            feedback = self.get_processing_feedback()
            
            # FASE 1: Reparación Nativa (C++)
            # Arregla la mayoría de auto-intersecciones y geometrías degeneradas
            fixed = processing.run("native:fixgeometries", {
                'INPUT': self.working_layer,
                'OUTPUT': 'memory:'
            }, feedback=feedback)['OUTPUT']
            
            # FASE 1b: Conversión Multipartes → Partes Simples (C++)
            # Las entidades multipart del DXF causan problemas en edición de vértices,
            # selección de extremos y borrado inesperado de partes no deseadas.
            fixed = processing.run("native:multiparttosingleparts", {
                'INPUT': fixed,
                'OUTPUT': 'memory:'
            }, feedback=feedback)['OUTPUT']
            
            # FASE 2: Purga Nativa de Cortos (Mediante Expresión C++)
            # Mucho más rápido que el bucle for de Python
            purged = processing.run("native:extractbyexpression", {
                'INPUT': fixed,
                'EXPRESSION': f"length($geometry) > {tol}",
                'OUTPUT': 'memory:'
            }, feedback=feedback)['OUTPUT']
            
            # FASE 3: Validación de Errores Persistentes (ELIMINADA)
            # Se ha eliminado native:checkvalidity porque ralentizaba el proceso
            # y 'native:fixgeometries' ya corrige la mayoría de problemas estructurales.
            invalid_count = 0
                
            # FASE 4: Guardado Instantáneo (Bypass Python loop)
            # Actualiza valNUL y guarda a disco en C++
            filename = get_step_filename(2)
            output_path = os.path.join(self.output_dir, filename)
            
            self.working_layer = save_layer_nitro(purged, output_path, log_callback=lambda m: self.log(m, indent=True))
            
            self.add_layer_to_project(self.working_layer)
            self.created_layers.append(self.working_layer.id())
            
            # FASE 5: Reporte Final
            final_count = self.working_layer.featureCount()
            deleted_count = initial_count - final_count
            
            if deleted_count > 0:
                self.log(f"⚡ Rendimiento Nitro: Eliminadas {deleted_count} geometrías (nulas o < {tol}m).", indent=True)
            else:
                self.log("✅ Integridad Total: 0 elementos degenerados detectados.", indent=True)
            
            duration = time.time() - start_time
            update_step_status(self.output_dir, 2, 'completed', final_count, duration, invalid_count, self.dxf_name)
            
            self.log(f"Reparación completada en {duration:.2f}s.", indent=True)
            return True
            
        except Exception as e:
            self.log(f"Error crítico en reparación Nitro: {e}", indent=True)
            import traceback
            self.log(traceback.format_exc(), indent=True)
            return True
    def step_smart_snap_logic(self):
        """Smart snap: finds intersection points for near-touching lines"""
        start_time = time.time()
        from .steps.step_smart_snap import StepSmartSnap
        tol = self.sbTolerance.value()
        angle_tol = self.sbAngleTolerance.value()
        step = StepSmartSnap()
        
        # Find Layer field
        layer_field = None
        for field in self.working_layer.fields():
            if field.name().lower() == 'layer':
                layer_field = field.name()
                break
        
        # Run smart snap with intersection calculation
        snapped_count = step.run(self.working_layer, tol, layer_field, angle_tol, log_callback=lambda m: self.log(m, indent=True), log_helper=self.log_helper, callback=self.progress_callback)
        
        # Save
        filename = get_step_filename(5)
        output_path = os.path.join(self.output_dir, filename)
        from .helpers.layer_utils import clean_and_save_layer
        self.working_layer, _ = clean_and_save_layer(self.working_layer, output_path)
        
        self.add_layer_to_project(self.working_layer)
        self.created_layers.append(self.working_layer.id())
        
        # Update HTML summary
        duration = time.time() - start_time
        update_step_status(
            self.output_dir,
            step_number=5,
            status='completed',
            features=self.working_layer.featureCount(),
            time_seconds=duration,
            errors=0,
            dxf_name=self.dxf_name
        )
        
        self.log(f"Snap inteligente: {snapped_count} ajustes.", indent=True)
        return True

    def step_join_collinear_logic(self):
        """First pass of join collinear"""
        start_time = time.time()
        tol = self.sbTolerance.value()
        from .steps.step_join_collinear import StepJoinCollinear
        step = StepJoinCollinear()
        angle_tol = self.sbAngleTolerance.value()
        
        filename = get_step_filename(6)
        self.working_layer = step.run(
            self.working_layer, 
            self.output_dir, 
            filename=filename,
            tolerance=tol,
            angle_tolerance=angle_tol,
            skip_snap=True,  # Skip internal snap - Smart Snap already executed
            log_callback=lambda m: self.log(m, indent=True),
            callback=self.progress_callback
        )
        self.add_layer_to_project(self.working_layer)
        self.created_layers.append(self.working_layer.id())
        
        # Update HTML summary
        duration = time.time() - start_time
        update_step_status(
            self.output_dir,
            step_number=6,
            status='completed',
            features=self.working_layer.featureCount(),
            time_seconds=duration,
            errors=0,
            dxf_name=self.dxf_name
        )
        
        self.log("Unión de colineales completada (sin snap previo).", indent=True)
        return True

    def step_join_collinear_2_logic(self):
        """Second pass of join collinear after snap"""
        start_time = time.time()
        tol = self.sbTolerance.value()
        from .steps.step_join_collinear import StepJoinCollinear
        step = StepJoinCollinear()
        angle_tol = self.sbAngleTolerance.value()
        
        filename = get_step_filename(7)
        self.working_layer = step.run(
            self.working_layer, 
            self.output_dir, 
            filename=filename,
            tolerance=tol,
            angle_tolerance=angle_tol,
            skip_snap=True,  # Skip internal snap - Smart Snap already executed
            log_callback=lambda m: self.log(m, indent=True),
            log_helper=self.log_helper,
            callback=self.progress_callback
        )
        self.add_layer_to_project(self.working_layer)
        self.created_layers.append(self.working_layer.id())
        
        # Update HTML summary
        duration = time.time() - start_time
        update_step_status(
            self.output_dir,
            step_number=7,
            status='completed',
            features=self.working_layer.featureCount(),
            time_seconds=duration,
            errors=0,
            dxf_name=self.dxf_name
        )
        
        self.log("Re-unión completada (sin snap previo).", indent=True)
        return True

    def step_split_intersections_logic(self):
        start_time = time.time()
        from .steps.step_split_intersections import StepSplitIntersections
        step = StepSplitIntersections()
        
        # Get groups
        recintos_names = [self.listRecintos.item(i).text().split(" [")[0] for i in range(self.listRecintos.count())]
        clases_names = [self.listClases.item(i).text().split(" [")[0] for i in range(self.listClases.count())]
        
        filename = get_step_filename(8)
        self.working_layer = step.run(
            self.working_layer, 
            self.output_dir, 
            filename=filename, 
            log_callback=lambda m: self.log(m, indent=True),
            log_helper=self.log_helper,
            recintos_layers=recintos_names,
            clases_layers=clases_names,
            callback=self.progress_callback
        )
        self.add_layer_to_project(self.working_layer)
        self.created_layers.append(self.working_layer.id()) # Track layer
        
        # Update HTML summary
        duration = time.time() - start_time
        update_step_status(
            self.output_dir,
            step_number=8,
            status='completed',
            features=self.working_layer.featureCount(),
            time_seconds=duration,
            errors=0,
            dxf_name=self.dxf_name
        )
        
        self.log("Intersecciones cortadas.", indent=True)
        return True

    def step_advanced_shorts_logic(self):
        min_len = self.sbMinLength.value()
        step = StepAdvancedShorts()
        
        if self.auto_fix_enabled():
            errors, fixed_count = step.run(self.working_layer, min_len, callback=self.progress_callback, log_helper=self.log_helper, log_callback=lambda m: self.log(m, indent=True))
            
            if fixed_count > 0:
                self.log(f"Se corrigieron automáticamente {fixed_count} segmentos cortos.", indent=True)
                self.changes_made_in_loop = True
                
            return self.handle_errors(errors)
        else:
            # Manual mode: detect without fixing
            errors = []
            for feature in self.working_layer.getFeatures():
                geom = feature.geometry()
                if geom.length() < min_len:
                    errors.append({
                        'id': feature.id(),
                        'msg': "Objeto corto (< min_length)",
                        'point': geom.centroid().asPoint(),
                        'type': 'short_feature'
                    })
                    continue
                
                # Check segments
                if geom.isMultipart():
                    parts = geom.asMultiPolyline()
                else:
                    parts = [geom.asPolyline()]
                
                for part in parts:
                    if len(part) < 2: continue
                    
                    for i in range(len(part) - 1):
                        p1 = part[i]
                        p2 = part[i+1]
                        dist = p1.distance(p2)
                        
        tol = self.sbSagitta.value()
        if tol <= 0:
            tol = 1e-6
            
        to_delete = []
        
        for feature in self.working_layer.getFeatures():
            if feature.geometry().length() < tol:
                to_delete.append(feature.id())
                
        if to_delete:
            self.working_layer.startEditing()
            self.working_layer.deleteFeatures(to_delete)
            self.working_layer.commitChanges()
            self.log(f"Pre-limpieza antes de simplificar: Eliminados {len(to_delete)} elementos menores a {tol:.6f}", indent=True)
        
        # 2. Simplify (if there's a simplify step to run)
        # For now, just log that simplification would happen here
        self.log("Simplificación completada.", indent=True)
        return True

    def step_check_validity_logic(self):
        start_time = time.time()
        step = StepCheckValidity()
        errors = step.run(self.working_layer, log_callback=lambda m: self.log(m, indent=True))
        
        # Update HTML summary
        duration = time.time() - start_time
        update_step_status(
            self.output_dir,
            step_number=13,
            status='completed',
            features=self.working_layer.featureCount(),
            time_seconds=duration,
            errors=len(errors),
            dxf_name=self.dxf_name
        )
        
        return self.handle_errors(errors)




    def step_open_enclosures_logic(self):
        step = StepOpenEnclosures()
        errors = step.run(self.working_layer)
        return self.handle_errors(errors)

    def step_verify_enclosures_logic(self):
        """
        Paso 14 — Verificar Áreas (Dos Fases).

        FASE A — Guardia de Longitud:
            Detecta segmentos < min_length y los muestra como errores.
            NO los borra. El usuario los corrige manualmente y da 'Siguiente'.
            Se repite hasta que no haya ningún segmento corto.

        FASE B — Verificación de Áreas Cerradas:
            Solo se activa cuando la Fase A está limpia.
            Detecta dangles, intenta autocorregir, pausa si hay errores.
            Cuando no hay errores avanza al Paso 15.
        """
        start_time = time.time()
        from .steps.step_verify_enclosures import StepVerifyEnclosures
        from .helpers.layer_utils import explode_multipart_features, purge_zero_length_features
        step = StepVerifyEnclosures()

        min_length = self.sbMinLength.value()
        tol = self.sbTolerance.value()

        self.apply_group_styles()

        # ------------------------------------------------------------------
        # FASE 0: GARANTIZAR MONOPARTE (defensivo)
        # ------------------------------------------------------------------
        # Este paso se re-ejecuta cada vez que el usuario pulsa 'Siguiente'
        # tras corregir errores manualmente en QGIS. Si durante esa corrección
        # manual se ha usado, por ejemplo, la herramienta nativa "Fusionar
        # entidades seleccionadas", el resultado es un ÚNICO objeto MULTIPARTE
        # (varias líneas dentro del mismo feature), no una sola línea continua
        # fusionada. Un multiparte cuyo límite interno entre partes coincide
        # con el punto que se quiere corregir no se puede cortar como si fuera
        # un vértice real de una línea continua, y el error queda sin
        # solución posible desde este paso.
        # Por eso, antes de analizar nada, forzamos que toda la capa de
        # trabajo sea monoparte (separando cada parte en un objeto
        # independiente, conservando atributos).
        n_exploded = explode_multipart_features(
            self.working_layer,
            step_label="Verificar Áreas",
            log_callback=lambda m: self.log(m, indent=True)
        )
        if n_exploded:
            self.log(f"  ℹ️ {n_exploded} objeto(s) multiparte detectados y separados en objetos independientes.", indent=True)

        # ------------------------------------------------------------------
        # FASE 0b: PURGA AUTOMÁTICA DE RESTOS MICROSCÓPICOS (< 0.0001 m)
        # ------------------------------------------------------------------
        # Estos son restos de precisión (p.ej. de redondeos de coordenadas en
        # pasos previos), no segmentos "cortos" reales que el usuario deba
        # revisar. No tiene sentido pedirle que los corrija a mano: se
        # eliminan automáticamente ANTES de que la Fase A analice nada, para
        # que solo se le muestren como error los segmentos cortos genuinos.
        AUTO_PURGE_THRESHOLD = 0.0001
        n_purged, _purged_ids = purge_zero_length_features(
            self.working_layer,
            step_label="Verificar Áreas (purga automática)",
            log_callback=lambda m: self.log(m, indent=True),
            callback=self.progress_callback,
            min_length=AUTO_PURGE_THRESHOLD
        )
        if n_purged > 0:
            self.log(f"  🧹 {n_purged} segmento(s) residual(es) < {AUTO_PURGE_THRESHOLD}m eliminados automáticamente (restos de redondeo).", indent=True)

        # ------------------------------------------------------------------
        # FASE A: GUARDIA DE LONGITUD (sin borrar nada)
        # ------------------------------------------------------------------
        self.log("━━ FASE A: Verificando segmentos cortos...", indent=True)
        short_errors = step.check_short_segments(
            self.working_layer,
            min_length=min_length,
            log_callback=lambda m: self.log(m, indent=True),
            callback=self.progress_callback
        )

        if short_errors:
            # Mostrar errores y pausar. El usuario los corrige y da 'Siguiente'.
            # El sistema volverá a ejecutar step_verify_enclosures_logic (Fase A de nuevo).
            self.log(f"⛔ Fase A bloqueada: {len(short_errors)} segmentos cortos. Corrija manualmente y pulse 'Siguiente'.", indent=True)
            self.handle_errors(short_errors)
            return False  # Bloquea el avance al Paso 15

        # ------------------------------------------------------------------
        # FASE B: SUPER SNAPPER (AJUSTE AUTOMÁTICO)
        # ------------------------------------------------------------------
        self.log("━━ FASE B: Ajuste automático de extremos sueltos (Super Snapper)...", indent=True)

        recintos_names = [self.listRecintos.item(i).text().split(" [")[0] for i in range(self.listRecintos.count())]
        clases_names = [self.listClases.item(i).text().split(" [")[0] for i in range(self.listClases.count())]

        # FASE B: RECINTOS
        if recintos_names:
            quoted_recintos = [f"'{n}'" for n in recintos_names]
            expr = f"\"Layer\" IN ({','.join(quoted_recintos)})"
            from qgis.core import QgsFeatureRequest
            
            it = self.working_layer.getFeatures(QgsFeatureRequest().setFilterExpression(expr))
            from qgis.core import QgsFeature
            if it.nextFeature(QgsFeature()):
                self.log("  Ejecutando Fase B en grupo RECINTOS...", indent=True)
                step.snap_dangles(
                    self.working_layer,
                    tolerance=tol,
                    auto_fix=self.auto_fix_enabled(),
                    log_callback=lambda m: self.log(m, indent=True),
                    callback=self.progress_callback,
                    filter_expression=expr
                )

        # FASE B: CLASES
        if clases_names:
            quoted_clases = [f"'{n}'" for n in clases_names]
            expr = f"\"Layer\" IN ({','.join(quoted_clases)})"
            from qgis.core import QgsFeatureRequest

            it = self.working_layer.getFeatures(QgsFeatureRequest().setFilterExpression(expr))
            from qgis.core import QgsFeature
            if it.nextFeature(QgsFeature()):
                self.log("  Ejecutando Fase B en grupo CLASES...", indent=True)
                step.snap_dangles(
                    self.working_layer,
                    tolerance=tol,
                    auto_fix=self.auto_fix_enabled(),
                    log_callback=lambda m: self.log(m, indent=True),
                    callback=self.progress_callback,
                    filter_expression=expr
                )

        # ------------------------------------------------------------------
        # FASE B.5: RE-GARANTIZAR MONOPARTE (defensivo, segunda red de seguridad)
        # ------------------------------------------------------------------
        # La Fase B (Super Snapper) mueve extremos de vértices; en teoría nunca
        # debería fusionar features distintos entre sí, pero como red de
        # seguridad adicional volvemos a exigir monoparte justo antes de que
        # la Fase C construya el grafo topológico. Así, aunque algo hubiera
        # reintroducido un multiparte entre la Fase 0 y este punto, la
        # detección de "extremo colgante" de la Fase C nunca lo verá.
        n_exploded_b = explode_multipart_features(
            self.working_layer,
            step_label="Verificar Áreas (pre Fase C)",
            log_callback=lambda m: self.log(m, indent=True)
        )
        if n_exploded_b:
            self.log(f"  ℹ️ {n_exploded_b} objeto(s) multiparte adicionales detectados y separados antes de Fase C.", indent=True)

        # ------------------------------------------------------------------
        # FASE C: VERIFICACIÓN FINAL DE ÁREAS CERRADAS
        # ------------------------------------------------------------------
        self.log("━━ FASE C: Verificando áreas cerradas...", indent=True)

        all_errors = []

        # FASE C: RECINTOS
        if recintos_names:
            self.log("  Comprobando topología (Dangles) en grupo RECINTOS...", indent=True)
            quoted_recintos = [f"'{n}'" for n in recintos_names]
            expr = f"\"Layer\" IN ({','.join(quoted_recintos)})"
            
            from qgis.core import QgsFeatureRequest
            it = self.working_layer.getFeatures(QgsFeatureRequest().setFilterExpression(expr))
            from qgis.core import QgsFeature
            if it.nextFeature(QgsFeature()):
                errors_rec = step.verify_enclosures(
                    self.working_layer,
                    log_helper=self.log_helper,
                    callback=self.progress_callback,
                    log_callback=lambda m: self.log(m, indent=True),
                    filter_expression=expr
                )
                for e in errors_rec:
                    e['msg'] = f"[RECINTOS] {e['msg']}"
                all_errors.extend(errors_rec)

        # FASE C: CLASES
        if clases_names:
            self.log("  Comprobando topología (Dangles) en grupo CLASES...", indent=True)
            quoted_clases = [f"'{n}'" for n in clases_names]
            expr = f"\"Layer\" IN ({','.join(quoted_clases)})"
            
            from qgis.core import QgsFeatureRequest
            it = self.working_layer.getFeatures(QgsFeatureRequest().setFilterExpression(expr))
            from qgis.core import QgsFeature
            if it.nextFeature(QgsFeature()):
                errors_cla = step.verify_enclosures(
                    self.working_layer,
                    log_helper=self.log_helper,
                    callback=self.progress_callback,
                    log_callback=lambda m: self.log(m, indent=True),
                    filter_expression=expr
                )
                for e in errors_cla:
                    e['msg'] = f"[CLASES] {e['msg']}"
                all_errors.extend(errors_cla)

        if all_errors:
            self.log(f"❌ Fase C: {len(all_errors)} áreas no cerradas (dangles restantes).", indent=True)
            self.handle_errors(all_errors)
            return False  # Bloquea — usuario corrige → 'Siguiente' → Fase A + B + C de nuevo

        # ✅ Sin errores en ninguna fase → avanzar al Paso 15
        self.log("✅ FASE C completa. Todas las áreas están correctamente cerradas.", indent=True)

        duration = time.time() - start_time
        update_step_status(
            self.output_dir,
            step_number=14,
            status='completed',
            features=self.working_layer.featureCount(),
            time_seconds=duration,
            errors=0,
            dxf_name=self.dxf_name
        )

        return True

    def step_verify_slivers_logic(self):
        """Verify slivers (small/thin polygons)"""
        start_time = time.time()
        from .steps.step_verify_slivers import StepVerifySlivers
        step = StepVerifySlivers()
        
        # Apply group styles for visualization
        self.apply_group_styles()
        
        # Get groups
        recintos_names = [self.listRecintos.item(i).text().split(" [")[0] for i in range(self.listRecintos.count())]
        clases_names = [self.listClases.item(i).text().split(" [")[0] for i in range(self.listClases.count())]
        
        all_errors = []
        
        # Verify Recintos (R + Common)
        if recintos_names:
            self.log("Verificando astillas en grupo RECINTOS...", indent=True)
            quoted_recintos = [f"'{n}'" for n in recintos_names]
            expr = f"\"Layer\" IN ({','.join(quoted_recintos)})"
            
            # Check if there are features
            it = self.working_layer.getFeatures(QgsFeatureRequest().setFilterExpression(expr))
            from qgis.core import QgsFeature
            if it.nextFeature(QgsFeature()):
                # Note: step_verify_slivers.py should also be updated if we want subset processing,
                # but removing selection manipulation here is the priority for stability.
                errors_rec = step.run(self.working_layer, log_helper=self.log_helper, callback=self.progress_callback, log_callback=lambda m: self.log(m, indent=True))
                if errors_rec:
                    for e in errors_rec:
                        e['msg'] = f"[RECINTOS] {e['msg']}"
                    all_errors.extend(errors_rec)
                
        # Verify Clases (C + Common)
        if clases_names:
            self.log("Verificando astillas en grupo CLASES...", indent=True)
            quoted_clases = [f"'{n}'" for n in clases_names]
            expr = f"\"Layer\" IN ({','.join(quoted_clases)})"
            
            # Check if there are features
            it = self.working_layer.getFeatures(QgsFeatureRequest().setFilterExpression(expr))
            from qgis.core import QgsFeature
            if it.nextFeature(QgsFeature()):
                errors_cla = step.run(self.working_layer, log_helper=self.log_helper, callback=self.progress_callback, log_callback=lambda m: self.log(m, indent=True))
                if errors_cla:
                    for e in errors_cla:
                        e['msg'] = f"[CLASES] {e['msg']}"
                    all_errors.extend(errors_cla)
        
        if all_errors:
            self.log(f"⚠️ Se detectaron {len(all_errors)} posibles astillas.", indent=True)
            self.handle_errors(all_errors)
            return True # Return True to let go_next handle the confirmation
            
        self.log("✓ No se detectaron astillas.", indent=True)
        
        # Update HTML summary
        duration = time.time() - start_time
        update_step_status(
            self.output_dir,
            step_number=15,
            status='completed',
            features=self.working_layer.featureCount(),
            time_seconds=duration,
            errors=0,
            dxf_name=self.dxf_name
        )
        
        return True

    def step_generate_polygons_logic(self):
        # 1. LIMPIEZA DE CAPAS PREVIAS (Evitar bloqueos de archivo en re-ejecución)
        project = QgsProject.instance()
        layers_to_remove = []
        if self.poly_recintos: layers_to_remove.append(self.poly_recintos.id())
        if self.poly_clases: layers_to_remove.append(self.poly_clases.id())
        
        if layers_to_remove:
            project.removeMapLayers(layers_to_remove)
            for lid in layers_to_remove:
                if lid in self.created_layers:
                    self.created_layers.remove(lid)
            self.poly_recintos = None
            self.poly_clases = None
            # Forzar liberación de handles y refresco
            QApplication.processEvents()
            time.sleep(0.3) 
            
        # Ensure all features are used correctly for polygonization without UI selection
        start_time = time.time()
        
        # IMPORTANT: Save the lines layer before polygonization for DXF export
        self.lines_layer_for_dxf = self.working_layer
        
        # Get groups
        recintos_names = [self.listRecintos.item(i).text().split(" [")[0] for i in range(self.listRecintos.count())]
        clases_names = [self.listClases.item(i).text().split(" [")[0] for i in range(self.listClases.count())]
        
        step = StepGeneratePolygons()
        
        # Usar contador de iteración para evitar WinError 32
        self.step_17_iter += 1
        v_suffix = f"_RUN_{self.step_17_iter}"
        
        self.poly_recintos = None
        self.poly_clases = None
        
        # --- PROCESS RECINTOS ---
        all_fugas = []
        
        self.log(f"Procesando grupo RECINTOS (Ejecución {self.step_17_iter})...", indent=True)
        # Instead of selecting, we pass the expression or check existence
        rec_list = "','".join(recintos_names)
        expr_rec = f"\"Layer\" IN ('{rec_list}')"
        
        # Check if there are features
        it = self.working_layer.getFeatures(QgsFeatureRequest().setFilterExpression(expr_rec))
        from qgis.core import QgsFeature
        if it.nextFeature(QgsFeature()):
            filename_rec = f"17_00_Poligonos_Recintos{v_suffix}.shp"
            # We will use selection but with signal blocking to avoid crashing QGIS 3.40
            self.working_layer.blockSignals(True)
            self.working_layer.selectByExpression(expr_rec)
            self.working_layer.blockSignals(False)
            
            self.poly_recintos, internal_errors = step.run(self.working_layer, self.output_dir, filename=filename_rec, log_helper=self.log_helper, log_callback=lambda m: self.log(m, indent=True), callback=self.progress_callback)
            
            self.working_layer.blockSignals(True)
            self.working_layer.removeSelection()
            self.working_layer.blockSignals(False)

            if self.poly_recintos:
                self.add_layer_to_project(self.poly_recintos)
                self.created_layers.append(self.poly_recintos.id())
                self.log(f"  ✓ Polígonos Recintos: {self.poly_recintos.featureCount()}", indent=True)
                
                # Recuperar errores de fuga (líneas interiores)
                if internal_errors:
                    for e in internal_errors:
                        e['msg'] = f"[RECINTOS] {e['msg']}"
                    all_fugas.extend(internal_errors)
        else:
            self.log("  ⚠️ No se encontraron líneas para el grupo RECINTOS.", indent=True)

        # --- PROCESS CLASES ---
        if clases_names:
            self.log(f"Procesando grupo CLASES (Ejecución {self.step_17_iter})...", indent=True)
            cla_list = "','".join(clases_names)
            expr_cla = f"\"Layer\" IN ('{cla_list}')"
            
            it = self.working_layer.getFeatures(QgsFeatureRequest().setFilterExpression(expr_cla))
            from qgis.core import QgsFeature
            if it.nextFeature(QgsFeature()):
                filename_cla = f"17_00_Poligonos_Clases{v_suffix}.shp"
                
                self.working_layer.blockSignals(True)
                self.working_layer.selectByExpression(expr_cla)
                self.working_layer.blockSignals(False)
                
                self.poly_clases, internal_errors = step.run(self.working_layer, self.output_dir, filename=filename_cla, log_helper=self.log_helper, log_callback=lambda m: self.log(m, indent=True), callback=self.progress_callback)
                
                self.working_layer.blockSignals(True)
                self.working_layer.removeSelection()
                self.working_layer.blockSignals(False)

                if self.poly_clases:
                    self.add_layer_to_project(self.poly_clases)
                    self.created_layers.append(self.poly_clases.id())
                    self.log(f"  ✓ Polígonos Clases: {self.poly_clases.featureCount()}", indent=True)
                    
                    # Recuperar errores de fuga (líneas interiores)
                    if internal_errors:
                        for e in internal_errors:
                            e['msg'] = f"[CLASES] {e['msg']}"
                        all_fugas.extend(internal_errors)
            else:
                self.log("  ⚠️ No se encontraron líneas para el grupo CLASES.", indent=True)
        
        # --- RESULTADO FINAL / CONTROL DE FUGAS ---
        if all_fugas:
            self.log(f"⚠️ ¡ATENCIÓN!: Se detectaron {len(all_fugas)} posibles FUGAS (líneas que no cierran).", indent=True)
            self.handle_errors(all_fugas)
            # Ya NO mostramos el QMessageBox aquí ni devolvemos True directamente.
            # Dejamos que la tabla se llene y go_next se detenga en el chequeo post-ejecución.
            
        if self.poly_recintos or self.poly_clases:
            self.log("✓ Poligonización finalizada.", indent=True)
            return True 

        # Update HTML summary
        duration = time.time() - start_time
        total_feats = (self.poly_recintos.featureCount() if self.poly_recintos else 0) + \
                      (self.poly_clases.featureCount() if self.poly_clases else 0)
                      
        update_step_status(
            self.output_dir,
            step_number=17,
            status='completed',
            features=total_feats,
            time_seconds=duration,
            errors=0,
            dxf_name=self.dxf_name
        )
        
        self.log("Generación de polígonos completada.", indent=True)
        return True

    def finalize_step_17(self):
        """Consolida las capas temporales del Paso 17 en archivos definitivos y limpia el disco."""
        self.log("Consolidando archivos de polígonos definitivos...", indent=True)
        
        def consolidate(layer, final_filename):
            if not layer: return None
            
            # 1. Ruta definitiva
            final_path = os.path.join(self.output_dir, final_filename)
            source_to_delete = layer.source()
            
            # 2. Guardar la capa actual en la ruta definitiva
            from .helpers.layer_utils import clean_and_save_layer
            new_layer, _ = clean_and_save_layer(layer, final_path)
            
            # 3. Eliminar la capa temporal (_RUN_X) del proyecto
            layer_id = layer.id()
            QgsProject.instance().removeMapLayer(layer_id)
            if layer_id in self.created_layers:
                self.created_layers.remove(layer_id)
                
            # 4. Eliminar archivos temporales de disco (si son _RUN_)
            if "_RUN_" in source_to_delete:
                base_path = os.path.splitext(source_to_delete)[0]
                for ext in ['.shp', '.shx', '.dbf', '.prj', '.cpg', '.qpj', '.fix']:
                    f = base_path + ext
                    if os.path.exists(f):
                        try:
                            os.remove(f)
                        except:
                            pass # Ignorar si aún está bloqueado, no es crítico
                
            # 5. Añadir la definitiva al proyecto
            self.add_layer_to_project(new_layer)
            self.created_layers.append(new_layer.id())
            
            return new_layer

        self.poly_recintos = consolidate(self.poly_recintos, "17_00_Poligonos_Recintos.shp")
        self.poly_clases = consolidate(self.poly_clases, "17_00_Poligonos_Clases.shp")
        
        # Forzar refresco
        QApplication.processEvents()

    def step_generate_viales_logic(self):
        """Lógica para la generación satélite de viales."""
        if not self.poly_recintos:
            QMessageBox.warning(self, "Paso 17 Requerido", "Debe completar el Paso 17 (Generar Polígonos) antes de generar los viales.")
            return

        # Buscar Exterior.shp
        # El usuario dice que está en la raíz del archivo DXF original
        if not self.output_dir:
            QMessageBox.warning(self, "Directorio no definido", "No se ha definido el directorio de salida.")
            return

        self.btnGenerateViales.setEnabled(False)
        self.progressViales.setValue(0)
        self.txtLogViales.clear()
        self.log_viales("Iniciando proceso independiente de generación viaria...")
        
        def viales_progress(current, total):
            if total > 0:
                val = int((current / total) * 100)
                self.progressViales.setValue(val)
            QApplication.processEvents()

        try:
            step = StepGenerateViales()
            dens_val = self.sbDensificacion.value()
            self.poly_viales, self.ejes_viales, self.intersecciones_viales = step.run(
                self.poly_recintos, 
                self.output_dir,
                densificacion_metros=dens_val,
                log_callback=self.log_viales,
                callback=viales_progress
            )
            
            if self.poly_viales:
                self.progressViales.setValue(100)
                self.add_layer_to_project(self.poly_viales)
                self.created_layers.append(self.poly_viales.id())
                if self.ejes_viales:
                    self.add_layer_to_project(self.ejes_viales)
                    self.created_layers.append(self.ejes_viales.id())
                if self.intersecciones_viales:
                    self.add_layer_to_project(self.intersecciones_viales)
                    self.created_layers.append(self.intersecciones_viales.id())
                self.log_viales("✓ Capas cargadas exitosamente en QGIS.")
                QMessageBox.information(self, "Generación Exitosa", "Se ha generado la estructura viaria.\nLas capas se incluirán automáticamente en el DXF final.")
            else:
                self.log_viales("Falló la generación de viales.")
                
        except Exception as e:
            self.log_viales(f"ERROR CRÍTICO: {str(e)}")
            import traceback
            self.log_viales(traceback.format_exc())
        finally:
            self.btnGenerateViales.setEnabled(True)
            self.progressViales.setValue(0)

    def step_final_check_logic(self):
        step = StepFinalCheck()
        errors = step.run(self.working_layer, log_callback=lambda m: self.log(m, indent=True))
        return self.handle_errors(errors)


    def step_detect_dangles_logic(self):
        """Pure detection of dangles (read-only for idempotency)"""
        start_time = time.time()
        from .steps.step_detect_dangles import StepDetectDangles
        
        tol = self.sbTolerance.value()
        step = StepDetectDangles()
        
        self.log("Escaneando colgados (modo detección pura)...", indent=True)
        
        # Ejecutar en modo dry_run=True para no modificar la geometría
        errors, _ = step.run(
            self.working_layer, 
            tol, 
            dry_run=True, 
            log_callback=lambda m: self.log(m, indent=True),
            callback=self.progress_callback
        )
        
        # Report errors to UI list
        if errors:
            self.handle_errors(errors)
        
        # Update HTML summary
        duration = time.time() - start_time
        update_step_status(
            self.output_dir,
            step_number=9,
            status='completed',
            features=self.working_layer.featureCount(),
            time_seconds=duration,
            errors=len(errors),
            dxf_name=self.dxf_name
        )
        
        return True



    def step_extend_dangles_logic(self):
        """Extend dangles directionally to nearby lines"""
        start_time = time.time()
        from .steps.step_detect_dangles import StepDetectDangles
        tol = self.sbExtensionTolerance.value()
        step = StepDetectDangles()
        
        # Run in extend-only mode (dry_run=False to extend)
        errors, fixed_count = step.run(
            self.working_layer,
            tolerance=tol,
            callback=self.progress_callback,
            dry_run=False,  # Actually extend
            log_helper=self.log_helper,
            log_callback=lambda m: self.log(m, indent=True)
        )
        
        if fixed_count > 0:
            self.log(f"Extensión de dangles: {fixed_count} corregidos.", indent=True)
        
        # Report errors to UI list and ASK to proceed
        # Report errors to UI list
        if errors:
            self.handle_errors(errors)
        
        self.log("Extensión de dangles completada.", indent=True)
        
        # Update HTML summary
        duration = time.time() - start_time
        update_step_status(
            self.output_dir,
            step_number=10,
            status='completed',
            features=self.working_layer.featureCount(),
            time_seconds=duration,
            errors=len(errors),
            dxf_name=self.dxf_name
        )
        
        return True

    def step_split_intersections_2_logic(self):
        """Re-cut intersections after extending dangles"""
        start_time = time.time()
        from .steps.step_split_intersections import StepSplitIntersections
        step = StepSplitIntersections()
        
        # Get groups
        recintos_names = [self.listRecintos.item(i).text().split(" [")[0] for i in range(self.listRecintos.count())]
        clases_names = [self.listClases.item(i).text().split(" [")[0] for i in range(self.listClases.count())]
        
        filename = get_step_filename(11)
        self.working_layer = step.run(
            self.working_layer, 
            self.output_dir, 
            filename=filename, 
            log_callback=lambda m: self.log(m, indent=True),
            log_helper=self.log_helper,
            recintos_layers=recintos_names,
            clases_layers=clases_names,
            callback=self.progress_callback
        )
        self.add_layer_to_project(self.working_layer)
        self.created_layers.append(self.working_layer.id())
        
        # Update HTML summary
        duration = time.time() - start_time
        update_step_status(
            self.output_dir,
            step_number=11,
            status='completed',
            features=self.working_layer.featureCount(),
            time_seconds=duration,
            errors=0,
            dxf_name=self.dxf_name
        )
        
        self.log("Re-corte completado.", indent=True)
        
        # Update HTML summary
        update_step_status(
            self.output_dir,
            step_number=11,
            status='completed',
            features=self.working_layer.featureCount(),
            time_seconds=0,
            errors=0,
            dxf_name=self.dxf_name
        )
        
        return True



    def step_analyze_changes_logic(self):
        """Analyze geometric changes between original and current layer"""
        start_time = time.time()
        from .steps.step_analyze_changes import StepAnalyzeChanges
        from .helpers.summary_report import set_comparison_summary
        
        # STAGE 2: Confirmation
        if self.analysis_done:
            # User clicked "Next" again after seeing errors
            reply = QMessageBox.question(
                self, 
                "Confirmar Cambios", 
                "¿Das por buenos los cambios realizados respecto al original?",
                QMessageBox.Yes | QMessageBox.No, 
                QMessageBox.No
            )
            
            if reply == QMessageBox.Yes:
                self.log("Usuario aceptó los cambios. Continuando...", indent=True)
                self.analysis_done = False # Reset for future runs
                self.analysis_errors = []
                
                # Update HTML summary
                duration = time.time() - start_time
                update_step_status(
                    self.output_dir,
                    step_number=16,
                    status='completed',
                    features=self.working_layer.featureCount(),
                    time_seconds=duration,
                    errors=0,
                    dxf_name=self.dxf_name
                )
                
                return True
            else:
                self.log("Usuario rechazó los cambios. Pausando workflow.", indent=True)
                # Restore errors to table so user can review them
                if self.analysis_errors:
                    self.handle_errors(self.analysis_errors)
                return False

        # STAGE 1: Analysis
        step = StepAnalyzeChanges()
        
        # Run analysis
        errors = step.run(
            self.working_layer,
            self.output_dir,
            geometry_tolerance=0.001,  # 1mm tolerance for comparison
            log_callback=lambda m: self.log(m, indent=True),
            log_helper=self.log_helper,
            callback=self.progress_callback
        )
        
        # Generate comparison text for HTML report
        if not errors:
            comparison_text = "No se detectaron cambios significativos respecto a la geometría original (Tolerancia: 1mm)."
        else:
            comparison_text = f"Se detectaron {len(errors)} cambios significativos respecto al original (Tolerancia: 1mm). "
            # Add breakdown if possible, for now just count
            
        set_comparison_summary(self.output_dir, comparison_text, self.dxf_name)
        
        # If there are substantial changes, show them in error table and PAUSE
        if errors and len(errors) > 0:
            self.log(f"Se encontraron {len(errors)} cambios sustanciales.", indent=True)
            self.log("Pausando para revisión. Presione 'Siguiente' nuevamente para confirmar y continuar.", indent=True)
            
            # Save errors for restoration if needed
            self.analysis_errors = errors
            
            # Populate error table
            self.handle_errors(errors)
            
            # Set flag so next click triggers confirmation
            self.analysis_done = True
            
            return False # Pause workflow
        else:
            # No substantial changes, continue automatically
            
            # Update HTML summary (only if no pause)
            duration = time.time() - start_time
            update_step_status(
                self.output_dir,
                step_number=16,
                status='completed',
                features=self.working_layer.featureCount(),
                time_seconds=duration,
                errors=0,
                dxf_name=self.dxf_name
            )
            
            return True



    def step_validate_polygons_logic(self):
        """Validate polygon quality: overlaps, gaps, slivers, invalid geometries"""
        start_time = time.time()
        from .steps.step_validate_polygons import StepValidatePolygons
        
        step = StepValidatePolygons()
        gap_tolerance = self.sbTolerance.value()
        
        all_errors = []
        
        # Validate Recintos
        if self.poly_recintos:
            self.log("Validando Polígonos RECINTOS...", indent=True)
            errors_rec = step.run(
                self.poly_recintos,
                min_area=0.01,
                min_ratio=0.005,
                gap_tolerance=gap_tolerance,
                callback=self.progress_callback,
                log_helper=self.log_helper,
                log_callback=lambda m: self.log(m, indent=True)
            )
            # Tag errors and set layer_id
            for e in errors_rec:
                e['msg'] = f"[RECINTOS] {e['msg']}"
                e['layer_id'] = self.poly_recintos.id()
            all_errors.extend(errors_rec)
            
        # Validate Clases
        if self.poly_clases:
            self.log("Validando Polígonos CLASES...", indent=True)
            errors_cla = step.run(
                self.poly_clases,
                min_area=0.01,
                min_ratio=0.005,
                gap_tolerance=gap_tolerance,
                callback=self.progress_callback,
                log_helper=self.log_helper,
                log_callback=lambda m: self.log(m, indent=True)
            )
            # Tag errors and set layer_id
            for e in errors_cla:
                e['msg'] = f"[CLASES] {e['msg']}"
                e['layer_id'] = self.poly_clases.id()
            all_errors.extend(errors_cla)
            
        # Update HTML summary
        duration = time.time() - start_time
        total_feats = (self.poly_recintos.featureCount() if self.poly_recintos else 0) + \
                      (self.poly_clases.featureCount() if self.poly_clases else 0)
                      
        update_step_status(
            self.output_dir,
            step_number=18,
            status='completed',
            features=total_feats,
            time_seconds=duration,
            errors=len(all_errors),
            dxf_name=self.dxf_name
        )
        
        if all_errors:
            self.log(f"⚠️ Se encontraron {len(all_errors)} problemas de calidad en total.", indent=True)
            self.handle_errors(all_errors)
            return True 
        else:
            self.log("✓ Todos los polígonos son válidos y de buena calidad.", indent=True)
            return True

    def step_verify_polygon_topology_logic(self):
        """Paso 18.5: Verificar Topología de Polígonos Cerrados"""
        # Buscar capas de polígonos cerrados
        rec_layer = None
        cla_layer = None
        
        # Buscamos de forma exhaustiva en todo el proyecto
        for layer in QgsProject.instance().mapLayers().values():
            name = layer.name()
            if "17_00_Poligonos_Recintos" in name:
                rec_layer = layer
            elif "17_00_Poligonos_Clases" in name:
                cla_layer = layer
        
        # Log de diagnóstico para confirmar hallazgo
        encontradas = []
        if rec_layer: encontradas.append("Recintos")
        if cla_layer: encontradas.append("Clases")
        
        if not rec_layer and not cla_layer:
            self.log("ADVERTENCIA: No se detectaron las capas 17_00_Poligonos_Recintos/Clases en el proyecto.", indent=True)
            return True
        else:
            self.log(f"✓ Iniciando verificación sobre: {', '.join(encontradas)}", indent=True)
        
        verifier = StepVerifyPolygonTopology()
        result = verifier.run(
            rec_layer=rec_layer,
            cla_layer=cla_layer,
            output_dir=self.output_dir,
            log_helper=self.log_helper,
            log_callback=self.log,
            callback=self.progress_callback
        )
        
        # Guardar resultado para usar en exportación (aunque la limpieza es automática)
        self.polygon_topology_issues = result
        
        # Si el usuario canceló, detenemos el proceso
        if result['user_action'] == 'cancel':
            return False
            
        return True

    def export_current_layer_to_dxf(self):
        """
        Exporta la capa de trabajo actual a DXF.
        Cada entidad se exporta a la capa DXF cuyo nombre coincide con el campo 'Layer'
        de su tabla de atributos. Si no hay capa de trabajo activa, usa la capa activa de QGIS.
        """
        from qgis.PyQt.QtWidgets import QFileDialog
        from qgis.core import (
            QgsVectorLayer, QgsFeature, QgsGeometry, QgsField,
            QgsVectorFileWriter, QgsProject, QgsWkbTypes
        )
        from qgis.PyQt.QtCore import QVariant

        # Determinar qué capa exportar
        layer = self.working_layer
        if layer is None or not layer.isValid():
            layer = self.iface.activeLayer()
        if layer is None or not layer.isValid():
            QMessageBox.warning(self, "Exportar DXF", "No hay ninguna capa de trabajo disponible.\nCargue un DXF o avance al menos al paso 1.")
            return

        # Pedir ruta de destino
        default_name = ""
        if self.output_dir:
            step_num = self.current_step + 1  # paso en curso (1-based)
            default_name = os.path.join(self.output_dir, f"Exportacion_Paso{step_num:02d}.dxf")
        dxf_path, _ = QFileDialog.getSaveFileName(
            self,
            "Guardar DXF",
            default_name,
            "Archivos DXF (*.dxf)"
        )
        if not dxf_path:
            return  # Usuario canceló

        # Buscar campo 'Layer' (insensible a mayúsculas)
        layer_field_name = None
        for field in layer.fields():
            if field.name().lower() == 'layer':
                layer_field_name = field.name()
                break

        # Crear capa temporal de exportación (solo campo Layer para DXF)
        crs_id = layer.crs().authid()
        geom_type_str = QgsWkbTypes.displayString(
            QgsWkbTypes.flatType(layer.wkbType())
        )
        # DXF solo soporta LineString bien; usar LineString como base
        temp_layer = QgsVectorLayer(f"LineString?crs={crs_id}", "DXF_Export_Temp", "memory")
        pr = temp_layer.dataProvider()
        pr.addAttributes([QgsField("Layer", QVariant.String)])
        temp_layer.updateFields()
        layer_idx = temp_layer.fields().indexOf("Layer")

        features_to_add = []
        is_line = layer.geometryType() == QgsWkbTypes.LineGeometry
        is_polygon = layer.geometryType() == QgsWkbTypes.PolygonGeometry

        for feat in layer.getFeatures():
            geom = feat.geometry()
            if not geom or geom.isEmpty():
                continue

            # Obtener nombre de capa DXF
            dxf_layer_name = "0"
            if layer_field_name:
                val = feat[layer_field_name]
                if val and str(val).strip():
                    dxf_layer_name = str(val).strip()

            # Convertir polígonos a contornos; las líneas se exportan tal cual
            if is_polygon:
                # Explotar multipartes
                single_geom = geom
                if geom.isMultipart():
                    polys = geom.asMultiPolygon()
                else:
                    polys = [geom.asPolygon()]
                for poly in polys:
                    if poly and len(poly) > 0:
                        ring = poly[0]
                        # Eliminar vértice de cierre si coincide con el primero
                        if len(ring) >= 2 and ring[0].x() == ring[-1].x() and ring[0].y() == ring[-1].y():
                            ring = ring[:-1]
                        if len(ring) < 2:
                            continue
                        boundary = QgsGeometry.fromPolylineXY(ring)
                        if boundary.isEmpty():
                            continue
                        new_feat = QgsFeature(temp_layer.fields())
                        new_feat.setGeometry(boundary)
                        new_feat.setAttribute(layer_idx, dxf_layer_name)
                        features_to_add.append(new_feat)
            else:
                # Líneas: exportar directamente (multipartes como están)
                new_feat = QgsFeature(temp_layer.fields())
                new_feat.setGeometry(geom)
                new_feat.setAttribute(layer_idx, dxf_layer_name)
                features_to_add.append(new_feat)

        pr.addFeatures(features_to_add)

        # Exportar a DXF
        options = QgsVectorFileWriter.SaveVectorOptions()
        options.driverName = "DXF"
        options.fileEncoding = "UTF-8"

        error = QgsVectorFileWriter.writeAsVectorFormatV3(
            temp_layer,
            dxf_path,
            QgsProject.instance().transformContext(),
            options
        )

        if error[0] == QgsVectorFileWriter.NoError:
            self.log(f"✅ DXF exportado: {os.path.basename(dxf_path)} ({len(features_to_add)} entidades)")
            QMessageBox.information(
                self, "Exportar DXF",
                f"DXF exportado correctamente:\n{dxf_path}\n\n{len(features_to_add)} entidades exportadas."
            )
        else:
            self.log(f"❌ Error al exportar DXF: {error[1]}")
            QMessageBox.critical(self, "Error al exportar DXF", f"No se pudo exportar el DXF:\n{error[1]}")

    def step_export_dxf_logic(self):
        """Export final result to DXF"""
        start_time = time.time()
        
        # Confirmar con el usuario antes de proceder
        reply = QMessageBox.question(
            self, 
            "Generar DXF Final", 
            "¿Desea generar el archivo DXF final ahora?\n\nSeleccione 'Sí' para continuar o 'No' para detener el proceso y revisar los resultados.",
            QMessageBox.Yes | QMessageBox.No, 
            QMessageBox.Yes
        )
        
        if reply == QMessageBox.No:
            self.log("   ⏸️ Proceso detenido por el usuario antes de la exportación.", indent=True)
            return False

        from .steps.step_export_dxf import StepExportDXF
        
        if not self.lines_layer_for_dxf:
            self.log("ERROR: No se encontró la capa de líneas original.", indent=True)
            return False
            
        step = StepExportDXF()
        
        # Prepare polygon layers list
        polygons_input = []
        if self.poly_recintos:
            polygons_input.append({'layer': self.poly_recintos, 'dxf_layer': 'REC_POLCERRADOS'})
        if self.poly_clases:
            polygons_input.append({'layer': self.poly_clases, 'dxf_layer': 'CLA_POLCERRADOS'})
            
        # NUEVO: Incluir Viales si existen
        if self.poly_viales:
            polygons_input.append({'layer': self.poly_viales, 'dxf_layer': 'VIAL_POLCERRADOS'})
        if self.lines_cierres:
            polygons_input.append({'layer': self.lines_cierres, 'dxf_layer': 'ValGIS_CIERRES'})
            
        dxf_path = step.run(
            self.lines_layer_for_dxf,
            polygons_input, 
            self.output_dir,
            log_callback=lambda m: self.log(m, indent=True),
            callback=self.progress_callback
        )
        
        if dxf_path:
            # Update HTML summary
            duration = time.time() - start_time
            update_step_status(
                self.output_dir,
                step_number=19,
                status='completed',
                features=0,  # DXF export doesn't have feature count
                time_seconds=duration,
                errors=0,
                dxf_name=self.dxf_name
            )
            
            QMessageBox.information(self, "Exportación Exitosa", f"Archivo generado:\n{dxf_path}")
            return True
        else:
            return False



    def check_tab_access(self, index):
        """Prevent moving to Processing tab if layers are not configured."""
        if index == 0: # Processing Tab
            if not self.validate_layers():
                self.tabWidget.setCurrentIndex(1) # Go back to Layers tab
                QMessageBox.warning(self, "Configuración Incompleta", 
                    "Debe configurar las capas en los grupos RECINTOS y CLASES antes de procesar.\n"
                    "Asegúrese de que todas las capas lineales estén asignadas.")

    def populate_layers(self):
        """Populate the source list with unique values from the 'Layer' field of the working layer."""
        self.listAllLayers.clear()
        
        # Try to use working_layer first, if not set, use active layer from QGIS
        layer_to_scan = self.working_layer
        
        if not layer_to_scan or not layer_to_scan.isValid():
            # Try to get the active layer from QGIS
            layer_to_scan = self.iface.activeLayer()
            if not layer_to_scan or not layer_to_scan.isValid():
                self.log("Advertencia: No hay capa activa. Seleccione una capa DXF en QGIS.", indent=True)
                QMessageBox.warning(self, "Sin capa", 
                    "Por favor, seleccione una capa DXF en QGIS antes de actualizar las capas.")
                return

        # Check if 'Layer' field exists
        layer_idx = layer_to_scan.fields().indexOf('Layer')
        if layer_idx == -1:
            # Try uppercase
            layer_idx = layer_to_scan.fields().indexOf('LAYER')
            
        if layer_idx == -1:
            self.log("Advertencia: No se encontró el campo 'Layer' en la capa seleccionada.", indent=True)
            QMessageBox.warning(self, "Campo no encontrado", 
                "La capa seleccionada no tiene un campo 'Layer'. Asegúrese de seleccionar una capa DXF.")
            return

        # Get unique layer names that have LineString geometry
        # We need to check each feature's geometry type
        from qgis.core import QgsWkbTypes
        
        layer_geom_types = {}  # Track geometry types per layer
        
        for feature in layer_to_scan.getFeatures():
            layer_name = feature.attribute(layer_idx)
            if not layer_name:
                continue
            layer_name = str(layer_name)
            
            geom = feature.geometry()
            if geom and not geom.isEmpty():
                geom_type = geom.wkbType()
                # Check if it's a LineString type (any variant)
                if QgsWkbTypes.geometryType(geom_type) == QgsWkbTypes.LineGeometry:
                    if layer_name not in layer_geom_types:
                        layer_geom_types[layer_name] = True
        
        # Sort and populate only layers with linear features
        for layer_name in sorted(layer_geom_types.keys()):
            item = QListWidgetItem(layer_name)
            # Use layer name as ID since we are dealing with logical layers
            item.setData(Qt.UserRole, layer_name) 
            self.listAllLayers.addItem(item)
        
        self.log(f"Capas lineales encontradas: {len(layer_geom_types)}", indent=True)
        self.update_source_list_visuals()
        
        # Validate layer names for problematic characters
        import re
        problematic_layers = []
        valid_pattern = re.compile(r'^[a-zA-Z0-9_]+$')
        
        for layer_name in sorted(layer_geom_types.keys()):
            if not valid_pattern.match(layer_name):
                problematic_layers.append(layer_name)
        
        if problematic_layers:
            problem_list = "\n".join([f"  - {name}" for name in problematic_layers[:10]])
            if len(problematic_layers) > 10:
                problem_list += f"\n  ... y {len(problematic_layers) - 10} más"
            
            QMessageBox.warning(self, "Nombres de capas no normalizados",
                f"⚠️ Se detectaron {len(problematic_layers)} capas con nombres no normalizados.\n\n"
                f"Los nombres contienen caracteres especiales (espacios, tildes, ñ, comillas, etc.)\n"
                f"que pueden causar errores o resultados inesperados.\n\n"
                f"Capas problemáticas:\n{problem_list}\n\n"
                f"Se recomienda renombrar las capas usando solo:\n"
                f"  • Letras (a-z, A-Z)\n  • Números (0-9)\n  • Guión bajo (_)\n\n"
                f"¿Desea continuar de todos modos?")
            
            self.log(f"⚠️ ADVERTENCIA: {len(problematic_layers)} capas con nombres no normalizados.", indent=True)
            for name in problematic_layers:
                self.log(f"    - {name}", indent=True)

    def update_source_list_visuals(self):
        """Update colors and tags in source list based on assignment."""
        recintos_ids = [self.listRecintos.item(i).data(Qt.UserRole) for i in range(self.listRecintos.count())]
        clases_ids = [self.listClases.item(i).data(Qt.UserRole) for i in range(self.listClases.count())]
        
        for i in range(self.listAllLayers.count()):
            item = self.listAllLayers.item(i)
            lid = item.data(Qt.UserRole)
            name = item.text().split(" [")[0] # Reset name
            
            in_recintos = lid in recintos_ids
            in_clases = lid in clases_ids
            
            tags = []
            if in_recintos: tags.append("R")
            if in_clases: tags.append("C")
            
            if tags:
                item.setText(f"{name} [{','.join(tags)}]")
            else:
                item.setText(name)
                
            # Color logic
            if in_recintos and in_clases:
                item.setForeground(QColor("blue"))
            elif in_recintos or in_clases:
                item.setForeground(QColor("green"))
            else:
                item.setForeground(QColor("black"))

    def add_layer_to_target(self, item):
        """Add double-clicked layer to the selected target group."""
        layer_id = item.data(Qt.UserRole)
        layer_name = item.text().split(" [")[0]
        
        if self.optRecintos.isChecked():
            self.add_layer_to_group(layer_id, layer_name, self.listRecintos)
        elif self.optClases.isChecked():
            self.add_layer_to_group(layer_id, layer_name, self.listClases)
            
        self.update_source_list_visuals()
        self.validate_layers()

    def add_layer_to_group(self, layer_id, layer_name, list_widget):
        # Check if already exists
        for i in range(list_widget.count()):
            if list_widget.item(i).data(Qt.UserRole) == layer_id:
                return # Already added
        
        item = QListWidgetItem(layer_name)
        item.setData(Qt.UserRole, layer_id)
        list_widget.addItem(item)

    def remove_layer_from_recintos(self, item):
        self.listRecintos.takeItem(self.listRecintos.row(item))
        self.update_source_list_visuals()
        self.validate_layers()

    def remove_layer_from_clases(self, item):
        self.listClases.takeItem(self.listClases.row(item))
        self.update_source_list_visuals()
        self.validate_layers()

    def add_all_to_recintos(self):
        for i in range(self.listAllLayers.count()):
            item = self.listAllLayers.item(i)
            self.add_layer_to_group(item.data(Qt.UserRole), item.text().split(" [")[0], self.listRecintos)
        self.update_source_list_visuals()
        self.validate_layers()

    def add_all_to_clases(self):
        for i in range(self.listAllLayers.count()):
            item = self.listAllLayers.item(i)
            self.add_layer_to_group(item.data(Qt.UserRole), item.text().split(" [")[0], self.listClases)
        self.update_source_list_visuals()
        self.validate_layers()

    def clear_recintos(self):
        self.listRecintos.clear()
        self.update_source_list_visuals()
        self.validate_layers()

    def clear_clases(self):
        self.listClases.clear()
        self.update_source_list_visuals()
        self.validate_layers()
        
    def move_all_to_target(self):
        if self.optRecintos.isChecked():
            self.add_all_to_recintos()
        elif self.optClases.isChecked():
            self.add_all_to_clases()

    def validate_layers(self):
        """
        Validate that:
        1. All layers in source are assigned to at least one group.
        2. Recintos group is not empty.
        3. Update 'Missing in Clases' list.
        """
        recintos_ids = {self.listRecintos.item(i).data(Qt.UserRole) for i in range(self.listRecintos.count())}
        clases_ids = {self.listClases.item(i).data(Qt.UserRole) for i in range(self.listClases.count())}
        all_ids = {self.listAllLayers.item(i).data(Qt.UserRole) for i in range(self.listAllLayers.count())}
        
        # Check coverage
        assigned_ids = recintos_ids.union(clases_ids)
        unassigned = all_ids - assigned_ids
        
        valid = True
        msg = []
        
        if not recintos_ids:
            valid = False
            msg.append("El grupo RECINTOS no puede estar vacío.")
            
        if unassigned:
            valid = False
            msg.append(f"Hay {len(unassigned)} capas sin asignar.")
            
            
        return valid


    def import_config(self):
        """
        Import layer configuration from RECINTOS.las and CLASES.las in the DXF directory.
        Format: Code 8 followed by layer name on next line.
        """
        dir_name = None
        # La ruta natural de los .las es junto al DXF original. Si output_dir existe 
        # (ej: C:/Folder/ValGIS_Output_001), los .las están en su carpeta padre (C:/Folder).
        if self.output_dir and os.path.exists(self.output_dir):
            dir_name = os.path.dirname(self.output_dir)
        else:
            # Fallback a la capa activa
            layer = self.iface.activeLayer()
            if layer and layer.isValid():
                source_source = layer.source()
                file_path = source_source.split("|")[0]
                if os.path.exists(file_path):
                    dir_name = os.path.dirname(file_path)
        
        if not dir_name:
            QMessageBox.warning(self, "Error", "No se ha detectado el directorio del proyecto para importar configuración.")
            return
            
        recintos_path = os.path.join(dir_name, "RECINTOS.las")
        clases_path = os.path.join(dir_name, "CLASES.las")
        
        if not os.path.exists(recintos_path) and not os.path.exists(clases_path):
            QMessageBox.warning(self, "Archivos no encontrados", 
                f"No se encontraron archivos de configuración (RECINTOS.las / CLASES.las) en:\n{dir_name}")
            return
            
        def parse_las(path):
            """
            Parse .las file and return only EDITABLE layers.
            A layer is editable if FLAGS (code 90) has:
            - Bit 0 (1) = 0 → ON (visible)
            - Bit 1 (2) = 0 → THAWED (not frozen)
            - Bit 2 (4) = 0 → UNLOCKED
            """
            layers = []
            if not os.path.exists(path):
                return layers
            try:
                with open(path, 'r', encoding='utf-8', errors='ignore') as f:
                    lines = f.readlines()
                    
                i = 0
                while i < len(lines):
                    line = lines[i].strip()
                    
                    # Look for layer name (code 8)
                    if line == '8':
                        if i + 1 < len(lines):
                            layer_name = lines[i + 1].strip()
                            
                            # Now look for FLAGS (code 90) after this layer name
                            # It should be within the next few lines
                            flags = None
                            for j in range(i + 2, min(i + 20, len(lines))):
                                if lines[j].strip() == '90':
                                    if j + 1 < len(lines):
                                        try:
                                            flags = int(lines[j + 1].strip())
                                        except ValueError:
                                            pass
                                        break
                                # Stop if we hit the next layer (code 8 again)
                                if lines[j].strip() == '8':
                                    break
                            
                            # Check if layer is editable
                            if flags is not None:
                                is_on = (flags & 1) == 0
                                is_thawed = (flags & 2) == 0
                                is_unlocked = (flags & 4) == 0
                                
                                if is_on and is_thawed and is_unlocked:
                                    if layer_name:
                                        layers.append(layer_name)
                                        self.log(f"    {layer_name} — FLAGS={flags} (editable)", indent=True)
                                else:
                                    self.log(f"    {layer_name} — FLAGS={flags} (ignorada: {'OFF' if not is_on else ''}{'FROZEN' if not is_thawed else ''}{'LOCKED' if not is_unlocked else ''})", indent=True)
                            else:
                                # No FLAGS found, skip this layer
                                self.log(f"    {layer_name} — sin FLAGS (ignorada)", indent=True)
                    
                    i += 1
                    
            except Exception as e:
                self.log(f"Error leyendo {os.path.basename(path)}: {e}", indent=True)
            return layers

        # Clear current lists
        self.clear_recintos()
        self.clear_clases()
        
        # Parse files
        recintos_layers = parse_las(recintos_path)
        clases_layers = parse_las(clases_path)
        
        # Special case: if only CLASES.las exists, load it into RECINTOS
        if not os.path.exists(recintos_path) and os.path.exists(clases_path):
            self.log("  Solo se encontró CLASES.las, cargando en grupo RECINTOS...", indent=True)
            recintos_layers = clases_layers
            clases_layers = []
        
        self.log(f"Importando configuración desde {dir_name}...", indent=True)
        if recintos_layers:
            self.log(f"  RECINTOS: {len(recintos_layers)} capas encontradas.", indent=True)
        if clases_layers:
            self.log(f"  CLASES: {len(clases_layers)} capas encontradas.", indent=True)
            
        # Get available layers in listAllLayers
        available_layers = set()
        for i in range(self.listAllLayers.count()):
            item = self.listAllLayers.item(i)
            available_layers.add(item.data(Qt.UserRole))
            
        # Add to lists
        missing_rec = []
        for layer in recintos_layers:
            if layer in available_layers:
                self.add_layer_to_group(layer, layer, self.listRecintos)
            else:
                missing_rec.append(layer)
                
        missing_cla = []
        for layer in clases_layers:
            if layer in available_layers:
                self.add_layer_to_group(layer, layer, self.listClases)
            else:
                missing_cla.append(layer)
                
        if missing_rec:
            self.log(f"  Advertencia: {len(missing_rec)} capas de RECINTOS no existen en el DXF actual.", indent=True)
            if len(missing_rec) < 10:
                self.log(f"    Faltan: {', '.join(missing_rec)}", indent=True)
                
        if missing_cla:
            self.log(f"  Advertencia: {len(missing_cla)} capas de CLASES no existen en el DXF actual.", indent=True)
            if len(missing_cla) < 10:
                self.log(f"    Faltan: {', '.join(missing_cla)}", indent=True)
                
        self.update_source_list_visuals()
        self.validate_layers()
        self.log("Importación finalizada.")

    def apply_group_styles(self):
        """
        Apply categorized renderer to working layer:
        - Recintos Only: Blue
        - Clases Only: Red
        - Common: Magenta
        """
        if not self.working_layer or not self.working_layer.isValid():
            return
            
        from qgis.core import QgsCategorizedSymbolRenderer, QgsRendererCategory, QgsSymbol
        from qgis.PyQt.QtGui import QColor
        
        # Check if ESTADO field exists
        estado_idx = self.working_layer.fields().indexOf('ESTADO')
        
        if estado_idx != -1:
            # Use ESTADO field for categorization
            categories = []
            
            def add_category(value, color, label, width):
                symbol = QgsSymbol.defaultSymbol(self.working_layer.geometryType())
                symbol.setColor(QColor(color))
                symbol.setWidth(width)
                categories.append(QgsRendererCategory(value, symbol, label))
            
            add_category("RECINTO", "blue", "Recintos", 0.25)
            add_category("CLASE", "orange", "Clases", 0.15)
            add_category("COMUN", "black", "Común", 0.25)
            
            renderer = QgsCategorizedSymbolRenderer("ESTADO", categories)
            self.working_layer.setRenderer(renderer)
            self.working_layer.triggerRepaint()
            self.iface.layerTreeView().refreshLayerSymbology(self.working_layer.id())
        else:
            # Fallback to Layer field
            recintos_names = set([self.listRecintos.item(i).text().split(" [")[0] for i in range(self.listRecintos.count())])
            clases_names = set([self.listClases.item(i).text().split(" [")[0] for i in range(self.listClases.count())])
            
            r_only = recintos_names - clases_names
            c_only = clases_names - recintos_names
            common = recintos_names & clases_names
            
            categories = []
            
            def add_category(value, color, label, width):
                symbol = QgsSymbol.defaultSymbol(self.working_layer.geometryType())
                symbol.setColor(QColor(color))
                symbol.setWidth(width) 
                categories.append(QgsRendererCategory(value, symbol, label))
                
            for name in r_only:
                add_category(name, "blue", f"{name} (Recintos)", 0.25)
            for name in c_only:
                add_category(name, "orange", f"{name} (Clases)", 0.15)
            for name in common:
                add_category(name, "black", f"{name} (Común)", 0.25)
                
            renderer = QgsCategorizedSymbolRenderer("Layer", categories)
            self.working_layer.setRenderer(renderer)
            self.working_layer.triggerRepaint()
            self.iface.layerTreeView().refreshLayerSymbology(self.working_layer.id())

    def add_state_field(self):
        """
        Add 'ESTADO' field and populate it based on group membership:
        - Recintos Only -> 'RECINTO'
        - Clases Only -> 'CLASE'
        - Common -> 'COMUN'
        """
        if not self.working_layer or not self.working_layer.isValid():
            return

        self.log("Añadiendo campo ESTADO...", indent=True)
        
        # Add field if it doesn't exist
        from qgis.core import QgsField
        from qgis.PyQt.QtCore import QVariant
        
        if self.working_layer.fields().indexOf('ESTADO') == -1:
            self.working_layer.startEditing()
            self.working_layer.dataProvider().addAttributes([QgsField("ESTADO", QVariant.String, len=20)])
            self.working_layer.updateFields()
            self.working_layer.commitChanges()
            
        # Get groups
        recintos_names = set([self.listRecintos.item(i).text().split(" [")[0] for i in range(self.listRecintos.count())])
        clases_names = set([self.listClases.item(i).text().split(" [")[0] for i in range(self.listClases.count())])
        
        r_only = recintos_names - clases_names
        c_only = clases_names - recintos_names
        common = recintos_names & clases_names
        
        # Update features
        self.working_layer.startEditing()
        
        layer_idx = self.working_layer.fields().indexOf('Layer')
        if layer_idx == -1:
            layer_idx = self.working_layer.fields().indexOf('LAYER')
            
        estado_idx = self.working_layer.fields().indexOf('ESTADO')
        
        count = 0
        for feature in self.working_layer.getFeatures():
            layer_name = feature.attribute(layer_idx)
            if not layer_name: continue
            layer_name = str(layer_name)
            
            new_val = None
            if layer_name in common:
                new_val = "COMUN"
            elif layer_name in r_only:
                new_val = "RECINTO"
            elif layer_name in c_only:
                new_val = "CLASE"
                
            if new_val:
                self.working_layer.changeAttributeValue(feature.id(), estado_idx, new_val)
                count += 1
                
        self.working_layer.commitChanges()
        self.log(f"Campo ESTADO actualizado en {count} elementos.", indent=True)

    def open_help(self):
        """Abre el archivo de ayuda en el navegador."""
        import webbrowser
        help_path = os.path.join(os.path.dirname(__file__), 'ayuda.html')
        url = f"file:///{help_path.replace(os.sep, '/')}"
        webbrowser.open(url)

    def save_project(self):
        """
        Guarda el estado del plugin + el proyecto QGIS en un par de archivos
        con el mismo nombre base: ValGIS_Project_XXXX.json + ValGIS_Project_XXXX.qgs
        """
        if not self.output_dir or not os.path.exists(self.output_dir):
            default_path = os.path.join(os.path.expanduser("~"), "Desktop")
        else:
            default_path = self.output_dir

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        default_file = os.path.join(default_path, f"ValGIS_Project_{timestamp}.json")

        json_path, _ = QFileDialog.getSaveFileName(
            self, "Guardar Proyecto ValGIS", default_file, "JSON Files (*.json)"
        )
        if not json_path:
            return

        # Asegurar extensión .json
        if not json_path.lower().endswith('.json'):
            json_path += '.json'

        # El QGIS project usa .qgz (formato comprimido) para que sea en un único archivo
        qgs_path = os.path.splitext(json_path)[0] + '.qgz'

        try:
            # ── 1. Guardar el proyecto QGIS (delega en QGIS toda la gestión de capas)
            # Forzamos a QGIS a usar rutas RELATIVAS internamente en el .qgz
            project = QgsProject.instance()
            try:
                # Intentar en Qgis (versiones más recientes de QGIS 3)
                from qgis.core import Qgis
                project.setFilePathStorage(Qgis.FilePathStorage.Relative)
            except:
                try:
                    # Intentar en QgsProject (versiones anteriores de QGIS 3)
                    project.setFilePathStorage(QgsProject.Relative)
                except:
                    # Fallback silencioso si la API es distinta
                    pass
            project.write(qgs_path)
            self.log(f"Proyecto QGIS guardado (Rutas Relativas): {qgs_path}", indent=True)

            # ── 2. Serializar estado lógico del plugin
            # Capas de los ListWidgets (valores lógicos del campo 'layer' del CAD): guardamos solo el texto
            def list_logical_layers(list_widget):
                result = []
                for i in range(list_widget.count()):
                    result.append(list_widget.item(i).text())
                return result

            json_dir = os.path.dirname(json_path)

            # Helper to relativize paths including QGIS source strings
            def relativize(path):
                if not path: return None
                parts = path.split('|')
                file_part = parts[0]
                if os.path.isabs(file_part):
                    try:
                        # Convert to relative and use forward slashes for better JSON compatibility
                        rel_file = os.path.relpath(file_part, json_dir).replace('\\', '/')
                        parts[0] = rel_file
                        return '|'.join(parts)
                    except ValueError:
                        # Paths on different drives (Windows)
                        return path
                return path

            # Función auxiliar para obtener datos de capa de forma segura
            def get_layer_data(lyr):
                try:
                    # Verificamos si el objeto existe y si QGIS lo reconoce como capa válida
                    if lyr and QgsProject.instance().mapLayer(lyr.id()):
                        return {
                            'name': lyr.name(),
                            'source': relativize(lyr.source())
                        }
                except:
                    pass
                return {'name': None, 'source': None}

            state = {
                'version': '2.1',
                'timestamp': timestamp,
                'qgs_file': relativize(qgs_path),
                'current_step': self.current_step,
                'output_dir': relativize(self.output_dir),
                'dxf_name': self.dxf_name,
                'dxf_source': relativize(getattr(self, 'dxf_source', None)),
                'dxf_crs': getattr(self, 'dxf_crs', None),
                'analysis_done': self.analysis_done,
                'changes_made_in_loop': getattr(self, 'changes_made_in_loop', False),
                'dup_version': getattr(self, '_dup_version', 0),
                'params': {
                    'tolerance': self.sbTolerance.value(),
                    'extension_tolerance': self.sbExtensionTolerance.value(),
                    'angle_tolerance': self.sbAngleTolerance.value(),
                    'min_length': self.sbMinLength.value(),
                    'sagitta': self.sbSagitta.value(),
                    'arc_length': self.sbArcLength.value(),
                    'auto_fix': self.chkAutoFix.isChecked()
                },
                # Arrays con los textos descriptivos de la pestaña "Configuración de Capas"
                'layer_groups': {
                    'recintos': list_logical_layers(self.listRecintos),
                    'clases': list_logical_layers(self.listClases)
                },
                'working_layer': get_layer_data(self.working_layer),
                'poly_recintos': get_layer_data(self.poly_recintos),
                'poly_clases': get_layer_data(self.poly_clases),
                'lines_layer_for_dxf': get_layer_data(self.lines_layer_for_dxf)
            }

            with open(json_path, 'w', encoding='utf-8') as f:
                json.dump(state, f, indent=4, ensure_ascii=False)

            self.log(f"Estado del plugin guardado: {json_path}", indent=True)
            QMessageBox.information(
                self, "Proyecto Guardado",
                f"Proyecto guardado correctamente:\n\n  • {os.path.basename(qgs_path)}\n  • {os.path.basename(json_path)}\n\nEn: {os.path.dirname(json_path)}"
            )

        except Exception as e:
            import traceback
            self.log(f"Error al guardar proyecto: {str(e)}")
            self.log(traceback.format_exc(), indent=True)
            QMessageBox.critical(self, "Error al Guardar", f"Fallo al guardar el proyecto:\n{str(e)}")

    def open_project(self):
        """
        Abre un proyecto ValGIS desde un archivo JSON.
        Flujo atómico:
          1. Cerrar proyecto QGIS actual sin preguntar nada.
          2. Abrir el .qgs asociado al JSON (delega en QGIS la restauración de capas).
          3. Restaurar lógica del plugin desde el JSON.
        """
        # ── Selección del JSON
        # Proponer output_dir si existe, si no el Desktop
        start_dir = self.output_dir if (self.output_dir and os.path.exists(self.output_dir)) \
                    else os.path.join(os.path.expanduser("~"), "Desktop")

        json_path, _ = QFileDialog.getOpenFileName(
            self, "Abrir Proyecto ValGIS", start_dir, "JSON Files (*.json)"
        )
        if not json_path:
            return

        try:
            # ── Leer JSON antes de limpiar nada (si está corrompido, abortamos)
            with open(json_path, 'r', encoding='utf-8') as f:
                state = json.load(f)

            version = state.get('version', '1.0')

            json_dir = os.path.dirname(json_path)

            # Helper to resolve relative paths back to absolute
            def resolve_path(path):
                if not path: return None
                parts = path.split('|')
                file_part = parts[0]
                if not os.path.isabs(file_part):
                    # Join with JSON dir and normalize
                    abs_file = os.path.abspath(os.path.join(json_dir, file_part))
                    parts[0] = abs_file
                    return '|'.join(parts)
                return path

            # ── Localizar el .qgs asociado
            qgs_path = resolve_path(state.get('qgs_file'))
            qgs_exists = qgs_path and os.path.exists(qgs_path)

            # ── 1. LIMPIEZA ATÓMICA: cerrar QGIS sin preguntar nada
            QgsProject.instance().setDirty(False)   # Impide el diálogo "¿Guardar?"
            QgsProject.instance().clear()            # Vacía el proyecto completamente

            # ── 2. Reset completo del plugin (force=True → sin confirmación)
            self.reset_plugin(force=True)

            QApplication.processEvents()  # Refrescar UI después del reset

            self.log(f"Cargando proyecto desde: {json_path}")

            # ── 3. Cargar .qgs si existe (QGIS restaura capas, simbología, grupos…)
            if qgs_exists:
                QgsProject.instance().read(qgs_path)
                QApplication.processEvents()
                self.log(f"Proyecto QGIS cargado: {qgs_path}", indent=True)
            else:
                self.log("Advertencia: archivo .qgs no encontrado. Solo se restaurará la lógica del plugin.", indent=True)

            # ── 4. Restaurar parámetros del plugin
            params = state.get('params', {})
            self.sbTolerance.setValue(params.get('tolerance', 0.025))
            self.sbExtensionTolerance.setValue(params.get('extension_tolerance', 0.025))
            self.sbAngleTolerance.setValue(params.get('angle_tolerance', 15.0))
            self.sbMinLength.setValue(params.get('min_length', 0.025))
            self.sbSagitta.setValue(params.get('sagitta', 0.001))
            self.sbArcLength.setValue(params.get('arc_length', 0.30))
            self.chkAutoFix.setChecked(params.get('auto_fix', False))

            # ── 5. Restaurar variables de estado del plugin
            self.output_dir = resolve_path(state.get('output_dir'))
            
            # Restaurar DXF (intentar dxf_source/path primero, luego dxf_name por retrocompatibilidad)
            dxf_info = state.get('dxf_source') or state.get('dxf_path') or state.get('dxf_name')
            self.dxf_source = resolve_path(dxf_info)
            self.dxf_crs = state.get('dxf_crs')
            
            if self.dxf_source:
                # Extraer solo el nombre base para el atributo dxf_name (usado en reportes)
                self.dxf_name = os.path.basename(self.dxf_source.split('|')[0])
            else:
                self.dxf_name = state.get('dxf_name', "")
            
            self.analysis_done = state.get('analysis_done', False)
            self.changes_made_in_loop = state.get('changes_made_in_loop', False)
            self._dup_version = state.get('dup_version', 0)

            # ── 6. Re-vincular capas: buscar en el proyecto cargado por source()
            project = QgsProject.instance()
            loaded_layers = {layer.source(): layer for layer in project.mapLayers().values()}

            def find_layer_by_source(info_dict):
                """Devuelve la capa del proyecto usando la ruta normalizada o el nombre en caso de fallo."""
                if not info_dict:
                    return None
                
                src = resolve_path(info_dict.get('source'))
                if src:
                    src_norm = os.path.normpath(src)
                    # 1. Buscar coincidencia exacta o por ruta normalizada
                    for l_src, layer in loaded_layers.items():
                        if l_src == src or os.path.normpath(l_src) == src_norm:
                            return layer
                
                # 2. Fallback: Buscar por nombre en el proyecto
                name = info_dict.get('name')
                if name:
                    layers = project.mapLayersByName(name)
                    if layers:
                        return layers[0]
                
                return None

            # Capa de trabajo
            self.working_layer = find_layer_by_source(state.get('working_layer'))
            
            # --- SELF-HEALING: Si el JSON referenciaba una capa pero no se cargó ---
            if not self.working_layer and state.get('working_layer') and state.get('working_layer').get('source'):
                # Intentar cargar directo desde el disco (ej. 04_00 si el save fue a medias)
                resolved_src = resolve_path(state.get('working_layer').get('source'))
                expected_source = os.path.normpath(resolved_src.split("|")[0])
                
                # Fallback inteligiente: si guardó en 04_02 pero luego en disco consolidó a 04_00 sin guardar
                import re
                if not os.path.exists(expected_source):
                    basename = os.path.basename(expected_source)
                    if re.match(r'^04_\d{2}_Sin_Duplicados', basename):
                        fallback_source = os.path.join(os.path.dirname(expected_source), "04_00_Sin_Duplicados.shp")
                        if os.path.exists(fallback_source):
                            expected_source = fallback_source

                if os.path.exists(expected_source):
                    self.log(f"Autosanando: cargando capa de trabajo desde el disco {expected_source}", indent=True)
                    display_name = os.path.splitext(os.path.basename(expected_source))[0]
                    self.working_layer = QgsVectorLayer(expected_source, display_name, "ogr")
                    if self.working_layer.isValid():
                        QgsProject.instance().addMapLayer(self.working_layer)
                        self.created_layers.append(self.working_layer.id())
                    else:
                        self.working_layer = None
                
            if self.working_layer:
                self.log(f"Capa de trabajo: {self.working_layer.name()}", indent=True)
            else:
                self.log("Advertencia: no se pudo re-vincular la capa de trabajo.", indent=True)

            # Capas poligonales
            self.poly_recintos = find_layer_by_source(state.get('poly_recintos'))
            self.poly_clases = find_layer_by_source(state.get('poly_clases'))
            self.lines_layer_for_dxf = find_layer_by_source(state.get('lines_layer_for_dxf'))

            # ── 7. Reconstruir ListWidgets RECINTOS / CLASES
            from qgis.PyQt.QtWidgets import QListWidgetItem

            # A) Primero refescamos 'Todas las capas' para tener la base disponible
            self.populate_layers()          

            # B) Ahora repoblamos las listas lógicas de configuración
            def repopulate_logical_list(group_key, list_widget):
                list_widget.clear()
                for info in state.get('layer_groups', {}).get(group_key, []):
                    label = info.get('name', '') if isinstance(info, dict) else info
                    if not label:
                        continue
                    
                    item = QListWidgetItem(label)
                    clean_name = label.split(" [")[0] if " [" in label else label
                    item.setData(Qt.UserRole, clean_name)
                    list_widget.addItem(item)
                    self.log(f"  [{group_key.upper()}] {clean_name}", indent=True)

            repopulate_logical_list('recintos', self.listRecintos)
            repopulate_logical_list('clases', self.listClases)

            # C) Actualizamos los estilos (color y tachado) en 'Todas las capas' usando las listas ya pobladas
            self.update_source_list_visuals()

            # ── 8. Restaurar paso actual y refrescar UI
            self.current_step = state.get('current_step', 0)
            self.update_ui()                # Actualizar textos de paso y botones
            if self.working_layer:
                self.update_layer_visibility()  # Mostrar solo la capa activa

            # ── 9. Foco automático en la pestaña "Procesamiento" lista para continuar
            self.tabWidget.setCurrentWidget(self.tabProcessing)

            # ── 10. Recreación de Capa LOG Temporal
            if self.working_layer:
                # Eliminar LOG si quedó remanente del guardado (para evitar duplicados corruptos)
                for lyr in QgsProject.instance().mapLayersByName("LOG"):
                    QgsProject.instance().removeMapLayer(lyr)
                # Volver a instanciar la memory layer a través de la helper
                self.log_helper.create_log_layer(self.output_dir, self.working_layer.crs())

            QApplication.processEvents()

            self.log(f"Proyecto restaurado. Listo en Paso {self.current_step + 1}: {self.step_info[self.current_step][0]}")
            QMessageBox.information(
                self, "Proyecto Cargado",
                f"Proyecto restaurado correctamente.\n\nPaso actual: {self.current_step + 1} – {self.step_info[self.current_step][0]}\n\nPulse 'Siguiente' para continuar."
            )

        except Exception as e:
            import traceback
            self.log(f"Error al abrir proyecto: {str(e)}")
            self.log(traceback.format_exc(), indent=True)
            QMessageBox.critical(self, "Error al Abrir", f"Fallo al abrir el proyecto:\n{str(e)}")

