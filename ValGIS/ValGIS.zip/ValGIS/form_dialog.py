import os
import time
import re
from qgis.PyQt import uic
from qgis.PyQt.QtWidgets import QDockWidget, QMessageBox, QApplication, QTableWidgetItem, QFileDialog, QProgressBar, QListWidgetItem, QStyle
from qgis.PyQt.QtCore import QTimer, Qt
from qgis.PyQt.QtGui import QColor
from qgis.core import QgsProject, QgsRectangle, QgsGeometry, QgsPointXY, QgsFeature, QgsVectorLayer
from qgis.gui import QgsHighlight

from .steps.step_load import StepLoad
from .steps.step_simplify import StepSimplify
from .steps.step_detect_shorts import StepDetectShorts
from .steps.step_detect_duplicates import StepDetectDuplicates
from .steps.step_detect_dangles import StepDetectDangles
from .steps.step_normalize_coordinates import StepNormalizeCoordinates

from .steps.step_join_collinear import StepJoinCollinear
from .steps.step_split_intersections import StepSplitIntersections
from .steps.step_advanced_shorts import StepAdvancedShorts
from .steps.step_check_validity import StepCheckValidity
from .steps.step_open_enclosures import StepOpenEnclosures
from .steps.step_generate_polygons import StepGeneratePolygons
from .steps.step_validate_polygons import StepValidatePolygons
from .steps.step_analyze_changes import StepAnalyzeChanges
from .steps.step_final_check import StepFinalCheck
from .steps.step_fix_islands import StepFixIslands
from .steps.step_verify_polygon_topology import StepVerifyPolygonTopology
from .topology.graph import Graph

from .helpers.layer_utils import clean_and_save_layer
from .helpers.log_helper import LogHelper
from .helpers.naming_convention import get_step_filename
from .helpers.summary_report import create_summary_html, update_step_status

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'ui', 'dock_widget.ui'))

class TopoCADGISDockWidget(QDockWidget, FORM_CLASS):
    def __init__(self, iface, parent=None):
        super(TopoCADGISDockWidget, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_timer_label)
        self.start_time = 0
        self.estimated_duration = 10.0
        self.current_step = 0
        self.created_layers = []
        self.highlights = []
        self.log_helper = LogHelper()
        self.analysis_done = False # Flag for two-stage analysis confirmation
        self.analysis_errors = [] # Store errors for restoration
        self.lines_layer_for_dxf = None # Store lines layer for final DXF export
        self.dxf_name = "" # Store DXF name for HTML summary
        self.working_layer = None # Initialize working layer
        self.output_dir = None # Initialize output directory
        self.poly_recintos = None # Polygon layer for Recintos
        self.poly_clases = None # Polygon layer for Clases
        
        # Añadir barra de progreso programáticamente
        self.progressBar = QProgressBar()
        self.progressBar.setRange(0, 100)
        self.progressBar.setValue(0)
        self.progressBar.setTextVisible(True)
        self.progressBar.setVisible(False)
        
        # Buscar layout para insertar la barra de progreso (asumiendo layout vertical del dock widget)
        # Intentamos insertarla después de lblTimer
        if self.lblTimer.parent():
            layout = self.lblTimer.parent().layout()
            if layout:
                idx = layout.indexOf(self.lblTimer)
                if idx >= 0:
                    layout.insertWidget(idx + 1, self.progressBar)
                else:
                    layout.addWidget(self.progressBar)
        
        # Inicializar Pasos - Flujo de trabajo topológico profesional
        self.steps = [
            self.step_load_logic,              # 0 - Cargar DXF
            self.step_fix_geometries_logic,    # 1 - Reparar geometrías inválidas
            self.step_normalize_coordinates_logic, # 2 - Normalizar coordenadas (NUEVO)
            self.step_detect_duplicates_logic, # 3 - Detectar duplicados
            self.step_smart_snap_logic,        # 4 - Snap inteligente (MOVIDO AQUÍ)
            self.step_join_collinear_logic,    # 5 - Unir colineales (1er pase, SIN snap)
            self.step_join_collinear_2_logic,  # 6 - Re-unir colineales (2do pase, SIN snap)
            self.step_split_intersections_logic,# 7 - Cortar intersecciones
            self.step_detect_dangles_logic,    # 8 - Detectar dangles
            self.step_extend_dangles_logic,    # 9 - Extender dangles
            self.step_split_intersections_2_logic,# 10 - Re-cortar después de extender
            self.step_simplify_logic_3,        # 11 - Simplificar (protegido)
            self.step_check_validity_logic,    # 12 - Validar errores
            self.step_verify_enclosures_logic, # 13 - Verificar áreas cerradas
            self.step_verify_slivers_logic,    # 14 - Verificar astillas (NUEVO)
            self.step_analyze_changes_logic,   # 15 - Analizar cambios geométricos
            self.step_generate_polygons_logic, # 16 - Generar polígonos
            self.step_validate_polygons_logic, # 17 - Validar polígonos
            self.step_verify_polygon_topology_logic, # 18 - Verificar Topología (NUEVO)
            self.step_export_dxf_logic         # 19 - Exportar DXF Final
        ]

        self.step_info = [
            ("Cargar DXF", "Carga el archivo DXF y crea una copia de trabajo."),
            ("Reparar Geometrías", "Corrige geometrías inválidas del DXF."),
            ("Normalizar Coordenadas", "Redondea coordenadas a 5 decimales (0.01mm)."),
            ("Detectar Duplicados", "Elimina líneas duplicadas o contenidas."),
            ("Snap Inteligente", "Conecta vértices cercanos (Snap)."),
            ("Unir Colineales", "Fusiona líneas consecutivas."),
            ("Re-unir Colineales", "Segunda pasada de fusión."),
            ("Cortar Intersecciones", "Crea nodos en intersecciones."),
            ("Detectar Dangles", "Identifica líneas colgadas."),
            ("Extender Dangles", "Extiende líneas cortas."),
            ("Re-cortar", "Corta nuevas intersecciones."),
            ("Simplificar", "Elimina vértices redundantes."),
            ("Validar Errores", "Chequeo final de validez."),
            ("Verificar Áreas", "Asegura cierre de polígonos."),
            ("Verificar Astillas", "Detecta polígonos extraños o muy pequeños."),
            ("Analizar Cambios", "Compara geometría original vs final."),
            ("Generar Polígonos", "Crea polígonos finales."),
            ("Validar Polígonos", "Detecta solapes, huecos y astillas."),
            ("Verificar Topología", "Detecta nodos duplicados en contornos cerrados."),
            ("Exportar DXF", "Genera archivo final para CAD.")
        ]
        
        # Conectar interfaz de usuario
        self.btnNext.clicked.connect(self.go_next)
        self.btnPrevious.clicked.connect(self.go_previous)
        self.tableErrors.itemSelectionChanged.connect(self.update_button_state)
        self.tableErrors.itemDoubleClicked.connect(self.zoom_to_error_table)
        self.btnZoom.clicked.connect(self.zoom_to_error)
        self.btnFix.clicked.connect(self.fix_action)
        self.btnReset.clicked.connect(self.reset_plugin)
        
        # Configurar botón de ayuda
        self.btnHelp.setIcon(self.style().standardIcon(QStyle.SP_TitleBarContextHelpButton))
        self.btnHelp.clicked.connect(self.open_help)

        # Estado inicial
        self.lblWorking.setText("")
        self.lblWorking.setVisible(True) 
        self.lblTimer.setText("Estimado: 00:00.00")
        
        self.update_ui()
        
        # Conectar nuevos elementos de UI
        self.btnRefreshLayers.clicked.connect(self.populate_layers)
        
        # Conectar interacciones de listas
        self.listAllLayers.itemDoubleClicked.connect(self.add_layer_to_target)
        self.listRecintos.itemDoubleClicked.connect(self.remove_layer_from_recintos)
        self.listClases.itemDoubleClicked.connect(self.remove_layer_from_clases)
        
        # Conectar cambio de pestaña a validación
        self.tabWidget.currentChanged.connect(self.check_tab_access)
        
        # Conectar botones de acciones masivas
        self.btnAddAllRecintos.clicked.connect(self.add_all_to_recintos)
        self.btnAddAllClases.clicked.connect(self.add_all_to_clases)
        self.btnClearRecintos.clicked.connect(self.clear_recintos)
        self.btnClearClases.clicked.connect(self.clear_clases)
        self.btnImportConfig.clicked.connect(self.import_config)
        
        # Población inicial si el proyecto está cargado
        self.populate_layers()
        self.validate_layers()
        
    def log(self, message, indent=False):
        import re
        
        # Convertir rutas de archivo a enlaces de carpeta clicables
        def make_path_clickable(text):
            # Coincidir rutas de Windows (ej: C:\ruta\a\archivo.ext)
            path_pattern = r'([A-Z]:\\[^<>\s]+\.\w+)'
            
            def replace_path(match):
                full_path = match.group(1)
                folder_path = os.path.dirname(full_path)
                filename = os.path.basename(full_path)
                # Crear una URL file:/// que abre la carpeta
                folder_url = f"file:///{folder_path.replace(os.sep, '/')}"
                return f'<a href="{folder_url}">{full_path}</a>'
            
            return re.sub(path_pattern, replace_path, text)
        
        if indent:
            processed_message = make_path_clickable(message)
            self.txtLog.append(f" - {processed_message}")
        else:
            timestamp = time.strftime("[%Y-%m-%d %H:%M:%S]")
            processed_message = make_path_clickable(message)
            # Usar HTML para timestamp en negrita
            self.txtLog.append(f"<b>{timestamp}</b> {processed_message}")

    def get_feature_by_uuid(self, uuid_value):
        """
        Buscar una feature por su campo UUID.
        Devuelve la feature si se encuentra, None en caso contrario.
        """
        if not self.working_layer:
            return None
        
        # Verificar si el campo UUID existe
        has_uuid = False
        for field in self.working_layer.fields():
            if field.name() == 'UUID':
                has_uuid = True
                break
        
        if not has_uuid:
            return None
        
        # Buscar feature con UUID coincidente
        for feat in self.working_layer.getFeatures():
            if feat['UUID'] == uuid_value:
                return feat
        
        return None

    def update_button_state(self):
        has_selection = len(self.tableErrors.selectedRanges()) > 0
        self.btnZoom.setEnabled(has_selection)
        self.btnFix.setEnabled(has_selection)

    def handle_errors(self, errors):
        """
        Manejar errores devueltos por los pasos.
        Puebla la tabla de errores y devuelve False si hay errores, True en caso contrario.
        """
        if not errors:
            return True
            
        self.current_errors = errors
        self.tableErrors.setRowCount(len(errors))
        
        for i, error in enumerate(errors):
            msg = error.get('msg', 'Error desconocido')
            # Añadir a la tabla
            item_msg = QTableWidgetItem(msg)
            self.tableErrors.setItem(i, 0, item_msg)
            
        self.label_errors.setText(f"Errores Detectados: ({len(errors)})")
        self.log(f"Se encontraron {len(errors)} errores/advertencias.", indent=True)
        
        return False

    def update_ui(self):
        if self.current_step < len(self.step_info):
            name, desc = self.step_info[self.current_step]
            self.lblStep.setText(f"Paso {self.current_step + 1} de {len(self.steps)}: {name}")
            self.lblDescription.setText(desc)
        
        self.btnPrevious.setEnabled(self.current_step > 0)
        if self.current_step == len(self.steps) - 1:
            self.btnNext.setText("Finalizar")
        else:
            self.btnNext.setText("Siguiente")
        
        self.update_button_state()

    def update_timer_label(self):
        # Obsoleto: Lógica del temporizador eliminada en favor de etiqueta simple TRABAJANDO
        pass

    def progress_callback(self, current=None, total=None):
        """Llamado por pasos de larga duración para mantener la UI activa."""
        if current is not None:
            self.processed_items = current
        if total is not None:
            self.total_items_to_process = total
            
        QApplication.processEvents()

    def reset_plugin(self):
        reply = QMessageBox.question(self, "Confirmar Reinicio", 
            "¿Está seguro de que desea reiniciar el plugin?\nSe eliminarán todas las capas generadas del proyecto y se restablecerán los parámetros.",
            QMessageBox.Yes | QMessageBox.No)
        if reply == QMessageBox.No: return

        project = QgsProject.instance()
        
        layers_to_remove = []
        for layer_id in self.created_layers:
            layers_to_remove.append(layer_id)
            
        for layer_id, layer in project.mapLayers().items():
            name = layer.name()
            # Eliminar capas numeradas (ej: 01_00_Carga.shp)
            if re.match(r'^\d{2}_\d{2}_', name):
                layers_to_remove.append(layer_id)
            # Eliminar capa LOG
            elif name == "LOG":
                layers_to_remove.append(layer_id)
            # Eliminar capas del directorio de salida ValGIS
            elif "ValGIS_Output" in layer.source():
                 layers_to_remove.append(layer_id)

        layers_to_remove = list(set(layers_to_remove))
        if layers_to_remove:
            project.removeMapLayers(layers_to_remove)
            
        self.created_layers = []
        
        # Reiniciar log_helper
        self.log_helper = LogHelper()
        
        # Reiniciar parámetros
        self.sbTolerance.setValue(0.025)
        self.sbExtensionTolerance.setValue(0.025)
        self.sbAngleTolerance.setValue(15.0)
        self.sbMinLength.setValue(0.025)
        self.sbSagitta.setValue(0.001)
        self.sbArcLength.setValue(0.30)
        self.clear_highlights()
        
        # Reiniciar al paso 1
        self.current_step = 0
        self.working_layer = None
        self.output_dir = None
        self.current_errors = []
        self.tableErrors.setRowCount(0)
        self.label_errors.setText("Errores Detectados: (0)")
        
        # Limpiar texto del log
        self.txtLog.clear()
        
        self.log("Plugin reiniciado y parámetros restablecidos.")
        
        # Restaurar visibilidad de capas restantes (DXF Original)
        root = project.layerTreeRoot()
        for child in root.children():
            child.setItemVisibilityChecked(True)
        
        # Zoom a extensión completa
        self.iface.mapCanvas().refresh()
        self.iface.mapCanvas().zoomToFullExtent()
        
        self.update_ui()

    def restart_topology_loop(self):
        """
        Reiniciar el bucle de topología desde el paso 7 (Cortar Intersecciones) después de correcciones manuales.
        Esto guarda el estado actual, limpia archivos intermedios y prepara para re-ejecución.
        """
        import os
        import shutil
        from qgis.core import QgsProject, QgsVectorLayer
        
        self.log("Reiniciando bucle de topología desde 'Cortar Intersecciones'...")
        
        # 1. Guardar capa de trabajo actual al nombre esperado para el paso 7
        target_filename = "04_00_Unido2.shp"
        target_path = os.path.join(self.output_dir, target_filename)
        
        # Eliminar archivo antiguo si existe
        if os.path.exists(target_path):
            for ext in ['.shp', '.shx', '.dbf', '.prj', '.cpg', '.qpj']:
                file_to_remove = target_path.replace('.shp', ext)
                if os.path.exists(file_to_remove):
                    try:
                        os.remove(file_to_remove)
                    except Exception as e:
                        self.log(f"  Advertencia: No se pudo eliminar {file_to_remove}: {e}", indent=True)
        
        # Guardar estado actual a la ruta destino
        from .helpers.layer_utils import clean_and_save_layer
        self.working_layer, _ = clean_and_save_layer(self.working_layer, target_path)
        self.log(f"  Estado actual guardado como: {target_filename}", indent=True)
        
        # 2. Eliminar capas intermedias del proyecto QGIS
        project = QgsProject.instance()
        layers_to_remove = []
        
        # Identificar capas de los pasos 7-10 por sus nombres de archivo
        intermediate_files = [
            "05_00_Cortado.shp",
            "08_00_Recortado.shp"
        ]
        
        for layer_id in list(self.created_layers):
            layer = project.mapLayer(layer_id)
            if layer:
                source = layer.source()
                for intermediate_file in intermediate_files:
                    if intermediate_file in source:
                        layers_to_remove.append(layer_id)
                        self.created_layers.remove(layer_id)
                        break
        
        if layers_to_remove:
            project.removeMapLayers(layers_to_remove)
            self.log(f"  Eliminadas {len(layers_to_remove)} capas intermedias del proyecto.", indent=True)
        
        # 3. Eliminar shapefiles intermedios del disco
        for intermediate_file in intermediate_files:
            file_path = os.path.join(self.output_dir, intermediate_file)
            if os.path.exists(file_path):
                for ext in ['.shp', '.shx', '.dbf', '.prj', '.cpg', '.qpj']:
                    file_to_remove = file_path.replace('.shp', ext)
                    if os.path.exists(file_to_remove):
                        try:
                            os.remove(file_to_remove)
                        except Exception as e:
                            self.log(f"  Advertencia: No se pudo eliminar {file_to_remove}: {e}", indent=True)
                self.log(f"  Eliminado archivo intermedio: {intermediate_file}", indent=True)
        
        # 4. Añadir la capa renombrada al proyecto (será usada por el paso 7)
        self.add_layer_to_project(self.working_layer)
        self.created_layers.append(self.working_layer.id())
        
        # 5. Reiniciar la bandera del bucle
        self.changes_made_in_loop = False
        
        self.log("  Bucle de topología reiniciado. Continuando desde paso 7...", indent=True)

    def clear_highlights(self):
        for h in self.highlights:
            h.hide()
            del h
        self.highlights = []

    def update_layer_visibility(self):
        if not self.working_layer: return
        
        root = QgsProject.instance().layerTreeRoot()
        for child in root.children():
            if child.layerId() == self.working_layer.id():
                child.setItemVisibilityChecked(True)
            else:
                child.setItemVisibilityChecked(False)
        
        self.iface.mapCanvas().refresh()

    def go_next(self):
        try:
            # Limpiar tabla de errores al inicio de cada paso
            self.tableErrors.setRowCount(0)
            self.current_errors = []
            self.label_errors.setText("Errores Detectados: (0)")
            
            if self.current_step > 0:
                if not self.working_layer or not self.working_layer.isValid():
                    QMessageBox.warning(self, "Capa no encontrada", "Capa inválida.")
                    return

            self.log(f"Ejecutando Paso {self.current_step + 1}: {self.step_info[self.current_step][0]}...")
            
            # self.estimated_duration = 5.0 
            # if self.working_layer:
            #     count = self.working_layer.featureCount()
            #     if count > 0:
            #         self.estimated_duration = max(1.0, count * 0.001)
            
            self.start_time = time.time()
            # self.timer.start(50) 
            # self.update_timer_label()
            
            # Reutilizar lblTimer como etiqueta de Trabajo
            self.lblTimer.setText("TRABAJANDO")
            self.lblTimer.setStyleSheet("color: red; font-weight: bold;")
            self.lblTimer.repaint()
            
            # self.lblWorking.setText("TRABAJANDO...")
            # self.lblWorking.repaint()
            QApplication.processEvents()
            # self.lblTimer.setText("Estimado: 00:00.00") 
            
            if self.current_step == 4: 
                self.changes_made_in_loop = False
            
            # Añadir campo ESTADO antes de iniciar procesamiento (Paso 1)
            if self.current_step == 1:
                self.add_state_field()
                
            result = self.steps[self.current_step]()
            
            self.lblTimer.setText("") # Limpiar etiqueta de trabajo
            self.progressBar.setVisible(False) # Ocultar barra de progreso
            self.progressBar.setValue(0)
            
            elapsed = time.time() - self.start_time
            self.log(f"Completado en {elapsed:.2f} segundos.", indent=True)
            
            if result: 
                self.update_layer_visibility()
                
                # Verificar si hay errores después de la ejecución
                if self.tableErrors.rowCount() > 0:
                    # Manejo especial para Paso 15 (Verificar Astillas) - Índice 14
                    if self.current_step == 14:
                        reply = QMessageBox.question(
                            self, 
                            "Advertencias Detectadas", 
                            f"Se encontraron {self.tableErrors.rowCount()} posibles astillas.\n\n¿Desea ignorarlas y continuar de todos modos?", 
                            QMessageBox.Yes | QMessageBox.No,
                            QMessageBox.No
                        )
                        
                        if reply == QMessageBox.Yes:
                            self.log("   Usuario decidió ignorar advertencias y continuar.", indent=True)
                            # Proceder (continuar para incrementar paso)
                        else:
                            self.log("   Usuario decidió revisar advertencias. Re-ejecutando validación...", indent=True)
                            # Re-ejecutar lógica para refrescar lista de errores
                            self.steps[self.current_step]()
                            return # Detener avance
                    # Manejo especial para Paso 18 (Validar Polígonos) - Índice 17
                    elif self.current_step == 17:
                        reply = QMessageBox.question(
                            self, 
                            "Problemas de Calidad Detectados", 
                            f"Se encontraron {self.tableErrors.rowCount()} problemas en los polígonos (huecos, solapes, etc.).\n\n¿Desea ignorarlos y generar el DXF final de todos modos?", 
                            QMessageBox.Yes | QMessageBox.No,
                            QMessageBox.No
                        )
                        
                        if reply == QMessageBox.Yes:
                            self.log("   Usuario decidió ignorar problemas de calidad y continuar.", indent=True)
                            # Proceder
                        else:
                            self.log("   Usuario decidió revisar problemas. Re-ejecutando validación...", indent=True)
                            self.steps[self.current_step]()
                            return # Detener avance
                    else:
                        # Comportamiento por defecto para otros pasos: Detener
                        self.log(f"Hay {self.tableErrors.rowCount()} errores. Corrija manualmente y presione 'Siguiente' para validar.", indent=True)
                        self.apply_group_styles()
                        return  # No avanzar

                # TEMPORALMENTE DESHABILITADO: Reinicio de bucle topológico
                # ... (omitido por brevedad)

                if self.current_step < len(self.steps) - 1:
                    self.current_step += 1
                    self.update_ui()
                    # Solo avanzar automáticamente si auto-corrección está habilitada
                    if self.auto_fix_enabled():
                        self.go_next()
                else:
                    self.log("Proceso finalizado.")
            else:
                # Errores detectados - detener aquí independientemente del estado del checkbox
                self.apply_group_styles()
                pass

        except Exception as e:
            self.timer.stop()
            self.lblWorking.setText("")
            self.log(f"Error en Paso {self.current_step + 1}: {str(e)}")
            QMessageBox.critical(self, "Error", f"Fallo en Paso {self.current_step + 1} ({self.step_info[self.current_step][0]}):\n{str(e)}")

    def go_previous(self):
        # Limpiar tabla de errores al retroceder
        self.tableErrors.setRowCount(0)
        self.current_errors = []
        self.label_errors.setText("Errores Detectados: (0)")
        
        if self.current_step > 0:
            self.current_step -= 1
            self.update_ui()

    def zoom_to_error(self, item=None):
        # Limpiar cualquier resaltado previo primero
        self.clear_highlights()
        
        if not item:
            row = self.tableErrors.currentRow()
        else:
            row = item.row()
        
        if row < 0 or row >= len(self.current_errors): return
        
        idx = row
        if idx < len(self.current_errors):
            error_data = self.current_errors[idx]
            

            
            # Seleccionar feature usando UUID si está disponible
            if 'uuid' in error_data and self.working_layer:
                feat = self.get_feature_by_uuid(error_data['uuid'])
                if feat and feat.isValid():
                    self.working_layer.selectByIds([feat.id()])
            elif 'id' in error_data and self.working_layer:
                self.working_layer.selectByIds([error_data['id']])
                
            if 'point' in error_data:
                pt = error_data['point']
                # Ventana de zoom más pequeña (0.5m x 0.5m) para mejor visibilidad del error
                rect = QgsRectangle(pt.x() - 0.25, pt.y() - 0.25, pt.x() + 0.25, pt.y() + 0.25)
                self.iface.mapCanvas().setExtent(rect)
                self.iface.mapCanvas().refresh()

    def zoom_to_error_table(self, item):
        """Manejar doble-clic en elemento de tabla."""
        if item:
            self.zoom_to_error(item)


    def apply_fix(self, error_data):
        success = False
        err_type = error_data.get('type', '')
        
        # Helper function to get feature from error_data
        def get_feature_from_error(error_data):
            """Get feature using UUID if available, otherwise FID"""
            if 'uuid' in error_data:
                return self.get_feature_by_uuid(error_data['uuid'])
            elif 'id' in error_data:
                return self.working_layer.getFeature(error_data['id'])
            return None
        
        if err_type == 'dangle':
            if error_data.get('can_snap') and error_data.get('snap_point'):
                pt = error_data['point']
                snap_pt = error_data['snap_point']
                rect = QgsRectangle(pt.x()-0.001, pt.y()-0.001, pt.x()+0.001, pt.y()+0.001)
                req = self.working_layer.getFeatures(rect)
                
                for feat in req:
                    geom = feat.geometry()
                    
                    if geom.isMultipart():
                        parts = geom.asMultiPolyline()
                    else:
                        parts = [geom.asPolyline()]
                    
                    modified_feat = False
                    new_parts = []
                    
                    for poly in parts:
                        if not poly: 
                            new_parts.append(poly)
                            continue
                        
                        new_poly = list(poly)
                        modified_poly = False
                        
                        if QgsPointXY(poly[0]).distance(pt) < 0.001:
                            new_poly[0] = snap_pt
                            modified_poly = True
                        elif QgsPointXY(poly[-1]).distance(pt) < 0.001:
                            new_poly[-1] = snap_pt
                            modified_poly = True
                        
                        new_parts.append(new_poly)
                        if modified_poly:
                            modified_feat = True
                    
                    if modified_feat:
                        if geom.isMultipart():
                            new_geom = QgsGeometry.fromMultiPolylineXY(new_parts)
                        else:
                            if len(new_parts) > 0:
                                new_geom = QgsGeometry.fromPolylineXY(new_parts[0])
                            else:
                                new_geom = None # Should not happen if original was valid
                        
                        if new_geom:
                            self.working_layer.changeGeometry(feat.id(), new_geom)
                            success = True
                            self.changes_made_in_loop = True
                    
                    if not parts:
                        self.working_layer.deleteFeature(feat.id())
                    else:
                        if len(parts) == 1 and not geom.isMultipart():
                             new_geom = QgsGeometry.fromPolylineXY(parts[0])
                        else:
                             new_geom = QgsGeometry.fromMultiPolylineXY(parts)
                             
                        self.working_layer.changeGeometry(feat.id(), new_geom)
                    
                    success = True
                    self.changes_made_in_loop = True

        elif err_type == 'open_area':
            # Open area errors (from step 14) - analyze why auto-fix failed
            self.log(f"Error 'Área no cerrada': Analizando por qué no se pudo corregir automáticamente...", indent=True)
            
            pt = error_data.get('point')
            if not pt:
                self.log(f"  ✗ No se pudo obtener la ubicación del dangle.", indent=True)
                return False
            
            # Get tolerance
            tol = self.sbTolerance.value()
            
            # Build spatial index
            from qgis.core import QgsSpatialIndex, QgsRectangle
            index = QgsSpatialIndex(self.working_layer.getFeatures())
            
            # Search for nearby features
            search_rect = QgsRectangle(
                pt.x() - tol,
                pt.y() - tol,
                pt.x() + tol,
                pt.y() + tol
            )
            
            candidate_fids = index.intersects(search_rect)
            
            self.log(f"  📍 Dangle en: ({pt.x():.3f}, {pt.y():.3f})", indent=True)
            self.log(f"  🔍 Buscando segmentos dentro de {tol}m...", indent=True)
            
            found_candidates = 0
            closest_segment_dist = float('inf')
            diagnostics = []
            
            for fid in candidate_fids:
                feat = self.working_layer.getFeature(fid)
                if not feat.isValid():
                    continue
                
                geom = feat.geometry()
                if geom.isMultipart():
                    parts = geom.asMultiPolyline()
                else:
                    parts = [geom.asPolyline()]
                
                # Check if this is the dangle's own feature
                is_dangle_feature = False
                for part in parts:
                    if len(part) >= 2:
                        start = QgsPointXY(part[0])
                        end = QgsPointXY(part[-1])
                        if start.distance(pt) < 0.001 or end.distance(pt) < 0.001:
                            is_dangle_feature = True
                            break
                
                if is_dangle_feature:
                    continue
                
                # Analyze each segment
                for part_idx, part in enumerate(parts):
                    if len(part) < 2:
                        continue
                    
                    for seg_idx in range(len(part) - 1):
                        seg_start = QgsPointXY(part[seg_idx])
                        seg_end = QgsPointXY(part[seg_idx + 1])
                        
                        # Calculate projection
                        dx = seg_end.x() - seg_start.x()
                        dy = seg_end.y() - seg_start.y()
                        
                        if abs(dx) < 1e-10 and abs(dy) < 1e-10:
                            continue  # Degenerate segment
                        
                        t = ((pt.x() - seg_start.x()) * dx + (pt.y() - seg_start.y()) * dy) / (dx * dx + dy * dy)
                        
                        # Calculate projection point
                        proj_x = seg_start.x() + t * dx
                        proj_y = seg_start.y() + t * dy
                        projection = QgsPointXY(proj_x, proj_y)
                        
                        dist = pt.distance(projection)
                        
                        if dist < tol:
                            found_candidates += 1
                            closest_segment_dist = min(closest_segment_dist, dist)
                            
                            # Diagnose why it failed
                            reason = []
                            if t < 0:
                                reason.append(f"proyección antes del inicio (t={t:.3f})")
                            elif t > 1:
                                reason.append(f"proyección después del fin (t={t:.3f})")
                            
                            if projection.distance(seg_start) < 0.001:
                                reason.append(f"muy cerca del vértice inicial ({projection.distance(seg_start)*1000:.1f}mm)")
                            if projection.distance(seg_end) < 0.001:
                                reason.append(f"muy cerca del vértice final ({projection.distance(seg_end)*1000:.1f}mm)")
                            
                            if reason:
                                diagnostics.append(f"    • Segmento FID={fid}, dist={dist*100:.1f}cm: {', '.join(reason)}")
            
            if found_candidates == 0:
                self.log(f"  ✗ No se encontraron segmentos cercanos dentro de {tol}m", indent=True)
                self.log(f"  💡 Solución: Aumente la tolerancia de snap o conecte manualmente la línea.", indent=True)
            else:
                self.log(f"  ℹ️ Se encontraron {found_candidates} segmentos cercanos, pero ninguno válido para auto-corrección:", indent=True)
                for diag in diagnostics[:5]:  # Show max 5
                    self.log(diag, indent=True)
                if len(diagnostics) > 5:
                    self.log(f"    ... y {len(diagnostics) - 5} más.", indent=True)
                self.log(f"  💡 Solución: Use las herramientas de edición de QGIS para extender/conectar manualmente.", indent=True)
            
            return False

        elif err_type == 'island':
            step = StepFixIslands()
            if step.fix(self.working_layer, error_data.get('id'), error_data):
                success = True
                self.changes_made_in_loop = True
                self.log(f"  ✓ Isla corregida (corte aplicado).", indent=True)
            else:
                self.log(f"  ✗ No se pudo corregir la isla automáticamente.", indent=True)

        else:
            # Generic delete for other error types
            feat = get_feature_from_error(error_data)
            if feat and feat.isValid():
                success = self.working_layer.deleteFeature(feat.id())
                self.changes_made_in_loop = True
            else:
                self.log(f"Error tipo '{err_type}': No se pudo encontrar la feature para eliminar.", indent=True)
             
        return success

    def fix_action(self):
        selected_rows = set()
        for item in self.tableErrors.selectedItems():
            selected_rows.add(item.row())
        
        if not selected_rows: return
        
        if len(selected_rows) > 1:
            reply = QMessageBox.question(self, "Confirmar Corrección Múltiple", 
                f"¿Desea corregir los {len(selected_rows)} elementos seleccionados?",
                QMessageBox.Yes | QMessageBox.No)
            if reply == QMessageBox.No: return
            
        self.working_layer.startEditing()
        fixed_indices = []
        
        indices = sorted(list(selected_rows), reverse=True)
        
        count = 0
        for idx in indices:
            if idx < len(self.current_errors):
                error_data = self.current_errors[idx]
                try:
                    if self.apply_fix(error_data):
                        fixed_indices.append(idx)
                        count += 1
                except Exception as e:
                    self.log(f"Error corrigiendo ítem {idx}: {str(e)}", indent=True)
        
        if count > 0:
            self.working_layer.commitChanges()
            self.working_layer.triggerRepaint()
            
            for idx in fixed_indices:
                self.tableErrors.removeRow(idx)
                self.current_errors.pop(idx)
            
            self.log(f"Corregidos {count} errores.", indent=True)
            
            self.label_errors.setText(f"Errores Detectados: ({self.tableErrors.rowCount()})")
            
            self.update_ui()
            
            if self.tableErrors.rowCount() == 0:
                QMessageBox.information(self, "Info", "Errores corregidos. Avanzando...")
                self.go_next()
        else:
            self.working_layer.rollBack()
            self.log("No se pudo corregir la selección.", indent=True)

    # --- Step Logic ---

    def add_layer_to_project(self, layer):
        """
        Adds a layer to the project, ensuring it is placed below the LOG layer if it exists.
        """
        project = QgsProject.instance()
        root = project.layerTreeRoot()
        
        # Check if LOG layer exists
        log_layer_node = None
        for child in root.children():
            if child.name() == "LOG":
                log_layer_node = child
                break
        
        project.addMapLayer(layer, False) # Add to registry but not to tree yet
        
        if log_layer_node:
            # Insert below LOG layer
            # We need the index of the LOG node
            idx = root.children().index(log_layer_node)
            root.insertLayer(idx + 1, layer)
        else:
            # Add to top if LOG doesn't exist
            root.insertLayer(0, layer)
            
        return layer

    def step_load_logic(self):
        start_time = time.time()
        layer = self.iface.activeLayer()
        if not layer: raise ValueError("Seleccione capa.")
        
        source_source = layer.source()
        file_path = source_source.split("|")[0]
        if not os.path.exists(file_path):
             file_path = os.path.join(os.path.expanduser("~"), "temp.dxf")
        dir_name = os.path.dirname(file_path)
        
        # Capture DXF name for HTML summary
        self.dxf_name = os.path.basename(file_path)
        
        i = 1
        while True:
            folder_name = f"ValGIS_Output_{i:03d}"
            full_path = os.path.join(dir_name, folder_name)
            if not os.path.exists(full_path):
                os.makedirs(full_path)
                self.output_dir = full_path
                break
            i += 1
        
        self.log(f"Directorio de salida: {self.output_dir}", indent=True)

        step = StepLoad()
        # Step 1: Use structured naming convention
        filename = get_step_filename(1)
        self.working_layer, errors = step.run(layer, self.output_dir, filename=filename)
        
        # Create HTML summary report
        create_summary_html(self.output_dir, self.dxf_name)
        self.log(f"Resumen HTML creado: RESUMEN_PROCESO.html", indent=True)
        
        # Create LOG layer FIRST so it's at the top
        self.log_helper.create_log_layer(self.output_dir, self.working_layer.crs())
        if self.log_helper.get_layer():
            self.created_layers.append(self.log_helper.get_layer().id())
            self.log("Capa LOG creada.", indent=True)
            
        # Now add the working layer (it will go below LOG)
        self.add_layer_to_project(self.working_layer)
        self.created_layers.append(self.working_layer.id()) # Track layer
            
        self.log("Capa cargada.", indent=True)
        
        # Update HTML summary with step 1 completion
        feature_count = self.working_layer.featureCount()
        duration = time.time() - start_time
        update_step_status(
            self.output_dir,
            step_number=1,
            status='completed',
            features=feature_count,
            time_seconds=duration,
            errors=len(errors),
            dxf_name=self.dxf_name
        )
        
        # Report any geometries that were filtered during DXF->SHP conversion
        if errors:
            return self.handle_errors(errors)
        
        return True

    def step_simplify_logic_3(self):
        # Post-Split simplification: Use Flecha (Sagitta) value from UI
        filename = get_step_filename(12)
        return self._run_simplify(filename)

    def _run_simplify(self, filename, override_tol=None):
        start_time = time.time()
        if override_tol is not None:
            tol = override_tol
        else:
            tol = self.sbSagitta.value()
            
        step = StepSimplify()
        self.working_layer = step.run(self.working_layer, tol, self.output_dir, filename=filename)
        self.add_layer_to_project(self.working_layer)
        self.created_layers.append(self.working_layer.id()) # Track layer
        
        # Ensure ESTADO field exists and is populated
        if self.working_layer.fields().indexOf('ESTADO') == -1:
            self.log("Campo ESTADO no encontrado en capa simplificada, añadiendo...", indent=True)
            self.add_state_field()
        
        # Apply group styles to the simplified layer
        self.apply_group_styles()
        
        # Update HTML summary (Step 12 is simplification)
        duration = time.time() - start_time
        update_step_status(
            self.output_dir,
            step_number=12,
            status='completed',
            features=self.working_layer.featureCount(),
            time_seconds=duration,
            errors=0,
            dxf_name=self.dxf_name
        )
        
        self.log(f"Simplificación completada ({filename}).", indent=True)
        return True

    def auto_fix_enabled(self):
        """Check if auto-fix checkbox is enabled."""
        return self.chkAutoFix.isChecked()

    def step_detect_shorts_logic(self):
        min_len = self.sbMinLength.value()
        tol = self.sbTolerance.value()
        step = StepDetectShorts()
        
        if self.auto_fix_enabled():
            # Auto mode: fix everything automatically
            errors, fixed_count = step.run(self.working_layer, min_len, tol, callback=self.progress_callback, log_helper=self.log_helper)
            
            if fixed_count > 0:
                self.log(f"Se eliminaron automáticamente {fixed_count} objetos cortos.", indent=True)
                self.changes_made_in_loop = True
            
            # In auto mode, only stop if there are unfixable errors
            # If all were fixed, continue automatically
            return self.handle_errors(errors)
        else:
            # Manual mode: detect all without auto-fixing and stop for user correction
            errors = []
            for feature in self.working_layer.getFeatures():
                geom = feature.geometry()
                length = geom.length()
                
                if length < min_len:
                    errors.append({
                        'id': feature.id(),
                        'msg': f"Objeto corto (Long: {length:.4f})",
                        'type': 'short_feature',
                        'point': geom.centroid().asPoint()
                    })
            
            return self.handle_errors(errors)

    def step_normalize_coordinates_logic(self):
        """Normalize coordinates to 5 decimal places"""
        start_time = time.time()
        step = StepNormalizeCoordinates()
        
        # Run normalization
        count = step.run(self.working_layer, precision=5, log_callback=lambda m: self.log(m, indent=True), log_helper=self.log_helper)
        
        # Save
        filename = get_step_filename(3)
        output_path = os.path.join(self.output_dir, filename)
        from .helpers.layer_utils import clean_and_save_layer
        self.working_layer, _ = clean_and_save_layer(self.working_layer, output_path)
        
        self.add_layer_to_project(self.working_layer)
        self.created_layers.append(self.working_layer.id())
        
        # Update HTML summary
        duration = time.time() - start_time
        update_step_status(
            self.output_dir,
            step_number=3,
            status='completed',
            features=self.working_layer.featureCount(),
            time_seconds=duration,
            errors=0,
            dxf_name=self.dxf_name
        )
        
        self.log(f"Normalización: {count} geometrías ajustadas.", indent=True)
        return True

    def step_detect_duplicates_logic(self):
        start_time = time.time()
        step = StepDetectDuplicates()
        
        if self.auto_fix_enabled():
            # Auto mode: fix everything automatically
            errors, fixed_count = step.run(self.working_layer, callback=self.progress_callback, log_helper=self.log_helper)
            
            if fixed_count > 0:
                self.log(f"Se eliminaron automáticamente {fixed_count} geometrías duplicadas.", indent=True)
                self.changes_made_in_loop = True
                
                # Save intermediate file if changes were made
                filename = get_step_filename(4)
                output_path = os.path.join(self.output_dir, filename)
                from .helpers.layer_utils import clean_and_save_layer
                self.working_layer, _ = clean_and_save_layer(self.working_layer, output_path)
                
                self.add_layer_to_project(self.working_layer)
                self.created_layers.append(self.working_layer.id())
                
                # Update HTML summary
                duration = time.time() - start_time
                update_step_status(
                    self.output_dir,
                    step_number=4,
                    status='completed',
                    features=self.working_layer.featureCount(),
                    time_seconds=duration,
                    errors=0,
                    dxf_name=self.dxf_name
                )
            
            # In auto mode, only stop if there are unfixable errors
            return self.handle_errors(errors)
        else:
            # Manual mode: detect without deleting and stop for user correction
            errors = []
            geoms_map = {}
            
            for feature in self.working_layer.getFeatures():
                geom = feature.geometry()
                wkt = geom.asWkt()
                
                if wkt not in geoms_map:
                    geoms_map[wkt] = []
                geoms_map[wkt].append(feature.id())
            
            for wkt, ids in geoms_map.items():
                count = len(ids)
                if count > 1:
                    for fid in ids[1:]:
                        feat = self.working_layer.getFeature(fid)
                        errors.append({
                            'id': fid,
                            'msg': f"Geometría duplicada (Total: {count} copias)",
                            'type': 'duplicate',
                            'point': feat.geometry().centroid().asPoint()
                        })
            
            return self.handle_errors(errors)

    def step_fix_geometries_logic(self):
        """Repair invalid geometries from DXF import"""
        start_time = time.time()
        import processing
        
        # 1. Pre-cleaning: Remove short segments
        # Use "Flecha" (Sagitta) parameter as tolerance, or default to micro-tolerance
        tol = self.sbSagitta.value()
        if tol <= 0:
            tol = 1e-6
            
        to_delete = []
        total_count = self.working_layer.featureCount()
        
        for feature in self.working_layer.getFeatures():
            if feature.geometry().length() < tol:
                to_delete.append(feature.id())
                
        if to_delete:
            self.working_layer.startEditing()
            self.working_layer.deleteFeatures(to_delete)
            self.working_layer.commitChanges()
            self.log(f"Pre-limpieza: Eliminados {len(to_delete)} elementos menores a {tol:.6f}", indent=True)
            
        # 2. Fix geometries
        try:
            fixed = processing.run("native:fixgeometries", {
                'INPUT': self.working_layer,
                'OUTPUT': 'memory:'
            })['OUTPUT']
            
            # Save fixed layer
            filename = get_step_filename(2)
            output_path = os.path.join(self.output_dir, filename)
            from .helpers.layer_utils import clean_and_save_layer
            self.working_layer, _ = clean_and_save_layer(fixed, output_path)
            
            self.add_layer_to_project(self.working_layer)
            self.created_layers.append(self.working_layer.id())
            
            # Update HTML summary
            duration = time.time() - start_time
            update_step_status(
                self.output_dir,
                step_number=2,
                status='completed',
                features=self.working_layer.featureCount(),
                time_seconds=duration,
                errors=0,
                dxf_name=self.dxf_name
            )
            
            self.log("Geometrías reparadas.", indent=True)
            return True
        except Exception as e:
            self.log(f"Error al reparar geometrías: {e}", indent=True)
            return True  # Continue anyway
    def step_smart_snap_logic(self):
        """Smart snap: finds intersection points for near-touching lines"""
        start_time = time.time()
        from .steps.step_smart_snap import StepSmartSnap
        tol = self.sbTolerance.value()
        angle_tol = self.sbAngleTolerance.value()
        step = StepSmartSnap()
        
        # Find Layer field
        layer_field = None
        for field in self.working_layer.fields():
            if field.name().lower() == 'layer':
                layer_field = field.name()
                break
        
        # Run smart snap with intersection calculation
        snapped_count = step.run(self.working_layer, tol, layer_field, angle_tol, lambda m: self.log(m, indent=True), log_helper=self.log_helper)
        
        # Save
        filename = get_step_filename(5)
        output_path = os.path.join(self.output_dir, filename)
        from .helpers.layer_utils import clean_and_save_layer
        self.working_layer, _ = clean_and_save_layer(self.working_layer, output_path)
        
        self.add_layer_to_project(self.working_layer)
        self.created_layers.append(self.working_layer.id())
        
        # Update HTML summary
        duration = time.time() - start_time
        update_step_status(
            self.output_dir,
            step_number=5,
            status='completed',
            features=self.working_layer.featureCount(),
            time_seconds=duration,
            errors=0,
            dxf_name=self.dxf_name
        )
        
        self.log(f"Snap inteligente: {snapped_count} ajustes.", indent=True)
        return True

    def step_join_collinear_logic(self):
        """First pass of join collinear"""
        start_time = time.time()
        tol = self.sbTolerance.value()
        from .steps.step_join_collinear import StepJoinCollinear
        step = StepJoinCollinear()
        angle_tol = self.sbAngleTolerance.value()
        
        filename = get_step_filename(6)
        self.working_layer = step.run(
            self.working_layer, 
            self.output_dir, 
            filename=filename,
            tolerance=tol,
            angle_tolerance=angle_tol,
            skip_snap=True,  # Skip internal snap - Smart Snap already executed
            log_callback=lambda m: self.log(m, indent=True),
            log_helper=self.log_helper
        )
        self.add_layer_to_project(self.working_layer)
        self.created_layers.append(self.working_layer.id())
        
        # Update HTML summary
        duration = time.time() - start_time
        update_step_status(
            self.output_dir,
            step_number=6,
            status='completed',
            features=self.working_layer.featureCount(),
            time_seconds=duration,
            errors=0,
            dxf_name=self.dxf_name
        )
        
        self.log("Unión de colineales completada (sin snap previo).", indent=True)
        return True

    def step_join_collinear_2_logic(self):
        """Second pass of join collinear after snap"""
        start_time = time.time()
        tol = self.sbTolerance.value()
        from .steps.step_join_collinear import StepJoinCollinear
        step = StepJoinCollinear()
        angle_tol = self.sbAngleTolerance.value()
        
        filename = get_step_filename(7)
        self.working_layer = step.run(
            self.working_layer, 
            self.output_dir, 
            filename=filename,
            tolerance=tol,
            angle_tolerance=angle_tol,
            skip_snap=True,  # Skip internal snap - Smart Snap already executed
            log_callback=lambda m: self.log(m, indent=True),
            log_helper=self.log_helper
        )
        self.add_layer_to_project(self.working_layer)
        self.created_layers.append(self.working_layer.id())
        
        # Update HTML summary
        duration = time.time() - start_time
        update_step_status(
            self.output_dir,
            step_number=7,
            status='completed',
            features=self.working_layer.featureCount(),
            time_seconds=duration,
            errors=0,
            dxf_name=self.dxf_name
        )
        
        self.log("Re-unión completada (sin snap previo).", indent=True)
        return True

    def step_split_intersections_logic(self):
        start_time = time.time()
        from .steps.step_split_intersections import StepSplitIntersections
        step = StepSplitIntersections()
        
        # Get groups
        recintos_names = [self.listRecintos.item(i).text().split(" [")[0] for i in range(self.listRecintos.count())]
        clases_names = [self.listClases.item(i).text().split(" [")[0] for i in range(self.listClases.count())]
        
        filename = get_step_filename(8)
        self.working_layer = step.run(
            self.working_layer, 
            self.output_dir, 
            filename=filename, 
            log_callback=lambda m: self.log(m, indent=True),
            log_helper=self.log_helper,
            recintos_layers=recintos_names,
            clases_layers=clases_names
        )
        self.add_layer_to_project(self.working_layer)
        self.created_layers.append(self.working_layer.id()) # Track layer
        
        # Update HTML summary
        duration = time.time() - start_time
        update_step_status(
            self.output_dir,
            step_number=8,
            status='completed',
            features=self.working_layer.featureCount(),
            time_seconds=duration,
            errors=0,
            dxf_name=self.dxf_name
        )
        
        self.log("Intersecciones cortadas.", indent=True)
        return True

    def step_advanced_shorts_logic(self):
        min_len = self.sbMinLength.value()
        step = StepAdvancedShorts()
        
        if self.auto_fix_enabled():
            errors, fixed_count = step.run(self.working_layer, min_len, callback=self.progress_callback, log_helper=self.log_helper)
            
            if fixed_count > 0:
                self.log(f"Se corrigieron automáticamente {fixed_count} segmentos cortos.", indent=True)
                self.changes_made_in_loop = True
                
            return self.handle_errors(errors)
        else:
            # Manual mode: detect without fixing
            errors = []
            for feature in self.working_layer.getFeatures():
                geom = feature.geometry()
                if geom.length() < min_len:
                    errors.append({
                        'id': feature.id(),
                        'msg': "Objeto corto (< min_length)",
                        'point': geom.centroid().asPoint(),
                        'type': 'short_feature'
                    })
                    continue
                
                # Check segments
                if geom.isMultipart():
                    parts = geom.asMultiPolyline()
                else:
                    parts = [geom.asPolyline()]
                
                for part in parts:
                    if len(part) < 2: continue
                    
                    for i in range(len(part) - 1):
                        p1 = part[i]
                        p2 = part[i+1]
                        dist = p1.distance(p2)
                        
        tol = self.sbSagitta.value()
        if tol <= 0:
            tol = 1e-6
            
        to_delete = []
        
        for feature in self.working_layer.getFeatures():
            if feature.geometry().length() < tol:
                to_delete.append(feature.id())
                
        if to_delete:
            self.working_layer.startEditing()
            self.working_layer.deleteFeatures(to_delete)
            self.working_layer.commitChanges()
            self.log(f"Pre-limpieza antes de simplificar: Eliminados {len(to_delete)} elementos menores a {tol:.6f}", indent=True)
        
        # 2. Simplify (if there's a simplify step to run)
        # For now, just log that simplification would happen here
        self.log("Simplificación completada.", indent=True)
        return True

    def step_check_validity_logic(self):
        start_time = time.time()
        step = StepCheckValidity()
        errors = step.run(self.working_layer)
        
        # Update HTML summary
        duration = time.time() - start_time
        update_step_status(
            self.output_dir,
            step_number=13,
            status='completed',
            features=self.working_layer.featureCount(),
            time_seconds=duration,
            errors=len(errors),
            dxf_name=self.dxf_name
        )
        
        return self.handle_errors(errors)




    def step_open_enclosures_logic(self):
        step = StepOpenEnclosures()
        errors = step.run(self.working_layer)
        return self.handle_errors(errors)

    def step_verify_enclosures_logic(self):
        """Verify that all lines form closed areas before polygonization"""
        start_time = time.time()
        from .steps.step_verify_enclosures import StepVerifyEnclosures
        step = StepVerifyEnclosures()
        
        # Use snap tolerance for dangle correction
        tol = self.sbTolerance.value()
        
        # Apply group styles for visualization
        self.apply_group_styles()
        
        # Get groups
        recintos_names = [self.listRecintos.item(i).text().split(" [")[0] for i in range(self.listRecintos.count())]
        clases_names = [self.listClases.item(i).text().split(" [")[0] for i in range(self.listClases.count())]
        
        all_errors = []
        
        # Verify Recintos (R + Common)
        if recintos_names:
            self.log("Verificando áreas cerradas en grupo RECINTOS...", indent=True)
            quoted_recintos = [f"'{n}'" for n in recintos_names]
            expr = f"\"Layer\" IN ({','.join(quoted_recintos)})"
            self.working_layer.selectByExpression(expr)
            
            if self.working_layer.selectedFeatureCount() > 0:
                errors_rec = step.run(
                    self.working_layer,
                    tolerance=tol,
                    auto_fix=True,
                    log_helper=self.log_helper
                )
                for e in errors_rec:
                    e['msg'] = f"[RECINTOS] {e['msg']}"
                all_errors.extend(errors_rec)
                
        # Verify Clases (C + Common)
        if clases_names:
            self.log("Verificando áreas cerradas en grupo CLASES...", indent=True)
            quoted_clases = [f"'{n}'" for n in clases_names]
            expr = f"\"Layer\" IN ({','.join(quoted_clases)})"
            self.working_layer.selectByExpression(expr)
            
            if self.working_layer.selectedFeatureCount() > 0:
                errors_cla = step.run(
                    self.working_layer,
                    tolerance=tol,
                    auto_fix=True,
                    log_helper=self.log_helper
                )
                for e in errors_cla:
                    e['msg'] = f"[CLASES] {e['msg']}"
                all_errors.extend(errors_cla)
                
        self.working_layer.removeSelection()
        
        # Report critical errors (dangles)
        if all_errors:
            self.log(f"❌ Se encontraron {len(all_errors)} áreas no cerradas (dangles restantes).", indent=True)
            self.handle_errors(all_errors)
            return False  # Block progression - User must fix dangles
        
        # No errors - all areas are closed
        self.log("✓ Todas las líneas forman áreas cerradas correctamente.", indent=True)
        
        # Update HTML summary
        duration = time.time() - start_time
        update_step_status(
            self.output_dir,
            step_number=14,
            status='completed',
            features=self.working_layer.featureCount(),
            time_seconds=duration,
            errors=0,
            dxf_name=self.dxf_name
        )
        
        return True

    def step_verify_slivers_logic(self):
        """Verify slivers (small/thin polygons)"""
        start_time = time.time()
        from .steps.step_verify_slivers import StepVerifySlivers
        step = StepVerifySlivers()
        
        # Apply group styles for visualization
        self.apply_group_styles()
        
        # Get groups
        recintos_names = [self.listRecintos.item(i).text().split(" [")[0] for i in range(self.listRecintos.count())]
        clases_names = [self.listClases.item(i).text().split(" [")[0] for i in range(self.listClases.count())]
        
        all_errors = []
        
        # Verify Recintos (R + Common)
        if recintos_names:
            self.log("Verificando astillas en grupo RECINTOS...", indent=True)
            quoted_recintos = [f"'{n}'" for n in recintos_names]
            expr = f"\"Layer\" IN ({','.join(quoted_recintos)})"
            self.working_layer.selectByExpression(expr)
            
            if self.working_layer.selectedFeatureCount() > 0:
                errors_rec = step.run(self.working_layer, log_helper=self.log_helper)
                for e in errors_rec:
                    e['msg'] = f"[RECINTOS] {e['msg']}"
                all_errors.extend(errors_rec)
                
        # Verify Clases (C + Common)
        if clases_names:
            self.log("Verificando astillas en grupo CLASES...", indent=True)
            quoted_clases = [f"'{n}'" for n in clases_names]
            expr = f"\"Layer\" IN ({','.join(quoted_clases)})"
            self.working_layer.selectByExpression(expr)
            
            if self.working_layer.selectedFeatureCount() > 0:
                errors_cla = step.run(self.working_layer, log_helper=self.log_helper)
                for e in errors_cla:
                    e['msg'] = f"[CLASES] {e['msg']}"
                all_errors.extend(errors_cla)
                
        self.working_layer.removeSelection()
        
        if all_errors:
            self.log(f"⚠️ Se detectaron {len(all_errors)} posibles astillas.", indent=True)
            self.handle_errors(all_errors)
            return True # Return True to let go_next handle the confirmation
            
        self.log("✓ No se detectaron astillas.", indent=True)
        
        # Update HTML summary
        duration = time.time() - start_time
        update_step_status(
            self.output_dir,
            step_number=15,
            status='completed',
            features=self.working_layer.featureCount(),
            time_seconds=duration,
            errors=0,
            dxf_name=self.dxf_name
        )
        
        return True

    def step_generate_polygons_logic(self):
        # Clear selection to ensure all features are used for polygonization
        start_time = time.time()
        if self.working_layer:
            self.working_layer.removeSelection()
        
        # IMPORTANT: Save the lines layer before polygonization for DXF export
        self.lines_layer_for_dxf = self.working_layer
        
        # Get groups
        recintos_names = [self.listRecintos.item(i).text().split(" [")[0] for i in range(self.listRecintos.count())]
        clases_names = [self.listClases.item(i).text().split(" [")[0] for i in range(self.listClases.count())]
        
        step = StepGeneratePolygons()
        self.poly_recintos = None
        self.poly_clases = None
        
        # --- PROCESS RECINTOS ---
        self.log("Procesando grupo RECINTOS...", indent=True)
        # Select features belonging to Recintos layers
        # Assuming 'Layer' field exists. If not, we might have issues.
        # DXF import usually creates 'Layer' field.
        
        rec_list = "','".join(recintos_names)
        expr = f"\"Layer\" IN ('{rec_list}')"
        self.working_layer.selectByExpression(expr)
        
        if self.working_layer.selectedFeatureCount() > 0:
            filename_rec = "17_00_Poligonos_Recintos.shp"
            self.poly_recintos = step.run(self.working_layer, self.output_dir, filename=filename_rec, log_helper=self.log_helper, log_callback=lambda m: self.log(m, indent=True))
            if self.poly_recintos:
                self.add_layer_to_project(self.poly_recintos)
                self.created_layers.append(self.poly_recintos.id())
                self.log(f"  ✓ Polígonos Recintos: {self.poly_recintos.featureCount()}", indent=True)
        else:
            self.log("  ⚠️ No se encontraron líneas para el grupo RECINTOS.", indent=True)

        # --- PROCESS CLASES ---
        if clases_names:
            self.log("Procesando grupo CLASES...", indent=True)
            self.working_layer.removeSelection()
            cla_list = "','".join(clases_names)
            expr = f"\"Layer\" IN ('{cla_list}')"
            self.working_layer.selectByExpression(expr)
            
            if self.working_layer.selectedFeatureCount() > 0:
                filename_cla = "17_00_Poligonos_Clases.shp"
                self.poly_clases = step.run(self.working_layer, self.output_dir, filename=filename_cla, log_helper=self.log_helper, log_callback=lambda m: self.log(m, indent=True))
                if self.poly_clases:
                    self.add_layer_to_project(self.poly_clases)
                    self.created_layers.append(self.poly_clases.id())
                    self.log(f"  ✓ Polígonos Clases: {self.poly_clases.featureCount()}", indent=True)
            else:
                self.log("  ⚠️ No se encontraron líneas para el grupo CLASES.", indent=True)
        
        self.working_layer.removeSelection()
        
        # Update HTML summary
        duration = time.time() - start_time
        total_feats = (self.poly_recintos.featureCount() if self.poly_recintos else 0) + \
                      (self.poly_clases.featureCount() if self.poly_clases else 0)
                      
        update_step_status(
            self.output_dir,
            step_number=17,
            status='completed',
            features=total_feats,
            time_seconds=duration,
            errors=0,
            dxf_name=self.dxf_name
        )
        
        self.log("Generación de polígonos completada.", indent=True)
        return True

    def step_final_check_logic(self):
        step = StepFinalCheck()
        errors = step.run(self.working_layer)
        return self.handle_errors(errors)


    def step_detect_dangles_logic(self):
        """Detect and resolve dangles using smart hierarchical strategy"""
        start_time = time.time()
        from .steps.step_smart_dangle_resolver import StepSmartDangleResolver
        
        tol_snap = self.sbTolerance.value()
        tol_extension = self.sbExtensionTolerance.value()
        angle_tol = self.sbAngleTolerance.value()
        
        step = StepSmartDangleResolver()
        
        # Get groups
        recintos_names = [self.listRecintos.item(i).text().split(" [")[0] for i in range(self.listRecintos.count())]
        clases_names = [self.listClases.item(i).text().split(" [")[0] for i in range(self.listClases.count())]
        
        self.log("Ejecutando resolución inteligente de colgados...", indent=True)
        
        resolved_count = step.run(
            self.working_layer,
            tol_snap,
            tol_extension,
            angle_tol,
            lambda m: self.log(m, indent=True),
            log_helper=self.log_helper,
            recintos_layers=recintos_names,
            clases_layers=clases_names
        )
        
        # Mark that changes were made
        if sum(resolved_count.values()) - resolved_count['ERROR'] > 0:
            self.changes_made_in_loop = True
        
        # Post-cleaning: Remove very short segments created during dangle resolution
        tol = self.sbSagitta.value()
        if tol <= 0:
            tol = 1e-6
            
        to_delete = []
        
        for feature in self.working_layer.getFeatures():
            if feature.geometry().length() < tol:
                to_delete.append(feature.id())
                
        if to_delete:
            self.working_layer.startEditing()
            self.working_layer.deleteFeatures(to_delete)
            self.working_layer.commitChanges()
            self.log(f"Post-limpieza tras resolver dangles: Eliminados {len(to_delete)} elementos menores a {tol:.6f}", indent=True)
        
        # Update HTML summary
        duration = time.time() - start_time
        update_step_status(
            self.output_dir,
            step_number=9,
            status='completed',
            features=self.working_layer.featureCount(),
            time_seconds=duration,
            errors=0,
            dxf_name=self.dxf_name
        )
        
        # Continue to next step
        return True



    def step_extend_dangles_logic(self):
        """Extend dangles directionally to nearby lines"""
        start_time = time.time()
        from .steps.step_detect_dangles import StepDetectDangles
        tol = self.sbExtensionTolerance.value()
        step = StepDetectDangles()
        
        # Run in extend-only mode (dry_run=False to extend)
        errors, fixed_count = step.run(
            self.working_layer,
            tolerance=tol,
            callback=self.progress_callback,
            dry_run=False,  # Actually extend
            log_helper=self.log_helper
        )
        
        if fixed_count > 0:
            self.log(f"Extensión de dangles: {fixed_count} corregidos.", indent=True)
        
        self.log("Extensión de dangles completada.", indent=True)
        
        # Update HTML summary
        duration = time.time() - start_time
        update_step_status(
            self.output_dir,
            step_number=10,
            status='completed',
            features=self.working_layer.featureCount(),
            time_seconds=duration,
            errors=0,
            dxf_name=self.dxf_name
        )
        
        return True

    def step_split_intersections_2_logic(self):
        """Re-cut intersections after extending dangles"""
        start_time = time.time()
        from .steps.step_split_intersections import StepSplitIntersections
        step = StepSplitIntersections()
        
        # Get groups
        recintos_names = [self.listRecintos.item(i).text().split(" [")[0] for i in range(self.listRecintos.count())]
        clases_names = [self.listClases.item(i).text().split(" [")[0] for i in range(self.listClases.count())]
        
        filename = get_step_filename(11)
        self.working_layer = step.run(
            self.working_layer, 
            self.output_dir, 
            filename=filename, 
            log_callback=lambda m: self.log(m, indent=True),
            log_helper=self.log_helper,
            recintos_layers=recintos_names,
            clases_layers=clases_names
        )
        self.add_layer_to_project(self.working_layer)
        self.created_layers.append(self.working_layer.id())
        
        # Update HTML summary
        duration = time.time() - start_time
        update_step_status(
            self.output_dir,
            step_number=11,
            status='completed',
            features=self.working_layer.featureCount(),
            time_seconds=duration,
            errors=0,
            dxf_name=self.dxf_name
        )
        
        self.log("Re-corte completado.", indent=True)
        
        # Update HTML summary
        update_step_status(
            self.output_dir,
            step_number=11,
            status='completed',
            features=self.working_layer.featureCount(),
            time_seconds=0,
            errors=0,
            dxf_name=self.dxf_name
        )
        
        return True



    def step_analyze_changes_logic(self):
        """Analyze geometric changes between original and current layer"""
        start_time = time.time()
        from .steps.step_analyze_changes import StepAnalyzeChanges
        from .helpers.summary_report import set_comparison_summary
        
        # STAGE 2: Confirmation
        if self.analysis_done:
            # User clicked "Next" again after seeing errors
            reply = QMessageBox.question(
                self, 
                "Confirmar Cambios", 
                "¿Das por buenos los cambios realizados respecto al original?",
                QMessageBox.Yes | QMessageBox.No, 
                QMessageBox.No
            )
            
            if reply == QMessageBox.Yes:
                self.log("Usuario aceptó los cambios. Continuando...", indent=True)
                self.analysis_done = False # Reset for future runs
                self.analysis_errors = []
                
                # Update HTML summary
                duration = time.time() - start_time
                update_step_status(
                    self.output_dir,
                    step_number=16,
                    status='completed',
                    features=self.working_layer.featureCount(),
                    time_seconds=duration,
                    errors=0,
                    dxf_name=self.dxf_name
                )
                
                return True
            else:
                self.log("Usuario rechazó los cambios. Pausando workflow.", indent=True)
                # Restore errors to table so user can review them
                if self.analysis_errors:
                    self.handle_errors(self.analysis_errors)
                return False

        # STAGE 1: Analysis
        step = StepAnalyzeChanges()
        
        # Run analysis
        errors = step.run(
            self.working_layer,
            self.output_dir,
            geometry_tolerance=0.001,  # 1mm tolerance for comparison
            log_callback=lambda m: self.log(m, indent=True),
            log_helper=self.log_helper
        )
        
        # Generate comparison text for HTML report
        if not errors:
            comparison_text = "No se detectaron cambios significativos respecto a la geometría original (Tolerancia: 1mm)."
        else:
            comparison_text = f"Se detectaron {len(errors)} cambios significativos respecto al original (Tolerancia: 1mm). "
            # Add breakdown if possible, for now just count
            
        set_comparison_summary(self.output_dir, comparison_text, self.dxf_name)
        
        # If there are substantial changes, show them in error table and PAUSE
        if errors and len(errors) > 0:
            self.log(f"Se encontraron {len(errors)} cambios sustanciales.", indent=True)
            self.log("Pausando para revisión. Presione 'Siguiente' nuevamente para confirmar y continuar.", indent=True)
            
            # Save errors for restoration if needed
            self.analysis_errors = errors
            
            # Populate error table
            self.handle_errors(errors)
            
            # Set flag so next click triggers confirmation
            self.analysis_done = True
            
            return False # Pause workflow
        else:
            # No substantial changes, continue automatically
            
            # Update HTML summary (only if no pause)
            duration = time.time() - start_time
            update_step_status(
                self.output_dir,
                step_number=16,
                status='completed',
                features=self.working_layer.featureCount(),
                time_seconds=duration,
                errors=0,
                dxf_name=self.dxf_name
            )
            
            return True



    def step_validate_polygons_logic(self):
        """Validate polygon quality: overlaps, gaps, slivers, invalid geometries"""
        start_time = time.time()
        from .steps.step_validate_polygons import StepValidatePolygons
        
        step = StepValidatePolygons()
        gap_tolerance = self.sbTolerance.value()
        
        all_errors = []
        
        # Validate Recintos
        if self.poly_recintos:
            self.log("Validando Polígonos RECINTOS...", indent=True)
            errors_rec = step.run(
                self.poly_recintos,
                min_area=0.01,
                min_ratio=0.005,
                gap_tolerance=gap_tolerance,
                callback=lambda m: self.log(f"  [RECINTOS] {m}", indent=True),
                log_helper=self.log_helper
            )
            # Tag errors
            for e in errors_rec:
                e['msg'] = f"[RECINTOS] {e['msg']}"
            all_errors.extend(errors_rec)
            
        # Validate Clases
        if self.poly_clases:
            self.log("Validando Polígonos CLASES...", indent=True)
            errors_cla = step.run(
                self.poly_clases,
                min_area=0.01,
                min_ratio=0.005,
                gap_tolerance=gap_tolerance,
                callback=lambda m: self.log(f"  [CLASES] {m}", indent=True),
                log_helper=self.log_helper
            )
            # Tag errors
            for e in errors_cla:
                e['msg'] = f"[CLASES] {e['msg']}"
            all_errors.extend(errors_cla)
            
        # Update HTML summary
        duration = time.time() - start_time
        total_feats = (self.poly_recintos.featureCount() if self.poly_recintos else 0) + \
                      (self.poly_clases.featureCount() if self.poly_clases else 0)
                      
        update_step_status(
            self.output_dir,
            step_number=18,
            status='completed',
            features=total_feats,
            time_seconds=duration,
            errors=len(all_errors),
            dxf_name=self.dxf_name
        )
        
        if all_errors:
            self.log(f"⚠️ Se encontraron {len(all_errors)} problemas de calidad en total.", indent=True)
            self.handle_errors(all_errors)
            return True 
        else:
            self.log("✓ Todos los polígonos son válidos y de buena calidad.", indent=True)
            return True

    def step_verify_polygon_topology_logic(self):
        """Paso 18.5: Verificar Topología de Polígonos Cerrados"""
        # Buscar capas de polígonos cerrados
        rec_layer = None
        cla_layer = None
        
        # Las capas generadas tienen nombres específicos
        # Buscamos por ID en created_layers o por nombre en el proyecto
        for layer_id in self.created_layers:
            layer = QgsProject.instance().mapLayer(layer_id)
            if layer:
                if "17_00_Poligonos_Recintos" in layer.name():
                    rec_layer = layer
                elif "17_00_Poligonos_Clases" in layer.name():
                    cla_layer = layer
        
        if not rec_layer and not cla_layer:
            self.log("ADVERTENCIA: No se encontraron capas de polígonos cerrados para verificar.")
            return True # Continuar sin error
        
        verifier = StepVerifyPolygonTopology()
        result = verifier.run(
            rec_layer=rec_layer,
            cla_layer=cla_layer,
            output_dir=self.output_dir,
            log_helper=self.log_helper,
            log_callback=self.log
        )
        
        # Guardar resultado para usar en exportación (aunque la limpieza es automática)
        self.polygon_topology_issues = result
        
        # Si el usuario canceló, detenemos el proceso
        if result['user_action'] == 'cancel':
            return False
            
        return True

    def step_export_dxf_logic(self):
        """Export final result to DXF"""
        start_time = time.time()
        
        # Confirmar con el usuario antes de proceder
        reply = QMessageBox.question(
            self, 
            "Generar DXF Final", 
            "¿Desea generar el archivo DXF final ahora?\n\nSeleccione 'Sí' para continuar o 'No' para detener el proceso y revisar los resultados.",
            QMessageBox.Yes | QMessageBox.No, 
            QMessageBox.Yes
        )
        
        if reply == QMessageBox.No:
            self.log("   ⏸️ Proceso detenido por el usuario antes de la exportación.", indent=True)
            return False

        from .steps.step_export_dxf import StepExportDXF
        
        if not self.lines_layer_for_dxf:
            self.log("ERROR: No se encontró la capa de líneas original.", indent=True)
            return False
            
        step = StepExportDXF()
        
        # Prepare polygon layers list
        polygons_input = []
        if self.poly_recintos:
            polygons_input.append({'layer': self.poly_recintos, 'dxf_layer': 'REC_POLCERRADOS'})
        if self.poly_clases:
            polygons_input.append({'layer': self.poly_clases, 'dxf_layer': 'CLA_POLCERRADOS'})
            
        dxf_path = step.run(
            self.lines_layer_for_dxf,
            polygons_input, 
            self.output_dir,
            log_callback=lambda m: self.log(m, indent=True)
        )
        
        if dxf_path:
            # Update HTML summary
            duration = time.time() - start_time
            update_step_status(
                self.output_dir,
                step_number=19,
                status='completed',
                features=0,  # DXF export doesn't have feature count
                time_seconds=duration,
                errors=0,
                dxf_name=self.dxf_name
            )
            
            QMessageBox.information(self, "Exportación Exitosa", f"Archivo generado:\n{dxf_path}")
            return True
        else:
            return False



    def check_tab_access(self, index):
        """Prevent moving to Processing tab if layers are not configured."""
        if index == 0: # Processing Tab
            if not self.validate_layers():
                self.tabWidget.setCurrentIndex(1) # Go back to Layers tab
                QMessageBox.warning(self, "Configuración Incompleta", 
                    "Debe configurar las capas en los grupos RECINTOS y CLASES antes de procesar.\n"
                    "Asegúrese de que todas las capas lineales estén asignadas.")

    def populate_layers(self):
        """Populate the source list with unique values from the 'Layer' field of the working layer."""
        self.listAllLayers.clear()
        
        # Try to use working_layer first, if not set, use active layer from QGIS
        layer_to_scan = self.working_layer
        
        if not layer_to_scan or not layer_to_scan.isValid():
            # Try to get the active layer from QGIS
            layer_to_scan = self.iface.activeLayer()
            if not layer_to_scan or not layer_to_scan.isValid():
                self.log("Advertencia: No hay capa activa. Seleccione una capa DXF en QGIS.", indent=True)
                QMessageBox.warning(self, "Sin capa", 
                    "Por favor, seleccione una capa DXF en QGIS antes de actualizar las capas.")
                return

        # Check if 'Layer' field exists
        layer_idx = layer_to_scan.fields().indexOf('Layer')
        if layer_idx == -1:
            # Try uppercase
            layer_idx = layer_to_scan.fields().indexOf('LAYER')
            
        if layer_idx == -1:
            self.log("Advertencia: No se encontró el campo 'Layer' en la capa seleccionada.", indent=True)
            QMessageBox.warning(self, "Campo no encontrado", 
                "La capa seleccionada no tiene un campo 'Layer'. Asegúrese de seleccionar una capa DXF.")
            return

        # Get unique layer names that have LineString geometry
        # We need to check each feature's geometry type
        from qgis.core import QgsWkbTypes
        
        layer_geom_types = {}  # Track geometry types per layer
        
        for feature in layer_to_scan.getFeatures():
            layer_name = feature.attribute(layer_idx)
            if not layer_name:
                continue
            layer_name = str(layer_name)
            
            geom = feature.geometry()
            if geom and not geom.isEmpty():
                geom_type = geom.wkbType()
                # Check if it's a LineString type (any variant)
                if QgsWkbTypes.geometryType(geom_type) == QgsWkbTypes.LineGeometry:
                    if layer_name not in layer_geom_types:
                        layer_geom_types[layer_name] = True
        
        # Sort and populate only layers with linear features
        for layer_name in sorted(layer_geom_types.keys()):
            item = QListWidgetItem(layer_name)
            # Use layer name as ID since we are dealing with logical layers
            item.setData(Qt.UserRole, layer_name) 
            self.listAllLayers.addItem(item)
        
        self.log(f"Capas lineales encontradas: {len(layer_geom_types)}", indent=True)
        self.update_source_list_visuals()
        
        # Validate layer names for problematic characters
        import re
        problematic_layers = []
        valid_pattern = re.compile(r'^[a-zA-Z0-9_]+$')
        
        for layer_name in sorted(layer_geom_types.keys()):
            if not valid_pattern.match(layer_name):
                problematic_layers.append(layer_name)
        
        if problematic_layers:
            problem_list = "\n".join([f"  - {name}" for name in problematic_layers[:10]])
            if len(problematic_layers) > 10:
                problem_list += f"\n  ... y {len(problematic_layers) - 10} más"
            
            QMessageBox.warning(self, "Nombres de capas no normalizados",
                f"⚠️ Se detectaron {len(problematic_layers)} capas con nombres no normalizados.\n\n"
                f"Los nombres contienen caracteres especiales (espacios, tildes, ñ, comillas, etc.)\n"
                f"que pueden causar errores o resultados inesperados.\n\n"
                f"Capas problemáticas:\n{problem_list}\n\n"
                f"Se recomienda renombrar las capas usando solo:\n"
                f"  • Letras (a-z, A-Z)\n  • Números (0-9)\n  • Guión bajo (_)\n\n"
                f"¿Desea continuar de todos modos?")
            
            self.log(f"⚠️ ADVERTENCIA: {len(problematic_layers)} capas con nombres no normalizados.", indent=True)
            for name in problematic_layers:
                self.log(f"    - {name}", indent=True)

    def update_source_list_visuals(self):
        """Update colors and tags in source list based on assignment."""
        recintos_ids = [self.listRecintos.item(i).data(Qt.UserRole) for i in range(self.listRecintos.count())]
        clases_ids = [self.listClases.item(i).data(Qt.UserRole) for i in range(self.listClases.count())]
        
        for i in range(self.listAllLayers.count()):
            item = self.listAllLayers.item(i)
            lid = item.data(Qt.UserRole)
            name = item.text().split(" [")[0] # Reset name
            
            in_recintos = lid in recintos_ids
            in_clases = lid in clases_ids
            
            tags = []
            if in_recintos: tags.append("R")
            if in_clases: tags.append("C")
            
            if tags:
                item.setText(f"{name} [{','.join(tags)}]")
            else:
                item.setText(name)
                
            # Color logic
            if in_recintos and in_clases:
                item.setForeground(QColor("blue"))
            elif in_recintos or in_clases:
                item.setForeground(QColor("green"))
            else:
                item.setForeground(QColor("black"))

    def add_layer_to_target(self, item):
        """Add double-clicked layer to the selected target group."""
        layer_id = item.data(Qt.UserRole)
        layer_name = item.text().split(" [")[0]
        
        if self.optRecintos.isChecked():
            self.add_layer_to_group(layer_id, layer_name, self.listRecintos)
        elif self.optClases.isChecked():
            self.add_layer_to_group(layer_id, layer_name, self.listClases)
            
        self.update_source_list_visuals()
        self.validate_layers()

    def add_layer_to_group(self, layer_id, layer_name, list_widget):
        # Check if already exists
        for i in range(list_widget.count()):
            if list_widget.item(i).data(Qt.UserRole) == layer_id:
                return # Already added
        
        item = QListWidgetItem(layer_name)
        item.setData(Qt.UserRole, layer_id)
        list_widget.addItem(item)

    def remove_layer_from_recintos(self, item):
        self.listRecintos.takeItem(self.listRecintos.row(item))
        self.update_source_list_visuals()
        self.validate_layers()

    def remove_layer_from_clases(self, item):
        self.listClases.takeItem(self.listClases.row(item))
        self.update_source_list_visuals()
        self.validate_layers()

    def add_all_to_recintos(self):
        for i in range(self.listAllLayers.count()):
            item = self.listAllLayers.item(i)
            self.add_layer_to_group(item.data(Qt.UserRole), item.text().split(" [")[0], self.listRecintos)
        self.update_source_list_visuals()
        self.validate_layers()

    def add_all_to_clases(self):
        for i in range(self.listAllLayers.count()):
            item = self.listAllLayers.item(i)
            self.add_layer_to_group(item.data(Qt.UserRole), item.text().split(" [")[0], self.listClases)
        self.update_source_list_visuals()
        self.validate_layers()

    def clear_recintos(self):
        self.listRecintos.clear()
        self.update_source_list_visuals()
        self.validate_layers()

    def clear_clases(self):
        self.listClases.clear()
        self.update_source_list_visuals()
        self.validate_layers()
        
    def move_all_to_target(self):
        if self.optRecintos.isChecked():
            self.add_all_to_recintos()
        elif self.optClases.isChecked():
            self.add_all_to_clases()

    def validate_layers(self):
        """
        Validate that:
        1. All layers in source are assigned to at least one group.
        2. Recintos group is not empty.
        3. Update 'Missing in Clases' list.
        """
        recintos_ids = {self.listRecintos.item(i).data(Qt.UserRole) for i in range(self.listRecintos.count())}
        clases_ids = {self.listClases.item(i).data(Qt.UserRole) for i in range(self.listClases.count())}
        all_ids = {self.listAllLayers.item(i).data(Qt.UserRole) for i in range(self.listAllLayers.count())}
        
        # Check coverage
        assigned_ids = recintos_ids.union(clases_ids)
        unassigned = all_ids - assigned_ids
        
        valid = True
        msg = []
        
        if not recintos_ids:
            valid = False
            msg.append("El grupo RECINTOS no puede estar vacío.")
            
        if unassigned:
            valid = False
            msg.append(f"Hay {len(unassigned)} capas sin asignar.")
            
            
        return valid


    def import_config(self):
        """
        Import layer configuration from RECINTOS.las and CLASES.las in the DXF directory.
        Format: Code 8 followed by layer name on next line.
        """
        # Try working_layer first, then active layer
        layer = self.working_layer if self.working_layer else self.iface.activeLayer()
        
        if not layer or not layer.isValid():
            QMessageBox.warning(self, "Error", "No hay ningún DXF cargado. Por favor, cargue un archivo DXF en QGIS primero.")
            return

        source_source = layer.source()
        file_path = source_source.split("|")[0]
        if not os.path.exists(file_path):
             # Fallback if source is memory or weird
             dir_name = self.output_dir if self.output_dir else os.path.expanduser("~")
        else:
            dir_name = os.path.dirname(file_path)
            
        recintos_path = os.path.join(dir_name, "RECINTOS.las")
        clases_path = os.path.join(dir_name, "CLASES.las")
        
        if not os.path.exists(recintos_path) and not os.path.exists(clases_path):
            QMessageBox.warning(self, "Archivos no encontrados", 
                f"No se encontraron archivos de configuración (RECINTOS.las / CLASES.las) en:\n{dir_name}")
            return
            
        def parse_las(path):
            """
            Parse .las file and return only EDITABLE layers.
            A layer is editable if FLAGS (code 90) has:
            - Bit 0 (1) = 0 → ON (visible)
            - Bit 1 (2) = 0 → THAWED (not frozen)
            - Bit 2 (4) = 0 → UNLOCKED
            """
            layers = []
            if not os.path.exists(path):
                return layers
            try:
                with open(path, 'r', encoding='utf-8', errors='ignore') as f:
                    lines = f.readlines()
                    
                i = 0
                while i < len(lines):
                    line = lines[i].strip()
                    
                    # Look for layer name (code 8)
                    if line == '8':
                        if i + 1 < len(lines):
                            layer_name = lines[i + 1].strip()
                            
                            # Now look for FLAGS (code 90) after this layer name
                            # It should be within the next few lines
                            flags = None
                            for j in range(i + 2, min(i + 20, len(lines))):
                                if lines[j].strip() == '90':
                                    if j + 1 < len(lines):
                                        try:
                                            flags = int(lines[j + 1].strip())
                                        except ValueError:
                                            pass
                                        break
                                # Stop if we hit the next layer (code 8 again)
                                if lines[j].strip() == '8':
                                    break
                            
                            # Check if layer is editable
                            if flags is not None:
                                is_on = (flags & 1) == 0
                                is_thawed = (flags & 2) == 0
                                is_unlocked = (flags & 4) == 0
                                
                                if is_on and is_thawed and is_unlocked:
                                    if layer_name:
                                        layers.append(layer_name)
                                        self.log(f"    {layer_name} — FLAGS={flags} (editable)", indent=True)
                                else:
                                    self.log(f"    {layer_name} — FLAGS={flags} (ignorada: {'OFF' if not is_on else ''}{'FROZEN' if not is_thawed else ''}{'LOCKED' if not is_unlocked else ''})", indent=True)
                            else:
                                # No FLAGS found, skip this layer
                                self.log(f"    {layer_name} — sin FLAGS (ignorada)", indent=True)
                    
                    i += 1
                    
            except Exception as e:
                self.log(f"Error leyendo {os.path.basename(path)}: {e}", indent=True)
            return layers

        # Clear current lists
        self.clear_recintos()
        self.clear_clases()
        
        # Parse files
        recintos_layers = parse_las(recintos_path)
        clases_layers = parse_las(clases_path)
        
        # Special case: if only CLASES.las exists, load it into RECINTOS
        if not os.path.exists(recintos_path) and os.path.exists(clases_path):
            self.log("  Solo se encontró CLASES.las, cargando en grupo RECINTOS...", indent=True)
            recintos_layers = clases_layers
            clases_layers = []
        
        self.log(f"Importando configuración desde {dir_name}...", indent=True)
        if recintos_layers:
            self.log(f"  RECINTOS: {len(recintos_layers)} capas encontradas.", indent=True)
        if clases_layers:
            self.log(f"  CLASES: {len(clases_layers)} capas encontradas.", indent=True)
            
        # Get available layers in listAllLayers
        available_layers = set()
        for i in range(self.listAllLayers.count()):
            item = self.listAllLayers.item(i)
            available_layers.add(item.data(Qt.UserRole))
            
        # Add to lists
        missing_rec = []
        for layer in recintos_layers:
            if layer in available_layers:
                self.add_layer_to_group(layer, layer, self.listRecintos)
            else:
                missing_rec.append(layer)
                
        missing_cla = []
        for layer in clases_layers:
            if layer in available_layers:
                self.add_layer_to_group(layer, layer, self.listClases)
            else:
                missing_cla.append(layer)
                
        if missing_rec:
            self.log(f"  Advertencia: {len(missing_rec)} capas de RECINTOS no existen en el DXF actual.", indent=True)
            if len(missing_rec) < 10:
                self.log(f"    Faltan: {', '.join(missing_rec)}", indent=True)
                
        if missing_cla:
            self.log(f"  Advertencia: {len(missing_cla)} capas de CLASES no existen en el DXF actual.", indent=True)
            if len(missing_cla) < 10:
                self.log(f"    Faltan: {', '.join(missing_cla)}", indent=True)
                
        self.update_source_list_visuals()
        self.validate_layers()
        self.log("Importación finalizada.")

    def apply_group_styles(self):
        """
        Apply categorized renderer to working layer:
        - Recintos Only: Blue
        - Clases Only: Red
        - Common: Magenta
        """
        if not self.working_layer or not self.working_layer.isValid():
            return
            
        from qgis.core import QgsCategorizedSymbolRenderer, QgsRendererCategory, QgsSymbol
        from qgis.PyQt.QtGui import QColor
        
        # Check if ESTADO field exists
        estado_idx = self.working_layer.fields().indexOf('ESTADO')
        
        if estado_idx != -1:
            # Use ESTADO field for categorization
            categories = []
            
            def add_category(value, color, label, width):
                symbol = QgsSymbol.defaultSymbol(self.working_layer.geometryType())
                symbol.setColor(QColor(color))
                symbol.setWidth(width)
                categories.append(QgsRendererCategory(value, symbol, label))
            
            add_category("RECINTO", "blue", "Recintos", 0.25)
            add_category("CLASE", "orange", "Clases", 0.15)
            add_category("COMUN", "black", "Común", 0.25)
            
            renderer = QgsCategorizedSymbolRenderer("ESTADO", categories)
            self.working_layer.setRenderer(renderer)
            self.working_layer.triggerRepaint()
            self.iface.layerTreeView().refreshLayerSymbology(self.working_layer.id())
        else:
            # Fallback to Layer field
            recintos_names = set([self.listRecintos.item(i).text().split(" [")[0] for i in range(self.listRecintos.count())])
            clases_names = set([self.listClases.item(i).text().split(" [")[0] for i in range(self.listClases.count())])
            
            r_only = recintos_names - clases_names
            c_only = clases_names - recintos_names
            common = recintos_names & clases_names
            
            categories = []
            
            def add_category(value, color, label, width):
                symbol = QgsSymbol.defaultSymbol(self.working_layer.geometryType())
                symbol.setColor(QColor(color))
                symbol.setWidth(width) 
                categories.append(QgsRendererCategory(value, symbol, label))
                
            for name in r_only:
                add_category(name, "blue", f"{name} (Recintos)", 0.25)
            for name in c_only:
                add_category(name, "orange", f"{name} (Clases)", 0.15)
            for name in common:
                add_category(name, "black", f"{name} (Común)", 0.25)
                
            renderer = QgsCategorizedSymbolRenderer("Layer", categories)
            self.working_layer.setRenderer(renderer)
            self.working_layer.triggerRepaint()
            self.iface.layerTreeView().refreshLayerSymbology(self.working_layer.id())

    def add_state_field(self):
        """
        Add 'ESTADO' field and populate it based on group membership:
        - Recintos Only -> 'RECINTO'
        - Clases Only -> 'CLASE'
        - Common -> 'COMUN'
        """
        if not self.working_layer or not self.working_layer.isValid():
            return

        self.log("Añadiendo campo ESTADO...", indent=True)
        
        # Add field if it doesn't exist
        from qgis.core import QgsField
        from qgis.PyQt.QtCore import QVariant
        
        if self.working_layer.fields().indexOf('ESTADO') == -1:
            self.working_layer.startEditing()
            self.working_layer.dataProvider().addAttributes([QgsField("ESTADO", QVariant.String, len=20)])
            self.working_layer.updateFields()
            self.working_layer.commitChanges()
            
        # Get groups
        recintos_names = set([self.listRecintos.item(i).text().split(" [")[0] for i in range(self.listRecintos.count())])
        clases_names = set([self.listClases.item(i).text().split(" [")[0] for i in range(self.listClases.count())])
        
        r_only = recintos_names - clases_names
        c_only = clases_names - recintos_names
        common = recintos_names & clases_names
        
        # Update features
        self.working_layer.startEditing()
        
        layer_idx = self.working_layer.fields().indexOf('Layer')
        if layer_idx == -1:
            layer_idx = self.working_layer.fields().indexOf('LAYER')
            
        estado_idx = self.working_layer.fields().indexOf('ESTADO')
        
        count = 0
        for feature in self.working_layer.getFeatures():
            layer_name = feature.attribute(layer_idx)
            if not layer_name: continue
            layer_name = str(layer_name)
            
            new_val = None
            if layer_name in common:
                new_val = "COMUN"
            elif layer_name in r_only:
                new_val = "RECINTO"
            elif layer_name in c_only:
                new_val = "CLASE"
                
            if new_val:
                self.working_layer.changeAttributeValue(feature.id(), estado_idx, new_val)
                count += 1
                
        self.working_layer.commitChanges()
        self.log(f"Campo ESTADO actualizado en {count} elementos.", indent=True)

    def open_help(self):
        """Abre el archivo de ayuda en el navegador."""
        import webbrowser
        help_path = os.path.join(os.path.dirname(__file__), 'ayuda.html')
        url = f"file:///{help_path.replace(os.sep, '/')}"
        webbrowser.open(url)