import os
import math
import uuid
from qgis.core import QgsVectorLayer, QgsVectorFileWriter, QgsCoordinateTransformContext, QgsField
from qgis.PyQt.QtCore import QVariant
from .file_utils import clean_existing_file

def clean_and_save_layer(layer, output_path, log_callback=None):
    """
    Guarda una capa a un shapefile, filtrando SOLO geometrías con coordenadas NaN/Inf.
    Asegura que un campo 'UUID' existe y está poblado para cada feature.
    
    Args:
        layer (QgsVectorLayer): La capa a guardar (puede ser capa de memoria).
        output_path (str): Ruta completa al shapefile de salida.
        log_callback (func, opcional): Función para registrar mensajes.
        
    Returns:
        tuple: (QgsVectorLayer, lista de dicts de error) - La capa resultado cargada y lista de geometrías filtradas
    """
    def log(msg):
        if log_callback: log_callback(msg)

    # No registrar operaciones de archivos temporales - solo las salidas finales son registradas por los pasos que llaman
    # log(f"Guardando capa en: {output_path}")
    clean_existing_file(output_path)
    
    # Encontrar el campo 'Layer' (insensible a mayúsculas)
    fields = layer.fields().names()
    layer_field = next((f for f in fields if f.lower() == 'layer'), None)
    
    # Verificar si el campo UUID existe en el origen
    uuid_field_idx = -1
    for i, f in enumerate(layer.fields()):
        if f.name() == 'UUID':
            uuid_field_idx = i
            break
    
    # Determinar tipo de geometría de la capa de entrada
    from qgis.core import QgsWkbTypes
    geom_type = QgsWkbTypes.displayString(layer.wkbType())
    
    # Crear una capa de memoria temporal para limpieza con el tipo de geometría correcto
    clean_layer = QgsVectorLayer(f"{geom_type}?crs={layer.crs().authid()}", "clean_temp", "memory")
    clean_layer.startEditing()
    dp = clean_layer.dataProvider()
    
    # Añadir campos existentes
    dp.addAttributes(layer.fields())
    
    # Añadir campo UUID si no existe
    if uuid_field_idx == -1:
        dp.addAttributes([QgsField("UUID", QVariant.String, len=50)])
        
    clean_layer.updateFields()
    
    # Obtener el índice del campo UUID en la NUEVA capa
    new_uuid_idx = clean_layer.fields().indexOf('UUID')
    
    valid_feats = []
    errors = []
    empty_count = 0
    corrupt_count = 0
    total_count = layer.featureCount()
    
    for feat in layer.getFeatures():
        geom = feat.geometry()
        
        # Obtener valor de Layer si el campo existe
        layer_value = feat[layer_field] if layer_field else "?"
        
        # Solo omitir geometrías verdaderamente vacías
        if not feat.isValid() or geom is None or geom.isEmpty():
            empty_count += 1
            errors.append({
                'id': feat.id(),
                'msg': f'Geometría inválida o vacía - LAYER={layer_value}',
                'type': 'invalid_geometry',
                'point': None,
                'layer_value': layer_value
            })
            continue
        
        # SOLO filtrar coordenadas NaN/Inf (datos verdaderamente corruptos)
        is_corrupt = False
        try:
            for v in geom.vertices():
                if math.isnan(v.x()) or math.isinf(v.x()) or math.isnan(v.y()) or math.isinf(v.y()):
                    is_corrupt = True
                    break
        except:
            # Si no podemos iterar vértices, considerarlo corrupto
            is_corrupt = True
        
        if is_corrupt:
            corrupt_count += 1
            # Intentar obtener un punto representativo para el error
            try:
                pt = geom.centroid().asPoint()
            except:
                pt = None
            
            errors.append({
                'id': feat.id(),
                'msg': f'Geometría corrupta en DXF (coordenadas NaN/Inf) - LAYER={layer_value}',
                'type': 'corrupt_geometry',
                'point': pt,
                'layer_value': layer_value
            })
            continue
        
        # Preparar feature para guardar
        # Si añadimos el campo UUID, necesitamos asegurar que los atributos coincidan
        attrs = feat.attributes()
        
        # SIEMPRE regenerar UUID para asegurar unicidad
        # Si el origen no tenía UUID, añadir uno nuevo
        if uuid_field_idx == -1:
            attrs.append(str(uuid.uuid4()))
        else:
            # El origen tiene campo UUID, sobrescribirlo con nuevo ID único
            attrs[uuid_field_idx] = str(uuid.uuid4())
        
        feat.setAttributes(attrs)
        valid_feats.append(feat)
        
    dp.addFeatures(valid_feats)
    clean_layer.commitChanges()
    
    if empty_count > 0:
        log(f"Info: Se omitieron {empty_count} geometrías vacías.")
    if corrupt_count > 0:
        log(f"ADVERTENCIA: Se eliminaron {corrupt_count} de {total_count} objetos con coordenadas corruptas (NaN/Inf).")
    
    # No registrar estadísticas internas - solo errores/advertencias son relevantes
    # log(f"Geometrías válidas guardadas: {len(valid_feats)} de {total_count}")
    
    # Escribir a Disco
    options = QgsVectorFileWriter.SaveVectorOptions()
    options.driverName = "ESRI Shapefile"
    options.fileEncoding = "UTF-8"
    
    error, error_msg = QgsVectorFileWriter.writeAsVectorFormatV2(
        clean_layer,
        output_path,
        QgsCoordinateTransformContext(),
        options
    )
    
    if error != QgsVectorFileWriter.NoError:
        raise Exception(f"Error al guardar Shapefile: {error_msg} (Código: {error})")
        
    # Cargar resultado
    base_name = os.path.splitext(os.path.basename(output_path))[0]
    result_layer = QgsVectorLayer(output_path, base_name, "ogr")
    
    if not result_layer.isValid():
        raise Exception("La capa resultante no es válida.")
        
    return result_layer, errors
