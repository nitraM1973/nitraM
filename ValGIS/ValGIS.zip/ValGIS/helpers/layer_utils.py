import os
import math
import uuid
from qgis.core import (
    QgsVectorLayer,
    QgsVectorFileWriter,
    QgsCoordinateTransformContext,
    QgsField,
    QgsWkbTypes,
    QgsProcessingFeedback
)
from qgis.PyQt.QtCore import QVariant
from .file_utils import clean_existing_file

def get_feedback(callback):
    """
    Crea un objeto QgsProcessingFeedback que redirige el progreso a un callback.
    Util para algoritmos de 'processing.run()' que bloquean la UI.
    """
    class PluginFeedback(QgsProcessingFeedback):
        def __init__(self, c):
            super().__init__()
            self.c = c
        def setProgress(self, progress):
            if self.c:
                self.c(int(progress), 100)
    return PluginFeedback(callback)

def clean_and_save_layer(layer, output_path, log_callback=None, regenerate_uuids=True):
    """
    Guarda una capa a un shapefile, filtrando SOLO geometrías con coordenadas NaN/Inf.
    Asegura que la capa es 100% plana en 2 dimensions (sin Z/M).
    Asegura que un campo 'UUID' existe y está poblado para cada feature.
    
    Args:
        layer (QgsVectorLayer): La capa a guardar (puede ser capa de memoria).
        output_path (str): Ruta completa al shapefile de salida.
        log_callback (func, opcional): Función para registrar mensajes.
        regenerate_uuids (bool, opcional): Si es False, preserva los UUIDs existentes.
        
    Returns:
        tuple: (QgsVectorLayer, lista de dicts de error) - La capa resultado cargada y lista de geometrías filtradas
    """
    def log(msg):
        if log_callback: log_callback(msg)

    clean_existing_file(output_path)
    
    import processing
    # APLASTAMIENTO 2D MASIVO (Vía 2): Delegamos en GEOS/QGIS la limpieza
    # estructurada previa para que todo DXF 3D pase a ser 2D obligatoriamente
    # Esto salva de todos los `Coordinates with non-finite values` al exportar OGR.
    try:
        safe_layer = processing.run("native:dropmzvalues", {
            'INPUT': layer,
            'DROP_M_VALUES': True,
            'DROP_Z_VALUES': True,
            'OUTPUT': 'memory:'
        })['OUTPUT']
    except Exception as e:
        log(f"Aviso: Falló dropmzvalues: {str(e)}")
        safe_layer = layer
    
    # Encontrar el campo 'Layer' (insensible a mayúsculas)
    fields = safe_layer.fields().names()
    layer_field = next((f for f in fields if f.lower() == 'layer'), None)
    
    # Verificar si el campo UUID existe en el origen
    uuid_field_idx = -1
    valnul_field_idx = -1
    for i, f in enumerate(safe_layer.fields()):
        name = f.name()
        if name == 'UUID':
            uuid_field_idx = i
        elif name == 'valNUL':
            valnul_field_idx = i
    
    # Determinar tipo de geometría de la capa APLASTADA (ahora será LineString estricto)
    geom_type = QgsWkbTypes.displayString(safe_layer.wkbType())
    
    # Crear una capa de memoria temporal para limpieza con el tipo de geometría bidimensional correcto
    clean_layer = QgsVectorLayer(f"{geom_type}?crs={safe_layer.crs().authid()}", "clean_temp", "memory")
    clean_layer.startEditing()
    dp = clean_layer.dataProvider()
    
    # Añadir campos existentes
    dp.addAttributes(safe_layer.fields())
    
    # Añadir campo UUID si no existe
    if uuid_field_idx == -1:
        dp.addAttributes([QgsField("UUID", QVariant.String, len=50)])
        
    # Añadir campo valNUL si no existe (numérico con decimales)
    if valnul_field_idx == -1:
        dp.addAttributes([QgsField("valNUL", QVariant.Double)])
        
    clean_layer.updateFields()
    
    # Obtener el índice del campo UUID en la NUEVA capa
    new_uuid_idx = clean_layer.fields().indexOf('UUID')
    uuid_field_idx_in_safe = safe_layer.fields().indexOf('UUID') # Por si cambió
    
    valid_feats = []
    errors = []
    empty_count = 0
    corrupt_count = 0
    total_count = safe_layer.featureCount()
    
    for feat in safe_layer.getFeatures():
        geom = feat.geometry()
        
        # Obtener valor de Layer si el campo existe
        layer_value = feat[layer_field] if layer_field else "?"
        
        # Solo omitir geometrías verdaderamente vacías
        if not feat.isValid() or geom is None or geom.isEmpty():
            empty_count += 1
            errors.append({
                'id': feat.id(),
                'msg': f'Geometría inválida o vacía - LAYER={layer_value}',
                'type': 'invalid_geometry',
                'point': None,
                'layer_value': layer_value
            })
            continue
        
        # SOLO filtrar coordenadas NaN/Inf (datos verdaderamente corruptos en X o Y)
        is_corrupt = False
        try:
            for v in geom.vertices():
                if math.isnan(v.x()) or math.isinf(v.x()) or math.isnan(v.y()) or math.isinf(v.y()):
                    is_corrupt = True
                    break
        except:
            # Si no podemos iterar vértices, considerarlo corrupto
            is_corrupt = True
        
        if is_corrupt:
            corrupt_count += 1
            # Intentar obtener un punto representativo para el error
            try:
                pt = geom.centroid().asPoint()
            except:
                pt = None
            
            errors.append({
                'id': feat.id(),
                'msg': f'Geometría corrupta en DXF (coordenadas NaN/Inf) - LAYER={layer_value}',
                'type': 'corrupt_geometry',
                'point': pt,
                'layer_value': layer_value
            })
            continue
        
        # Preparar feature para guardar
        attrs = feat.attributes()
        
        # Gestión de UUID
        if regenerate_uuids:
            # SIEMPRE regenerar UUID para asegurar unicidad (comportamiento original)
            if uuid_field_idx_in_safe == -1:
                attrs.append(str(uuid.uuid4()))
            else:
                attrs[uuid_field_idx_in_safe] = str(uuid.uuid4())
        else:
            # PRESERVAR UUID existente
            if uuid_field_idx_in_safe == -1:
                # Si no tiene, generar uno nuevo por primera vez
                attrs.append(str(uuid.uuid4()))
            else:
                # Ya tiene, mantener el valor que traía
                pass
            
        # Asegurar campo valNUL y ACTUALIZAR con la longitud real de la característica final
        geom = feat.geometry()
        length = 0.0
        if geom is not None and not geom.isEmpty():
            length = geom.length()

        if valnul_field_idx == -1:
            attrs.append(length)
        else:
            attrs[valnul_field_idx] = length
        
        feat.setAttributes(attrs)
        valid_feats.append(feat)
        
    dp.addFeatures(valid_feats)
    clean_layer.commitChanges()
    
    if empty_count > 0:
        log(f"Info: Se omitieron {empty_count} geometrías vacías.")
    if corrupt_count > 0:
        log(f"ADVERTENCIA: Se eliminaron {corrupt_count} de {total_count} objetos con coordenadas corruptas (NaN/Inf).")
    
    # No registrar estadísticas internas - solo errores/advertencias son relevantes
    # log(f"Geometrías válidas guardadas: {len(valid_feats)} de {total_count}")
    
    # Escribir a Disco
    options = QgsVectorFileWriter.SaveVectorOptions()
    options.driverName = "ESRI Shapefile"
    options.fileEncoding = "UTF-8"
    
    error, error_msg = QgsVectorFileWriter.writeAsVectorFormatV2(
        clean_layer,
        output_path,
        QgsCoordinateTransformContext(),
        options
    )
    
    if error != QgsVectorFileWriter.NoError:
        raise Exception(f"Error al guardar Shapefile: {error_msg} (Código: {error})")
        
    # Cargar resultado
    base_name = os.path.splitext(os.path.basename(output_path))[0]
    result_layer = QgsVectorLayer(output_path, base_name, "ogr")
    
    if not result_layer.isValid():
        raise Exception("La capa resultante no es válida.")
        
    return result_layer, errors


def save_layer_nitro(layer, output_path, log_callback=None):
    """
    Versión ultra-rápida (Nitro) de guardado. 
    Usa solo comandos nativos (C++) evitando los bucles for de Python.
    
    1. Actualiza el campo valNUL usando native:fieldcalculator ($length).
    2. Guarda a disco usando native:savefeatures.
    
    Args:
        layer (QgsVectorLayer): Capa de entrada.
        output_path (str): Ruta .shp de salida.
        log_callback (callable): Función de log.
        
    Returns:
        QgsVectorLayer: La capa cargada desde disco.
    """
    import processing
    from .file_utils import clean_existing_file
    clean_existing_file(output_path)
    
    # 1. Asegurar campo valNUL actualizado mediante motor de expresiones nativo (C++)
    # Este comando es instantáneo incluso para capas masivas.
    fixed_fields = processing.run("native:fieldcalculator", {
        'INPUT': layer,
        'FIELD_NAME': 'valNUL',
        'FIELD_TYPE': 0, # Float
        'FORMULA': 'length($geometry)',
        'OUTPUT': 'memory:'
    })['OUTPUT']
    
    # 2. Guardar a disco de forma nativa (C++)
    # Bypass total de iteradores de Python.
    processing.run("native:savefeatures", {
        'INPUT': fixed_fields,
        'OUTPUT': output_path
    })
    
    # 3. Cargar y devolver
    base_name = os.path.splitext(os.path.basename(output_path))[0]
    result_layer = QgsVectorLayer(output_path, base_name, "ogr")
    
    if not result_layer.isValid():
        raise RuntimeError(f"Error al cargar la capa nitro guardada en {output_path}")
        
    return result_layer

def purge_zero_length_features(layer, step_label="", log_callback=None, callback=None, min_length=0.0, request=None):
    """
    Elimina features con longitud <= min_length. 
    Optimizado para no bloquear la UI y usar el DataProvider directamente.
    
    Args:
        layer (QgsVectorLayer): Capa de trabajo.
        step_label (str): Nombre del paso para el log.
        log_callback (callable): Función de logging.
        callback (callable): Función de progreso (current, total).
        min_length (float): Longitud mínima (incluye 0.0 y sagitta).
        request (QgsFeatureRequest, opcional): Filtro para limitar las features a procesar.
    """
    def log(msg):
        if log_callback:
            log_callback(msg)

    to_delete = []
    total = layer.featureCount()
    
    # Bucle de detección rápida sin sesión de edición
    from qgis.core import QgsFeatureRequest
    it = layer.getFeatures(request if request else QgsFeatureRequest())
    for i, feat in enumerate(it):
        if callback and i % 100 == 0:
            callback(i, total)

        geom = feat.geometry()
        if geom is None or geom.isEmpty():
            to_delete.append(feat.id())
            continue
            
        if geom.length() <= min_length:
            to_delete.append(feat.id())

    # 3. Eliminar (Bypass Undo/Redo si es posible mediante DataProvider)
    if to_delete:
        from qgis.core import QgsVectorDataProvider
        caps = layer.dataProvider().capabilities()
        
        if caps & QgsVectorDataProvider.DeleteFeatures:
            # Opción rápida: DataProvider directo
            if layer.isEditable():
                layer.commitChanges()
            success = layer.dataProvider().deleteFeatures(to_delete)
        else:
            # Opción segura: Buffer de edición (para capas que no soportan borrado directo en provider)
            log("⚠️ El origen no soporta borrado directo. Usando buffer de edición local...")
            layer.startEditing()
            success = layer.deleteFeatures(to_delete)
            # En capas de solo lectura, esto queda en el buffer pero permite seguir el proceso
            # No hacemos commitChanges() aquí para evitar el error de OGR si es solo lectura
            if not (caps & QgsVectorDataProvider.DeleteFeatures):
                # Dejamos en modo edición para que clean_and_save_layer vea los cambios
                pass 
            else:
                layer.commitChanges()
        
        if success:
            if min_length > 0:
                log(f"⚡ Limpieza Crítica: Eliminadas {len(to_delete)} geometrías (longitud <= {min_length}).")
            else:
                log(f"⚠️ Comprobación NulOS: Eliminadas {len(to_delete)} geometrías longitud=0.")
            layer.triggerRepaint()
        else:
            log(f"❌ Error crítico al eliminar {len(to_delete)} geometrías degeneradas.")
    else:
        log(f"✅ Integridad Geométrica: 0 elementos degenerados detectados.")

    return len(to_delete), to_delete
