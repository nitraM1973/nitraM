import os
import math
import uuid
from qgis.core import (
    QgsVectorLayer,
    QgsVectorFileWriter,
    QgsCoordinateTransformContext,
    QgsField,
    QgsWkbTypes,
    QgsProcessingFeedback,
    QgsGeometry,
    QgsPointXY
)
from qgis.PyQt.QtCore import QVariant
from .file_utils import clean_existing_file

def get_feedback(callback):
    """
    Crea un objeto QgsProcessingFeedback que redirige el progreso a un callback.
    Util para algoritmos de 'processing.run()' que bloquean la UI.
    """
    class PluginFeedback(QgsProcessingFeedback):
        def __init__(self, c):
            super().__init__()
            self.c = c
        def setProgress(self, progress):
            if self.c:
                self.c(int(progress), 100)
    return PluginFeedback(callback)

def clean_and_save_layer(layer, output_path, log_callback=None, regenerate_uuids=True):
    """
    Guarda una capa a un shapefile, filtrando SOLO geometrías con coordenadas NaN/Inf.
    Asegura que la capa es 100% plana en 2 dimensions (sin Z/M).
    Asegura que un campo 'UUID' existe y está poblado para cada feature.
    
    Args:
        layer (QgsVectorLayer): La capa a guardar (puede ser capa de memoria).
        output_path (str): Ruta completa al shapefile de salida.
        log_callback (func, opcional): Función para registrar mensajes.
        regenerate_uuids (bool, opcional): Si es False, preserva los UUIDs existentes.
        
    Returns:
        tuple: (QgsVectorLayer, lista de dicts de error) - La capa resultado cargada y lista de geometrías filtradas
    """
    def log(msg):
        if log_callback: log_callback(msg)

    clean_existing_file(output_path)
    
    import processing
    # APLASTAMIENTO 2D MASIVO (Vía 2): Delegamos en GEOS/QGIS la limpieza
    # estructurada previa para que todo DXF 3D pase a ser 2D obligatoriamente
    # Esto salva de todos los `Coordinates with non-finite values` al exportar OGR.
    try:
        safe_layer = processing.run("native:dropmzvalues", {
            'INPUT': layer,
            'DROP_M_VALUES': True,
            'DROP_Z_VALUES': True,
            'OUTPUT': 'memory:'
        })['OUTPUT']
    except Exception as e:
        log(f"Aviso: Falló dropmzvalues: {str(e)}")
        safe_layer = layer
    
    # Encontrar el campo 'Layer' (insensible a mayúsculas)
    fields = safe_layer.fields().names()
    layer_field = next((f for f in fields if f.lower() == 'layer'), None)
    
    # Verificar si el campo UUID existe en el origen
    uuid_field_idx = -1
    valnul_field_idx = -1
    for i, f in enumerate(safe_layer.fields()):
        name = f.name()
        if name == 'UUID':
            uuid_field_idx = i
        elif name == 'valNUL':
            valnul_field_idx = i
    
    # Determinar tipo de geometría de la capa APLASTADA (ahora será LineString estricto)
    geom_type = QgsWkbTypes.displayString(safe_layer.wkbType())
    
    # Crear una capa de memoria temporal para limpieza con el tipo de geometría bidimensional correcto
    clean_layer = QgsVectorLayer(f"{geom_type}?crs={safe_layer.crs().authid()}", "clean_temp", "memory")
    clean_layer.startEditing()
    dp = clean_layer.dataProvider()
    
    # Añadir campos existentes
    dp.addAttributes(safe_layer.fields())
    
    # Añadir campo UUID si no existe
    if uuid_field_idx == -1:
        dp.addAttributes([QgsField("UUID", QVariant.String, len=50)])
        
    # Añadir campo valNUL si no existe (numérico con decimales)
    if valnul_field_idx == -1:
        dp.addAttributes([QgsField("valNUL", QVariant.Double)])
        
    clean_layer.updateFields()
    
    # Obtener el índice del campo UUID en la NUEVA capa
    new_uuid_idx = clean_layer.fields().indexOf('UUID')
    uuid_field_idx_in_safe = safe_layer.fields().indexOf('UUID') # Por si cambió
    
    valid_feats = []
    errors = []
    empty_count = 0
    corrupt_count = 0
    total_count = safe_layer.featureCount()
    
    for feat in safe_layer.getFeatures():
        geom = feat.geometry()
        
        # Obtener valor de Layer si el campo existe
        layer_value = feat[layer_field] if layer_field else "?"
        
        # Solo omitir geometrías verdaderamente vacías
        if not feat.isValid() or geom is None or geom.isEmpty():
            empty_count += 1
            errors.append({
                'id': feat.id(),
                'msg': f'Geometría inválida o vacía - LAYER={layer_value}',
                'type': 'invalid_geometry',
                'point': None,
                'layer_value': layer_value
            })
            continue
        
        # FIX: Normalización de polilíneas DXF con vértice de cierre o flag closed.
        #
        # Hay tres situaciones distintas al importar un DXF a QGIS:
        #
        #   CASO 1 — DXF nativo closed=True, 2 vértices únicos: [A, B]
        #     QGIS lo importa como [A, B] con flag interno closed=True.
        #     geom.length() devuelve 0 (QGIS lo trata como anillo vacío).
        #     → Reconstruir con fromPolylineXY para destruir el flag.
        #       Resultado: línea abierta [A, B] con longitud real A→B. ✔
        #
        #   CASO 2 — DXF nativo closed=True, 3+ vértices: p.ej. [A, B, C]
        #     QGIS lo importa a veces como [A, B, C, A] (duplica el primer vértice).
        #     Son exactamente 3 vértices únicos → la polilínea tiene 2 lados reales.
        #     Si quitamos el vértice de cierre queda [A, B, C]: correcto.
        #     → Quitar el último vértice (duplicado) y reconstruir. ✔
        #
        #   CASO 3 — DXF exportado desde QGIS con closed=False pero vértice repetido.
        #     La polilínea ya era cerrada en QGIS y se exportó con todos sus vértices
        #     explícitos: p.ej. [A, B, C, A] (4 vértices, 3 lados).
        #     Aquí primero == último PERO hay 3+ vértices únicos: NO se puede quitar
        #     el último sin perder un lado. Hay que conservar todos los vértices.
        #     → Reconstruir sin tocar los vértices (solo destruir flag closed). ✔
        #
        #   CASO DEGENERADO — [A, B, A]: 3 vértices, solo 2 únicos (A y B).
        #     Quitar el cierre da [A, B]: línea de un único segmento. Correcto.
        #     (Equivale al Caso 2 con 2 vértices únicos → misma regla.)
        #
        # Regla de decisión para "primero == último":
        #   - vértices únicos = len(part) - 1  (sin contar el cierre)
        #   - Si vértices únicos == 1  → degenerada (colapsa a punto), descartar.
        #   - Si vértices únicos == 2  → quitar cierre, queda segmento [A, B]. ✔
        #   - Si vértices únicos >= 3  → CONSERVAR todos los vértices (Caso 3). ✔
        #
        # En todos los casos se reconstruye SIEMPRE con fromPolylineXY para
        # destruir cualquier flag closed interno heredado del DXF.
        try:
            if geom.type() == 1:  # LineGeometry
                is_multi = geom.isMultipart()
                parts = geom.asMultiPolyline() if is_multi else [geom.asPolyline()]
                fixed_parts = []
                skip_feat = False

                for part in parts:
                    if len(part) >= 3:
                        first = part[0]
                        last = part[-1]
                        if first.x() == last.x() and first.y() == last.y():
                            unique_count = len(part) - 1  # vértices sin el cierre
                            if unique_count == 1:
                                # Colapsa a un punto: descartar toda la feature
                                empty_count += 1
                                errors.append({
                                    'id': feat.id(),
                                    'msg': f'Geometría cerrada degenerada (colapsa a punto) eliminada - LAYER={layer_value}',
                                    'type': 'invalid_geometry',
                                    'point': None,
                                    'layer_value': layer_value
                                })
                                skip_feat = True
                                break
                            elif unique_count == 2:
                                # [A, B, A] → quitar cierre → [A, B] (un segmento)
                                part = part[:-1]
                            else:
                                # unique_count >= 3: polilínea cerrada con 3+ lados.
                                # Conservar TODOS los vértices incluyendo el de cierre
                                # para no perder ningún lado. Solo reconstruir para
                                # destruir el flag closed interno.
                                pass  # part queda intacta

                    if len(part) >= 2:
                        fixed_parts.append(part)

                if skip_feat:
                    continue

                if not fixed_parts:
                    empty_count += 1
                    errors.append({
                        'id': feat.id(),
                        'msg': f'Geometría sin partes válidas tras normalizar cierres - LAYER={layer_value}',
                        'type': 'invalid_geometry',
                        'point': None,
                        'layer_value': layer_value
                    })
                    continue

                # Reconstruir SIEMPRE desde vértices crudos para destruir el flag
                # closed interno heredado del DXF. Garantiza que geom.length()
                # devolverá la longitud real en todos los casos.
                if is_multi:
                    new_geom = QgsGeometry.fromMultiPolylineXY(fixed_parts)
                else:
                    new_geom = QgsGeometry.fromPolylineXY(fixed_parts[0])

                if not new_geom.isEmpty():
                    feat.setGeometry(new_geom)
                    geom = new_geom
        except Exception:
            pass  # Si falla el fix, continuamos con la geometría original

        # SOLO filtrar coordenadas NaN/Inf (datos verdaderamente corruptos en X o Y)
        is_corrupt = False
        try:
            for v in geom.vertices():
                if math.isnan(v.x()) or math.isinf(v.x()) or math.isnan(v.y()) or math.isinf(v.y()):
                    is_corrupt = True
                    break
        except:
            # Si no podemos iterar vértices, considerarlo corrupto
            is_corrupt = True
        
        if is_corrupt:
            corrupt_count += 1
            # Intentar obtener un punto representativo para el error
            try:
                pt = geom.centroid().asPoint()
            except:
                pt = None
            
            errors.append({
                'id': feat.id(),
                'msg': f'Geometría corrupta en DXF (coordenadas NaN/Inf) - LAYER={layer_value}',
                'type': 'corrupt_geometry',
                'point': pt,
                'layer_value': layer_value
            })
            continue
        
        # Preparar feature para guardar
        attrs = feat.attributes()
        
        # Gestión de UUID
        if regenerate_uuids:
            # SIEMPRE regenerar UUID para asegurar unicidad (comportamiento original)
            if uuid_field_idx_in_safe == -1:
                attrs.append(str(uuid.uuid4()))
            else:
                attrs[uuid_field_idx_in_safe] = str(uuid.uuid4())
        else:
            # PRESERVAR UUID existente
            if uuid_field_idx_in_safe == -1:
                # Si no tiene, generar uno nuevo por primera vez
                attrs.append(str(uuid.uuid4()))
            else:
                # Ya tiene, mantener el valor que traía
                pass
            
        # Asegurar campo valNUL y ACTUALIZAR con la longitud real de la característica final
        geom = feat.geometry()
        length = 0.0
        if geom is not None and not geom.isEmpty():
            length = geom.length()

        if valnul_field_idx == -1:
            attrs.append(length)
        else:
            attrs[valnul_field_idx] = length
        
        feat.setAttributes(attrs)
        valid_feats.append(feat)
        
    dp.addFeatures(valid_feats)
    clean_layer.commitChanges()
    
    if empty_count > 0:
        log(f"Info: Se omitieron {empty_count} geometrías vacías.")
    if corrupt_count > 0:
        log(f"ADVERTENCIA: Se eliminaron {corrupt_count} de {total_count} objetos con coordenadas corruptas (NaN/Inf).")
    
    # No registrar estadísticas internas - solo errores/advertencias son relevantes
    # log(f"Geometrías válidas guardadas: {len(valid_feats)} de {total_count}")
    
    # Escribir a Disco
    options = QgsVectorFileWriter.SaveVectorOptions()
    options.driverName = "ESRI Shapefile"
    options.fileEncoding = "UTF-8"
    
    error, error_msg = QgsVectorFileWriter.writeAsVectorFormatV2(
        clean_layer,
        output_path,
        QgsCoordinateTransformContext(),
        options
    )
    
    if error != QgsVectorFileWriter.NoError:
        raise Exception(f"Error al guardar Shapefile: {error_msg} (Código: {error})")
        
    # Cargar resultado
    base_name = os.path.splitext(os.path.basename(output_path))[0]
    result_layer = QgsVectorLayer(output_path, base_name, "ogr")
    
    if not result_layer.isValid():
        raise Exception("La capa resultante no es válida.")
        
    return result_layer, errors


def save_layer_nitro(layer, output_path, log_callback=None):
    """
    Versión ultra-rápida (Nitro) de guardado. 
    Usa solo comandos nativos (C++) evitando los bucles for de Python.
    
    1. Actualiza el campo valNUL usando native:fieldcalculator ($length).
    2. Guarda a disco usando native:savefeatures.
    
    Args:
        layer (QgsVectorLayer): Capa de entrada.
        output_path (str): Ruta .shp de salida.
        log_callback (callable): Función de log.
        
    Returns:
        QgsVectorLayer: La capa cargada desde disco.
    """
    import processing
    from .file_utils import clean_existing_file
    clean_existing_file(output_path)
    
    # 1. Asegurar campo valNUL actualizado mediante motor de expresiones nativo (C++)
    # Este comando es instantáneo incluso para capas masivas.
    fixed_fields = processing.run("native:fieldcalculator", {
        'INPUT': layer,
        'FIELD_NAME': 'valNUL',
        'FIELD_TYPE': 0, # Float
        'FORMULA': 'length($geometry)',
        'OUTPUT': 'memory:'
    })['OUTPUT']
    
    # 2. Guardar a disco de forma nativa (C++)
    # Bypass total de iteradores de Python.
    processing.run("native:savefeatures", {
        'INPUT': fixed_fields,
        'OUTPUT': output_path
    })
    
    # 3. Cargar y devolver
    base_name = os.path.splitext(os.path.basename(output_path))[0]
    result_layer = QgsVectorLayer(output_path, base_name, "ogr")
    
    if not result_layer.isValid():
        raise RuntimeError(f"Error al cargar la capa nitro guardada en {output_path}")
        
    return result_layer

def purge_zero_length_features(layer, step_label="", log_callback=None, callback=None, min_length=0.0, request=None):
    """
    Elimina features con longitud <= min_length. 
    Optimizado para no bloquear la UI y usar el DataProvider directamente.
    
    Args:
        layer (QgsVectorLayer): Capa de trabajo.
        step_label (str): Nombre del paso para el log.
        log_callback (callable): Función de logging.
        callback (callable): Función de progreso (current, total).
        min_length (float): Longitud mínima (incluye 0.0 y sagitta).
        request (QgsFeatureRequest, opcional): Filtro para limitar las features a procesar.
    """
    def log(msg):
        if log_callback:
            log_callback(msg)

    to_delete = []
    total = layer.featureCount()
    
    # Bucle de detección rápida sin sesión de edición
    from qgis.core import QgsFeatureRequest
    it = layer.getFeatures(request if request else QgsFeatureRequest())
    for i, feat in enumerate(it):
        if callback and i % 100 == 0:
            callback(i, total)

        geom = feat.geometry()
        if geom is None or geom.isEmpty():
            to_delete.append(feat.id())
            continue

        # Segunda línea de defensa contra el flag closed interno del DXF:
        # si geom.length() devuelve 0 pero la geometría tiene 2+ vértices distintos,
        # reconstruirla desde cero para que length() calcule la longitud real.
        measured_length = geom.length()
        if measured_length <= min_length and geom.type() == 1:  # LineGeometry
            try:
                is_multi = geom.isMultipart()
                parts = geom.asMultiPolyline() if is_multi else [geom.asPolyline()]
                valid_parts = [p for p in parts if len(p) >= 2]
                if valid_parts:
                    if is_multi:
                        rebuilt = QgsGeometry.fromMultiPolylineXY(valid_parts)
                    else:
                        rebuilt = QgsGeometry.fromPolylineXY(valid_parts[0])
                    if not rebuilt.isEmpty():
                        measured_length = rebuilt.length()
            except Exception:
                pass  # Si falla la reconstruccion, usar measured_length original

        if measured_length <= min_length:
            to_delete.append(feat.id())

    # 3. Eliminar (Bypass Undo/Redo si es posible mediante DataProvider)
    if to_delete:
        from qgis.core import QgsVectorDataProvider
        caps = layer.dataProvider().capabilities()
        
        if caps & QgsVectorDataProvider.DeleteFeatures:
            # Opción rápida: DataProvider directo
            if layer.isEditable():
                layer.commitChanges()
            success = layer.dataProvider().deleteFeatures(to_delete)
        else:
            # Opción segura: Buffer de edición (para capas que no soportan borrado directo en provider)
            log("⚠️ El origen no soporta borrado directo. Usando buffer de edición local...")
            layer.startEditing()
            success = layer.deleteFeatures(to_delete)
            # En capas de solo lectura, esto queda en el buffer pero permite seguir el proceso
            # No hacemos commitChanges() aquí para evitar el error de OGR si es solo lectura
            if not (caps & QgsVectorDataProvider.DeleteFeatures):
                # Dejamos en modo edición para que clean_and_save_layer vea los cambios
                pass 
            else:
                layer.commitChanges()
        
        if success:
            if min_length > 0:
                log(f"⚡ Limpieza Crítica: Eliminadas {len(to_delete)} geometrías (longitud <= {min_length}).")
            else:
                log(f"⚠️ Comprobación NulOS: Eliminadas {len(to_delete)} geometrías longitud=0.")
            layer.triggerRepaint()
        else:
            log(f"❌ Error crítico al eliminar {len(to_delete)} geometrías degeneradas.")
    else:
        log(f"✅ Integridad Geométrica: 0 elementos degenerados detectados.")

    return len(to_delete), to_delete


def explode_multipart_features(layer, step_label="", log_callback=None):
    """
    Convierte geometrías multipart en singlepart IN-PLACE sobre la capa dada,
    usando el DataProvider directamente (sin sesión de edición, sin processing.run).

    Por cada feature multipart con N partes se genera:
      - La feature original se actualiza con la primera parte.
      - Se añaden N-1 features nuevas (una por el resto de partes) con los
        mismos atributos que la original.

    Solo actúa si hay geometrías multipart reales (isMultipart() Y len(parts) > 1).
    Las geometrías ya simples no se tocan.

    Args:
        layer (QgsVectorLayer): Capa de trabajo (debe tener DataProvider con escritura).
        step_label (str): Etiqueta para el log.
        log_callback (callable): Función de logging opcional.

    Returns:
        int: Número de geometrías multipart explotadas (0 si ninguna).
    """
    from qgis.core import QgsFeature, QgsGeometry, QgsVectorDataProvider
    import uuid as _uuid

    def log(msg):
        if log_callback:
            log_callback(msg)

    dp = layer.dataProvider()
    caps = dp.capabilities()

    # Necesitamos poder cambiar geometrías y añadir features
    can_change = caps & QgsVectorDataProvider.ChangeGeometries
    can_add = caps & QgsVectorDataProvider.AddFeatures

    if not (can_change and can_add):
        log(f"⚠️ [{step_label}] El proveedor no soporta edición in-place. Saltando explode_multipart.")
        return 0

    # FIX RENDIMIENTO: antes 'multipart_fids' era una lista y se comprobaba
    # pertenencia con "fid not in multipart_fids" dentro de otro bucle sobre
    # todas las features (líneas más abajo). Cada comprobación "in" sobre una
    # lista es O(n), así que con capas grandes esto degeneraba a O(n²). Un
    # set() hace la comprobación O(1).
    multipart_fids = set()
    for feat in layer.getFeatures():
        geom = feat.geometry()
        if geom is None or geom.isEmpty():
            continue
        if geom.isMultipart():
            parts = geom.asMultiPolyline()
            if len(parts) > 1:
                multipart_fids.add(feat.id())

    if not multipart_fids:
        log(f"✅ [{step_label}] Sin geometrías multipart. Nada que explotar.")
        return 0

    log(f"  [{step_label}] Explotando {len(multipart_fids)} geometrías multipart → singlepart...")

    uuid_field_idx = layer.fields().indexOf('UUID')

    geom_updates = {}   # fid -> QgsGeometry  (primera parte)
    new_features = []   # QgsFeature nuevas    (resto de partes)

    for feat in layer.getFeatures():
        if feat.id() not in multipart_fids:
            continue
        geom = feat.geometry()
        parts = geom.asMultiPolyline()
        attrs = feat.attributes()

        # Primera parte: actualizar la feature original (conserva su UUID)
        geom_updates[feat.id()] = QgsGeometry.fromPolylineXY(parts[0])

        # Partes restantes: nuevas features con los mismos atributos, pero
        # con UUID propio: si se reutilizara el UUID original en varios
        # features, las búsquedas por UUID (localizar/corregir un error)
        # podrían coincidir con el objeto equivocado.
        for part in parts[1:]:
            new_feat = QgsFeature(layer.fields())
            new_feat.setAttributes(attrs)
            new_feat.setGeometry(QgsGeometry.fromPolylineXY(part))
            if uuid_field_idx != -1:
                new_feat.setAttribute(uuid_field_idx, str(_uuid.uuid4()))
            new_features.append(new_feat)

    if layer.isEditable():
        layer.commitChanges()

    dp.changeGeometryValues(geom_updates)
    if new_features:
        dp.addFeatures(new_features)

    layer.triggerRepaint()
    log(f"⚡ [{step_label}] Explotadas {len(multipart_fids)} multipart → {len(multipart_fids) + len(new_features)} singlepart.")
    return len(multipart_fids)
