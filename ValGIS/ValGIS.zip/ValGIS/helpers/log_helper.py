import os
import time
from qgis.core import (QgsVectorLayer, QgsField, QgsFeature, QgsGeometry, 
                      QgsProject, QgsPointXY, QgsWkbTypes)
from qgis.PyQt.QtCore import QVariant

class LogHelper:
    def __init__(self):
        self.log_layer = None
        
    def create_log_layer(self, output_dir, crs):
        """
        Creates the LOG layer (Point) with required fields.
        """
        # Create memory layer first for speed
        uri = f"Point?crs={crs.authid()}"
        self.log_layer = QgsVectorLayer(uri, "LOG", "memory")
        
        # Add fields
        provider = self.log_layer.dataProvider()
        provider.addAttributes([
            QgsField("step", QVariant.String),
            QgsField("description", QVariant.String),
            QgsField("layer", QVariant.String),
            QgsField("timestamp", QVariant.String)
        ])
        self.log_layer.updateFields()
        
        # Add to project
        QgsProject.instance().addMapLayer(self.log_layer)
        
        # Save reference to output path (for potential saving later, though memory layer is live)
        # We could also create it directly as a shapefile if persistence is critical during crash
        # But memory is faster for many updates.
        
        return self.log_layer

    def add_log_point(self, point, step_name, description, layer_name):
        """
        Adds a log point at the specified location.
        """
        if not self.log_layer:
            return
            
        feat = QgsFeature(self.log_layer.fields())
        feat.setGeometry(QgsGeometry.fromPointXY(point))
        
        timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
        
        feat.setAttribute("step", step_name)
        feat.setAttribute("description", description)
        feat.setAttribute("layer", layer_name)
        feat.setAttribute("timestamp", timestamp)
        
        self.log_layer.dataProvider().addFeatures([feat])
        # self.log_layer.triggerRepaint() # Optional, might slow down if called too often

    def get_layer(self):
        return self.log_layer
