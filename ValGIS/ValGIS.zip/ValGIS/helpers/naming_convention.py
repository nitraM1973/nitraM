"""
Sistema centralizado de nomenclatura para archivos de salida.

Este módulo define los nombres estructurados de todos los archivos generados
durante el proceso de limpieza topológica, siguiendo el formato:
    [PASO]_[SECUENCIA]_[NOMBRE_DESCRIPTIVO].shp

Donde:
    - PASO: Número de paso (01-19) con dos dígitos
    - SECUENCIA: Sub-número (00, 10, 20...) para archivos intermedios
    - NOMBRE_DESCRIPTIVO: Nombre claro en español
"""

# Nombres de archivos para cada paso
STEP_NAMES = {
    1: "01_00_DXF_Cargado.shp",
    2: "02_00_Geometrias_Reparadas.shp",
    3: "03_00_Coordenadas_Normalizadas.shp",
    4: "04_00_Sin_Duplicados.shp",
    5: "05_00_Snap_Inteligente.shp",
    6: "06_00_Colineales_Unidas_P1.shp",
    7: "07_00_Colineales_Unidas_P2.shp",
    8: "08_00_Intersecciones_Cortadas.shp",
    9: "09_00_Dangles_Detectados.shp",
    10: "10_00_Dangles_Extendidos.shp",
    11: "11_00_Intersecciones_Recortadas.shp",
    12: "12_00_Lineas_Simplificadas.shp",
    13: "13_00_Validacion_Geometrica.shp",
    14: "14_00_Verificacion_Cierres.shp",
    15: "15_00_Verificacion_Astillas.shp",
    16: "16_00_Analisis_Cambios.shp",
    17: "17_00_Poligonos_Generados.shp",
    18: "18_00_Poligonos_Validados.shp",
    19: "19_00_Resultado_Final.dxf"
}

# Descripciones amigables para el usuario
STEP_DESCRIPTIONS = {
    1: "DXF Cargado",
    2: "Geometrías Reparadas",
    3: "Coordenadas Normalizadas",
    4: "Duplicados Eliminados",
    5: "Snap Inteligente Aplicado",
    6: "Colineales Unidas (Pase 1)",
    7: "Colineales Unidas (Pase 2)",
    8: "Intersecciones Cortadas",
    9: "Dangles Detectados",
    10: "Dangles Extendidos",
    11: "Intersecciones Re-cortadas",
    12: "Líneas Simplificadas",
    13: "Validación Geométrica",
    14: "Verificación de Cierres",
    15: "Verificación de Astillas",
    16: "Análisis de Cambios",
    17: "Polígonos Generados",
    18: "Polígonos Validados",
    19: "Resultado Final (DXF)"
}


def get_step_filename(step_number):
    """
    Obtiene el nombre de archivo para un paso específico.
    
    Args:
        step_number (int): Número del paso (1-19)
        
    Returns:
        str: Nombre del archivo (ej: "08_00_Intersecciones_Cortadas.shp")
    """
    return STEP_NAMES.get(step_number, f"{step_number:02d}_00_Paso_{step_number}.shp")


def get_step_description(step_number):
    """
    Obtiene la descripción amigable para un paso específico.
    
    Args:
        step_number (int): Número del paso (1-19)
        
    Returns:
        str: Descripción del paso (ej: "Intersecciones Cortadas")
    """
    return STEP_DESCRIPTIONS.get(step_number, f"Paso {step_number}")


def get_all_step_names():
    """
    Obtiene todos los nombres de pasos.
    
    Returns:
        dict: Diccionario con todos los nombres de pasos
    """
    return STEP_NAMES.copy()


def get_all_step_descriptions():
    """
    Obtiene todas las descripciones de pasos.
    
    Returns:
        dict: Diccionario con todas las descripciones
    """
    return STEP_DESCRIPTIONS.copy()
