from qgis.core import QgsPointXY, QgsSpatialIndex, QgsRectangle, QgsGeometry, QgsFeature
from ..topology.graph import Graph

# Precisión idéntica a la usada en Fase C (step_verify_enclosures.py)
GRAPH_PRECISION = 6


def snap_hanging_vertices(layer, tolerance=0.01, callback=None, log_callback=None, request=None):
    """
    SUPER SNAPPER v3.1: Detecta extremos que Fase C vería como dangles
    y los lleva al extremo más cercano de otro segmento.

    Construye el mismo `Graph` que la Fase C, buscando específicamente
    nodos de grado 1.

    Args:
        layer (QgsVectorLayer): Capa de líneas.
        tolerance (float): Distancia máxima para snap (metros).
        callback (callable): Progreso (i, total).
        log_callback (callable): Función para escribir en el log del plugin.
        request (QgsFeatureRequest, opcional): Filtro para capa.

    Returns:
        int: Número de extremos corregidos.
    """
    def log(msg):
        if log_callback:
            log_callback(msg)

    # ━━ 1. RECOPILAR EXTREMOS Y CONSTRUIR GRAFO ━━
    endpoints = []  # Lista de dicts: {pt, fid, type, pidx, key}
    if request:
        features = list(layer.getFeatures(request))
    else:
        features = list(layer.getFeatures())
    total_feats = len(features)

    graph = Graph()

    for i, feat in enumerate(features):
        if callback and i % 500 == 0:
            callback(i, total_feats)

        geom = feat.geometry()
        if not geom or geom.isEmpty():
            continue

        if geom.isMultipart():
            parts = geom.asMultiPolyline()
        else:
            parts = [geom.asPolyline()]

        for pidx, part in enumerate(parts):
            if len(part) >= 2:
                # Nodo grafo
                u = (round(part[0].x(), GRAPH_PRECISION), round(part[0].y(), GRAPH_PRECISION))
                v = (round(part[-1].x(), GRAPH_PRECISION), round(part[-1].y(), GRAPH_PRECISION))
                graph.add_edge(u, v)

                # Registrar endpoints físicos
                endpoints.append({
                    'pt': QgsPointXY(part[0]),
                    'fid': feat.id(),
                    'type': 'start',
                    'pidx': pidx,
                    'key': u
                })
                endpoints.append({
                    'pt': QgsPointXY(part[-1]),
                    'fid': feat.id(),
                    'type': 'end',
                    'pidx': pidx,
                    'key': v
                })

    total_ep = len(endpoints)
    log(f"    Extremos recopilados: {total_ep} (de {total_feats} segmentos)")

    if total_ep == 0:
        return 0

    # ━━ 2. IDENTIFICAR DANGLES RECTOS DEL GRAFO ━━
    # Un extremo es "suelto" SOLAMENTE si su grado en el grafo es 1
    suelto_indices = []
    for i, ep in enumerate(endpoints):
        if len(graph.nodes[ep['key']]) == 1:
            suelto_indices.append(i)

    log(f"    Extremos sueltos detectados (Grado 1 real): {len(suelto_indices)}")

    if not suelto_indices:
        return 0

    # ━━ 3. ÍNDICE ESPACIAL DE TODOS LOS EXTREMOS ━━
    index = QgsSpatialIndex()
    for i, ep in enumerate(endpoints):
        f = QgsFeature()
        f.setId(i)
        f.setGeometry(QgsGeometry.fromPointXY(ep['pt']))
        index.addFeature(f)

    # ━━ 4. BUSCAR DESTINO PARA CADA SUELTO ━━
    snap_plan = {}  # {source_idx: target_idx}

    for i in suelto_indices:
        ep = endpoints[i]
        pt = ep['pt']
        fid = ep['fid']

        search_rect = QgsRectangle(
            pt.x() - tolerance, pt.y() - tolerance,
            pt.x() + tolerance, pt.y() + tolerance
        )
        near = index.intersects(search_rect)

        best_dist = tolerance + 1e-9  # Ligeramente mayor para incluir == tolerance
        best_j = -1

        for j in near:
            if j == i:
                continue
            other = endpoints[j]
            if other['fid'] == fid:
                continue  # No snap a tu propia feature

            dist = pt.distance(other['pt'])
            if dist < best_dist and dist > 0:
                best_dist = dist
                best_j = j

        if best_j >= 0:
            snap_plan[i] = best_j

    log(f"    Destinos encontrados: {len(snap_plan)}")

    if not snap_plan:
        return 0

    # ━━ 5. RESOLVER PARES MUTUOS ━━
    # Si A→B y B→A, solo mover A hacia B (evitar intercambio).
    resolved = {}  # {source_idx: target_QgsPointXY}
    skip = set()

    for src, tgt in snap_plan.items():
        if src in skip:
            continue

        target_pt = endpoints[tgt]['pt']
        resolved[src] = target_pt

        # Si el destino también apunta a nosotros, bloquearlo
        if tgt in snap_plan and snap_plan[tgt] == src:
            skip.add(tgt)

    log(f"    Operaciones de snap tras resolver mutuos: {len(resolved)}")

    # ━━ 6. APLICAR SNAPPING ━━
    layer.startEditing()
    fixed_count = 0

    for src_idx, target_pt in resolved.items():
        ep = endpoints[src_idx]
        fid = ep['fid']
        etype = ep['type']
        pidx = ep['pidx']

        feat = layer.getFeature(fid)
        if not feat.isValid():
            continue

        geom = feat.geometry()
        if not geom or geom.isEmpty():
            continue

        if geom.isMultipart():
            parts = geom.asMultiPolyline()
        else:
            parts = [geom.asPolyline()]

        if pidx >= len(parts):
            continue

        part = list(parts[pidx])
        if len(part) < 2:
            continue

        # Mover el extremo a la posición exacta del destino
        if etype == 'start':
            part[0] = target_pt
        else:
            part[-1] = target_pt

        # Reconstruir geometría
        parts_list = [list(p) for p in parts]
        parts_list[pidx] = part

        if geom.isMultipart():
            new_geom = QgsGeometry.fromMultiPolylineXY(parts_list)
        else:
            new_geom = QgsGeometry.fromPolylineXY(parts_list[0])

        layer.changeGeometry(fid, new_geom)
        fixed_count += 1

    layer.commitChanges()
    log(f"    ✓ Super Snapper: {fixed_count} extremos movidos a su destino.")
    return fixed_count
