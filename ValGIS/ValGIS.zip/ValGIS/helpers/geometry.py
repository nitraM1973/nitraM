from qgis.core import QgsPointXY, QgsGeometry

def distance_squared(p1, p2):
    return (p1.x() - p2.x())**2 + (p1.y() - p2.y())**2

def is_point_on_line(point, line_start, line_end, tolerance=1e-6):
    # Check if point is on the segment defined by line_start and line_end
    # This is a simplified check; QGIS geometry engine is preferred for complex cases
    geom_point = QgsGeometry.fromPointXY(point)
    geom_line = QgsGeometry.fromPolylineXY([line_start, line_end])
    return geom_line.distance(geom_point) < tolerance
