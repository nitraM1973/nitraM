"""
Generador de resumen HTML profesional para el proceso de limpieza topológica.

Este módulo crea y actualiza un archivo HTML que muestra el progreso del proceso,
estadísticas por paso, y archivos generados.
"""

import os
from datetime import datetime
from .naming_convention import get_step_description


class SummaryReport:
    """Generador de reportes HTML de resumen del proceso."""
    
    def __init__(self, output_dir, dxf_name=""):
        """
        Inicializa el generador de resumen.
        
        Args:
            output_dir (str): Directorio donde se guardará el HTML
            dxf_name (str): Nombre del archivo DXF original
        """
        self.output_dir = output_dir
        self.dxf_name = dxf_name
        self.html_path = os.path.join(output_dir, "RESUMEN_PROCESO.html")
        self.json_path = os.path.join(output_dir, "summary_data.json")
        self.steps_data = {}  # {step_num: {status, features, time, errors}}
        self._load_state()
        
    def _load_state(self):
        """Carga el estado desde el archivo JSON si existe."""
        import json
        if os.path.exists(self.json_path):
            try:
                with open(self.json_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    # Convert numeric keys to integers, preserve string keys
                    steps_data_raw = data.get('steps_data', {})
                    self.steps_data = {}
                    for k, v in steps_data_raw.items():
                        try:
                            # Try to convert to int
                            self.steps_data[int(k)] = v
                        except (ValueError, TypeError):
                            # Keep as string key (e.g., 'comparison_text')
                            self.steps_data[k] = v
                    
                    if not self.dxf_name and 'dxf_name' in data:
                        self.dxf_name = data['dxf_name']
            except Exception as e:
                print(f"Error loading summary state: {e}")

    def _save_state(self):
        """Guarda el estado actual en un archivo JSON."""
        import json
        data = {
            'dxf_name': self.dxf_name,
            'steps_data': self.steps_data
        }
        try:
            with open(self.json_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            print(f"Error saving summary state: {e}")

    def create_html(self):
        """Crea el archivo HTML inicial."""
        self._save_state() # Save state whenever we generate HTML
        html_content = self._generate_html()
        with open(self.html_path, 'w', encoding='utf-8') as f:
            f.write(html_content)
    
    def update_step(self, step_number, status='completed', features=0, time_seconds=0, errors=0):
        """
        Actualiza el estado de un paso específico.
        
        Args:
            step_number (int): Número del paso (1-19)
            status (str): 'completed', 'paused', 'pending', 'error'
            features (int): Número de features procesados
            time_seconds (float): Tiempo de ejecución en segundos
            errors (int): Número de errores detectados
        """
        self.steps_data[step_number] = {
            'status': status,
            'features': features,
            'time': time_seconds,
            'errors': errors
        }
        self.create_html()  # Regenerar HTML y guardar estado
    
    def _generate_html(self):
        """Genera el contenido HTML completo."""
        now = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
        
        version = self._get_plugin_version()

        # Calcular progreso (solo contar valores que son diccionarios de pasos)
        completed_steps = sum(1 for data in self.steps_data.values() 
                            if isinstance(data, dict) and data.get('status') == 'completed')
        total_steps = 19
        progress_percent = int((completed_steps / total_steps) * 100)
        
        # Generar filas de tabla
        rows_html = self._generate_table_rows()
        
        # Generar lista de archivos
        files_html = self._generate_files_list()
        
        # Obtener texto de comparación
        comparison_text = self.steps_data.get('comparison_text', 'Pendiente de análisis...')
        
        html = f"""<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resumen - Limpieza Topológica ValGIS</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 20px;
            min-height: 100vh;
        }}
        
        .container {{
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            overflow: hidden;
        }}
        
        header {{
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }}
        
        header h1 {{
            font-size: 28px;
            margin-bottom: 15px;
            font-weight: 600;
        }}
        
        header p {{
            font-size: 14px;
            opacity: 0.9;
            margin: 5px 0;
        }}
        
        header strong {{
            color: #ffd700;
        }}
        
        .content {{
            padding: 30px;
        }}
        
        section {{
            margin-bottom: 30px;
        }}
        
        h2 {{
            color: #1e3c72;
            font-size: 20px;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 2px solid #e0e0e0;
        }}
        
        .progress-container {{
            background: #f5f5f5;
            border-radius: 8px;
            padding: 20px;
            text-align: center;
        }}
        
        .progress-bar {{
            background: #e0e0e0;
            border-radius: 20px;
            height: 30px;
            overflow: hidden;
            position: relative;
            margin: 15px 0;
        }}
        
        .progress-fill {{
            background: linear-gradient(90deg, #4CAF50 0%, #45a049 100%);
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 14px;
            transition: width 0.3s ease;
        }}
        
        .progress-text {{
            font-size: 18px;
            color: #333;
            font-weight: 600;
        }}
        
        table {{
            width: 100%;
            border-collapse: collapse;
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }}
        
        thead {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }}
        
        th {{
            padding: 15px;
            text-align: left;
            font-weight: 600;
            font-size: 14px;
        }}
        
        td {{
            padding: 12px 15px;
            border-bottom: 1px solid #f0f0f0;
            font-size: 14px;
        }}
        
        tr:hover {{
            background: #f9f9f9;
        }}
        
        .status {{
            display: inline-block;
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
        }}
        
        .status.completed {{
            background: #d4edda;
            color: #155724;
        }}
        
        .status.paused {{
            background: #fff3cd;
            color: #856404;
        }}
        
        .status.pending {{
            background: #e7e7e7;
            color: #666;
        }}
        
        .status.error {{
            background: #f8d7da;
            color: #721c24;
        }}
        
        .files-table {{
            width: 100%;
            border-collapse: collapse;
            font-size: 13px;
            margin-top: 10px;
        }}
        
        .files-table th {{
            background: #f0f0f0;
            color: #333;
            font-weight: 600;
            text-align: left;
            padding: 10px;
            border-bottom: 2px solid #ddd;
        }}
        
        .files-table td {{
            padding: 8px 10px;
            border-bottom: 1px solid #eee;
            vertical-align: middle;
        }}
        
        .files-table tr:last-child td {{
            border-bottom: none;
        }}
        
        .type-badge {{
            display: inline-block;
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: bold;
            text-transform: uppercase;
        }}
        
        .type-temp {{ background: #f5f5f5; color: #999; }}
        .type-backup {{ background: #e3f2fd; color: #1976d2; }}
        .type-final {{ background: #d4edda; color: #155724; border: 1px solid #c3e6cb; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }}
        
        .row-final {{ background-color: #f8fff9; }}
        .row-final td {{ border-bottom: 1px solid #d4edda; }}
        
        .current-file {{
            background: #fff3cd;
            padding: 2px 6px;
            border-radius: 4px;
            margin-left: 5px;
            font-size: 11px;
            color: #856404;
        }}
        
        .comparison-box {{
            background: #e8f4f8;
            border-left: 5px solid #2a5298;
            padding: 15px;
            border-radius: 4px;
            margin-top: 20px;
            font-size: 15px;
            line-height: 1.6;
            color: #333;
        }}
        
        footer {{
            background: #f5f5f5;
            padding: 20px;
            text-align: center;
            color: #666;
            font-size: 12px;
            border-top: 1px solid #e0e0e0;
        }}
        
        .badge {{
            display: inline-block;
            padding: 2px 8px;
            border-radius: 10px;
            font-size: 11px;
            font-weight: 600;
            margin-left: 5px;
        }}
        
        .badge.success {{
            background: #d4edda;
            color: #155724;
        }}
        
        .badge.warning {{
            background: #fff3cd;
            color: #856404;
        }}
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>📊 Resumen del Proceso de Limpieza Topológica</h1>
            <p><strong>DXF Original:</strong> {self.dxf_name or 'No especificado'}</p>
            <p><strong>Última Actualización:</strong> {now}</p>
            <p><strong>ValGIS</strong> - Plugin de Limpieza Topológica Avanzada para QGIS</p>
        </header>
        
        <div class="content">
            <section class="progress">
                <h2>📈 Progreso General</h2>
                <div class="progress-container">
                    <p class="progress-text">{completed_steps} de {total_steps} pasos completados</p>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: {progress_percent}%">{progress_percent}%</div>
                    </div>
                </div>
            </section>
            
            <section class="steps">
                <h2>📋 Detalle de Pasos</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Paso</th>
                            <th>Descripción</th>
                            <th>Estado</th>
                            <th>Features</th>
                            <th>Tiempo</th>
                        </tr>
                    </thead>
                    <tbody>
                        {rows_html}
                    </tbody>
                </table>
                
                <div class="comparison-box">
                    <h3>🔍 Análisis Comparativo (Original vs Definitivo)</h3>
                    <p>{comparison_text}</p>
                </div>
            </section>
            
            <section class="files">
                <h2>📁 Archivos Generados</h2>
                <div class="table-responsive">
                    <table class="files-table">
                        <thead>
                            <tr>
                                <th>Archivo</th>
                                <th>Descripción</th>
                                <th>Uso</th>
                            </tr>
                        </thead>
                        <tbody>
                            {files_html}
                        </tbody>
                    </table>
                </div>
            </section>
        </div>
        
        <footer>
            <p><strong>ValGIS {version}</strong> - Plugin de Limpieza Topológica para QGIS</p>
            <p>Generado automáticamente el {now}</p>
        </footer>
    </div>
</body>
</html>"""
        return html
    
    def _get_plugin_version(self):
        """Obtiene la versión del plugin desde metadata.txt"""
        try:
            # Sube un nivel desde 'helpers' para encontrar metadata.txt
            metadata_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'metadata.txt')
            if os.path.exists(metadata_path):
                with open(metadata_path, 'r', encoding='utf-8') as f:
                    for line in f:
                        if line.strip().startswith('version='):
                            return f"v{line.split('=')[1].strip()}"
        except Exception:
            pass
        return "v?.?" # Valor por defecto si falla

    def set_comparison_text(self, text):
        """Establece el texto del análisis comparativo."""
        self.steps_data['comparison_text'] = text
        self.create_html()

    def _generate_table_rows(self):
        """Genera las filas HTML de la tabla de pasos."""
        from .naming_convention import STEP_NAMES
        
        rows = []
        for step_num in range(1, 20):
            data = self.steps_data.get(step_num, {'status': 'pending', 'features': 0, 'time': 0, 'errors': 0})
            description = get_step_description(step_num)
            
            # Determinar icono y texto de estado
            status_map = {
                'completed': ('✓ Completado', 'completed'),
                'paused': ('⏸ Pausado', 'paused'),
                'pending': ('⏳ Pendiente', 'pending'),
                'error': ('❌ Error', 'error')
            }
            status_text, status_class = status_map.get(data['status'], ('⏳ Pendiente', 'pending'))
            
            # Formatear tiempo
            time_str = f"{data['time']:.2f}s" if data['time'] > 0 else "-"
            
            # Formatear features
            features_str = f"{data['features']:,}" if data['features'] > 0 else "-"
            
            # Formatear errores
            errors_str = f"{data['errors']}" if data['errors'] > 0 else "-"
            if data['errors'] > 0:
                errors_str = f'<span class="badge warning">{errors_str}</span>'
            
            row = f"""
                    <tr>
                        <td><strong>{step_num:02d}</strong></td>
                        <td>{description}</td>
                        <td><span class="status {status_class}">{status_text}</span></td>
                        <td>{features_str}</td>
                        <td>{time_str}</td>
                    </tr>"""
            rows.append(row)
        
        return '\n'.join(rows)
    
    def _generate_files_list(self):
        """Genera la lista HTML de archivos generados."""
        from .naming_convention import STEP_NAMES
        
        # Mapping of descriptions and types
        FILE_INFO = {
            1: ("Copia exacta del DXF original", "Respaldo"),
            2: ("Geometrías reparadas (fixgeometries)", "Temporal"),
            3: ("Coordenadas normalizadas", "Temporal"),
            4: ("Sin duplicados", "Temporal"),
            5: ("Nodos ajustados (Smart Snap)", "Temporal"),
            6: ("Colineales unidas (Pase 1)", "Temporal"),
            7: ("Colineales unidas (Pase 2)", "Temporal"),
            8: ("Intersecciones cortadas", "Temporal"),
            9: ("Dangles detectados", "Temporal"),
            10: ("Dangles extendidos", "Temporal"),
            11: ("Intersecciones re-cortadas", "Temporal"),
            12: ("Líneas simplificadas", "Temporal"),
            13: ("Validación geométrica", "Temporal"),
            14: ("Verificación de cierres", "Temporal"),
            15: ("Verificación de astillas", "Temporal"),
            16: ("Análisis de cambios", "Temporal"),
            17: ("Polígonos generados limpios", "DEFINITIVO"),
            18: ("Polígonos validados", "Validación"),
            19: ("Archivo DXF final para entrega", "DEFINITIVO")
        }
        
        rows = []
        int_keys = [k for k in self.steps_data.keys() if isinstance(k, int)]
        current_step = max(int_keys) if int_keys else 0
        
        for step_num in range(1, 20):
            if step_num in self.steps_data:
                filename = STEP_NAMES.get(step_num, f"{step_num:02d}_00_Paso_{step_num}.shp")
                desc, type_ = FILE_INFO.get(step_num, ("Archivo intermedio", "Temporal"))
                
                # Determine styles
                row_class = "row-final" if type_ == "DEFINITIVO" else ""
                
                type_class = "type-temp"
                if type_ == "Respaldo": type_class = "type-backup"
                if type_ == "DEFINITIVO": type_class = "type-final"
                
                current_tag = '<span class="current-file">← Actual</span>' if step_num == current_step else ""
                
                # Bold filename for definitive files
                filename_display = f"<strong>{filename}</strong>" if type_ == "DEFINITIVO" else filename
                
                row = f"""
                    <tr class="{row_class}">
                        <td style="font-family: 'Courier New', monospace;">{filename_display}{current_tag}</td>
                        <td>{desc}</td>
                        <td><span class="type-badge {type_class}">{type_}</span></td>
                    </tr>"""
                rows.append(row)
        
        return '\n'.join(rows) if rows else '<tr><td colspan="3">No se han generado archivos aún</td></tr>'


# Funciones de conveniencia para uso desde form_dialog.py

def create_summary_html(output_dir, dxf_name=""):
    """
    Crea un nuevo archivo de resumen HTML.
    
    Args:
        output_dir (str): Directorio de salida
        dxf_name (str): Nombre del DXF original
    """
    report = SummaryReport(output_dir, dxf_name)
    report.create_html()
    return report


def update_step_status(output_dir, step_number, status='completed', features=0, time_seconds=0, errors=0, dxf_name=""):
    """
    Actualiza el estado de un paso en el resumen HTML.
    
    Args:
        output_dir (str): Directorio de salida
        step_number (int): Número del paso
        status (str): Estado del paso
        features (int): Número de features procesados
        time_seconds (float): Tiempo de ejecución
        errors (int): Número de errores
        dxf_name (str): Nombre del DXF original
    """
    report = SummaryReport(output_dir, dxf_name)
    
    # Update the specific step
    # The state is automatically loaded in __init__ and saved in update_step
    report.update_step(step_number, status, features, time_seconds, errors)

def set_comparison_summary(output_dir, text, dxf_name=""):
    """Establece el resumen comparativo."""
    report = SummaryReport(output_dir, dxf_name)
    report.set_comparison_text(text)
