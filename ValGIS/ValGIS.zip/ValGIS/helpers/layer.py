from qgis.core import QgsVectorLayer, QgsProject

def create_memory_layer(name, fields, geometry_type="LineString", crs=None):
    """Creates a temporary memory layer."""
    uri = f"{geometry_type}?crs={crs.authid() if crs else ''}"
    layer = QgsVectorLayer(uri, name, "memory")
    dp = layer.dataProvider()
    dp.addAttributes(fields)
    layer.updateFields()
    return layer

def clone_layer(source_layer, name_suffix="_clone"):
    """Clones a layer to a memory layer."""
    layer_name = source_layer.name() + name_suffix
    new_layer = create_memory_layer(
        layer_name, 
        source_layer.fields(), 
        source_layer.geometryType(), 
        source_layer.crs()
    )
    
    feats = [f for f in source_layer.getFeatures()]
    new_layer.dataProvider().addFeatures(feats)
    return new_layer
