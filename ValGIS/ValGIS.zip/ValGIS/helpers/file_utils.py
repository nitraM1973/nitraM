import os

def get_output_path(source_layer, suffix, output_dir=None):
    """
    Generates a safe output path.
    
    Args:
        source_layer (QgsVectorLayer): The layer to base the name on.
        suffix (str): The suffix for the new file (e.g., "_01_Importado.shp").
        output_dir (str, optional): The directory to save to. If None, calculates default.
        
    Returns:
        str: The full absolute path to the output file.
    """
    # Get source path for base name
    source_source = source_layer.source()
    file_path = source_source.split("|")[0]
    
    if not os.path.exists(file_path) or not os.path.isfile(file_path):
        file_path = os.path.join(os.path.expanduser("~"), "temp_dxf_export.dxf")
        
    base_name = os.path.splitext(os.path.basename(file_path))[0]
    
    # Clean base name from previous suffixes
    for s in ["_01_Importado", "_02_Limpiado", "_03_Unido", "_04_Cortado", "_03_Densificado"]:
        if s in base_name:
            base_name = base_name.replace(s, "")
            
    # Use provided output_dir or fallback
    if output_dir:
        final_dir = output_dir
    else:
        # Fallback logic (should be avoided by using output_dir)
        dir_name = os.path.dirname(file_path)
        if os.path.basename(dir_name).startswith("ValGIS_Output"):
             final_dir = dir_name
        else:
             final_dir = os.path.join(dir_name, "ValGIS_Output")
             
    if not os.path.exists(final_dir):
        os.makedirs(final_dir)
        
    output_path = os.path.join(final_dir, f"{base_name}{suffix}")
    
    return output_path

def clean_existing_file(file_path):
    """Deletes the shapefile and its sidecars if they exist."""
    if os.path.exists(file_path):
        try:
            base = os.path.splitext(file_path)[0]
            for ext in ['.shp', '.shx', '.dbf', '.prj', '.cpg', '.qpj']:
                f = base + ext
                if os.path.exists(f):
                    os.remove(f)
        except Exception as e:
            raise RuntimeError(f"No se pudo limpiar el archivo existente: {e}")
