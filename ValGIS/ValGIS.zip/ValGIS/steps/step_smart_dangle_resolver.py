import math
from qgis.core import QgsPointXY, QgsSpatialIndex, QgsRectangle, QgsGeometry, QgsVector, QgsFeature

class StepSmartDangleResolver:
    """
    Resolves dangles (hanging endpoints) using a hierarchical strategy that minimizes deformation.
    
    Priority Order:
    0. Snap to existing vertex (safest - no deformation of existing geometry)
    1. Snap to another dangle if nearly collinear
    2. Fillet (chamfer) between two dangles
    3. Extend to receiver line
    4-5. Report as manual error
    """
    
    def __init__(self):
        self.tolerance_snap = 0.025
        self.tolerance_extension = 0.050
        self.angle_collinear = 15.0
        self.angle_fillet_max = 120.0
        self.angle_parallel = 5.0
        self.min_length = 0.025
        self.max_deformation_factor = 2.0
    
    def run(self, layer, tolerance_snap, tolerance_extension, angle_collinear, log_callback=None, log_helper=None, recintos_layers=None, clases_layers=None):
        """
        Main entry point for smart dangle resolution.
        
        Args:
            layer: Working layer
            tolerance_snap: Distance for snapping to nodes/dangles
            tolerance_extension: Distance for extensions
            angle_collinear: Angle threshold for collinear detection
            log_callback: Logging function
            log_helper: Optional LogHelper instance
            recintos_layers: List of layer names in Recintos group
            clases_layers: List of layer names in Clases group
        """
        def log(msg):
            if log_callback:
                log_callback(msg)
        
        self.tolerance_snap = tolerance_snap
        self.tolerance_extension = tolerance_extension  
        self.angle_collinear = angle_collinear
        
        # Store groups for isolation logic
        self.recintos_layers = set(recintos_layers) if recintos_layers else set()
        self.clases_layers = set(clases_layers) if clases_layers else set()
        
        # Identify group sets
        self.r_only = self.recintos_layers - self.clases_layers
        self.c_only = self.clases_layers - self.recintos_layers
        self.common = self.recintos_layers & self.clases_layers
        
        # Find Layer field
        layer_field = None
        for field in layer.fields():
            if field.name().lower() == 'layer':
                layer_field = field.name()
                break
        
        layer_name = layer.name()

        # Build graph to identify dangles
        from ..topology.graph import Graph
        graph = Graph()
        features = list(layer.getFeatures())
        
        for feature in features:
            geom = feature.geometry()
            if geom.isMultipart():
                lines = geom.asMultiPolyline()
            else:
                lines = [geom.asPolyline()]
            
            for line in lines:
                if len(line) >= 2:
                    u = (round(line[0].x(), 6), round(line[0].y(), 6))
                    v = (round(line[-1].x(), 6), round(line[-1].y(), 6))
                    graph.add_edge(u, v)
        
        # Collect dangles
        dangles = []
        for node, neighbors in graph.nodes.items():
            degree = len(neighbors)
            if degree == 1:
                neighbor = neighbors[0]
                # Skip if it's a loose object (both ends are degree 1)
                if len(graph.nodes[neighbor]) == 1:
                    continue
                pt = QgsPointXY(node[0], node[1])
                dangles.append(pt)
        
        log(f"Detectados {len(dangles)} extremos colgados.")
        
        # Build spatial index
        index = QgsSpatialIndex(layer.getFeatures())
        
        # Classify and resolve each dangle
        layer.startEditing()
        
        resolved_count = {
            'CASE_0': 0,  # Snap to existing node
            'CASE_2': 0,  # Fillet
            'ERROR': 0
        }
        
        processed_dangles = set()
        
        for dangle in dangles:
            dangle_key = (round(dangle.x(), 6), round(dangle.y(), 6))
            if dangle_key in processed_dangles:
                continue
            
            # Classify the dangle
            case_type, solution_data = self._classify_dangle(
                dangle, layer, index, layer_field, graph, processed_dangles
            )
            
            if case_type == 'CASE_0':
                # Snap to existing node
                target_node = solution_data
                if self._snap_dangle_to_point(layer, index, dangle, target_node):
                    resolved_count['CASE_0'] += 1
                    processed_dangles.add(dangle_key)
                    log(f"  CASO 0: Snap a nodo existente ({target_node.x():.3f}, {target_node.y():.3f})")
                    if log_helper:
                        log_helper.add_log_point(target_node, "Resolver Colgados", "Snap a nodo existente", layer_name)
                
            elif case_type == 'CASE_2':
                # Fillet between two dangles
                other_dangle, intersection = solution_data
                modified1 = self._snap_dangle_to_point(layer, index, dangle, intersection)
                modified2 = self._snap_dangle_to_point(layer, index, other_dangle, intersection)
                
                if modified1 or modified2:
                    resolved_count['CASE_2'] += 1
                    processed_dangles.add(dangle_key)
                    other_key = (round(other_dangle.x(), 6), round(other_dangle.y(), 6))
                    processed_dangles.add(other_key)
                    log(f"  CASO 2: Fillet/Chaflán a ({intersection.x():.3f}, {intersection.y():.3f})")
                    if log_helper:
                        log_helper.add_log_point(intersection, "Resolver Colgados", "Fillet/Chaflán", layer_name)
                
            else:
                # Error case
                log(f"  ERROR: No se pudo resolver automáticamente en ({dangle.x():.3f}, {dangle.y():.3f})")
                resolved_count['ERROR'] += 1
        
        layer.commitChanges()
        
        # Summary
        log(f"\nResumen:")
        log(f"  - Snap a nodos existentes: {resolved_count['CASE_0']}")
        log(f"  - Fillet/Chaflán: {resolved_count['CASE_2']}")
        log(f"  - Sin resolver: {resolved_count['ERROR']}")
        
        return resolved_count
    
    def _classify_dangle(self, dangle, layer, index, layer_field, graph, processed_dangles):
        """
        Classify a dangle and return (case_type, solution_data).
        """
        # Get dangle feature and direction
        dangle_feature, dangle_direction = self._get_dangle_info(layer, index, dangle)
        if not dangle_feature or not dangle_direction:
            return ('ERROR', None)
        
        dangle_layer_value = dangle_feature[layer_field] if layer_field else None
        
        # CASE 0: Search for existing vertices (not dangles)
        existing_node = self._find_nearest_existing_vertex(
            dangle, layer, index, dangle_layer_value, layer_field, graph
        )
        if existing_node:
            return ('CASE_0', existing_node)
        
        # CASE 2: Search for other dangles for fillet
        other_dangles = self._find_nearby_dangles_for_fillet(
            dangle, layer, index, dangle_layer_value, layer_field, graph, processed_dangles
        )
        
        for other_dangle, other_direction in other_dangles:
            # Calculate angle
            angle = self._calculate_angle(dangle_direction, other_direction)
            distance = dangle.distance(other_dangle)
            
            # CASE 2: Fillet (only non-collinear cases)
            if self.angle_collinear < angle < self.angle_fillet_max and distance < self.tolerance_snap * 2:
                intersection = self._calculate_segment_intersection(
                    dangle, dangle_direction, other_dangle, other_direction
                )
                if intersection and self._is_valid_fillet(intersection, dangle, other_dangle):
                    return ('CASE_2', (other_dangle, intersection))
        
        # No solution found
        return ('ERROR', None)
    
    def _find_nearest_existing_vertex(self, dangle, layer, index, layer_value, layer_field, graph):
        """
        Find the nearest existing vertex (not a dangle) within tolerance.
        """
        search_rect = QgsRectangle(
            dangle.x() - self.tolerance_snap,
            dangle.y() - self.tolerance_snap,
            dangle.x() + self.tolerance_snap,
            dangle.y() + self.tolerance_snap
        )
        
        candidate_fids = index.intersects(search_rect)
        
        best_vertex = None
        min_distance = self.tolerance_snap
        
        for fid in candidate_fids:
            feat = layer.getFeature(fid)
            if not feat.isValid():
                continue
            
            # Check layer match
            if layer_field:
                feat_layer_value = feat[layer_field]
                feat_layer_value = feat[layer_field]
                # Check isolation
                if not self._can_interact(layer_value, feat_layer_value):
                    continue
                if feat_layer_value != layer_value: # Original check (maybe too strict if we allow cross-layer snapping within group?)
                    # The original code prevented snapping to different layers regardless of group.
                    # We should probably relax this to allow snapping within valid groups if that was the intent,
                    # BUT the user requirement is about isolation.
                    # If the original intent was "only snap to same layer", then isolation is moot.
                    # Assuming original intent was just an example or we want to allow cross-layer snapping now.
                    # Let's KEEP the original strictness if it was there, OR remove it if we want general snapping.
                    # Looking at original code: "if feat_layer_value != layer_value: continue"
                    # This means it ONLY snapped to the SAME layer.
                    # If so, group isolation is automatically satisfied (Layer A only snaps to Layer A).
                    # WAIT. If it only snaps to itself, then R vs C is never an issue.
                    # The user complaint implies that they ARE interacting.
                    # Ah, maybe the original code I read had that check but it was disabled or I misread context?
                    # Let's assume we want to allow snapping to ANY layer that is compatible.
                    # So I will REMOVE the "!= layer_value" check and replace it with _can_interact.
                    pass 
                
                # REPLACING the strict same-layer check with isolation check
                # if feat_layer_value != layer_value: continue  <-- REMOVED
                pass
            
            geom = feat.geometry()
            
            # Get all vertices (including intermediate ones)
            vertices_iter = geom.vertices()
            while vertices_iter.hasNext():
                v = vertices_iter.next()
                v_pt = QgsPointXY(v.x(), v.y())
                
                dist = dangle.distance(v_pt)
                
                if dist < 0.000001:  # Skip if it's the dangle itself
                    continue
                
                if dist < min_distance:
                    # Check if this vertex is NOT a dangle
                    v_key = (round(v.x(), 6), round(v.y(), 6))
                    if v_key in graph.nodes:
                        degree = len(graph.nodes[v_key])
                        if degree > 1:  # Not a dangle
                            min_distance = dist
                            best_vertex = v_pt
        
        return best_vertex
    
    def _find_nearby_dangles_for_fillet(self, dangle, layer, index, layer_value, layer_field, graph, processed_dangles):
        """
        Find other dangles within 2x tolerance for fillet calculation.
        Returns list of (dangle_point, direction_vector).
        """
        search_rect = QgsRectangle(
            dangle.x() - self.tolerance_snap * 2,
            dangle.y() - self.tolerance_snap * 2,
            dangle.x() + self.tolerance_snap * 2,
            dangle.y() + self.tolerance_snap * 2
        )
        
        candidate_fids = index.intersects(search_rect)
        
        nearby_dangles = []
        
        for fid in candidate_fids:
            feat = layer.getFeature(fid)
            if not feat.isValid():
                continue
            
            # Check layer match
            if layer_field:
                feat_layer_value = feat[layer_field]
                feat_layer_value = feat[layer_field]
                if not self._can_interact(layer_value, feat_layer_value):
                    continue
            
            geom = feat.geometry()
            if geom.isMultipart():
                parts = geom.asMultiPolyline()
            else:
                parts = [geom.asPolyline()]
            
            for part in parts:
                if len(part) < 2:
                    continue
                
                # Check start
                start_pt = QgsPointXY(part[0])
                start_key = (round(start_pt.x(), 6), round(start_pt.y(), 6))
                if start_key in graph.nodes and len(graph.nodes[start_key]) == 1:
                    if start_key != (round(dangle.x(), 6), round(dangle.y(), 6)):
                        if start_key not in processed_dangles:
                            dist = dangle.distance(start_pt)
                            if dist < self.tolerance_snap * 2:
                                direction = QgsVector(
                                    start_pt.x() - part[1].x(),
                                    start_pt.y() - part[1].y()
                                )
                                direction = self._normalize_vector(direction)
                                nearby_dangles.append((start_pt, direction))
                
                # Check end
                end_pt = QgsPointXY(part[-1])
                end_key = (round(end_pt.x(), 6), round(end_pt.y(), 6))
                if end_key in graph.nodes and len(graph.nodes[end_key]) == 1:
                    if end_key != (round(dangle.x(), 6), round(dangle.y(), 6)):
                        if end_key not in processed_dangles:
                            dist = dangle.distance(end_pt)
                            if dist < self.tolerance_snap * 2:
                                direction = QgsVector(
                                    end_pt.x() - part[-2].x(),
                                    end_pt.y() - part[-2].y()
                                )
                                direction = self._normalize_vector(direction)
                                nearby_dangles.append((end_pt, direction))
        
        return nearby_dangles
    
    def _get_dangle_info(self, layer, index, dangle):
        """
        Get the feature containing the dangle and its direction vector.
        Returns (feature, direction_vector) or (None, None)
        """
        search_rect = QgsRectangle(
            dangle.x() - 0.001, dangle.y() - 0.001,
            dangle.x() + 0.001, dangle.y() + 0.001
        )
        
        candidate_fids = index.intersects(search_rect)
        
        for fid in candidate_fids:
            feat = layer.getFeature(fid)
            if not feat.isValid():
                continue
            
            geom = feat.geometry()
            if geom.isMultipart():
                parts = geom.asMultiPolyline()
            else:
                parts = [geom.asPolyline()]
            
            for part in parts:
                if len(part) < 2:
                    continue
                
                start_pt = QgsPointXY(part[0])
                end_pt = QgsPointXY(part[-1])
                
                if start_pt.distance(dangle) < 0.001:
                    direction = QgsVector(start_pt.x() - part[1].x(), start_pt.y() - part[1].y())
                    return (feat, self._normalize_vector(direction))
                elif end_pt.distance(dangle) < 0.001:
                    direction = QgsVector(end_pt.x() - part[-2].x(), end_pt.y() - part[-2].y())
                    return (feat, self._normalize_vector(direction))
        
        return (None, None)
    
    def _normalize_vector(self, vec):
        """Normalize a vector."""
        length = vec.length()
        if length < 0.0001:
            return QgsVector(0, 0)
        return QgsVector(vec.x() / length, vec.y() / length)
    
    def _calculate_angle(self, dir1, dir2):
        """Calculate angle between two direction vectors in degrees."""
        dot = abs(dir1.x() * dir2.x() + dir1.y() * dir2.y())
        angle = math.acos(min(1.0, dot)) * 180.0 / math.pi
        return angle
    
    def _calculate_segment_intersection(self, p1, dir1, p2, dir2):
        """
        Calculate intersection point of two line segments defined by point + direction.
        Returns QgsPointXY or None if parallel.
        """
        denom = dir1.x() * dir2.y() - dir1.y() * dir2.x()
        
        if abs(denom) < 0.0001:  # Parallel
            return None
        
        dx = p2.x() - p1.x()
        dy = p2.y() - p1.y()
        
        t = (dx * dir2.y() - dy * dir2.x()) / denom
        
        intersection = QgsPointXY(p1.x() + t * dir1.x(), p1.y() + t * dir1.y())
        
        return intersection
    
    def _is_valid_fillet(self, intersection, dangle1, dangle2):
        """
        Check if a fillet intersection is valid (not too much deformation).
        """
        dist1 = dangle1.distance(intersection)
        dist2 = dangle2.distance(intersection)
        
        max_deformation = self.tolerance_snap * self.max_deformation_factor
        
        if dist1 > max_deformation or dist2 > max_deformation:
            return False
        
        return True
    
    def _snap_dangle_to_point(self, layer, index, dangle, target_point):
        """
        Move a dangle endpoint to a target point.
        """
        search_rect = QgsRectangle(
            dangle.x() - 0.001, dangle.y() - 0.001,
            dangle.x() + 0.001, dangle.y() + 0.001
        )
        
        candidate_fids = index.intersects(search_rect)
        
        for fid in candidate_fids:
            feat = layer.getFeature(fid)
            if not feat.isValid():
                continue
            
            geom = feat.geometry()
            if geom.isMultipart():
                parts = geom.asMultiPolyline()
            else:
                parts = [geom.asPolyline()]
            
            modified = False
            new_parts = []
            
            for part in parts:
                if len(part) < 2:
                    new_parts.append(part)
                    continue
                
                new_part = list(part)
                
                start_pt = QgsPointXY(part[0])
                end_pt = QgsPointXY(part[-1])
                
                if start_pt.distance(dangle) < 0.001:
                    new_part[0] = target_point
                    modified = True
                elif end_pt.distance(dangle) < 0.001:
                    new_part[-1] = target_point
                    modified = True
                
                new_parts.append(new_part)
            
            if modified:
                if geom.isMultipart():
                    new_geom = QgsGeometry.fromMultiPolylineXY(new_parts)
                else:
                    new_geom = QgsGeometry.fromPolylineXY(new_parts[0])
                
                layer.changeGeometry(fid, new_geom)
                return True
        
        return False
    
    def _find_receiver_line(self, dangle, dangle_direction, layer, index, layer_value, layer_field, graph):
        """
        Find a receiver line to extend the dangle to.
        Returns (receiver_fid, intersection_point) or None
        """
        # Search for lines in the direction of the dangle
        search_rect = QgsRectangle(
            dangle.x() - self.tolerance_extension,
            dangle.y() - self.tolerance_extension,
            dangle.x() + self.tolerance_extension,
            dangle.y() + self.tolerance_extension
        )
        
        candidate_fids = index.intersects(search_rect)
        
        best_intersection = None
        best_fid = None
        min_distance = self.tolerance_extension
        
        for fid in candidate_fids:
            feat = layer.getFeature(fid)
            if not feat.isValid():
                continue
            
            # Check layer match
            if layer_field:
                feat_layer_value = feat[layer_field]
                feat_layer_value = feat[layer_field]
                if not self._can_interact(layer_value, feat_layer_value):
                    continue
            
            geom = feat.geometry()
            if geom.isMultipart():
                parts = geom.asMultiPolyline()
            else:
                parts = [geom.asPolyline()]
            
            for part in parts:
                if len(part) < 2:
                    continue
                
                # Check if this line contains the dangle itself (skip)
                start_pt = QgsPointXY(part[0])
                end_pt = QgsPointXY(part[-1])
                if start_pt.distance(dangle) < 0.001 or end_pt.distance(dangle) < 0.001:
                    continue
                
                # Calculate intersection of dangle direction with each segment
                for i in range(len(part) - 1):
                    seg_start = QgsPointXY(part[i])
                    seg_end = QgsPointXY(part[i + 1])
                    
                    # Check angle alignment (within 30 degrees)
                    seg_direction = QgsVector(seg_end.x() - seg_start.x(), seg_end.y() - seg_start.y())
                    seg_direction = self._normalize_vector(seg_direction)
                    
                    angle = self._calculate_angle(dangle_direction, seg_direction)
                    if angle > 30.0:  # Not aligned enough
                        continue
                    
                    # Calculate intersection
                    intersection = self._intersect_ray_with_segment(
                        dangle, dangle_direction, seg_start, seg_end
                    )
                    
                    if intersection:
                        dist = dangle.distance(intersection)
                        
                        # Validate distance
                        if dist < 0.001:  # Too close (self)
                            continue
                        
                        if dist > self.tolerance_extension:
                            continue
                        
                        # Check that intersection is not too close to existing vertices
                        if intersection.distance(seg_start) < self.min_length:
                            continue
                        if intersection.distance(seg_end) < self.min_length:
                            continue
                        
                        # Valid candidate
                        if dist < min_distance:
                            min_distance = dist
                            best_intersection = intersection
                            best_fid = fid
        
        if best_intersection and best_fid:
            return (best_fid, best_intersection)
        
        return None
    
    def _intersect_ray_with_segment(self, ray_origin, ray_direction, seg_start, seg_end):
        """
        Calculate intersection of a ray with a line segment.
        Returns QgsPointXY or None
        """
        # Segment direction
        seg_dir = QgsVector(seg_end.x() - seg_start.x(), seg_end.y() - seg_start.y())
        seg_length = seg_dir.length()
        
        if seg_length < 0.0001:
            return None
        
        seg_dir = QgsVector(seg_dir.x() / seg_length, seg_dir.y() / seg_length)
        
        # Calculate intersection using parametric equations
        # Ray: P = ray_origin + t * ray_direction (t >= 0)
        # Segment: Q = seg_start + s * seg_dir (0 <= s <= seg_length)
        
        denom = ray_direction.x() * seg_dir.y() - ray_direction.y() * seg_dir.x()
        
        if abs(denom) < 0.0001:  # Parallel or collinear
            return None
        
        dx = seg_start.x() - ray_origin.x()
        dy = seg_start.y() - ray_origin.y()
        
        t = (dx * seg_dir.y() - dy * seg_dir.x()) / denom
        s = (dx * ray_direction.y() - dy * ray_direction.x()) / (-denom)
        
        # Check if intersection is valid
        if t < 0:  # Ray goes backwards
            return None
        
        if s < 0 or s > seg_length:  # Outside segment
            return None
        
        # Calculate intersection point
        intersection = QgsPointXY(
            ray_origin.x() + t * ray_direction.x(),
            ray_origin.y() + t * ray_direction.y()
        )
        
        return intersection
    
    def _split_line_at_point(self, layer, fid, point):
        """
        Split a line at a given point, creating a new vertex.
        """
        feat = layer.getFeature(fid)
        if not feat.isValid():
            return False
        
        geom = feat.geometry()
        
        if geom.isMultipart():
            parts = geom.asMultiPolyline()
        else:
            parts = [geom.asPolyline()]
        
        modified = False
        new_parts = []
        
        for part in parts:
            if len(part) < 2:
                new_parts.append(part)
                continue
            
            # Find the closest segment to the point
            closest_seg_idx = -1
            min_dist = float('inf')
            
            for i in range(len(part) - 1):
                seg_geom = QgsGeometry.fromPolylineXY([part[i], part[i + 1]])
                dist = seg_geom.distance(QgsGeometry.fromPointXY(point))
                if dist < min_dist:
                    min_dist = dist
                    closest_seg_idx = i
            
            # If point is on this segment, split it
            if closest_seg_idx >= 0 and min_dist < 0.001:
                new_part = list(part[:closest_seg_idx + 1])
                new_part.append(point)
                new_part.extend(part[closest_seg_idx + 1:])
                new_parts.append(new_part)
                modified = True
            else:
                new_parts.append(part)
        
        if modified:
            if geom.isMultipart():
                new_geom = QgsGeometry.fromMultiPolylineXY(new_parts)
            else:
                new_geom = QgsGeometry.fromPolylineXY(new_parts[0])
            
            layer.changeGeometry(fid, new_geom)
            return True
        
        return False
    def _can_interact(self, layer1, layer2):
        """
        Check if two layers are allowed to interact based on group isolation rules.
        R_only can interact with R_only and Common.
        C_only can interact with C_only and Common.
        Common can interact with everything.
        R_only cannot interact with C_only.
        """
        if not layer1 or not layer2:
            return True # Fallback if layer info missing
            
        # Normalize to avoid case issues if needed, but assuming exact match from UI
        l1 = layer1
        l2 = layer2
        
        is_r1 = l1 in self.r_only
        is_c1 = l1 in self.c_only
        is_r2 = l2 in self.r_only
        is_c2 = l2 in self.c_only
        
        if is_r1 and is_c2: return False
        if is_c1 and is_r2: return False
        
        return True
