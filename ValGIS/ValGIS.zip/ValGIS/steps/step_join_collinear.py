import processing
import os
from qgis.core import (
    QgsVectorLayer, 
    QgsFeature, 
    QgsSpatialIndex, 
    QgsGeometry, 
    QgsPointXY, 
    QgsRectangle,
    QgsVector
)
from ..helpers.layer_utils import clean_and_save_layer
import math

class StepJoinCollinear:
    def __init__(self):
        pass

    def run(self, layer, output_dir, filename="Joined.shp", tolerance=0.001, angle_tolerance=15.0, log_callback=None, skip_snap=False, log_helper=None):
        """
        Joins touching lines with the same 'Layer' attribute value.
        Uses custom snapping (endpoints only, same layer) + dissolve.
        
        Args:
            tolerance: Distance threshold for snapping endpoints (default 0.001m = 1mm)
            angle_tolerance: Maximum angle for collinear detection (default 15.0°)
            log_callback: Optional callback function for logging
            skip_snap: If True, skips internal snap operations (default False)
            log_helper: Optional LogHelper instance
        """
        def log(msg):
            if log_callback:
                log_callback(msg)
        
        # Find the 'Layer' field (case-insensitive)
        fields = layer.fields().names()
        layer_field = next((f for f in fields if f.lower() == 'layer'), None)
        
        fixed = layer
        layer_name = layer.name()
        
        log(f"Total features antes de unir: {fixed.featureCount()}")
        
        if not skip_snap:
            # 1. Custom Snap: Endpoints to closest Endpoint (Same Layer)
            log(f"Ajustando extremos a extremos cercanos (mismo Layer, tol: {tolerance}m, ang: {angle_tolerance}°)...")
            self.snap_endpoints_to_endpoints(fixed, tolerance, layer_field, log, angle_tolerance, log_helper, layer_name)
            
            # 1.2. Fictional Intersection Snap for paired dangles
            log(f"Ajustando pares de colgados a intersección ficticia...")
            self.snap_paired_dangles_to_intersection(fixed, tolerance, layer_field, log, log_helper, layer_name)
        else:
            log("Snap interno deshabilitado (skip_snap=True) - Las geometrías ya deben estar ajustadas.")
        
        snapped = fixed
        
        # 1.5. Fix geometries after snap (may create invalid geometries)
        try:
            snapped = processing.run("native:fixgeometries", {
                'INPUT': snapped,
                'OUTPUT': 'memory:'
            })['OUTPUT']
            log("Geometrías reparadas tras snap.")
        except Exception as e:
            log(f"Advertencia: No se pudieron reparar geometrías: {e}")
        
        # If no Layer field, just dissolve everything
        if not layer_field:
            log("No se encontró campo 'Layer', disolviendo todas las líneas...")
            
            try:
                dissolved = processing.run("native:dissolve", {
                    'INPUT': snapped,
                    'OUTPUT': 'memory:'
                })['OUTPUT']
                
                single_parts = processing.run("native:multiparttosingleparts", {
                    'INPUT': dissolved,
                    'OUTPUT': 'memory:'
                })['OUTPUT']
                
                log(f"Total features después de unir: {single_parts.featureCount()}")
                
                # Assign UUID to features without UUID
                import uuid
                from qgis.core import QgsField
                from PyQt5.QtCore import QVariant
                
                uuid_field_exists = 'UUID' in [f.name() for f in single_parts.fields()]
                if not uuid_field_exists:
                    single_parts.startEditing()
                    single_parts.addAttribute(QgsField("UUID", QVariant.String, len=50))
                    single_parts.commitChanges()
                
                single_parts.startEditing()
                uuid_field_idx = single_parts.fields().indexOf('UUID')
                for feature in single_parts.getFeatures():
                    if not feature['UUID']:
                        single_parts.changeAttributeValue(feature.id(), uuid_field_idx, str(uuid.uuid4()))
                single_parts.commitChanges()
                
                output_path = os.path.join(output_dir, filename)
                result_layer, _ = clean_and_save_layer(single_parts, output_path)
                return result_layer
            except Exception as e:
                log(f"Error en dissolve global: {e}")
                return snapped
        
        # 2. DISSOLVE by Layer field (merges connected lines with same Layer value)
        log(f"Disolviendo líneas agrupadas por campo '{layer_field}'...")
        
        try:
            dissolved = processing.run("native:dissolve", {
                'INPUT': snapped,
                'FIELD': [layer_field],
                'OUTPUT': 'memory:'
            })['OUTPUT']
            
            log(f"Features después de dissolve: {dissolved.featureCount()}")
            
            # 3. Convert multipart to singlepart
            single_parts = processing.run("native:multiparttosingleparts", {
                'INPUT': dissolved,
                'OUTPUT': 'memory:'
            })['OUTPUT']
            
            log(f"Total features después de unir: {single_parts.featureCount()}")
            
        except Exception as e:
            log(f"Error en dissolve: {e}, usando capa original")
            single_parts = snapped
        
        # Assign UUID to features without UUID
        import uuid
        from qgis.core import QgsField
        from PyQt5.QtCore import QVariant
        
        uuid_field_exists = 'UUID' in [f.name() for f in single_parts.fields()]
        if not uuid_field_exists:
            single_parts.startEditing()
            single_parts.addAttribute(QgsField("UUID", QVariant.String, len=50))
            single_parts.commitChanges()
        
        single_parts.startEditing()
        uuid_field_idx = single_parts.fields().indexOf('UUID')
        for feature in single_parts.getFeatures():
            if not feature['UUID']:
                single_parts.changeAttributeValue(feature.id(), uuid_field_idx, str(uuid.uuid4()))
        single_parts.commitChanges()
        
        output_path = os.path.join(output_dir, filename)
        result_layer, _ = clean_and_save_layer(single_parts, output_path)
        return result_layer

    def snap_endpoints_to_endpoints(self, layer, tolerance, layer_field, log_callback=None, angle_tolerance=15.0, log_helper=None, layer_name=""):
        """
        Snaps endpoints of lines to the closest ENDPOINT of any feature in the layer within tolerance.
        """
        layer.startEditing()
        
        index = QgsSpatialIndex(layer.getFeatures())
        features = {f.id(): f for f in layer.getFeatures()}
        
        count_snapped = 0
        
        for fid, feat in features.items():
            geom = feat.geometry()
            if not geom or geom.isEmpty(): continue
            
            current_layer_val = feat[layer_field] if layer_field else None
            
            if not geom.isMultipart():
                polylines = [geom.asPolyline()]
            else:
                polylines = geom.asMultiPolyline()
            
            modified_feat = False
            new_polylines = []
            
            for poly in polylines:
                if len(poly) < 2:
                    new_polylines.append(poly)
                    continue
                
                new_poly = list(poly)
                
                # Check Start
                start_pt = QgsPointXY(poly[0])
                best_match = self._find_closest_endpoint(start_pt, index, features, fid, tolerance, layer_field, current_layer_val, angle_tolerance)
                if best_match and best_match.distance(start_pt) > 0.0000001:
                    new_poly[0] = best_match
                    modified_feat = True
                    count_snapped += 1
                    if log_helper:
                        log_helper.add_log_point(start_pt, "Unir Colineales", f"Snap inicio a {best_match.x():.3f},{best_match.y():.3f}", layer_name)
                
                # Check End
                end_pt = QgsPointXY(poly[-1])
                best_match = self._find_closest_endpoint(end_pt, index, features, fid, tolerance, layer_field, current_layer_val, angle_tolerance)
                if best_match and best_match.distance(end_pt) > 0.0000001:
                    new_poly[-1] = best_match
                    modified_feat = True
                    count_snapped += 1
                    if log_helper:
                        log_helper.add_log_point(end_pt, "Unir Colineales", f"Snap fin a {best_match.x():.3f},{best_match.y():.3f}", layer_name)
                    
                new_polylines.append(new_poly)
            
            if modified_feat:
                if not geom.isMultipart():
                    new_geom = QgsGeometry.fromPolylineXY(new_polylines[0])
                else:
                    new_geom = QgsGeometry.fromMultiPolylineXY(new_polylines)
                
                layer.changeGeometry(fid, new_geom)
        
        layer.commitChanges()
        if log_callback:
            log_callback(f"Snap estricto (Extremo-Extremo, Mismo Layer): {count_snapped} ajustes.")

    def _find_closest_endpoint(self, point, index, features, current_fid, tolerance, layer_field, current_layer_val, angle_tolerance=15.0):
        """
        Find closest endpoint with same Layer value.
        Only snaps if the lines are nearly collinear (angle < angle_tolerance degrees).
        """
        current_feat = features[current_fid]
        current_geom = current_feat.geometry()
        
        if current_geom.isMultipart():
            current_parts = current_geom.asMultiPolyline()
        else:
            current_parts = [current_geom.asPolyline()]
        
        current_direction = None
        for part in current_parts:
            if len(part) < 2:
                continue
            start = QgsPointXY(part[0])
            end = QgsPointXY(part[-1])
            
            if start.distance(point) < 0.001:
                current_direction = QgsVector(start.x() - part[1].x(), start.y() - part[1].y())
                break
            elif end.distance(point) < 0.001:
                current_direction = QgsVector(end.x() - part[-2].x(), end.y() - part[-2].y())
                break
        
        if not current_direction or current_direction.length() < 0.0001:
            return None
        
        current_direction = QgsVector(
            current_direction.x() / current_direction.length(),
            current_direction.y() / current_direction.length()
        )
        
        rect = QgsRectangle(point.x()-tolerance, point.y()-tolerance, point.x()+tolerance, point.y()+tolerance)
        candidate_ids = index.intersects(rect)
        
        best_pt = None
        min_dist = tolerance
        
        for cid in candidate_ids:
            if cid == current_fid: continue 
            
            feat = features[cid]
            
            if layer_field:
                cand_val = feat[layer_field]
                if cand_val != current_layer_val:
                    continue
            
            geom = feat.geometry()
            
            if geom.isMultipart():
                parts = geom.asMultiPolyline()
            else:
                parts = [geom.asPolyline()]
            
            for part in parts:
                if not part or len(part) < 2: continue
                
                # Check Start
                p_start = QgsPointXY(part[0])
                dist_start = point.distance(p_start)
                if dist_start < min_dist:
                    cand_dir = QgsVector(p_start.x() - part[1].x(), p_start.y() - part[1].y())
                    cand_len = cand_dir.length()
                    if cand_len > 0.0001:
                        cand_dir = QgsVector(cand_dir.x() / cand_len, cand_dir.y() / cand_len)
                        
                        dot = abs(current_direction.x() * cand_dir.x() + current_direction.y() * cand_dir.y())
                        angle = math.acos(min(1.0, dot)) * 180.0 / math.pi
                        
                        if angle < angle_tolerance:
                            min_dist = dist_start
                            best_pt = p_start
                
                # Check End
                p_end = QgsPointXY(part[-1])
                dist_end = point.distance(p_end)
                if dist_end < min_dist:
                    cand_dir = QgsVector(p_end.x() - part[-2].x(), p_end.y() - part[-2].y())
                    cand_len = cand_dir.length()
                    if cand_len > 0.0001:
                        cand_dir = QgsVector(cand_dir.x() / cand_len, cand_dir.y() / cand_len)
                        
                        dot = abs(current_direction.x() * cand_dir.x() + current_direction.y() * cand_dir.y())
                        angle = math.acos(min(1.0, dot)) * 180.0 / math.pi
                        
                        if angle < angle_tolerance:
                            min_dist = dist_end
                            best_pt = p_end
        
        return best_pt

    def snap_paired_dangles_to_intersection(self, layer, tolerance, layer_field, log_callback=None, log_helper=None, layer_name=""):
        """
        Detects pairs of nearby dangles and snaps them to their fictional intersection point.
        """
        layer.startEditing()
        
        index = QgsSpatialIndex(layer.getFeatures())
        features = {f.id(): f for f in layer.getFeatures()}
        
        processed_pairs = set()
        count_snapped = 0
        
        for fid, feat in features.items():
            geom = feat.geometry()
            if not geom or geom.isEmpty(): continue
            
            current_layer_val = feat[layer_field] if layer_field else None
            
            if not geom.isMultipart():
                polylines = [geom.asPolyline()]
            else:
                polylines = geom.asMultiPolyline()
            
            modified_feat = False
            new_polylines = []
            
            for poly_idx, poly in enumerate(polylines):
                if len(poly) < 2:
                    new_polylines.append(poly)
                    continue
                
                new_poly = list(poly)
                
                # Check start
                start_pt = QgsPointXY(poly[0])
                pair_key_start = (fid, poly_idx, 0)
                
                if pair_key_start not in processed_pairs:
                    result = self._find_and_calculate_intersection(
                        start_pt, poly, True, fid, index, features, tolerance, layer_field, current_layer_val
                    )
                    if result:
                        other_fid, other_poly_idx, other_is_start, intersection = result
                        pair_key_other = (other_fid, other_poly_idx, 0 if other_is_start else 1)
                        
                        new_poly[0] = intersection
                        modified_feat = True
                        count_snapped += 1
                        
                        processed_pairs.add(pair_key_start)
                        processed_pairs.add(pair_key_other)
                        
                        self._update_other_feature_endpoint(layer, features, other_fid, other_poly_idx, other_is_start, intersection)
                        
                        if log_helper:
                             log_helper.add_log_point(start_pt, "Unir Colineales", "Intersección ficticia", layer_name)
                
                # Check end
                end_pt = QgsPointXY(poly[-1])
                pair_key_end = (fid, poly_idx, 1)
                
                if pair_key_end not in processed_pairs:
                    result = self._find_and_calculate_intersection(
                        end_pt, poly, False, fid, index, features, tolerance, layer_field, current_layer_val
                    )
                    if result:
                        other_fid, other_poly_idx, other_is_start, intersection = result
                        pair_key_other = (other_fid, other_poly_idx, 0 if other_is_start else 1)
                        
                        new_poly[-1] = intersection
                        modified_feat = True
                        count_snapped += 1
                        
                        processed_pairs.add(pair_key_end)
                        processed_pairs.add(pair_key_other)
                        
                        self._update_other_feature_endpoint(layer, features, other_fid, other_poly_idx, other_is_start, intersection)
                        
                        if log_helper:
                             log_helper.add_log_point(end_pt, "Unir Colineales", "Intersección ficticia", layer_name)
                
                new_polylines.append(new_poly)
            
            if modified_feat:
                if not geom.isMultipart():
                    new_geom = QgsGeometry.fromPolylineXY(new_polylines[0])
                else:
                    new_geom = QgsGeometry.fromMultiPolylineXY(new_polylines)
                
                layer.changeGeometry(fid, new_geom)
        
        layer.commitChanges()
        if log_callback:
            log_callback(f"Pares de colgados ajustados a intersección: {count_snapped} ajustes.")
    
    def _find_and_calculate_intersection(self, point, poly, is_start, current_fid, index, features, tolerance, layer_field, current_layer_val):
        """Find nearby dangle and calculate fictional intersection."""
        if is_start:
            if len(poly) < 2: return None
            direction = QgsVector(poly[0].x() - poly[1].x(), poly[0].y() - poly[1].y())
        else:
            if len(poly) < 2: return None
            direction = QgsVector(poly[-1].x() - poly[-2].x(), poly[-1].y() - poly[-2].y())
        
        dir_len = direction.length()
        if dir_len < 0.0001: return None
        direction = QgsVector(direction.x() / dir_len, direction.y() / dir_len)
        
        rect = QgsRectangle(point.x()-tolerance, point.y()-tolerance, point.x()+tolerance, point.y()+tolerance)
        candidate_ids = index.intersects(rect)
        
        for cid in candidate_ids:
            if cid == current_fid: continue
            
            feat = features[cid]
            
            if layer_field:
                cand_val = feat[layer_field]
                if cand_val != current_layer_val:
                    continue
            
            geom = feat.geometry()
            if geom.isMultipart():
                parts = geom.asMultiPolyline()
            else:
                parts = [geom.asPolyline()]
            
            for part_idx, part in enumerate(parts):
                if not part or len(part) < 2: continue
                
                p_start = QgsPointXY(part[0])
                dist_start = point.distance(p_start)
                if dist_start < tolerance and dist_start > 0.0001:
                    other_dir = QgsVector(p_start.x() - part[1].x(), p_start.y() - part[1].y())
                    other_len = other_dir.length()
                    if other_len > 0.0001:
                        other_dir = QgsVector(other_dir.x() / other_len, other_dir.y() / other_len)
                        intersection = self._calculate_line_intersection(point, direction, p_start, other_dir, tolerance)
                        if intersection:
                            return (cid, part_idx, True, intersection)
                
                p_end = QgsPointXY(part[-1])
                dist_end = point.distance(p_end)
                if dist_end < tolerance and dist_end > 0.0001:
                    other_dir = QgsVector(p_end.x() - part[-2].x(), p_end.y() - part[-2].y())
                    other_len = other_dir.length()
                    if other_len > 0.0001:
                        other_dir = QgsVector(other_dir.x() / other_len, other_dir.y() / other_len)
                        intersection = self._calculate_line_intersection(point, direction, p_end, other_dir, tolerance)
                        if intersection:
                            return (cid, part_idx, False, intersection)
        
        return None
    
    def _calculate_line_intersection(self, p1, dir1, p2, dir2, max_distance):
        """Calculate intersection of two rays."""
        det = dir1.x() * (-dir2.y()) - dir1.y() * (-dir2.x())
        
        if abs(det) < 0.0001:
            return None
        
        dx = p2.x() - p1.x()
        dy = p2.y() - p1.y()
        
        t1 = (dx * (-dir2.y()) - dy * (-dir2.x())) / det
        
        intersection = QgsPointXY(p1.x() + t1 * dir1.x(), p1.y() + t1 * dir1.y())
        
        dist1 = intersection.distance(p1)
        dist2 = intersection.distance(p2)
        
        if dist1 > max_distance * 2 or dist2 > max_distance * 2:
            return None
        
        if t1 < 0:
            return None
        
        return intersection
    
    def _update_other_feature_endpoint(self, layer, features, fid, poly_idx, is_start, new_point):
        """Update endpoint of another feature."""
        feat = features[fid]
        geom = feat.geometry()
        
        if geom.isMultipart():
            polylines = geom.asMultiPolyline()
        else:
            polylines = [geom.asPolyline()]
        
        new_polylines = []
        for idx, poly in enumerate(polylines):
            if idx == poly_idx:
                new_poly = list(poly)
                if is_start:
                    new_poly[0] = new_point
                else:
                    new_poly[-1] = new_point
                new_polylines.append(new_poly)
            else:
                new_polylines.append(poly)
        
        if not geom.isMultipart():
            new_geom = QgsGeometry.fromPolylineXY(new_polylines[0])
        else:
            new_geom = QgsGeometry.fromMultiPolylineXY(new_polylines)
        
        layer.changeGeometry(fid, new_geom)
        features[fid] = layer.getFeature(fid)
