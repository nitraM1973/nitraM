import math
import time
from qgis.core import QgsPointXY, QgsSpatialIndex, QgsRectangle, QgsGeometry, QgsVector, QgsFeature
from ..topology.graph import Graph


class CorrectionStrategy:
    """Enumeration of correction strategies for dangle groups."""
    INTERSECTION = "intersection"  # Fictional intersection (2 dangles pointing at each other)
    COMMON_NODE = "common_node"    # Common node (centroid of multiple dangles)
    CHAMFER = "chamfer"            # Chamfer (90° corner)
    SNAP_TO_LINE = "snap_to_line"  # Snap to nearby receiver line
    NONE = "none"                  # Cannot be corrected


class Dangle:
    """Represents a dangling endpoint."""
    def __init__(self, point, direction, fid, is_start, layer_value, poly_idx=0):
        self.point = point          # QgsPointXY
        self.direction = direction  # QgsVector (normalized)
        self.fid = fid             # Feature ID
        self.is_start = is_start   # bool
        self.layer_value = layer_value  # Value of Layer field
        self.poly_idx = poly_idx   # Part index (for multipart)


class DangleGroup:
    """Represents a group of dangles that should be corrected together."""
    def __init__(self, dangles):
        self.dangles = dangles      # List[Dangle]
        self.strategy = CorrectionStrategy.NONE
        self.target_point = None    # QgsPointXY


class StepSmartSnap:
    def __init__(self):
        self.layer_spatial_index = None  # Cache for layer spatial index
        self.features_map = None         # Cache for features
    
    def run(self, layer, tolerance, layer_field, angle_tolerance, log_callback=None, log_helper=None):
        """
        Smart snap: analyzes all dangles as groups and applies optimal correction strategy.
        
        OPTIMIZED VERSION with performance improvements:
        - Single spatial index creation for layer (not per dangle)
        - Pre-cached features map
        - Spatial index for dangle grouping (O(n log n) instead of O(n²))
        - Cached geometries
        - Performance measurement and progress logging
        
        New approach (4 phases):
        1. Detection: Identify ALL dangles first
        2. Grouping: Group nearby dangles that can be resolved together
        3. Strategy: Determine best correction strategy for each group
        4. Correction: Apply correction atomically for entire group
        
        Args:
            layer: The working layer
            tolerance: Maximum distance to search for endpoints
            layer_field: Name of the Layer attribute field
            angle_tolerance: Maximum angle (degrees) to consider lines as nearly collinear
            log_callback: Logging function
            log_helper: Optional LogHelper instance
        """
        start_time = time.time()
        
        def log(msg):
            if log_callback:
                log_callback(msg)
        
        # OPTIMIZATION 1: Pre-create spatial index ONCE for entire layer
        log("Preparando índices espaciales...")
        prep_start = time.time()
        self.layer_spatial_index = QgsSpatialIndex(layer.getFeatures())
        
        # OPTIMIZATION 2: Pre-load all features into dictionary
        self.features_map = {f.id(): f for f in layer.getFeatures()}
        prep_elapsed = time.time() - prep_start
        log(f"  Índices creados en {prep_elapsed:.2f}s")
        
        # PHASE 1: Detection
        log("Fase 1: Detectando dangles...")
        detect_start = time.time()
        dangles = self._detect_all_dangles(layer, layer_field)
        detect_elapsed = time.time() - detect_start
        log(f"  Detectados {len(dangles)} dangles en {detect_elapsed:.2f}s")
        
        if len(dangles) == 0:
            log("No se encontraron dangles.")
            total_elapsed = time.time() - start_time
            log(f"⏱️ Smart Snap completado en {total_elapsed:.2f}s (sin dangles)")
            return 0
        
        # PHASE 2: Grouping
        log("Fase 2: Agrupando dangles...")
        group_start = time.time()
        groups = self._group_dangles_optimized(dangles, tolerance, layer_field)
        group_elapsed = time.time() - group_start
        log(f"  Formados {len(groups)} grupos en {group_elapsed:.2f}s")
        
        # PHASE 3: Strategy Determination
        log("Fase 3: Determinando estrategias...")
        strategy_start = time.time()
        for i, group in enumerate(groups):
            if i % 100 == 0 and i > 0:
                log(f"  Procesando grupo {i}/{len(groups)}...")
            
            strategy, target = self._determine_strategy(group, layer, tolerance, angle_tolerance)
            group.strategy = strategy
            group.target_point = target
        
        strategy_elapsed = time.time() - strategy_start
        
        # Count strategies
        strategy_counts = {}
        for group in groups:
            strategy_counts[group.strategy] = strategy_counts.get(group.strategy, 0) + 1
        log(f"  Estrategias determinadas en {strategy_elapsed:.2f}s: {strategy_counts}")
        
        # PHASE 4: Atomic Correction
        log("Fase 4: Aplicando correcciones...")
        correction_start = time.time()
        layer.startEditing()
        corrected_groups = 0
        corrected_dangles = 0
        layer_name = layer.name()
        
        for i, group in enumerate(groups):
            if i % 100 == 0 and i > 0:
                log(f"  Corrigiendo grupo {i}/{len(groups)}...")
            
            if self._apply_group_correction(layer, group, log_helper, layer_name):
                corrected_groups += 1
                corrected_dangles += len(group.dangles)
        
        layer.commitChanges()
        correction_elapsed = time.time() - correction_start
        log(f"  Correcciones aplicadas en {correction_elapsed:.2f}s")
        
        total_elapsed = time.time() - start_time
        log(f"⏱️ Smart Snap completado en {total_elapsed:.2f}s: {corrected_groups} grupos ({corrected_dangles} dangles) corregidos")
        
        return corrected_groups

    def _detect_all_dangles(self, layer, layer_field):
        """Detect all dangles in the layer."""
        graph = Graph()
        
        # OPTIMIZATION: Use pre-cached features
        for fid, feature in self.features_map.items():
            geom = feature.geometry()
            if geom.isMultipart():
                parts = geom.asMultiPolyline()
            else:
                parts = [geom.asPolyline()]
            
            for idx, line in enumerate(parts):
                if len(line) >= 2:
                    u = (round(line[0].x(), 6), round(line[0].y(), 6))
                    v = (round(line[-1].x(), 6), round(line[-1].y(), 6))
                    graph.add_edge(u, v, {'fid': fid, 'part': idx})

        # OPTIMIZATION: Build edge map during graph construction would be better,
        # but keeping this for compatibility with Graph class
        edge_map = {}
        for u, v, data in graph.edges:
            edge_map[(u, v)] = data
            edge_map[(v, u)] = data

        dangles = []
        for node, neighbors in graph.nodes.items():
            if len(neighbors) == 1:
                # It's a dangle (degree 1)
                neighbor = neighbors[0]
                
                # Check if it's a loose object (isolated line)
                if len(graph.nodes[neighbor]) == 1:
                    continue
                
                # Get feature info
                edge_data = edge_map.get((node, neighbor))
                if not edge_data: 
                    continue
                
                fid = edge_data['fid']
                part_idx = edge_data['part']
                
                # OPTIMIZATION: Use pre-cached feature
                feature = self.features_map[fid]
                
                # Determine direction (vector pointing OUT from the line)
                pt = QgsPointXY(node[0], node[1])
                neighbor_pt = QgsPointXY(neighbor[0], neighbor[1])
                
                # Check if node is start or end of the line segment
                geom = feature.geometry()
                if geom.isMultipart():
                    line = geom.asMultiPolyline()[part_idx]
                else:
                    line = geom.asPolyline()
                
                is_start = False
                if QgsPointXY(line[0]).distance(pt) < 0.001:
                    is_start = True
                    p1 = line[0]
                    p2 = line[1]
                    direction = self._calculate_direction(p2, p1)
                else:
                    is_start = False
                    p1 = line[-1]
                    p2 = line[-2]
                    direction = self._calculate_direction(p2, p1)
                
                layer_val = feature[layer_field] if layer_field else "?"
                
                dangles.append(Dangle(pt, direction, fid, is_start, layer_val, part_idx))
        
        return dangles

    def _calculate_direction(self, p1, p2):
        """Calculate normalized vector from p1 to p2."""
        dx = p2.x() - p1.x()
        dy = p2.y() - p1.y()
        length = math.sqrt(dx*dx + dy*dy)
        if length > 0:
            return QgsVector(dx/length, dy/length)
        return QgsVector(0, 0)

    def _group_dangles_optimized(self, dangles, tolerance, layer_field):
        """
        OPTIMIZED: Group dangles using spatial index instead of O(n²) comparison.
        """
        if not dangles:
            return []
        
        # OPTIMIZATION: Create spatial index for dangles
        dangle_index = QgsSpatialIndex()
        dangle_features = {}
        
        for i, dangle in enumerate(dangles):
            # Create a temporary point feature for the spatial index
            feat = QgsFeature()
            feat.setId(i)
            feat.setGeometry(QgsGeometry.fromPointXY(dangle.point))
            dangle_features[i] = feat
            dangle_index.addFeature(feat)
        
        groups = []
        used_dangles = set()
        
        for i, d1 in enumerate(dangles):
            if i in used_dangles:
                continue
            
            current_group = [d1]
            used_dangles.add(i)
            
            # OPTIMIZATION: Use spatial index to find nearby dangles
            search_rect = QgsRectangle(
                d1.point.x() - tolerance, 
                d1.point.y() - tolerance,
                d1.point.x() + tolerance, 
                d1.point.y() + tolerance
            )
            
            candidate_ids = dangle_index.intersects(search_rect)
            
            for j in candidate_ids:
                if i == j or j in used_dangles:
                    continue
                
                d2 = dangles[j]
                if self._should_group(d1, d2, tolerance, layer_field):
                    current_group.append(d2)
                    used_dangles.add(j)
            
            groups.append(DangleGroup(current_group))
            
        return groups

    def _should_group(self, d1, d2, tolerance, layer_field):
        """Determine if two dangles should be grouped."""
        # 1. Distance check
        dist = d1.point.distance(d2.point)
        if dist > tolerance:
            return False
            
        # 2. Layer check (optional: only group same layer?)
        # For now, allow cross-layer snapping as it's usually desired in topology
        
        return True

    def _determine_strategy(self, group, layer, tolerance, angle_tolerance):
        """Determine the best correction strategy for a group."""
        dangles = group.dangles
        
        if len(dangles) == 1:
            # Single dangle: Try to snap to a nearby line (T-junction)
            # OPTIMIZATION: Pass pre-created spatial index
            return self._find_snap_to_line_strategy(dangles[0], layer, tolerance)
            
        elif len(dangles) == 2:
            # Pair of dangles
            d1, d2 = dangles[0], dangles[1]
            
            # Check 1: Intersection (Extension)
            intersection = self._calculate_intersection(d1, d2)
            if intersection:
                dist1 = d1.point.distance(intersection)
                dist2 = d2.point.distance(intersection)
                if dist1 <= tolerance and dist2 <= tolerance:
                     return CorrectionStrategy.INTERSECTION, intersection
            
            # Check 2: Common Node (Snap to midpoint)
            midpoint = QgsPointXY((d1.point.x() + d2.point.x())/2, (d1.point.y() + d2.point.y())/2)
            return CorrectionStrategy.COMMON_NODE, midpoint
            
        else:
            # > 2 dangles (Cluster)
            centroid = self._calculate_centroid([d.point for d in dangles])
            return CorrectionStrategy.COMMON_NODE, centroid
            
        return CorrectionStrategy.NONE, None

    def _find_snap_to_line_strategy(self, dangle, layer, tolerance):
        """
        OPTIMIZED: Try to find a line to snap to using pre-created spatial index.
        """
        # OPTIMIZATION: Use pre-created spatial index instead of creating new one
        search_rect = QgsRectangle(
            dangle.point.x() - tolerance, 
            dangle.point.y() - tolerance,
            dangle.point.x() + tolerance, 
            dangle.point.y() + tolerance
        )
        candidate_ids = self.layer_spatial_index.intersects(search_rect)
        
        best_snap = None
        min_dist = float('inf')
        
        for fid in candidate_ids:
            if fid == dangle.fid: 
                continue  # Don't snap to self
            
            # OPTIMIZATION: Use pre-cached feature
            feat = self.features_map[fid]
            geom = feat.geometry()
            
            # Find closest point on geometry
            closest_point = geom.closestSegmentWithContext(dangle.point)[1]
            dist = dangle.point.distance(closest_point)
            
            if dist < min_dist and dist <= tolerance:
                min_dist = dist
                best_snap = closest_point
        
        if best_snap:
            return CorrectionStrategy.SNAP_TO_LINE, best_snap
            
        return CorrectionStrategy.NONE, None

    def _calculate_intersection(self, d1, d2):
        """Calculate intersection of two ray vectors."""
        p1 = d1.point
        v1 = d1.direction
        p2 = d2.point
        v2 = d2.direction
        
        # Line 1: p1 + t*v1
        # Line 2: p2 + u*v2
        # Cross product 2D
        det = v1.x() * v2.y() - v1.y() * v2.x()
        
        if abs(det) < 1e-6:  # Parallel
            return None
            
        dx = p2.x() - p1.x()
        dy = p2.y() - p1.y()
        
        t = (dx * v2.y() - dy * v2.x()) / det
        u = (dx * v1.y() - dy * v1.x()) / det
        
        # Check if intersection is "in front" of both rays (t > 0, u > 0)
        if t > -0.001 and u > -0.001:
            x = p1.x() + t * v1.x()
            y = p1.y() + t * v1.y()
            return QgsPointXY(x, y)
            
        return None

    def _calculate_centroid(self, points):
        """Calculate centroid of points."""
        if not points: 
            return None
        sum_x = sum(p.x() for p in points)
        sum_y = sum(p.y() for p in points)
        return QgsPointXY(sum_x / len(points), sum_y / len(points))

    def _apply_group_correction(self, layer, group, log_helper=None, layer_name=""):
        """
        Phase 4: Apply correction for entire group atomically.
        
        Returns:
            bool: True if correction was applied, False otherwise
        """
        if group.strategy == CorrectionStrategy.NONE or not group.target_point:
            return False
        
        # Move all dangles in the group to the target point
        for dangle in group.dangles:
            self._move_endpoint(layer, dangle.fid, dangle.is_start, 
                              group.target_point, dangle.poly_idx, 
                              log_helper, layer_name, group.strategy)
        
        return True
    
    def _move_endpoint(self, layer, fid, is_start, new_point, poly_idx=0, log_helper=None, layer_name="", strategy=""):
        """Move an endpoint of a feature to a new position."""
        # OPTIMIZATION: Use pre-cached feature
        feat = self.features_map.get(fid)
        if not feat or not feat.isValid():
            return
        
        geom = feat.geometry()
        
        if geom.isMultipart():
            parts = geom.asMultiPolyline()
        else:
            parts = [geom.asPolyline()]
        
        modified = False
        new_parts = []
        original_point = None
        
        for idx, part in enumerate(parts):
            if len(part) < 2:
                new_parts.append(part)
                continue
            
            new_part = list(part)
            
            # Only modify the specific part index for multipart geometries
            if geom.isMultipart() and idx != poly_idx:
                new_parts.append(new_part)
                continue
            
            if is_start and QgsPointXY(part[0]).distance(new_point) > 0.000001:
                original_point = QgsPointXY(part[0])
                new_part[0] = new_point
                modified = True
            elif not is_start and QgsPointXY(part[-1]).distance(new_point) > 0.000001:
                original_point = QgsPointXY(part[-1])
                new_part[-1] = new_point
                modified = True
            
            new_parts.append(new_part)
        
        if modified:
            if geom.isMultipart():
                new_geom = QgsGeometry.fromMultiPolylineXY(new_parts)
            else:
                new_geom = QgsGeometry.fromPolylineXY(new_parts[0])
            
            layer.changeGeometry(fid, new_geom)
            
            # OPTIMIZATION: Update cached feature with new geometry
            self.features_map[fid].setGeometry(new_geom)
            
            if log_helper and original_point:
                log_helper.add_log_point(
                    new_point, 
                    "Smart Snap", 
                    f"Estrategia: {strategy}. Movido de {original_point.x():.3f},{original_point.y():.3f}", 
                    layer_name
                )

