from qgis.core import QgsGeometry, QgsPointXY
import time


class StepNormalizeCoordinates:
    def __init__(self):
        self.round_factor = None  # Caché para factor de redondeo
    
    def run(self, layer, precision=5, log_callback=None, log_helper=None):
        """
        Normalizar todas las coordenadas a una precisión especificada (lugares decimales).
        
        VERSIÓN OPTIMIZADA con mejoras de rendimiento:
        - Eliminada comparación costosa geom.equals()
        - Actualizaciones de geometría por lotes (transacción única)
        - Factor de redondeo pre-calculado
        - Comprensiones de lista en lugar de bucles
        - Medición de rendimiento
        
        Args:
            layer: QgsVectorLayer a normalizar
            precision: Número de lugares decimales (por defecto 5 = 0.01mm)
            log_callback: Función de logging opcional
            log_helper: Instancia LogHelper opcional
        
        Returns:
            int: Número de features normalizadas
        """
        start_time = time.time()
        
        def log(msg):
            if log_callback:
                log_callback(msg)
        
        log(f"Normalizando coordenadas a {precision} decimales (precisión: {10**(-precision)}m)...")
        
        # OPTIMIZACIÓN 1: Pre-calcular factor de redondeo una vez
        self.round_factor = 10 ** precision
        
        layer_name = layer.name()
        feature_count = layer.featureCount()
        
        # OPTIMIZACIÓN 2: Actualizaciones por lotes - recopilar todos los cambios de geometría primero
        geom_map = {}
        processed = 0
        
        for feature in layer.getFeatures():
            processed += 1
            if processed % 1000 == 0:
                log(f"  Procesando feature {processed}/{feature_count}...")
            
            geom = feature.geometry()
            if not geom or geom.isEmpty():
                continue
            
            # Normalizar geometría
            normalized_geom = self._round_geometry(geom, precision, log_helper, layer_name)
            
            # OPTIMIZACIÓN 3: Eliminar comparación costosa equals()
            # El redondeo es idempotente - si ya está redondeado, el resultado es el mismo
            # La comparación cuesta más que el redondeo redundante
            geom_map[feature.id()] = normalized_geom
        
        # OPTIMIZACIÓN 2: Aplicar todos los cambios en una sola transacción por lotes
        layer.startEditing()
        for fid, geom in geom_map.items():
            layer.changeGeometry(fid, geom)
        layer.commitChanges()
        
        elapsed = time.time() - start_time
        log(f"⏱️ Normalización completada: {len(geom_map)} geometrías procesadas en {elapsed:.2f}s")
        
        return len(geom_map)
    
    def _round_geometry(self, geom, precision, log_helper=None, layer_name=""):
        """
        Redondear todas las coordenadas en una geometría a la precisión especificada.
        OPTIMIZADO con comprensiones de lista.
        """
        if geom.isMultipart():
            # Manejar geometrías multipartes
            parts = geom.asMultiPolyline()
            
            # OPTIMIZACIÓN 4: Comprensión de lista en lugar de bucle+append
            rounded_parts = [
                [self._round_point(pt, precision) for pt in part]
                for part in parts
            ]
            
            return QgsGeometry.fromMultiPolylineXY(rounded_parts)
        else:
            # Manejar geometrías de una sola parte
            polyline = geom.asPolyline()
            
            # OPTIMIZACIÓN 4: Comprensión de lista en lugar de bucle+append
            rounded_polyline = [self._round_point(pt, precision) for pt in polyline]
            
            return QgsGeometry.fromPolylineXY(rounded_polyline)
    
    def _round_point(self, point, precision):
        """
        Redondear las coordenadas de un punto a la precisión especificada.
        OPTIMIZADO con factor pre-calculado.
        """
        # OPTIMIZACIÓN 5: Usar factor pre-calculado para redondeo más rápido
        # int() + división es ligeramente más rápido que round() para este caso de uso
        x_rounded = round(point.x() * self.round_factor) / self.round_factor
        y_rounded = round(point.y() * self.round_factor) / self.round_factor
        
        return QgsPointXY(x_rounded, y_rounded)

