import math
import time
from qgis.core import QgsGeometry, QgsPointXY, QgsSpatialIndex, QgsRectangle, QgsFeatureRequest
from ..helpers.layer_utils import purge_zero_length_features


class StepNormalizeCoordinates:
    def __init__(self):
        self.geometries_cache = {}  # O(N) cache de geometrías ligeras
        self.spatial_index = None

    def run(self, layer, precision=5, log_callback=None, log_helper=None, callback=None):
        """
        Normalizar coordenadas con Hardening Topológico (VERSIÓN NITRO 🚀).
        
        Optimizaciones para capas masivas (>180k elementos):
        1. Análisis de Frecuencia de Nodos: Solo busca snaps para extremos libres (dangles).
        2. Caché Geométrica Ligera: Solo almacena QgsGeometry, evitando objetos QgsFeature.
        3. Bulk Update: Actualización masiva de geometrías vía DataProvider para evitar overhead.
        4. Pruning de Caja Envolvente: Filtro rápido antes de proyección matemática.
        """
        start_time = time.time()
        
        def log(msg):
            if log_callback: log_callback(msg)
        
        grid_size = 10 ** (-precision)
        total_features = layer.featureCount()
        
        log(f"Iniciando Hardening Nitro (Total: {total_features} elementos)...")

        # --- FASE 1: INDEXACIÓN Y HASHING DE NODOS ---
        log("  [1/4] Indexando y analizando estructura de nodos...")
        self.spatial_index = QgsSpatialIndex()
        node_counts = {}  # (rounded_x, rounded_y) -> count
        
        # Iteración de una sola pasada para construir todo lo necesario
        processed = 0
        for feat in layer.getFeatures():
            processed += 1
            if processed % 5000 == 0 and callback:
                callback(processed, total_features * 4) # 4 fases
            
            fid = feat.id()
            geom = feat.geometry()
            if not geom or geom.isEmpty(): continue
            
            # 1. Guardar en índice espacial
            self.spatial_index.addFeature(feat)
            
            # 2. Cachear geometría (ligera)
            self.geometries_cache[fid] = geom
            
            # 3. Contar nodos (solo extremos de línea)
            if geom.isMultipart():
                parts = geom.asMultiPolyline()
            else:
                parts = [geom.asPolyline()]
            
            for poly in parts:
                if len(poly) < 2: continue
                for pt in [poly[0], poly[-1]]:
                    # Usamos 5 decimales para el hash de coincidencia nominal
                    key = (round(pt.x(), 5), round(pt.y(), 5))
                    node_counts[key] = node_counts.get(key, 0) + 1

        # --- FASE 2: DETECCIÓN DE SNAPS (HARDENING) ---
        log(f"  [2/4] Detectando uniones críticas en nodos libres...")
        snaps_to_apply = [] # List of dicts
        
        # Solo revisamos de nuevo la capa, pero con lógica de filtrado agresiva
        processed = 0
        for fid, geom in self.geometries_cache.items():
            processed += 1
            if processed % 5000 == 0 and callback:
                callback(total_features + processed, total_features * 4)
            
            if geom.isMultipart():
                parts = geom.asMultiPolyline()
            else:
                parts = [geom.asPolyline()]
            
            for p_idx, poly in enumerate(parts):
                if len(poly) < 2: continue
                
                # Solo analizamos extremos que NO estén ya conectados (count == 1)
                # Opcional: permitir count > 1 si queremos snaps de cluster, pero ralentiza.
                endpoints = [(poly[0], True), (poly[-1], False)]
                for pt, is_start in endpoints:
                    key = (round(pt.x(), 5), round(pt.y(), 5))
                    if node_counts.get(key, 0) > 1:
                        continue # Ya está conectado a algo, saltar.
                    
                    # Búsqueda espacial
                    search_rect = QgsRectangle(pt.x() - 0.001, pt.y() - 0.001, pt.x() + 0.001, pt.y() + 0.001)
                    candidates = self.spatial_index.intersects(search_rect)
                    
                    best_dist = 0.001001
                    best_snap = None
                    
                    for c_fid in candidates:
                        if c_fid == fid: continue
                        
                        c_geom = self.geometries_cache[c_fid]
                        # Filtro rápido de BB antes de geometría real
                        if not c_geom.boundingBox().intersects(search_rect):
                            continue
                            
                        res = c_geom.closestSegmentWithContext(pt)
                        closest_pt = res[1]
                        dist = pt.distance(closest_pt)
                        
                        if dist < best_dist and dist < 0.001:
                            best_dist = dist
                            best_snap = (c_fid, closest_pt)
                    
                    if best_snap:
                        snaps_to_apply.append({
                            'fid_e': fid, 'is_start': is_start, 'p_idx': p_idx,
                            'fid_t': best_snap[0], 'point': best_snap[1]
                        })

        # --- FASE 3: EJECUCIÓN DE TRANSFORMACIONES (HARDENING) ---
        log(f"  [3/4] Ejecutando sincronización de {len(snaps_to_apply)} uniones...")
        
        # Usamos un mapa de actualizaciones para el DataProvider
        updates_map = {} # fid -> QgsGeometry
        
        # A. Inyección en paredes
        # Agrupar inyecciones por destino
        injections = {}
        for snap in snaps_to_apply:
            fid_t = snap['fid_t']
            if fid_t not in injections: injections[fid_t] = []
            injections[fid_t].append(snap['point'])
            
        for fid_t, points in injections.items():
            geom = updates_map.get(fid_t, self.geometries_cache[fid_t])
            new_geom = QgsGeometry(geom)
            for p in points:
                res = new_geom.closestSegmentWithContext(p)
                v_idx = res[2]
                if QgsPointXY(new_geom.vertexAt(v_idx)).distance(p) > 1e-7 and \
                   QgsPointXY(new_geom.vertexAt(v_idx-1)).distance(p) > 1e-7:
                    new_geom.insertVertex(p.x(), p.y(), v_idx)
            updates_map[fid_t] = new_geom
            
        # B. Ajuste de extremos
        for snap in snaps_to_apply:
            fid_e = snap['fid_e']
            geom = updates_map.get(fid_e, self.geometries_cache[fid_e])
            
            if geom.isMultipart(): parts = geom.asMultiPolyline()
            else: parts = [geom.asPolyline()]
            
            poly = list(parts[snap['p_idx']])
            if snap['is_start']: poly[0] = snap['point']
            else: poly[-1] = snap['point']
            parts[snap['p_idx']] = poly
            
            new_geom = QgsGeometry.fromMultiPolylineXY(parts) if geom.isMultipart() else QgsGeometry.fromPolylineXY(parts[0])
            updates_map[fid_e] = new_geom
            
        # Aplicar cambios al proveedor de forma masiva
        if updates_map:
            layer.dataProvider().changeGeometryValues(updates_map)
            # Actualizar nuestra caché para la fase final
            for fid, new_geom in updates_map.items():
                self.geometries_cache[fid] = new_geom

        # --- FASE 4: REDONDEO FINAL ---
        log(f"  [4/4] Aplicando redondeo final a {precision} decimales...")
        final_updates = {}
        processed = 0
        errors = []
        
        for fid, geom in self.geometries_cache.items():
            processed += 1
            if processed % 5000 == 0 and callback:
                callback(total_features * 3 + processed, total_features * 4)
            
            new_geom = geom.snappedToGrid(grid_size, grid_size)
            if not new_geom.isGeosValid():
                errors.append({'id': fid, 'point': new_geom.centroid().asPoint()})
            
            final_updates[fid] = new_geom
            
        layer.dataProvider().changeGeometryValues(final_updates)
        
        # Limpiar
        purge_zero_length_features(layer, step_label="Normalizar Coordenadas", log_callback=log_callback)
        self.geometries_cache.clear()
        
        elapsed = time.time() - start_time
        log(f"⏱️ Hardening Nitro completado en {elapsed:.2f}s ({len(snaps_to_apply)} uniones tratadas)")
        
        return errors

