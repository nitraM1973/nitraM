from qgis.core import QgsGeometry, QgsPointXY

class StepFixIslands:
    def __init__(self):
        pass

    def detect(self, layer, log_callback=None):
        """
        Detects polygons with interior rings (islands).
        Supports both Polygon layers (direct check) and Line layers (via simulated polygonization).
        
        Args:
            layer: QgsVectorLayer to check.
            log_callback: Optional callback for logging.
            
        Returns:
            list: List of error dictionaries describing the islands found.
        """
        errors = []
        
        if not layer or not layer.isValid():
            return errors
            
        from qgis.core import QgsWkbTypes
        geom_type = layer.geometryType()
        
        # Case 1: Polygon Layer (Direct check)
        if geom_type == QgsWkbTypes.PolygonGeometry:
            feature_count = layer.featureCount()
            processed = 0
            
            for feature in layer.getFeatures():
                processed += 1
                geom = feature.geometry()
                
                if not geom:
                    continue
                    
                has_islands = False
                island_count = 0
                
                if geom.isMultipart():
                    polygons = geom.asMultiPolygon()
                    for poly in polygons:
                        if len(poly) > 1:
                            has_islands = True
                            island_count += len(poly) - 1
                else:
                    poly = geom.asPolygon()
                    if len(poly) > 1:
                        has_islands = True
                        island_count += len(poly) - 1
                
                if has_islands:
                    errors.append({
                        'id': feature.id(),
                        'uuid': feature['UUID'] if 'UUID' in feature.fields().names() else None,
                        'msg': f"Isla detectada: Polígono con {island_count} hueco(s) interior(es).",
                        'type': 'island',
                        'point': geom.centroid().asPoint(),
                        'island_count': island_count,
                        'layer_type': 'polygon'
                    })
                    
        # Case 2: Line Layer (Direct polygonization - Simple & Fast)
        elif geom_type == QgsWkbTypes.LineGeometry:
            if log_callback:
                log_callback("Capa de líneas detectada. Poligonizando para detectar islas...")
                
            import processing
            
            try:
                # Direct polygonization in memory
                result = processing.run("native:polygonize", {
                    'INPUT': layer,
                    'KEEP_FIELDS': False,
                    'OUTPUT': 'memory:'
                })
                poly_layer = result['OUTPUT']
                
                if not poly_layer or not poly_layer.isValid():
                    if log_callback:
                        log_callback("  Error en poligonización.")
                    return errors
                
                if log_callback:
                    log_callback(f"  Poligonización completada: {poly_layer.featureCount()} polígonos generados")
                    log_callback("  Analizando polígonos en busca de islas...")
                
                # Check each polygon for interior rings (islands)
                island_count = 0
                for feature in poly_layer.getFeatures():
                    geom = feature.geometry()
                    if not geom:
                        continue
                    
                    has_islands = False
                    num_islands = 0
                    
                    if geom.isMultipart():
                        polygons = geom.asMultiPolygon()
                        for poly in polygons:
                            if len(poly) > 1:  # Has interior rings
                                has_islands = True
                                num_islands += len(poly) - 1
                    else:
                        poly = geom.asPolygon()
                        if len(poly) > 1:  # Has interior rings
                            has_islands = True
                            num_islands += len(poly) - 1
                    
                    if has_islands:
                        island_count += 1
                        errors.append({
                            'id': None,
                            'msg': f"Isla detectada: Polígono con {num_islands} hueco(s) interior(es)",
                            'type': 'island',
                            'point': geom.centroid().asPoint(),
                            'island_count': num_islands,
                            'layer_type': 'line',
                            'simulated_poly_geom': geom
                        })
                
                if log_callback:
                    if island_count > 0:
                        log_callback(f"  ⚠️ Detectadas {island_count} islas en {poly_layer.featureCount()} polígonos")
                    else:
                        log_callback(f"  ✓ No se detectaron islas en {poly_layer.featureCount()} polígonos")
                        
            except Exception as e:
                if log_callback:
                    log_callback(f"  Error durante poligonización: {e}")
                
        if log_callback:
            log_callback(f"Detección de islas completada. Se encontraron {len(errors)} casos.")
            
        return errors

    def fix(self, layer, feature_id, error_data=None):
        """
        Fixes an island.
        - For Polygon layers: Splits the polygon.
        - For Line layers: Adds a cut line to break the island topology.
        """
        from qgis.core import QgsWkbTypes, QgsFeature, QgsGeometry, QgsPointXY
        import uuid
        
        geom_type = layer.geometryType()
        
        # --- CASE 1: POLYGON LAYER ---
        if geom_type == QgsWkbTypes.PolygonGeometry:
            feature = layer.getFeature(feature_id)
            if not feature.isValid():
                return False
                
            geom = feature.geometry()
            if not geom.isMultipart():
                polygons = [geom.asPolygon()]
            else:
                polygons = geom.asMultiPolygon()
                
            # Find the polygon part with the most interior rings (or the largest one)
            target_poly_idx = -1
            max_rings = 0
            
            for i, poly in enumerate(polygons):
                if len(poly) > 1: # Has interior rings
                    if len(poly) > max_rings:
                        max_rings = len(poly)
                        target_poly_idx = i
                        
            if target_poly_idx == -1:
                return False # No islands found
                
            # Get the target polygon (list of rings)
            poly_rings = polygons[target_poly_idx]
            exterior_ring = poly_rings[0]
            interior_rings = poly_rings[1:]
            
            # Find the largest interior ring to use as split center
            largest_inner_idx = -1
            max_area = -1.0
            
            for i, ring in enumerate(interior_rings):
                # Calculate area of ring (approximate)
                ring_geom = QgsGeometry.fromPolylineXY(ring)
                area = ring_geom.area()
                if area > max_area:
                    max_area = area
                    largest_inner_idx = i
                    
            if largest_inner_idx == -1:
                return False
                
            # Create cut line
            inner_ring_geom = QgsGeometry.fromPolylineXY(interior_rings[largest_inner_idx])
            center = inner_ring_geom.centroid().asPoint()
            
            outer_ring_geom = QgsGeometry.fromPolylineXY(exterior_ring)
            bbox = outer_ring_geom.boundingBox()
            
            y_min = bbox.yMinimum() - 1.0
            y_max = bbox.yMaximum() + 1.0
            
            cut_line = QgsGeometry.fromPolylineXY([
                QgsPointXY(center.x(), y_min),
                QgsPointXY(center.x(), y_max)
            ])
            
            cut_points = [QgsPointXY(center.x(), y_min), QgsPointXY(center.x(), y_max)]
            ret, new_geoms, topo_points = geom.splitGeometry(cut_points, False)
            
            if ret == 0: # Success
                layer.changeGeometry(feature_id, geom)
                fields = layer.fields()
                for new_geom in new_geoms:
                    new_feat = QgsFeature(fields)
                    new_feat.setGeometry(new_geom)
                    new_feat.setAttributes(feature.attributes())
                    idx = fields.indexFromName('UUID')
                    if idx != -1:
                        new_feat.setAttribute(idx, str(uuid.uuid4()))
                    layer.addFeature(new_feat)
                return True
            else:
                # Try horizontal cut
                x_min = bbox.xMinimum() - 1.0
                x_max = bbox.xMaximum() + 1.0
                
                cut_line_h = QgsGeometry.fromPolylineXY([
                    QgsPointXY(x_min, center.y()),
                    QgsPointXY(x_max, center.y())
                ])
                
                cut_points_h = [QgsPointXY(x_min, center.y()), QgsPointXY(x_max, center.y())]
                ret, new_geoms, topo_points = geom.splitGeometry(cut_points_h, False)
                
                if ret == 0:
                    layer.changeGeometry(feature_id, geom)
                    fields = layer.fields()
                    for new_geom in new_geoms:
                        new_feat = QgsFeature(fields)
                        new_feat.setGeometry(new_geom)
                        new_feat.setAttributes(feature.attributes())
                        idx = fields.indexFromName('UUID')
                        if idx != -1:
                            new_feat.setAttribute(idx, str(uuid.uuid4()))
                        layer.addFeature(new_feat)
                    return True
                    
            return False

        # --- CASE 2: LINE LAYER ---
        elif geom_type == QgsWkbTypes.LineGeometry:
            if not error_data or 'simulated_poly_geom' not in error_data:
                return False
                
            # Use the simulated polygon geometry to calculate the cut line
            sim_geom = error_data['simulated_poly_geom']
            
            # Extract rings from simulated geometry
            if sim_geom.isMultipart():
                polygons = sim_geom.asMultiPolygon()
            else:
                polygons = [sim_geom.asPolygon()]
                
            # Find target polygon (same logic as above)
            target_poly_idx = -1
            max_rings = 0
            for i, poly in enumerate(polygons):
                if len(poly) > 1:
                    if len(poly) > max_rings:
                        max_rings = len(poly)
                        target_poly_idx = i
            
            if target_poly_idx == -1: return False
            
            poly_rings = polygons[target_poly_idx]
            exterior_ring = poly_rings[0]
            interior_rings = poly_rings[1:]
            
            # Find largest inner ring
            largest_inner_idx = -1
            max_area = -1.0
            for i, ring in enumerate(interior_rings):
                ring_geom = QgsGeometry.fromPolylineXY(ring)
                area = ring_geom.area()
                if area > max_area:
                    max_area = area
                    largest_inner_idx = i
            
            if largest_inner_idx == -1: return False
            
            # Create cut line
            inner_ring_geom = QgsGeometry.fromPolylineXY(interior_rings[largest_inner_idx])
            center = inner_ring_geom.centroid().asPoint()
            
            outer_ring_geom = QgsGeometry.fromPolylineXY(exterior_ring)
            bbox = outer_ring_geom.boundingBox()
            
            # Vertical cut line
            y_min = bbox.yMinimum() - 0.1 # Extend slightly beyond
            y_max = bbox.yMaximum() + 0.1
            
            cut_line_geom = QgsGeometry.fromPolylineXY([
                QgsPointXY(center.x(), y_min),
                QgsPointXY(center.x(), y_max)
            ])
            
            # --- TOPOLOGICAL FIX ---
            # 1. Find intersecting features
            from qgis.core import QgsSpatialIndex
            index = QgsSpatialIndex(layer.getFeatures())
            candidate_ids = index.intersects(cut_line_geom.boundingBox())
            
            intersecting_features = []
            for fid in candidate_ids:
                f = layer.getFeature(fid)
                if f.geometry().intersects(cut_line_geom):
                    intersecting_features.append(f)
            
            layer.startEditing()
            
            # 2. Split existing features with the cut line
            for f in intersecting_features:
                f_geom = f.geometry()
                # splitGeometry returns (return_code, new_geometries, topological_points)
                cut_points = cut_line_geom.asPolyline()
                ret, new_geoms, _ = f_geom.splitGeometry(cut_points, False)
                
                if ret == 0: # Split successful
                    # Update original feature
                    layer.changeGeometry(f.id(), f_geom)
                    
                    # Add new parts
                    fields = layer.fields()
                    for new_geom in new_geoms:
                        new_feat = QgsFeature(fields)
                        new_feat.setGeometry(new_geom)
                        new_feat.setAttributes(f.attributes())
                        idx = fields.indexFromName('UUID')
                        if idx != -1:
                            new_feat.setAttribute(idx, str(uuid.uuid4()))
                        layer.addFeature(new_feat)
            
            # 3. Split the cut line with existing features
            # We start with one segment and split it iteratively
            cut_segments = [cut_line_geom]
            
            for f in intersecting_features:
                # We use the ORIGINAL geometry of intersecting features to split the cut line
                # (The feature might have been split in step 2, but the geometric path is the same)
                splitter_poly = f.geometry().asPolyline() if not f.geometry().isMultipart() else f.geometry().asMultiPolyline()[0]
                
                next_segments = []
                for seg in cut_segments:
                    # Try to split this segment
                    # Note: splitGeometry expects a polyline list of points
                    # If f is multipart, we might need to iterate parts. 
                    # For simplicity, assuming single part or taking first part if multipart line
                    # A more robust way is to use intersection points to split, but let's try splitGeometry first
                    
                    # Handle multipart splitter
                    splitter_parts = []
                    if f.geometry().isMultipart():
                        splitter_parts = f.geometry().asMultiPolyline()
                    else:
                        splitter_parts = [f.geometry().asPolyline()]
                        
                    current_seg_parts = [seg]
                    
                    for splitter in splitter_parts:
                        temp_parts = []
                        for s in current_seg_parts:
                            ret, new_geoms, _ = s.splitGeometry(splitter, False)
                            if ret == 0:
                                temp_parts.append(s) # Modified in place
                                temp_parts.extend(new_geoms)
                            else:
                                temp_parts.append(s)
                        current_seg_parts = temp_parts
                    
                    next_segments.extend(current_seg_parts)
                
                cut_segments = next_segments

            # 4. Add the (potentially split) cut line segments to the layer
            fields = layer.fields()
            uuid_idx = fields.indexFromName('UUID')
            
            for seg in cut_segments:
                if seg.length() < 0.001: continue # Skip tiny segments
                
                new_feat = QgsFeature(fields)
                new_feat.setGeometry(seg)
                
                # Set attributes
                if uuid_idx != -1:
                    new_feat.setAttribute(uuid_idx, str(uuid.uuid4()))
                
                # Set 'Layer' attribute if exists to mark as correction
                layer_idx = fields.indexFromName('Layer')
                if layer_idx != -1:
                    new_feat.setAttribute(layer_idx, "CORRECCION_ISLA")
                    
                layer.addFeature(new_feat)
            
            layer.commitChanges()
            return True
            
        return False

