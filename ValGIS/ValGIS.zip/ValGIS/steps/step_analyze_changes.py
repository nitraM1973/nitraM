import os
from qgis.core import QgsVectorLayer, QgsSpatialIndex, QgsGeometry

class StepAnalyzeChanges:
    def __init__(self):
        pass
    
    def run(self, current_layer, output_dir, geometry_tolerance=0.001, log_callback=None, log_helper=None):
        """
        Analiza cambios geométricos usando diferencia geométrica robusta (Original - Final) y (Final - Original).
        Aísla segmentos específicos que difieren entre los dos estados.
        
        Args:
            current_layer: Capa de trabajo actual (pre-poligonización)
            output_dir: Directorio que contiene archivos intermedios
            geometry_tolerance: Tolerancia para comparación de geometría (m)
            log_callback: Función de logging
            log_helper: LogHelper para logging espacial
            
        Returns:
            list: Errores representando diferencias geométricas específicas
        """
        def log(msg):
            if log_callback:
                log_callback(msg)
        
        # Cargar capa original normalizada
        log("=== ANÁLISIS DE CAMBIOS GEOMÉTRICOS (DIFERENCIA EXACTA) ===")
        log("")
        
        original_layer = self.load_original_layer(output_dir)
        if not original_layer:
            log("ERROR: No se pudo cargar la capa original normalizada")
            return []
        
        # Construir índices espaciales
        log("Construyendo índices espaciales...")
        current_index = QgsSpatialIndex(current_layer.getFeatures())
        current_features = {f.id(): f for f in current_layer.getFeatures()}
        
        original_index = QgsSpatialIndex(original_layer.getFeatures())
        original_features = {f.id(): f for f in original_layer.getFeatures()}
        
        errors = []
        
        # UMBRALES
        MIN_DIFF_LENGTH = 0.5  # Ignorar diferencias más cortas que 0.5m
        BUFFER_TOLERANCE = geometry_tolerance  # Tolerancia 1mm
        
        # 1. DETECTAR PARTES FALTANTES/MOVIDAS (Original - Final)
        log("1. Buscando tramos faltantes o desplazados...")
        missing_count = 0
        
        total_orig = original_layer.featureCount()
        processed = 0
        
        for orig_feat in original_layer.getFeatures():
            processed += 1
            if processed % 1000 == 0:
                log(f"   Procesando {processed}/{total_orig} originales...")
                
            orig_geom = orig_feat.geometry()
            if orig_geom.length() < MIN_DIFF_LENGTH:
                continue
                
            # Encontrar candidatos en capa Final que podrían cubrir esta feature original
            bbox = orig_geom.boundingBox()
            bbox.grow(BUFFER_TOLERANCE * 5)
            candidate_ids = current_index.intersects(bbox)
            
            # Empezar con geometría original completa
            remaining_geom = QgsGeometry(orig_geom)
            
            # Restar todas las geometrías finales cercanas (con buffer)
            for cand_id in candidate_ids:
                cand_feat = current_features.get(cand_id)
                cand_geom = cand_feat.geometry()
                
                # Buffer del candidato para tener en cuenta la tolerancia
                cand_buffer = cand_geom.buffer(BUFFER_TOLERANCE, 4)
                
                # Restar: remaining = remaining - candidate
                remaining_geom = remaining_geom.difference(cand_buffer)
                
                # Optimización: si no queda nada, detener
                if remaining_geom.isEmpty():
                    break
            
            # Verificar si queda algo sustancial
            if not remaining_geom.isEmpty() and remaining_geom.length() > MIN_DIFF_LENGTH:
                # Esta parte restante está FALTANTE en la capa final
                missing_count += 1
                
                # Manejar geometrías multipartes (obtener la parte más grande)
                if remaining_geom.isMultipart():
                    parts = remaining_geom.asGeometryCollection()
                    max_part = max(parts, key=lambda g: g.length())
                    remaining_geom = max_part
                
                msg = f"Tramo FALTANTE o DESPLAZADO (Longitud: {remaining_geom.length():.2f}m)"
                
                errors.append({
                    'id': orig_feat.id(),
                    'msg': msg,
                    'type': 'missing_geometry',
                    'point': remaining_geom.centroid().asPoint(), # Punto a la parte faltante
                    'length': remaining_geom.length(),
                    'geometry': remaining_geom # Almacenar la geometría de diferencia específica
                })
                
                if log_helper:
                    log_helper.add_log_point(
                        remaining_geom.centroid().asPoint(),
                        "Cambio: Faltante",
                        msg,
                        original_layer.name()
                    )

        # 2. DETECTAR PARTES NUEVAS/ESPURIAS (Final - Original)
        log("2. Buscando tramos nuevos o inventados...")
        new_count = 0
        
        total_curr = current_layer.featureCount()
        processed = 0
        
        for curr_feat in current_layer.getFeatures():
            processed += 1
            if processed % 1000 == 0:
                log(f"   Procesando {processed}/{total_curr} finales...")
                
            curr_geom = curr_feat.geometry()
            if curr_geom.length() < MIN_DIFF_LENGTH:
                continue
                
            # Encontrar candidatos en capa Original que podrían cubrir esta feature final
            bbox = curr_geom.boundingBox()
            bbox.grow(BUFFER_TOLERANCE * 5)
            candidate_ids = original_index.intersects(bbox)
            
            # Empezar con geometría final completa
            remaining_geom = QgsGeometry(curr_geom)
            
            # Restar todas las geometrías originales cercanas (con buffer)
            for cand_id in candidate_ids:
                cand_feat = original_features.get(cand_id)
                cand_geom = cand_feat.geometry()
                
                cand_buffer = cand_geom.buffer(BUFFER_TOLERANCE, 4)
                remaining_geom = remaining_geom.difference(cand_buffer)
                
                if remaining_geom.isEmpty():
                    break
            
            # Verificar si queda algo sustancial
            if not remaining_geom.isEmpty() and remaining_geom.length() > MIN_DIFF_LENGTH:
                # Esta parte restante es NUEVA en la capa final
                new_count += 1
                
                if remaining_geom.isMultipart():
                    parts = remaining_geom.asGeometryCollection()
                    max_part = max(parts, key=lambda g: g.length())
                    remaining_geom = max_part
                
                msg = f"Tramo NUEVO o INVENTADO (Longitud: {remaining_geom.length():.2f}m)"
                
                errors.append({
                    'id': curr_feat.id(),
                    'msg': msg,
                    'type': 'new_geometry',
                    'point': remaining_geom.centroid().asPoint(),
                    'length': remaining_geom.length(),
                    'geometry': remaining_geom
                })
                
                if log_helper:
                    log_helper.add_log_point(
                        remaining_geom.centroid().asPoint(),
                        "Cambio: Nuevo",
                        msg,
                        current_layer.name()
                    )

        # Resumen
        log("")
        log("RESUMEN DE DIFERENCIAS SUSTANCIALES:")
        log(f"- Tramos Faltantes/Desplazados (> {MIN_DIFF_LENGTH}m): {missing_count}")
        log(f"- Tramos Nuevos/Inventados (> {MIN_DIFF_LENGTH}m): {new_count}")
        log("")
        
        if len(errors) > 0:
            log(f"⚠ SE ENCONTRARON {len(errors)} DIFERENCIAS SUSTANCIALES")
            log("Revise la tabla de errores para ver exactamente qué tramos difieren.")
            log("El zoom le llevará al centro del tramo conflictivo.")
        else:
            log("✓ La geometría es consistente (salvo micro-ajustes de topología).")
            log("Presione 'Siguiente' para continuar.")
            
        return errors
    
    def load_original_layer(self, output_dir):
        """Cargar la capa original normalizada."""
        # Intentar cargar la capa normalizada (Paso 3) que es la mejor línea base
        # Nombre de archivo de naming_convention.py: 03_00_Coordenadas_Normalizadas.shp
        original_path = os.path.join(output_dir, "03_00_Coordenadas_Normalizadas.shp")
        
        if not os.path.exists(original_path):
            # Info de depuración
            print(f"DEBUG: Archivo no encontrado: {original_path}")
            
            # FALLBACK 1: Intentar Paso 2 (Geometrias Reparadas)
            fallback_path_1 = os.path.join(output_dir, "02_00_Geometrias_Reparadas.shp")
            if os.path.exists(fallback_path_1):
                print(f"DEBUG: Usando fallback 1: {fallback_path_1}")
                return QgsVectorLayer(fallback_path_1, "Original_Reparada_Fallback", "ogr")
                
            # FALLBACK 2: Intentar Paso 1 (DXF Cargado)
            fallback_path_2 = os.path.join(output_dir, "01_00_DXF_Cargado.shp")
            if os.path.exists(fallback_path_2):
                print(f"DEBUG: Usando fallback 2: {fallback_path_2}")
                return QgsVectorLayer(fallback_path_2, "Original_DXF_Fallback", "ogr")
            
            # Listar directorio para depuración
            print(f"DEBUG: Contenido de {output_dir}:")
            try:
                for f in os.listdir(output_dir):
                    print(f"  - {f}")
            except:
                print("  (No se pudo listar el directorio)")
                
            return None
        
        layer = QgsVectorLayer(original_path, "Original_Normalized", "ogr")
        
        if not layer.isValid():
            return None
        
        return layer
    
        return layer


