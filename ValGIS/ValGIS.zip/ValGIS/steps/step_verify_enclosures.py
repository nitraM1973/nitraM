from ..topology.graph import Graph
from ..topology.precision import TOPO_PRECISION
from qgis.core import QgsPointXY, QgsSpatialIndex, QgsRectangle, QgsGeometry, QgsFeature
import processing
from ..helpers.layer_utils import purge_zero_length_features

class StepVerifyEnclosures:
    def __init__(self):
        pass

    def check_short_segments(self, layer, min_length, log_callback=None, callback=None):
        """
        FASE A — Guardia de Longitud.
        Detecta segmentos con longitud < min_length y los devuelve como errores.
        NO borra nada. El usuario debe corregirlos manualmente.
        Devuelve lista de errores de tipo 'short_segment'.
        """
        def log(msg):
            if log_callback: log_callback(msg)

        errors = []
        features = list(layer.getFeatures())
        total = len(features)

        log(f"  Comprobando segmentos cortos (umbral: {min_length:.4f}m)...")
        for i, feat in enumerate(features):
            if i % 2000 == 0 and callback:
                callback(i, total)

            geom = feat.geometry()
            if not geom or geom.isEmpty(): continue

            length = geom.length()
            if 0 < length < min_length:
                pt = geom.centroid().asPoint()
                errors.append({
                    'id': feat.id(),
                    'point': pt,
                    'type': 'short_segment',
                    'msg': f"Segmento corto ({length:.5f}m < {min_length:.4f}m) — Revisar o eliminar manualmente"
                })

        if errors:
            log(f"  ⚠️ {len(errors)} segmentos cortos detectados. Corríjalos antes de continuar.")
        else:
            log(f"  ✅ Sin segmentos cortos. Procediendo a verificación de áreas...")

        return errors

    def snap_dangles(self, layer, tolerance=0.025, auto_fix=True, log_callback=None, callback=None, filter_expression=None):
        """
        FASE B — Ejecutar el Super Snapper sobre los extremos sueltos.
        """
        from qgis.core import QgsFeatureRequest
        from ..helpers.topology_utils import snap_hanging_vertices
        
        request = QgsFeatureRequest()
        if filter_expression:
            request.setFilterExpression(filter_expression)
            
        if auto_fix:
            if log_callback: log_callback(f"  ━━ FASE B: Super Snapper (detectar y corregir extremos sueltos a {tolerance}m)...")
            snapped_count = snap_hanging_vertices(layer, tolerance=tolerance, callback=callback, log_callback=log_callback, request=request)
            if snapped_count > 0 and log_callback:
                log_callback(f"  ✓ Fase B completada: {snapped_count} extremos corregidos.")
            elif snapped_count == 0 and log_callback:
                log_callback(f"  ✓ Fase B: No se encontraron extremos sueltos.")
                
        return True

    def verify_enclosures(self, layer, log_helper=None, callback=None, log_callback=None, filter_expression=None):
        """
        FASE C — DETECCIÓN FINAL DE DANGLES
        """
        if log_callback: log_callback("  ━━ FASE C: Verificación final de áreas abiertas...")
        
        from qgis.core import QgsFeatureRequest
        request = QgsFeatureRequest()
        if filter_expression:
            request.setFilterExpression(filter_expression)
            
        # Purgar SOLO geometrías absolutamente degeneradas (ruido de 0.001m fijo).
        NOISE_FLOOR = 0.001
        purge_zero_length_features(layer, step_label="Verificar Cierres", log_callback=log_callback, callback=callback, min_length=NOISE_FLOOR, request=request)

        # Construir grafo
        graph = Graph()
        
        features = list(layer.getFeatures(request))
        total = len(features)
        
        for i, feature in enumerate(features):
            if i % 100 == 0 and callback:
                callback(i, total)
            geom = feature.geometry()
            if not geom or geom.isEmpty(): continue
            
            if geom.isMultipart():
                lines = geom.asMultiPolyline()
            else:
                lines = [geom.asPolyline()]
            
            for line in lines:
                if len(line) >= 2:
                    u = (round(line[0].x(), TOPO_PRECISION), round(line[0].y(), TOPO_PRECISION))
                    v = (round(line[-1].x(), TOPO_PRECISION), round(line[-1].y(), TOPO_PRECISION))
                    # Pasar el ID de la feature para trazabilidad
                    graph.add_edge(u, v, data={'fid': feature.id()})
        
        # Encontrar todos los dangles (nodos de grado 1)
        dangles = []
        
        for node, neighbors in graph.nodes.items():
            degree = len(neighbors)
            if degree == 1:
                # Verificar si es un objeto suelto (ambos extremos son grado 1)
                neighbor = neighbors[0]
                if len(graph.nodes[neighbor]) == 1:
                    continue  # Omitir líneas aisladas
                
                # Este es un dangle real
                pt = QgsPointXY(node[0], node[1])
                dangles.append(pt)
        
        if not dangles:
            return []  # No se encontraron dangles
        

        
        # Reportar dangles restantes como errores
        errors = []
        
        # Umbral de sospecha para fugas (5 veces la tolerancia o 5cm min)
        LEAK_THRESHOLD = 0.05 
        
        # Crear índice espacial para búsquedas rápidas de proximidad
        # FIX RENDIMIENTO: reutilizar la lista 'features' ya cargada en vez
        # de volver a consultar la capa completa con layer.getFeatures(request).
        # NOTA: QgsSpatialIndex NO admite una lista de Python en su constructor
        # (solo QgsFeatureIterator, QgsFeatureSource, otro QgsSpatialIndex o
        # ningún argumento). Pasarle 'features' (una list) hacía fallar los
        # 4 overloads del constructor. Se crea vacío y se insertan las
        # features ya cargadas una a una, evitando así también la
        # relectura de la capa.
        spatial_index = QgsSpatialIndex()
        for _f in features:
            spatial_index.addFeature(_f)

        # FIX RENDIMIENTO: precalcular un mapa nodo -> fid en una sola
        # pasada sobre graph.edges. Antes, por CADA dangle se recorrían
        # TODAS las aristas del grafo (O(dangles × aristas)) para
        # encontrar el fid que originaba ese nodo; con capas grandes esto
        # dominaba el tiempo total del step.
        node_to_fid = {}
        for edge_u, edge_v, edge_data in graph.edges:
            if edge_data and 'fid' in edge_data:
                node_to_fid.setdefault(edge_u, edge_data['fid'])
                node_to_fid.setdefault(edge_v, edge_data['fid'])

        # FIX RENDIMIENTO: cachear features por fid en vez de llamar
        # layer.getFeature(fid) repetidamente dentro del bucle de fugas.
        features_map = {f.id(): f for f in features}

        for node, neighbors in graph.nodes.items():
            degree = len(neighbors)
            if degree == 1:
                neighbor = neighbors[0]
                if len(graph.nodes[neighbor]) == 1:
                    continue
                
                pt = QgsPointXY(node[0], node[1])
                
                # BUSCAR SI ES UNA FUGA (Está cerca de otra línea pero no toca)
                is_leak = False
                dist_to_nearest = float('inf')
                
                search_rect = QgsRectangle(
                    pt.x() - LEAK_THRESHOLD, pt.y() - LEAK_THRESHOLD,
                    pt.x() + LEAK_THRESHOLD, pt.y() + LEAK_THRESHOLD
                )
                
                candidates = spatial_index.intersects(search_rect)
                for cand_fid in candidates:
                    feat = features_map.get(cand_fid)
                    if feat is None or not feat.isValid(): continue
                    
                    # Proyectar el punto sobre la geometría candidata
                    dist = feat.geometry().distance(QgsGeometry.fromPointXY(pt))
                    
                    # Si la distancia es muy pequeña pero mayor que cero (o el error de precisión)
                    if 0.0001 < dist < dist_to_nearest:
                        dist_to_nearest = dist
                        if dist < LEAK_THRESHOLD:
                            is_leak = True
                
                # Buscar el ID de la feature que origina este dangle
                fid = node_to_fid.get(node)

                if is_leak:
                    msg = f'FUGA POTENCIAL: Extremo a {dist_to_nearest:.3f}m de cerrar'
                    err_type = 'potential_leak'
                else:
                    msg = f'Área no cerrada: extremo colgante'
                    err_type = 'open_area'
                
                errors.append({
                    'id': fid, # Añadir ID para selección en zoom_to_error
                    'point': pt,
                    'type': err_type,
                    'msg': msg
                })
        
        return errors
    
    def _try_fix_dangle(self, layer, index, dangle, tolerance, log_helper, layer_name):
        """
        Intentar corregir un dangle encontrando un segmento cercano y ajustándolo.
        Devuelve True si se corrigió, False en caso contrario.
        """
        # Buscar features cercanas
        search_rect = QgsRectangle(
            dangle.x() - tolerance,
            dangle.y() - tolerance,
            dangle.x() + tolerance,
            dangle.y() + tolerance
        )
        
        candidate_fids = index.intersects(search_rect)
        
        best_projection = None
        best_distance = tolerance
        best_fid = None
        best_segment_idx = None
        
        for fid in candidate_fids:
            feat = layer.getFeature(fid)
            if not feat.isValid():
                continue
            
            geom = feat.geometry()
            
            # Verificar si esta feature contiene el dangle mismo
            if geom.isMultipart():
                parts = geom.asMultiPolyline()
            else:
                parts = [geom.asPolyline()]
            
            is_dangle_feature = False
            for part in parts:
                if len(part) >= 2:
                    start = QgsPointXY(part[0])
                    end = QgsPointXY(part[-1])
                    if start.distance(dangle) < 0.001 or end.distance(dangle) < 0.001:
                        is_dangle_feature = True
                        break
            
            if is_dangle_feature:
                continue  # Omitir la feature que contiene el dangle
            
            # Encontrar segmento más cercano para proyección y división
            for part_idx, part in enumerate(parts):
                if len(part) < 2:
                    continue
                
                for seg_idx in range(len(part) - 1):
                    seg_start = QgsPointXY(part[seg_idx])
                    seg_end = QgsPointXY(part[seg_idx + 1])
                    
                    # Calcular proyección del dangle sobre el segmento
                    projection, dist = self._project_point_to_segment(dangle, seg_start, seg_end)
                    
                    if projection and dist < best_distance:
                        # Aceptar todas las proyecciones dentro del segmento, incluso si están cerca de vértices
                        # Esto asegura que se cree la conexión topológica
                        best_projection = projection
                        best_distance = dist
                        best_fid = fid
                        best_segment_idx = (part_idx, seg_idx)
        
        if best_projection and best_fid is not None:
            # Corregir el dangle
            # 1. Mover dangle al punto de proyección
            if self._move_dangle_to_point(layer, index, dangle, best_projection):
                # 2. Dividir el segmento objetivo en el punto de proyección
                # Esto crea la conexión topológica, incluso si la proyección está en un vértice existente
                self._split_segment_at_point(layer, best_fid, best_segment_idx, best_projection)
                
                if log_helper:
                    log_helper.add_log_point(best_projection, "Verificar Áreas Cerradas", 
                                            f"Dangle corregido (dist: {best_distance:.3f}m)", layer_name)
                return True
        
        return False
    
    def _project_point_to_segment(self, point, seg_start, seg_end):
        """
        Proyectar un punto sobre un segmento de línea.
        Devuelve (punto_proyección, distancia) o (None, inf) si la proyección está fuera del segmento.
        """
        # Vector de seg_start a seg_end
        dx = seg_end.x() - seg_start.x()
        dy = seg_end.y() - seg_start.y()
        
        if abs(dx) < 1e-10 and abs(dy) < 1e-10:
            # Segmento degenerado
            return (None, float('inf'))
        
        # Parámetro t para proyección
        t = ((point.x() - seg_start.x()) * dx + (point.y() - seg_start.y()) * dy) / (dx * dx + dy * dy)
        
        # Limitar t a [0, 1] para permanecer en el segmento con tolerancia epsilon
        # Manejar errores de punto flotante donde t podría ser ligeramente < 0 o > 1
        if t < -1e-9 or t > 1 + 1e-9:
            return (None, float('inf'))
            
        # Limitar estrictamente para cálculo de punto
        if t < 0: t = 0
        if t > 1: t = 1
        
        # Calcular punto de proyección
        proj_x = seg_start.x() + t * dx
        proj_y = seg_start.y() + t * dy
        projection = QgsPointXY(proj_x, proj_y)
        
        distance = point.distance(projection)
        
        return (projection, distance)
    
    def _move_dangle_to_point(self, layer, index, dangle, target_point):
        """
        Mover un extremo dangle a un punto objetivo.
        """
        search_rect = QgsRectangle(
            dangle.x() - 0.001,
            dangle.y() - 0.001,
            dangle.x() + 0.001,
            dangle.y() + 0.001
        )
        
        candidate_fids = index.intersects(search_rect)
        
        for fid in candidate_fids:
            feat = layer.getFeature(fid)
            if not feat.isValid():
                continue
            
            geom = feat.geometry()
            if geom.isMultipart():
                parts = geom.asMultiPolyline()
            else:
                parts = [geom.asPolyline()]
            
            modified = False
            new_parts = []
            
            for part in parts:
                if len(part) < 2:
                    new_parts.append(part)
                    continue
                
                new_part = list(part)
                
                start = QgsPointXY(part[0])
                end = QgsPointXY(part[-1])
                
                if start.distance(dangle) < 0.001:
                    new_part[0] = target_point
                    modified = True
                elif end.distance(dangle) < 0.001:
                    new_part[-1] = target_point
                    modified = True
                
                new_parts.append(new_part)
            
            if modified:
                if geom.isMultipart():
                    new_geom = QgsGeometry.fromMultiPolylineXY(new_parts)
                else:
                    new_geom = QgsGeometry.fromPolylineXY(new_parts[0])
                
                layer.changeGeometry(fid, new_geom)
                return True
        
        return False
    
    def _split_segment_at_point(self, layer, fid, segment_idx, point):
        """
        Dividir la feature en dos features separadas en el punto dado.
        Esto asegura que se cree un nodo topológico en la intersección.
        """
        feat = layer.getFeature(fid)
        if not feat.isValid():
            return False
        
        geom = feat.geometry()
        if geom.isMultipart():
            parts = geom.asMultiPolyline()
        else:
            parts = [geom.asPolyline()]
        
        part_idx, seg_idx = segment_idx
        
        if part_idx >= len(parts):
            return False
        
        part = parts[part_idx]
        
        # Determinar el índice del vértice de división
        split_index = -1
        
        seg_start = QgsPointXY(part[seg_idx])
        seg_end = QgsPointXY(part[seg_idx + 1])
        
        # Verificar si el punto coincide con vértices existentes
        if point.distance(seg_start) < 0.0001:
            split_index = seg_idx
        elif point.distance(seg_end) < 0.0001:
            split_index = seg_idx + 1
        else:
            # Insertar nuevo vértice
            new_part = list(part[:seg_idx + 1])
            new_part.append(point)
            new_part.extend(part[seg_idx + 1:])
            parts[part_idx] = new_part
            part = new_part
            split_index = seg_idx + 1
        
        # Si el punto de división es el inicio o fin de la polilínea, no podemos dividir
        if split_index <= 0 or split_index >= len(part) - 1:
            return True # Ya topológicamente válido (conectado en extremo)
            
        # Realizar la división
        # Parte 1: Inicio a split_index
        geom1_pts = part[:split_index + 1]
        
        # Parte 2: Split_index a Fin
        geom2_pts = part[split_index:]
        
        # Actualizar feature original con Parte 1
        if geom.isMultipart():
            # Para multipartes, mantenemos otras partes en la feature original? 
            # Caso complejo. Por ahora, asumimos que modificamos la parte específica.
            new_parts1 = list(parts)
            new_parts1[part_idx] = geom1_pts
            new_geom1 = QgsGeometry.fromMultiPolylineXY(new_parts1)
        else:
            new_geom1 = QgsGeometry.fromPolylineXY(geom1_pts)
            
        layer.changeGeometry(fid, new_geom1)
        
        # Crear nueva feature para Parte 2
        new_feat = QgsFeature(feat)
        new_feat.setGeometry(QgsGeometry.fromPolylineXY(geom2_pts))
        
        # Generar nuevo UUID si existe
        fields = layer.fields()
        if fields.indexOf('UUID') != -1:
            import uuid
            new_feat['UUID'] = str(uuid.uuid4())
            
        layer.addFeature(new_feat)
        



