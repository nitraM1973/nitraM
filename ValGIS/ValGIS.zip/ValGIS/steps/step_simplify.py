import processing
import os
import time
from qgis.core import QgsVectorLayer, QgsFeature, QgsGeometry, QgsPointXY, QgsFeatureRequest
from ..helpers.layer_utils import clean_and_save_layer, get_feedback, purge_zero_length_features
from ..topology.precision import TOPO_PRECISION

class StepSimplify:
    def __init__(self):
        pass

    def run(self, layer, tolerance, output_dir, filename="Simplified.shp", callback=None, log_callback=None):
        """
        Simplificación Topológica Hardened (Versión Manual Nitro 🚀).
        
        Novedad: Implementa fragmentación manual para asegurar que los anclajes topológicos
        sean extremos físicos de línea antes de simplificar. No depende de algoritmos externos
        de 'split' que puedan faltar en ciertas versiones de QGIS.
        """
        start_time = time.time()
        def log(msg):
            if log_callback: log_callback(msg)
            
        log("Iniciando Simplificación con Preservación Topológica (Manual)...")

        # --- FASE 1: EXTRACCIÓN DE ANCLAJES (Nodos de Conectividad) ---
        log("  [1/4] Identificando anclajes topológicos...")
        anchor_coords = set() # (rounded_x, rounded_y)
        
        # Primero recolectamos todos los extremos de todas las líneas
        features = list(layer.getFeatures())
        total_feats = len(features)
        
        for i, feat in enumerate(features):
            if i % 5000 == 0 and callback:
                callback(i, total_feats * 4) # 4 fases proyectadas
                
            geom = feat.geometry()
            if not geom or geom.isEmpty(): continue
            
            if geom.isMultipart(): parts = geom.asMultiPolyline()
            else: parts = [geom.asPolyline()]
                
            for poly in parts:
                if len(poly) < 2: continue
                # Añadir extremos como anclajes (redondeados para evitar micro-precisiones)
                anchor_coords.add((round(poly[0].x(), TOPO_PRECISION), round(poly[0].y(), TOPO_PRECISION)))
                anchor_coords.add((round(poly[-1].x(), TOPO_PRECISION), round(poly[-1].y(), TOPO_PRECISION)))
        
        log(f"  {len(anchor_coords)} anclajes detectados.")

        # --- FASE 2: FRAGMENTACIÓN MANUAL (Nitro Split) ---
        log("  [2/4] Fragmentando líneas en anclajes para garantizar protección...")
        
        # Nueva capa de memoria — hereda el ESQUEMA COMPLETO de la capa original
        split_layer = QgsVectorLayer(f"LineString?crs={layer.crs().authid()}", "split", "memory")
        split_pr = split_layer.dataProvider()
        split_pr.addAttributes(layer.fields().toList())  # ← Copiar todos los campos
        split_layer.updateFields()
        
        # Para cada línea original la troceamos en sus puntos de anclaje
        new_features = []
        processed = 0
        for feat in features:
            processed += 1
            if processed % 5000 == 0 and callback:
                callback(total_feats + processed, total_feats * 4)
                
            geom = feat.geometry()
            if not geom or geom.isEmpty(): continue
            
            if geom.isMultipart(): polylines = geom.asMultiPolyline()
            else: polylines = [geom.asPolyline()]
            
            for poly in polylines:
                if len(poly) < 2: continue
                
                fragments = self._split_polyline_at_anchors(poly, anchor_coords)
                for frag in fragments:
                    f = QgsFeature(split_layer.fields())  # ← Usar el esquema de la capa
                    f.setGeometry(QgsGeometry.fromPolylineXY(frag))
                    f.setAttributes(feat.attributes())    # ← Copiar atributos del original
                    new_features.append(f)
            
            # Vaciar buffer periódicamente para no saturar RAM
            if len(new_features) > 10000:
                split_pr.addFeatures(new_features)
                new_features = []
        
        if new_features:
            split_pr.addFeatures(new_features)
            
        log(f"  Fragmentación completada: {split_layer.featureCount()} segmentos generados.")

        # --- FASE 3: SIMPLIFICACIÓN ---
        log("  [3/4] Ejecutando algoritmo de simplificación Douglas-Peucker...")
        feedback = get_feedback(callback)
        params = {
            'INPUT': split_layer,
            'METHOD': 0, 
            'TOLERANCE': tolerance,
            'OUTPUT': 'memory:'
        }
        simplified = processing.run("native:simplifygeometries", params, feedback=feedback)['OUTPUT']
        
        # --- FASE 4: GUARDADO Y LIMPIEZA ---
        log(f"  [4/4] Guardando resultados y limpiando geometrías...")
        if callback: callback(total_feats * 3, total_feats * 4)
        
        purge_zero_length_features(simplified, step_label="Simplificación", log_callback=log_callback)
        
        output_path = os.path.join(output_dir, filename)
        result_layer, _ = clean_and_save_layer(simplified, output_path)
        
        elapsed = time.time() - start_time
        if callback: callback(total_feats * 4, total_feats * 4)
        log(f"⏱️ Simplificación finalizada en {elapsed:.2f}s")
        
        return result_layer

    def _split_polyline_at_anchors(self, poly, anchor_coords, tol=0.001):
        """Trocea una polilínea en múltiples segmentos en cada vértice que sea un anclaje topológico."""
        # Los anclajes ya son vértices reales de la línea (gracias al Paso 3 Hardened).
        # Simplemente los usamos como puntos de corte.
        all_fragments = []
        current_fragment = [poly[0]]
        
        for i in range(1, len(poly) - 1):
            pt = poly[i]
            current_fragment.append(pt)
            
            # ¿Es este vértice un anclaje topológico?
            key = (round(pt.x(), TOPO_PRECISION), round(pt.y(), TOPO_PRECISION))
            if key in anchor_coords:
                # Cortar aquí
                if len(current_fragment) >= 2:
                    all_fragments.append(list(current_fragment))
                current_fragment = [pt] # Empezar nuevo fragmento coincidente
        
        current_fragment.append(poly[-1])
        if len(current_fragment) >= 2:
            all_fragments.append(current_fragment)
            
        return all_fragments
