import processing
import os
from ..helpers.layer_utils import clean_and_save_layer

class StepSimplify:
    def __init__(self):
        pass

    def run(self, layer, tolerance, output_dir, filename="Simplified.shp"):
        """
        Simplifica geometrias usando el algoritmo Douglas-Peucker.
        Este metodo elimina vertices colineales (puntos intermedios en lineas rectas).
        """
        params = {
            'INPUT': layer,
            'METHOD': 0,  # Douglas-Peucker (basado en distancia, elimina vertices colineales)
            'TOLERANCE': tolerance,
            'OUTPUT': 'memory:'
        }
        simplified = processing.run("native:simplifygeometries", params)['OUTPUT']
        
        
        output_path = os.path.join(output_dir, filename)
        result_layer, _ = clean_and_save_layer(simplified, output_path)
        return result_layer
