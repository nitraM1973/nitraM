from qgis.core import QgsSpatialIndex, QgsGeometry

class StepValidatePolygons:
    def __init__(self):
        pass
    
    def run(self, layer, min_area=0.01, min_ratio=0.005, gap_tolerance=0.001, callback=None, log_helper=None):
        """
        Validates polygon layer for common topology issues.
        
        Args:
            layer: QgsVectorLayer with polygons
            min_area: Minimum area for sliver detection (m²)
            min_ratio: Minimum area/perimeter ratio for sliver detection
            gap_tolerance: Maximum gap distance to report (m)
            callback: Progress callback function
            log_helper: LogHelper instance for spatial logging
            
        Returns:
            list: List of error dictionaries
        """
        errors = []
        layer_name = layer.name()
        
        # 1. Check invalid geometries
        if callback:
            callback("Verificando geometrías inválidas...")
        invalid_errors = self.check_invalid_geometries(layer, layer_name, log_helper)
        errors.extend(invalid_errors)
        
        # 2. Build spatial index
        if callback:
            callback("Construyendo índice espacial...")
        index = QgsSpatialIndex(layer.getFeatures())
        features_dict = {f.id(): f for f in layer.getFeatures()}
        
        # 3. Check overlaps
        if callback:
            callback("Detectando solapes...")
        overlap_errors = self.check_overlaps(layer, index, features_dict, layer_name, log_helper)
        errors.extend(overlap_errors)
        
        # 4. Check gaps (optional - can be slow for large datasets)
        # Uncomment if needed:
        # if callback:
        #     callback("Detectando huecos...")
        # gap_errors = self.check_gaps(layer, index, features_dict, gap_tolerance, layer_name, log_helper)
        # errors.extend(gap_errors)
        
        # 5. Check slivers
        if callback:
            callback("Detectando polígonos astilla...")
        sliver_errors = self.check_slivers(layer, min_area, min_ratio, layer_name, log_helper)
        errors.extend(sliver_errors)
        
        return errors
    
    def check_invalid_geometries(self, layer, layer_name, log_helper=None):
        """Check for topologically invalid geometries."""
        errors = []
        
        for feat in layer.getFeatures():
            geom = feat.geometry()
            if not geom.isGeosValid():
                error_msg = geom.validateGeometry()
                msg = f"Geometría inválida: {error_msg[0].what() if error_msg else 'Topología incorrecta'}"
                
                errors.append({
                    'id': feat.id(),
                    'msg': msg,
                    'type': 'invalid_polygon',
                    'point': geom.centroid().asPoint(),
                    'area': geom.area()
                })
                
                if log_helper:
                    log_helper.add_log_point(
                        geom.centroid().asPoint(),
                        "Validar Polígonos",
                        msg,
                        layer_name
                    )
        
        return errors
    
    def check_overlaps(self, layer, index, features_dict, layer_name, log_helper=None):
        """Detect overlapping polygons."""
        errors = []
        checked_pairs = set()
        
        for fid, feat in features_dict.items():
            geom = feat.geometry()
            bbox = geom.boundingBox()
            
            # Find candidates
            candidate_ids = index.intersects(bbox)
            
            for cand_id in candidate_ids:
                if cand_id == fid:
                    continue
                
                # Avoid checking same pair twice
                pair = tuple(sorted([fid, cand_id]))
                if pair in checked_pairs:
                    continue
                checked_pairs.add(pair)
                
                candidate = features_dict.get(cand_id)
                if not candidate:
                    continue
                
                cand_geom = candidate.geometry()
                
                # Check for overlap (not just touching)
                if geom.overlaps(cand_geom):
                    intersection = geom.intersection(cand_geom)
                    overlap_area = intersection.area()
                    
                    msg = f"Solape con polígono ID {cand_id} (Área: {overlap_area:.4f} m²)"
                    
                    errors.append({
                        'id': fid,
                        'msg': msg,
                        'type': 'overlap',
                        'point': intersection.centroid().asPoint(),
                        'area': overlap_area,
                        'related_id': cand_id
                    })
                    
                    if log_helper:
                        log_helper.add_log_point(
                            intersection.centroid().asPoint(),
                            "Validar Polígonos",
                            msg,
                            layer_name
                        )
        
        return errors
    
    def check_gaps(self, layer, index, features_dict, tolerance, layer_name, log_helper=None):
        """
        Detect gaps between adjacent polygons.
        Note: This can be slow for large datasets.
        """
        errors = []
        checked_pairs = set()
        
        for fid, feat in features_dict.items():
            geom = feat.geometry()
            bbox = geom.boundingBox()
            bbox.grow(tolerance)  # Expand to find nearby polygons
            
            # Find candidates
            candidate_ids = index.intersects(bbox)
            
            for cand_id in candidate_ids:
                if cand_id == fid:
                    continue
                
                # Avoid checking same pair twice
                pair = tuple(sorted([fid, cand_id]))
                if pair in checked_pairs:
                    continue
                checked_pairs.add(pair)
                
                candidate = features_dict.get(cand_id)
                if not candidate:
                    continue
                
                cand_geom = candidate.geometry()
                
                # Check if they touch (share boundary)
                if geom.touches(cand_geom):
                    continue  # No gap if they touch
                
                # Check distance between them
                distance = geom.distance(cand_geom)
                
                if 0 < distance <= tolerance:
                    # There's a small gap
                    # Find the closest points
                    nearest_pt = geom.nearestPoint(cand_geom)
                    
                    msg = f"Hueco con polígono ID {cand_id} (Distancia: {distance:.4f} m)"
                    
                    errors.append({
                        'id': fid,
                        'msg': msg,
                        'type': 'gap',
                        'point': nearest_pt.asPoint(),
                        'distance': distance,
                        'related_id': cand_id
                    })
                    
                    if log_helper:
                        log_helper.add_log_point(
                            nearest_pt.asPoint(),
                            "Validar Polígonos",
                            msg,
                            layer_name
                        )
        
        return errors
    
    def check_slivers(self, layer, min_area, min_ratio, layer_name, log_helper=None):
        """Detect sliver polygons (very thin or small area)."""
        errors = []
        
        for feat in layer.getFeatures():
            geom = feat.geometry()
            area = geom.area()
            perimeter = geom.length()
            
            # Avoid division by zero
            if perimeter == 0:
                continue
            
            ratio = area / perimeter
            
            # Check if it's a sliver
            is_sliver = False
            reason = ""
            
            if area < min_area:
                is_sliver = True
                reason = f"área muy pequeña ({area:.6f} m²)"
            elif ratio < min_ratio:
                is_sliver = True
                reason = f"polígono muy delgado (ratio: {ratio:.6f})"
            
            if is_sliver:
                msg = f"Polígono astilla: {reason}"
                
                errors.append({
                    'id': feat.id(),
                    'msg': msg,
                    'type': 'sliver',
                    'point': geom.centroid().asPoint(),
                    'area': area,
                    'ratio': ratio
                })
                
                if log_helper:
                    log_helper.add_log_point(
                        geom.centroid().asPoint(),
                        "Validar Polígonos",
                        msg,
                        layer_name
                    )
        
        return errors
