import uuid
from ..topology.graph import Graph
from ..topology.precision import TOPO_PRECISION
from qgis.core import QgsPointXY, QgsSpatialIndex, QgsFeatureRequest, QgsGeometry, QgsRectangle, QgsVector, QgsFeature
from ..helpers.layer_utils import purge_zero_length_features

class StepDetectDangles:
    def __init__(self):
        pass

    def run(self, layer, tolerance, callback=None, dry_run=False, log_helper=None, log_callback=None):
        """
        Detects dangles and applies smart clustering-based fixes.
        Groups all dangles within tolerance and moves them to an optimal common point.
        Returns (list_of_remaining_errors, fixed_count).
        """
        layer_name = layer.name()

        # Purgar geometrías de longitud exactamente 0 antes de construir el grafo
        purge_zero_length_features(layer, step_label="Detectar Colgados", log_callback=log_callback, callback=callback)

        # Build Graph
        graph = Graph()
        features = list(layer.getFeatures())
        total = len(features)

        # Check if UUID field exists
        has_uuid = False
        for field in layer.fields():
            if field.name() == 'UUID':
                has_uuid = True
                break
        
        for i, feature in enumerate(features):
            if callback and i % 5 == 0: callback(i, total)
            
            geom = feature.geometry()
            if geom.isMultipart():
                lines = geom.asMultiPolyline()
            else:
                lines = [geom.asPolyline()]
            
            for line in lines:
                if len(line) >= 2:
                    # Round coordinates to avoid floating point precision issues
                    # 6 decimal places = 1 micrometer precision
                    # Aumentamos a 12 decimales para captar dangles infinitesimales
                    u = (round(line[0].x(), TOPO_PRECISION), round(line[0].y(), TOPO_PRECISION))
                    v = (round(line[-1].x(), TOPO_PRECISION), round(line[-1].y(), TOPO_PRECISION))
                    graph.add_edge(u, v)

        # Build Spatial Index
        index = QgsSpatialIndex(layer.getFeatures())
        
        # STEP 1: Extend dangles toward nearby receivers (before clustering)
        extended_dangles = set()
        if not dry_run:
            extended_dangles = self.extend_dangles_to_receivers(layer, graph, index, tolerance, log_helper, layer_name)
            if len(extended_dangles) > 0:
                # Rebuild graph after extensions
                graph = Graph()
                for feature in layer.getFeatures():
                    geom = feature.geometry()
                    if geom.isMultipart():
                        lines = geom.asMultiPolyline()
                    else:
                        lines = [geom.asPolyline()]
                    
                    for line in lines:
                        if len(line) >= 2:
                            u = (round(line[0].x(), TOPO_PRECISION), round(line[0].y(), TOPO_PRECISION))
                            v = (round(line[-1].x(), TOPO_PRECISION), round(line[-1].y(), TOPO_PRECISION))
                            graph.add_edge(u, v)
        
        # Collect all dangle points
        dangle_points = []
        for node, neighbors in graph.nodes.items():
            degree = len(neighbors)
            if degree == 1:
                neighbor = neighbors[0]
                # Skip if it's a loose object (both ends are degree 1)
                if len(graph.nodes[neighbor]) == 1:
                    continue
                pt = QgsPointXY(node[0], node[1])
                # Skip if this dangle was already extended
                node_key = (round(pt.x(), TOPO_PRECISION), round(pt.y(), TOPO_PRECISION))
                if node_key not in extended_dangles:
                    dangle_points.append(pt)
        
        # Cluster dangles within tolerance
        # FIX RENDIMIENTO: antes se comparaba cada dangle contra TODOS los
        # demás (O(n²)), igual que se detectó y ya se había corregido en
        # step_smart_snap.py. Con capas grandes (miles de dangles) esto
        # podía tardar minutos. Ahora se usa un QgsSpatialIndex, igual que
        # en step_smart_snap._group_dangles_optimized, reduciendo la
        # búsqueda de vecinos a O(n log n) en la práctica.
        clusters = []
        used = set()

        dangle_spatial_index = QgsSpatialIndex()
        dangle_features_by_id = {}
        for i, pt in enumerate(dangle_points):
            feat = QgsFeature()
            feat.setId(i)
            feat.setGeometry(QgsGeometry.fromPointXY(pt))
            dangle_spatial_index.addFeature(feat)
            dangle_features_by_id[i] = pt

        for i, pt in enumerate(dangle_points):
            if i in used:
                continue

            cluster = [pt]
            used.add(i)

            search_rect = QgsRectangle(
                pt.x() - tolerance, pt.y() - tolerance,
                pt.x() + tolerance, pt.y() + tolerance
            )
            candidate_ids = dangle_spatial_index.intersects(search_rect)

            for j in candidate_ids:
                if j == i or j in used:
                    continue
                other_pt = dangle_features_by_id[j]
                if pt.distance(other_pt) <= tolerance:
                    cluster.append(other_pt)
                    used.add(j)

            if len(cluster) > 0:
                clusters.append(cluster)
        
        # Process each cluster
        layer.startEditing()
        fixed_count = 0
        errors = []
        
        for cluster in clusters:
            # PRIORITY 1: Check if this is a pair of dangles that can be corrected via intersection
            if len(cluster) == 2:
                intersection_point = find_dangle_pair_intersection(cluster, graph, layer, index, tolerance)
                
                if intersection_point:
                    # We found a valid intersection for this pair
                    if dry_run:
                        # Report as fixable error (intersection-based)
                        for pt in cluster:
                            info, feat_id = get_info(pt, layer, index)
                            error_dict = {
                                'point': pt,
                                'type': 'dangle',
                                'msg': f'Nodo colgante{info} - Corregible (Par: Intersección)',
                                'can_snap': True,
                                'snap_point': intersection_point,
                                'id': feat_id
                            }
                            # Add UUID if available
                            if has_uuid and feat_id is not None:
                                feat = layer.getFeature(feat_id)
                                if feat.isValid():
                                    error_dict['uuid'] = feat['UUID']
                            
                            errors.append(error_dict)
                    else:
                        # Move both dangles to the intersection point
                        cluster_moved = False
                        for pt in cluster:
                            if move_endpoint(layer, index, pt, intersection_point, tolerance):
                                cluster_moved = True
                        
                        if cluster_moved:
                            fixed_count += 1
                            # DEBUG: Log the pair correction
                            # Par corregido por intersección (registrado en log_helper)
                            if log_helper:
                                log_helper.add_log_point(intersection_point, "Extender Dangles", "Par corregido (Intersección)", layer_name)
                    
                    # Skip to next cluster (pair handled)
                    continue
            
            # PRIORITY 2: Find optimal snap point for this cluster (original logic)
            # Returns: (point, target_fid, is_vertex)
            snap_result = find_optimal_snap_point(cluster, graph, layer, index, tolerance)
            
            if snap_result:
                snap_point, target_fid, is_vertex = snap_result
                
                if dry_run:
                    # Report as fixable error
                    for pt in cluster:
                        info, feat_id = get_info(pt, layer, index)
                        error_dict = {
                            'point': pt,
                            'type': 'dangle',
                            'msg': f'Nodo colgante{info} - Corregible (Snap & Split)',
                            'can_snap': True,
                            'snap_point': snap_point,
                            'id': feat_id
                        }
                        # Add UUID if available
                        if has_uuid and feat_id is not None:
                            feat = layer.getFeature(feat_id)
                            if feat.isValid():
                                error_dict['uuid'] = feat['UUID']
                        
                        errors.append(error_dict)
                else:
                    # Move all points in cluster to snap_point
                    cluster_moved = False
                    for pt in cluster:
                        if move_endpoint(layer, index, pt, snap_point, tolerance):
                            cluster_moved = True
                    
                    if cluster_moved:
                        fixed_count += 1
                        if log_helper:
                            log_helper.add_log_point(snap_point, "Extender Dangles", "Snap de cluster", layer_name)
                        
                        # SPLIT TARGET FEATURE if valid
                        if target_fid is not None:
                            split_feature_at_point(layer, target_fid, snap_point)
                            if log_helper:
                                log_helper.add_log_point(snap_point, "Extender Dangles", "Split de feature destino", layer_name)
            else:
                # No valid snap found - report as error
                for pt in cluster:
                    info, feat_id = get_info(pt, layer, index)
                    error_dict = {
                        'point': pt,
                        'type': 'dangle',
                        'msg': f'Nodo colgante{info} - No corregido: Sin solución clara en tolerancia',
                        'can_snap': False,
                        'snap_point': None,
                        'id': feat_id
                    }
                    # Add UUID if available
                    if has_uuid and feat_id is not None:
                        feat = layer.getFeature(feat_id)
                        if feat.isValid():
                            error_dict['uuid'] = feat['UUID']
                    
                    errors.append(error_dict)
        
        if not dry_run:
            layer.commitChanges()
        else:
            layer.rollBack() # No changes in dry run
            
        return errors, fixed_count

    def extend_dangles_to_receivers(self, layer, graph, index, tolerance, log_helper=None, layer_name=""):
        """
        Extend dangling endpoints toward nearby receivers within tolerance.
        Returns set of extended dangle node keys (rounded coordinates).
        """
        layer.startEditing()
        extended_nodes = set()
        
        # Get all dangles
        dangle_nodes = []
        for node, neighbors in graph.nodes.items():
            degree = len(neighbors)
            if degree == 1:
                neighbor = neighbors[0]
                # Skip loose objects
                if len(graph.nodes[neighbor]) == 1:
                    continue
                dangle_nodes.append((QgsPointXY(node[0], node[1]), neighbor))
        
        # Process each dangle
        for dangle_pt, neighbor_node in dangle_nodes:
            # Find the feature containing this dangle
            dangle_fid = None
            dangle_is_start = None
            
            search_rect = QgsRectangle(dangle_pt.x()-0.001, dangle_pt.y()-0.001,
                                       dangle_pt.x()+0.001, dangle_pt.y()+0.001)
            candidate_fids = index.intersects(search_rect)
            
            for fid in candidate_fids:
                feat = layer.getFeature(fid)
                if not feat.isValid():
                    continue
                geom = feat.geometry()
                
                if geom.isMultipart():
                    parts = geom.asMultiPolyline()
                else:
                    parts = [geom.asPolyline()]
                
                for part in parts:
                    if len(part) < 2:
                        continue
                    start = QgsPointXY(part[0])
                    end = QgsPointXY(part[-1])
                    
                    if start.distance(dangle_pt) < 0.001:
                        dangle_fid = fid
                        dangle_is_start = True
                        break
                    elif end.distance(dangle_pt) < 0.001:
                        dangle_fid = fid
                        dangle_is_start = False
                        break
                
                if dangle_fid is not None:
                    break
            
            if dangle_fid is None:
                continue
            
            # Get direction vector for extension
            dangle_feat = layer.getFeature(dangle_fid)
            dangle_geom = dangle_feat.geometry()
            
            if dangle_geom.isMultipart():
                dangle_line = dangle_geom.asMultiPolyline()[0]
            else:
                dangle_line = dangle_geom.asPolyline()
            
            if dangle_is_start:
                # Extend from start: direction is from point[1] to point[0]
                if len(dangle_line) < 2:
                    continue
                p1 = QgsPointXY(dangle_line[1])
                p0 = QgsPointXY(dangle_line[0])
                direction = QgsVector(p0.x() - p1.x(), p0.y() - p1.y())
            else:
                # Extend from end: direction is from point[-2] to point[-1]
                if len(dangle_line) < 2:
                    continue
                p1 = QgsPointXY(dangle_line[-2])
                p0 = QgsPointXY(dangle_line[-1])
                direction = QgsVector(p0.x() - p1.x(), p0.y() - p1.y())
            
            # Normalize direction
            length = direction.length()
            if length < 1e-12: # Umbral atómico para permitir segmentos de micras
                continue
            direction = QgsVector(direction.x() / length, direction.y() / length)
            
            # Extend by tolerance
            extended_pt = QgsPointXY(dangle_pt.x() + direction.x() * tolerance,
                                     dangle_pt.y() + direction.y() * tolerance)
            
            # Create extended line geometry
            if dangle_is_start:
                extended_line = [extended_pt, dangle_pt] + dangle_line[1:]
            else:
                extended_line = dangle_line[:-1] + [dangle_pt, extended_pt]
            
            extended_geom = QgsGeometry.fromPolylineXY(extended_line)
            # Find receivers that are within tolerance of the dangle point (Circular Search)
            # En lugar de centrar el buffer en el punto extendido, lo centramos en el dangle 
            # y usamos un radio de 2x tolerancia para capturar todo el área de influencia.
            search_rect = QgsRectangle(
                dangle_pt.x() - tolerance * 2, dangle_pt.y() - tolerance * 2,
                dangle_pt.x() + tolerance * 2, dangle_pt.y() + tolerance * 2
            )
            receiver_fids = index.intersects(search_rect)
            
            best_intersection = None
            best_receiver_fid = None
            min_dist_found = float('inf')
            
            # LOG: Seguimiento detallado por dangle
            # print(f"[DEBUG] Analizando dangle en {dangle_pt}")
            for receiver_fid in receiver_fids:
                # Quitamos la restricción de que el receptor no sea el propio dangle
                # para permitir autocierres en T de una misma línea compleja.
                is_self = (receiver_fid == dangle_fid)
                
                receiver_feat = layer.getFeature(receiver_fid)
                if not receiver_feat.isValid():
                    # RECOVERY LOGIC: If feature is invalid, it was probably split just now.
                    # Search for candidates in the exact same spot to find the "children" features.
                    recovery_request = QgsFeatureRequest().setFilterRect(search_rect)
                    recovery_feats = list(layer.getFeatures(recovery_request))
                    candidates = recovery_feats
                else:
                    candidates = [receiver_feat]
                
                for candidate_feat in candidates:
                    receiver_geom = candidate_feat.geometry()
                
                # --- EXTENUACIÓN: Cálculo Matemático Analítico ---
                # En lugar de intersects(), calculamos la intersección rayo-segmento
                if receiver_geom.isMultipart():
                    r_parts = receiver_geom.asMultiPolyline()
                else:
                    r_parts = [receiver_geom.asPolyline()]
                
                for r_part in r_parts:
                    for j in range(len(r_part)-1):
                        seg_p1 = QgsPointXY(r_part[j])
                        seg_p2 = QgsPointXY(r_part[j+1])
                        
                        # Intersección matemática Rayo(dangle_pt, direction) con Segmento(seg_p1, seg_p2)
                        # u es la distancia desde dangle_pt a lo largo del rayo
                        # t es el parámetro en el segmento [0, 1]
                        
                        # SEGURIDAD PARA AUTOCIERRE: Si es la propia línea, no anclar a segmentos adyacentes
                        if is_self:
                            # Ignoramos los primeros/últimos 2 segmentos para evitar snaps a la salida
                            if dangle_is_start:
                                if j < 2: continue
                            else:
                                if j > len(r_part) - 4: continue
                        
                        intersect_res = self._calculate_ray_segment_intersection(dangle_pt, direction, seg_p1, seg_p2)
                        
                        if intersect_res:
                            u_dist, t_param, i_pt = intersect_res
                            # Si está dentro de la tolerancia y es hacia adelante (u > -1e-9 para micro-precision)
                            if -1e-9 <= u_dist <= tolerance:
                                if best_intersection is None or u_dist < min_dist_found:
                                    best_intersection = i_pt
                                    best_receiver_fid = receiver_fid
                                    min_dist_found = u_dist
                
                # FALLBACK DE EXTREMA PROXIMIDAD: Si está a < 1e-6, snap aunque no corte direccionalmente
                dist_to_geom = receiver_geom.distance(QgsGeometry.fromPointXY(dangle_pt))
                if dist_to_geom < 2e-6: # Un poco más permisivo para el snap directo
                    closest_res = receiver_geom.closestSegmentWithContext(dangle_pt)
                    i_pt = closest_res[1]
                    if best_intersection is None or dist_to_geom < min_dist_found:
                        best_intersection = i_pt
                        best_receiver_fid = receiver_fid
                        min_dist_found = dist_to_geom
            
            if best_intersection is None:
                continue
            
            # Snap to intersection point
            snap_point = best_intersection
            
            # DEBUG: Log the extension
            # Extensión registrada via log_helper
            if log_helper:
                log_helper.add_log_point(snap_point, "Extender Dangles", "Extensión a intersección", layer_name)
            
            # Modify dangle geometry
            new_line = list(dangle_line)
            if dangle_is_start:
                new_line[0] = snap_point
            else:
                new_line[-1] = snap_point
            
            new_geom = QgsGeometry.fromPolylineXY(new_line)
            layer.changeGeometry(dangle_fid, new_geom)
            
            # Track this extended dangle
            snap_key = (round(snap_point.x(), TOPO_PRECISION), round(snap_point.y(), TOPO_PRECISION))
            extended_nodes.add(snap_key)

            # --- HARDENING INJECTED BY AGENT ---
            # MANDATORY: Split the receiver line at the intersection point to "harden" the topology
            if best_receiver_fid is not None:
                try:
                    # Attempt physical split (Priority 1)
                    split_feature_at_point(layer, best_receiver_fid, snap_point)
                except Exception as e:
                    # Fallback: Geometry reconstruction (Soft Split) if physical split fails
                    # Physical split failed, attempting soft split
                    try:
                        self._ensure_node_at_point(layer, best_receiver_fid, snap_point)
                    except Exception as e2:
                        pass  # Soft split also failed, skip silently
        
        layer.commitChanges()
        if log_helper:
            log_helper.add_log_point(QgsPointXY(0, 0), "Extender Dangles", f"Total extendidos: {len(extended_nodes)}", layer_name)
        return extended_nodes

    def _ensure_node_at_point(self, layer, fid, point):
        """
        Soft split fallback: inserts a vertex in the line's geometry without splitting features.
        """
        feat = layer.getFeature(fid)
        if not feat.isValid(): return
        
        geom = feat.geometry()
        # Insert vertex at the specific point (using context to find segment)
        res = geom.closestSegmentWithContext(point)
        vertex_idx = res[2]
        
        if vertex_idx > 0:
            # Reconstruct geometry to avoid OGR/GEOS insertVertex issues
            if geom.isMultipart():
                parts = geom.asMultiPolyline()
            else:
                parts = [geom.asPolyline()]
            
            inserted = False
            current_global = 0
            new_parts = []
            
            for part in parts:
                if inserted:
                    new_parts.append(list(part))
                    continue
                
                if current_global + len(part) >= vertex_idx:
                    local_idx = vertex_idx - current_global
                    new_part = list(part)
                    new_part.insert(local_idx, point)
                    new_parts.append(new_part)
                    inserted = True
                else:
                    new_parts.append(list(part))
                current_global += len(part)
                
            if inserted:
                if geom.isMultipart():
                    new_geom = QgsGeometry.fromMultiPolylineXY(new_parts)
                else:
                    new_geom = QgsGeometry.fromPolylineXY(new_parts[0])
                layer.changeGeometry(fid, new_geom)

    def _calculate_ray_segment_intersection(self, ray_p, ray_dir, seg_p1, seg_p2):
        """
        Mathematical intersection of a ray and a segment.
        Returns (u, t, point) or None.
        u: distance from ray_p along ray_dir.
        t: parameter along segment [0, 1].
        """
        v1 = ray_p
        v2 = ray_dir  # This is a unit vector
        v3 = seg_p1
        v4 = QgsVector(seg_p2.x() - seg_p1.x(), seg_p2.y() - seg_p1.y())
        
        # Determinant
        det = v2.x() * (-v4.y()) - v2.y() * (-v4.x())
        
        if abs(det) < 1e-15:
            # Parallel. Check if collinear.
            # For simplicity, we skip collinear intersections here as they are rare T-junctions
            # but we can improve if needed.
            return None
            
        dx = v3.x() - v1.x()
        dy = v3.y() - v1.y()
        
        u = (dx * (-v4.y()) - dy * (-v4.x())) / det
        t = (v2.x() * dy - v2.y() * dx) / det
        
        if 0 <= t <= 1:
            point = QgsPointXY(v1.x() + u * v2.x(), v1.y() + u * v2.y())
            return (u, t, point)
            
        return None


def find_optimal_snap_point(cluster, graph, layer, index, tolerance):
    """
    Find the optimal point to snap all cluster members to.
    Returns: (QgsPointXY, target_fid, is_vertex) or None
    
    Logic:
    1. Search candidates within tolerance.
    2. Priority A: Existing Vertex (Degree > 1).
    3. Priority B: Segment Point (Smart Snap logic).
    """
    # Get center of cluster
    center_x = sum(p.x() for p in cluster) / len(cluster)
    center_y = sum(p.y() for p in cluster) / len(cluster)
    center = QgsPointXY(center_x, center_y)
    
    # Search for features near cluster center
    search_geom = QgsGeometry.fromPointXY(center).buffer(tolerance, 5)
    fids = index.intersects(search_geom.boundingBox())
    
    candidates_vertex = []
    candidates_segment = []
    
    for fid in fids:
        feat = layer.getFeature(fid)
        if not feat.isValid(): continue
        geom = feat.geometry()
        
        # Check Vertices
        vertices = geom.vertices()
        while vertices.hasNext():
            v = vertices.next()
            v_pt = QgsPointXY(v.x(), v.y())
            dist = center.distance(v_pt)
            if dist <= tolerance:
                # Check if it's a valid node (degree > 1)
                node_key = (round(v.x(), 10), round(v.y(), 10))
                if node_key in graph.nodes and len(graph.nodes[node_key]) > 1:
                    candidates_vertex.append((dist, v_pt, fid))
        
        # Check Segment Projection
        closest_res = geom.closestSegmentWithContext(center)
        closest_pt = closest_res[1]
        dist_seg = center.distance(closest_pt)
        
        if dist_seg <= tolerance:
            # Check if it is actually a vertex
            is_v = False
            vertices = geom.vertices()
            while vertices.hasNext():
                v = vertices.next()
                if QgsPointXY(v.x(), v.y()).distance(closest_pt) < 0.0001:
                    is_v = True
                    break
            if not is_v:
                candidates_segment.append((dist_seg, closest_pt, fid))

    # Priority 1: Existing Vertex
    if candidates_vertex:
        # Return closest vertex
        best = min(candidates_vertex, key=lambda x: x[0])
        return (best[1], best[2], True)
    
    # Priority 2: Segment Point (Smart Snap)
    if candidates_segment:
        best_seg = min(candidates_segment, key=lambda x: x[0])
        dist, pt, fid = best_seg
        
        # SMART SNAP CHECK: Would splitting here create a short segment?
        feat = layer.getFeature(fid)
        geom = feat.geometry()
        
        # Find nearest vertex on this feature to the split point
        min_v_dist = float('inf')
        nearest_v = None
        vertices = geom.vertices()
        while vertices.hasNext():
            v = vertices.next()
            v_pt = QgsPointXY(v.x(), v.y())
            d = pt.distance(v_pt)
            if d < min_v_dist:
                min_v_dist = d
                nearest_v = v_pt
        
        # If split point is too close to a vertex (< tolerance)
        if min_v_dist < tolerance:
            # Check if we can snap to that vertex instead (allow up to 2x tolerance from original center)
            dist_to_center = center.distance(nearest_v)
            if dist_to_center <= (2 * tolerance):
                # YES: Snap to the existing vertex instead of creating a short segment
                return (nearest_v, fid, True)
            else:
                # NO: Too far, must split here (creates short segment, but unavoidable)
                return (pt, fid, False)
        
        return (pt, fid, False)
    
    # Priority 3: Center (No target feature)
    # We return the center but no target FID, so no split will happen.
    return (center, None, False)


def split_feature_at_point(layer, fid, point):
    """
    Splits the feature with ID `fid` at the given `point` into two separate features.
    Handles both single-part and multi-part geometries.
    """
    feat = layer.getFeature(fid)
    if not feat.isValid(): return
    
    geom = feat.geometry()
    
    # We need to find where the point is on the geometry
    # closestSegmentWithContext returns (sqrDist, minDistPoint, afterVertexIndex, leftOf)
    # afterVertexIndex is the index of the vertex *after* the segment.
    closest = geom.closestSegmentWithContext(point)
    pt_proj = closest[1]
    after_vertex = closest[2]
    
    if after_vertex < 1: return # Should be at least 1 (segment 0 is between 0 and 1)
    
    # Extract original points
    if geom.isMultipart():
        parts = geom.asMultiPolyline()
        
        # Identify which part contains the split point
        target_part_index = -1
        min_dist = float('inf')
        
        for i, part in enumerate(parts):
            # Check if point is on this part (using a small buffer/distance check)
            # Since we don't have part index from closestSegmentWithContext easily for multipart,
            # we re-check distance to each part.
            part_geom = QgsGeometry.fromPolylineXY(part)
            dist = part_geom.distance(QgsGeometry.fromPointXY(point))
            if dist < min_dist:
                min_dist = dist
                target_part_index = i
        
        if target_part_index == -1 or min_dist > 0.001:
            return # Could not identify part
            
        polyline = parts[target_part_index]
        
        # Recalculate vertex index for this specific part
        part_geom = QgsGeometry.fromPolylineXY(polyline)
        closest_part = part_geom.closestSegmentWithContext(point)
        after_vertex = closest_part[2]
        
    else:
        polyline = geom.asPolyline()
        target_part_index = -1 # Single part
    
    # Check if point is an endpoint (Start or End)
    # REDUCIDO A ESCALA ATÓMICA: 10^-12m para permitir uniones ultra-precisas en T
    if QgsPointXY(polyline[0]).distance(point) < 1e-12 or \
       QgsPointXY(polyline[-1]).distance(point) < 1e-12:
        return # Do not split at endpoints
    
    # Create two new point lists
    # Segment index is after_vertex - 1.
    # Points 0 to (after_vertex - 1) are first part.
    # Point 'point' is the split.
    # Points (after_vertex) to end are second part.
    
    # Part 1: Start -> ... -> Vertex Before -> Split Point
    part1_line = polyline[:after_vertex]
    part1_line.append(point)
    
    # Part 2: Split Point -> Vertex After -> ... -> End
    part2_line = [point]
    part2_line.extend(polyline[after_vertex:])
    
    # Create new features
    # We copy attributes from original
    attrs = feat.attributes()
    
    # IMPORTANTE: nunca se debe crear un feature multiparte a partir de este split.
    # Antes, si la línea receptora ya era multiparte, se pegaban las "otras partes"
    # (que no tienen ninguna relación real con el corte) junto con part1_line en
    # un único feature multiparte artificial (new_parts_1 + fromMultiPolylineXY).
    # Eso generaba objetos "raros" cuyo límite interno entre partes no es un
    # vértice real de una línea continua, y por tanto no se podían volver a
    # cortar correctamente en Fase C/Paso 14 (el punto de corte cae justo en
    # ese límite artificial entre partes ajenas).
    #
    # Ahora: cada parte se trata siempre como un objeto independiente monoparte.
    # - Las "otras partes" del multiparte original (si las había) se preservan
    #   cada una como su propio feature, sin tocar.
    # - La parte que contenía el punto de corte se divide en part1_line y
    #   part2_line, también como dos features monoparte independientes.
    new_features = []
    uuid_field_idx = layer.fields().indexOf('UUID')
    
    def _make_feature(pts):
        f = QgsFeature(layer.fields())
        f.setAttributes(attrs)
        f.setGeometry(QgsGeometry.fromPolylineXY(pts))
        # Regenerar UUID único: si se reutilizara el UUID original en varios
        # features nuevos, las búsquedas por UUID (ej. localizar/corregir un
        # error) podrían encontrar el objeto equivocado.
        if uuid_field_idx != -1:
            f.setAttribute(uuid_field_idx, str(uuid.uuid4()))
        return f
    
    if geom.isMultipart():
        for i, p in enumerate(parts):
            if i == target_part_index:
                continue
            if len(p) < 2:
                continue
            new_features.append(_make_feature(list(p)))
    
    # Parte 1 y Parte 2 (siempre monoparte)
    new_features.append(_make_feature(part1_line))
    new_features.append(_make_feature(part2_line))
    
    # Añadir los nuevos features (todos monoparte, nunca multiparte)
    layer.addFeatures(new_features)
    
    # Eliminar el feature original
    layer.deleteFeature(fid) 


def move_endpoint(layer, index, old_pt, new_pt, tolerance):
    """Move an endpoint from old_pt to new_pt."""
    # Use tolerance for searching the point to move
    search_tol = tolerance if tolerance > 0.000001 else 0.001
    search_rect = QgsRectangle(old_pt.x()-search_tol, old_pt.y()-search_tol, 
                                old_pt.x()+search_tol, old_pt.y()+search_tol)
    fids = index.intersects(search_rect)
    
    moved = False
    for fid in fids:
        feat = layer.getFeature(fid)
        if not feat.isValid():
            continue
        
        geom = feat.geometry()
        if geom.isMultipart():
            parts = geom.asMultiPolyline()
        else:
            parts = [geom.asPolyline()]
        
        modified = False
        new_parts = []
        
        for poly in parts:
            if not poly or len(poly) < 2:
                if poly:
                    new_parts.append(poly)
                continue
            
            new_poly = list(poly)
            
            # Check start and end using tolerance
            if QgsPointXY(poly[0]).distance(old_pt) < search_tol:
                new_poly[0] = new_pt
                modified = True
            elif QgsPointXY(poly[-1]).distance(old_pt) < search_tol:
                new_poly[-1] = new_pt
                modified = True
            
            new_parts.append(new_poly)
        
        if modified and new_parts:
            if geom.isMultipart():
                new_geom = QgsGeometry.fromMultiPolylineXY(new_parts)
            else:
                new_geom = QgsGeometry.fromPolylineXY(new_parts[0])
            
            layer.changeGeometry(fid, new_geom)
            moved = True
    
    return moved


def get_info(pt, layer, index):
    """Get L and N info for a point. Returns (info_str, fid)."""
    # Use a small fixed tolerance for info lookup, or pass tolerance if needed.
    # For info, 0.01 is usually fine, but let's make it slightly robust.
    search_tol = 0.01 
    search_rect = QgsRectangle(pt.x() - search_tol, pt.y() - search_tol, 
                                pt.x() + search_tol, pt.y() + search_tol)
    fids = index.intersects(search_rect)
    
    for fid in fids:
        feat = layer.getFeature(fid)
        if not feat.isValid():
            continue
        geom = feat.geometry()
        
        if geom.isMultipart():
            parts = geom.asMultiPolyline()
        else:
            parts = [geom.asPolyline()]
        
        for poly in parts:
            if not poly:
                continue
            if QgsPointXY(poly[0]).distance(pt) < search_tol or QgsPointXY(poly[-1]).distance(pt) < search_tol:
                L = geom.length()
                N = sum(len(p) for p in parts)
                return (f" (L={L:.2f}, N={N})", fid)
    
    return (" (L=?, N=?)", None)


def calculate_line_intersection(p1, dir1, p2, dir2, max_distance):
    """
    Calculate intersection of two rays defined by point + direction.
    Returns None if lines are parallel or intersection is invalid.
    
    Args:
        p1: QgsPointXY - Starting point of first ray
        dir1: QgsVector - Direction of first ray (normalized)
        p2: QgsPointXY - Starting point of second ray
        dir2: QgsVector - Direction of second ray (normalized)
        max_distance: Maximum allowed distance from intersection to either point
    
    Returns:
        QgsPointXY - Intersection point, or None if invalid
    """
    # Calculate determinant to check if lines are parallel
    det = dir1.x() * (-dir2.y()) - dir1.y() * (-dir2.x())
    
    if abs(det) < 0.0001:  # Lines are parallel
        return None
    
    dx = p2.x() - p1.x()
    dy = p2.y() - p1.y()
    
    # Calculate parameter t1 for first ray
    t1 = (dx * (-dir2.y()) - dy * (-dir2.x())) / det
    
    # Calculate intersection point
    intersection = QgsPointXY(p1.x() + t1 * dir1.x(), p1.y() + t1 * dir1.y())
    
    # Validate intersection distance from both points
    dist1 = intersection.distance(p1)
    dist2 = intersection.distance(p2)
    
    # Intersection must be within reasonable distance (2x tolerance)
    if dist1 > max_distance * 2 or dist2 > max_distance * 2:
        return None
    
    # Intersection must be forward (not backward) from p1
    if t1 < 0:
        return None
    
    return intersection


def find_dangle_pair_intersection(cluster, graph, layer, index, tolerance):
    """
    Detect if a cluster of 2 dangles can be corrected by moving both to their intersection.
    
    Args:
        cluster: List of 2 QgsPointXY representing the dangle endpoints
        graph: Graph object with topology information
        layer: QgsVectorLayer
        index: QgsSpatialIndex
        tolerance: Maximum distance for intersection validity
    
    Returns:
        QgsPointXY - Intersection point if valid, None otherwise
    """
    if len(cluster) != 2:
        return None
    
    pt1, pt2 = cluster
    
    # Get direction vectors for both dangles
    dir1 = get_dangle_direction(pt1, layer, index)
    dir2 = get_dangle_direction(pt2, layer, index)
    
    if dir1 is None or dir2 is None:
        return None
    
    # Calculate intersection
    intersection = calculate_line_intersection(pt1, dir1, pt2, dir2, tolerance)
    
    if intersection is None:
        return None
    
    # Validate that intersection is within tolerance for both points
    if pt1.distance(intersection) > tolerance or pt2.distance(intersection) > tolerance:
        return None
    
    return intersection


def get_dangle_direction(point, layer, index):
    """
    Get the direction vector of a dangle endpoint.
    
    Args:
        point: QgsPointXY - The dangle endpoint
        layer: QgsVectorLayer
        index: QgsSpatialIndex
    
    Returns:
        QgsVector - Normalized direction vector, or None if not found
    """
    search_tol = 0.001
    search_rect = QgsRectangle(point.x()-search_tol, point.y()-search_tol,
                               point.x()+search_tol, point.y()+search_tol)
    fids = index.intersects(search_rect)
    
    for fid in fids:
        feat = layer.getFeature(fid)
        if not feat.isValid():
            continue
        
        geom = feat.geometry()
        if geom.isMultipart():
            parts = geom.asMultiPolyline()
        else:
            parts = [geom.asPolyline()]
        
        for part in parts:
            if len(part) < 2:
                continue
            
            start = QgsPointXY(part[0])
            end = QgsPointXY(part[-1])
            
            # Check if this is the start point
            if start.distance(point) < search_tol:
                # Direction is from second point to first point (outward)
                direction = QgsVector(start.x() - part[1].x(), start.y() - part[1].y())
                length = direction.length()
                if length > 1e-12:
                    return QgsVector(direction.x() / length, direction.y() / length)
            
            # Check if this is the end point
            elif end.distance(point) < search_tol:
                # Direction is from second-to-last point to last point (outward)
                direction = QgsVector(end.x() - part[-2].x(), end.y() - part[-2].y())
                length = direction.length()
                if length > 1e-12:
                    return QgsVector(direction.x() / length, direction.y() / length)
    
    return None

