from ..topology.graph import Graph
from qgis.core import QgsPointXY, QgsSpatialIndex, QgsFeatureRequest, QgsGeometry, QgsRectangle, QgsVector, QgsFeature

class StepDetectDangles:
    def __init__(self):
        pass

    def run(self, layer, tolerance, callback=None, dry_run=False, log_helper=None):
        """
        Detects dangles and applies smart clustering-based fixes.
        Groups all dangles within tolerance and moves them to an optimal common point.
        Returns (list_of_remaining_errors, fixed_count).
        """
        # Build Graph
        graph = Graph()
        features = list(layer.getFeatures())
        total = len(features)
        layer_name = layer.name()
        
        # Check if UUID field exists
        has_uuid = False
        for field in layer.fields():
            if field.name() == 'UUID':
                has_uuid = True
                break
        
        for i, feature in enumerate(features):
            if callback and i % 5 == 0: callback(i, total)
            
            geom = feature.geometry()
            if geom.isMultipart():
                lines = geom.asMultiPolyline()
            else:
                lines = [geom.asPolyline()]
            
            for line in lines:
                if len(line) >= 2:
                    # Round coordinates to avoid floating point precision issues
                    # 6 decimal places = 1 micrometer precision
                    u = (round(line[0].x(), 10), round(line[0].y(), 10))
                    v = (round(line[-1].x(), 10), round(line[-1].y(), 10))
                    graph.add_edge(u, v)

        # Build Spatial Index
        index = QgsSpatialIndex(layer.getFeatures())
        
        # STEP 1: Extend dangles toward nearby receivers (before clustering)
        extended_dangles = set()
        if not dry_run:
            extended_dangles = self.extend_dangles_to_receivers(layer, graph, index, tolerance, log_helper, layer_name)
            if len(extended_dangles) > 0:
                # Rebuild graph after extensions
                graph = Graph()
                for feature in layer.getFeatures():
                    geom = feature.geometry()
                    if geom.isMultipart():
                        lines = geom.asMultiPolyline()
                    else:
                        lines = [geom.asPolyline()]
                    
                    for line in lines:
                        if len(line) >= 2:
                            u = (round(line[0].x(), 10), round(line[0].y(), 10))
                            v = (round(line[-1].x(), 10), round(line[-1].y(), 10))
                            graph.add_edge(u, v)
        
        # Collect all dangle points
        dangle_points = []
        for node, neighbors in graph.nodes.items():
            degree = len(neighbors)
            if degree == 1:
                neighbor = neighbors[0]
                # Skip if it's a loose object (both ends are degree 1)
                if len(graph.nodes[neighbor]) == 1:
                    continue
                pt = QgsPointXY(node[0], node[1])
                # Skip if this dangle was already extended
                node_key = (round(pt.x(), 10), round(pt.y(), 10))
                if node_key not in extended_dangles:
                    dangle_points.append(pt)
        
        # Cluster dangles within tolerance
        clusters = []
        used = set()
        
        for pt in dangle_points:
            if id(pt) in used:
                continue
            
            # Find all dangles within tolerance of this point
            cluster = [pt]
            used.add(id(pt))
            
            for other_pt in dangle_points:
                if id(other_pt) in used:
                    continue
                if pt.distance(other_pt) <= tolerance:
                    cluster.append(other_pt)
                    used.add(id(other_pt))
            
            if len(cluster) > 0:
                clusters.append(cluster)
        
        # Process each cluster
        layer.startEditing()
        fixed_count = 0
        errors = []
        
        for cluster in clusters:
            # PRIORITY 1: Check if this is a pair of dangles that can be corrected via intersection
            if len(cluster) == 2:
                intersection_point = find_dangle_pair_intersection(cluster, graph, layer, index, tolerance)
                
                if intersection_point:
                    # We found a valid intersection for this pair
                    if dry_run:
                        # Report as fixable error (intersection-based)
                        for pt in cluster:
                            info, feat_id = get_info(pt, layer, index)
                            error_dict = {
                                'point': pt,
                                'type': 'dangle',
                                'msg': f'Nodo colgante{info} - Corregible (Par: Intersección)',
                                'can_snap': True,
                                'snap_point': intersection_point,
                                'id': feat_id
                            }
                            # Add UUID if available
                            if has_uuid and feat_id is not None:
                                feat = layer.getFeature(feat_id)
                                if feat.isValid():
                                    error_dict['uuid'] = feat['UUID']
                            
                            errors.append(error_dict)
                    else:
                        # Move both dangles to the intersection point
                        cluster_moved = False
                        for pt in cluster:
                            if move_endpoint(layer, index, pt, intersection_point, tolerance):
                                cluster_moved = True
                        
                        if cluster_moved:
                            fixed_count += 1
                            # DEBUG: Log the pair correction
                            print(f"[DANGLE PAIR] Corrected pair at intersection {intersection_point}")
                            if log_helper:
                                log_helper.add_log_point(intersection_point, "Extender Dangles", "Par corregido (Intersección)", layer_name)
                    
                    # Skip to next cluster (pair handled)
                    continue
            
            # PRIORITY 2: Find optimal snap point for this cluster (original logic)
            # Returns: (point, target_fid, is_vertex)
            snap_result = find_optimal_snap_point(cluster, graph, layer, index, tolerance)
            
            if snap_result:
                snap_point, target_fid, is_vertex = snap_result
                
                if dry_run:
                    # Report as fixable error
                    for pt in cluster:
                        info, feat_id = get_info(pt, layer, index)
                        error_dict = {
                            'point': pt,
                            'type': 'dangle',
                            'msg': f'Nodo colgante{info} - Corregible (Snap & Split)',
                            'can_snap': True,
                            'snap_point': snap_point,
                            'id': feat_id
                        }
                        # Add UUID if available
                        if has_uuid and feat_id is not None:
                            feat = layer.getFeature(feat_id)
                            if feat.isValid():
                                error_dict['uuid'] = feat['UUID']
                        
                        errors.append(error_dict)
                else:
                    # Move all points in cluster to snap_point
                    cluster_moved = False
                    for pt in cluster:
                        if move_endpoint(layer, index, pt, snap_point, tolerance):
                            cluster_moved = True
                    
                    if cluster_moved:
                        fixed_count += 1
                        if log_helper:
                            log_helper.add_log_point(snap_point, "Extender Dangles", "Snap de cluster", layer_name)
                        
                        # SPLIT TARGET FEATURE if valid
                        if target_fid is not None:
                            split_feature_at_point(layer, target_fid, snap_point)
                            if log_helper:
                                log_helper.add_log_point(snap_point, "Extender Dangles", "Split de feature destino", layer_name)
            else:
                # No valid snap found - report as error
                for pt in cluster:
                    info, feat_id = get_info(pt, layer, index)
                    error_dict = {
                        'point': pt,
                        'type': 'dangle',
                        'msg': f'Nodo colgante{info} - No corregido: Sin solución clara en tolerancia',
                        'can_snap': False,
                        'snap_point': None,
                        'id': feat_id
                    }
                    # Add UUID if available
                    if has_uuid and feat_id is not None:
                        feat = layer.getFeature(feat_id)
                        if feat.isValid():
                            error_dict['uuid'] = feat['UUID']
                    
                    errors.append(error_dict)
        
        if not dry_run:
            layer.commitChanges()
        else:
            layer.rollBack() # No changes in dry run
            
        return errors, fixed_count

    def extend_dangles_to_receivers(self, layer, graph, index, tolerance, log_helper=None, layer_name=""):
        """
        Extend dangling endpoints toward nearby receivers within tolerance.
        Returns set of extended dangle node keys (rounded coordinates).
        """
        layer.startEditing()
        extended_nodes = set()
        
        # Get all dangles
        dangle_nodes = []
        for node, neighbors in graph.nodes.items():
            degree = len(neighbors)
            if degree == 1:
                neighbor = neighbors[0]
                # Skip loose objects
                if len(graph.nodes[neighbor]) == 1:
                    continue
                dangle_nodes.append((QgsPointXY(node[0], node[1]), neighbor))
        
        # Process each dangle
        for dangle_pt, neighbor_node in dangle_nodes:
            # Find the feature containing this dangle
            dangle_fid = None
            dangle_is_start = None
            
            search_rect = QgsRectangle(dangle_pt.x()-0.001, dangle_pt.y()-0.001,
                                       dangle_pt.x()+0.001, dangle_pt.y()+0.001)
            candidate_fids = index.intersects(search_rect)
            
            for fid in candidate_fids:
                feat = layer.getFeature(fid)
                if not feat.isValid():
                    continue
                geom = feat.geometry()
                
                if geom.isMultipart():
                    parts = geom.asMultiPolyline()
                else:
                    parts = [geom.asPolyline()]
                
                for part in parts:
                    if len(part) < 2:
                        continue
                    start = QgsPointXY(part[0])
                    end = QgsPointXY(part[-1])
                    
                    if start.distance(dangle_pt) < 0.001:
                        dangle_fid = fid
                        dangle_is_start = True
                        break
                    elif end.distance(dangle_pt) < 0.001:
                        dangle_fid = fid
                        dangle_is_start = False
                        break
                
                if dangle_fid is not None:
                    break
            
            if dangle_fid is None:
                continue
            
            # Get direction vector for extension
            dangle_feat = layer.getFeature(dangle_fid)
            dangle_geom = dangle_feat.geometry()
            
            if dangle_geom.isMultipart():
                dangle_line = dangle_geom.asMultiPolyline()[0]
            else:
                dangle_line = dangle_geom.asPolyline()
            
            if dangle_is_start:
                # Extend from start: direction is from point[1] to point[0]
                if len(dangle_line) < 2:
                    continue
                p1 = QgsPointXY(dangle_line[1])
                p0 = QgsPointXY(dangle_line[0])
                direction = QgsVector(p0.x() - p1.x(), p0.y() - p1.y())
            else:
                # Extend from end: direction is from point[-2] to point[-1]
                if len(dangle_line) < 2:
                    continue
                p1 = QgsPointXY(dangle_line[-2])
                p0 = QgsPointXY(dangle_line[-1])
                direction = QgsVector(p0.x() - p1.x(), p0.y() - p1.y())
            
            # Normalize direction
            length = direction.length()
            if length < 0.0001:
                continue
            direction = QgsVector(direction.x() / length, direction.y() / length)
            
            # Extend by tolerance
            extended_pt = QgsPointXY(dangle_pt.x() + direction.x() * tolerance,
                                     dangle_pt.y() + direction.y() * tolerance)
            
            # Create extended line geometry
            if dangle_is_start:
                extended_line = [extended_pt, dangle_pt] + dangle_line[1:]
            else:
                extended_line = dangle_line[:-1] + [dangle_pt, extended_pt]
            
            extended_geom = QgsGeometry.fromPolylineXY(extended_line)
            
            # Find receivers that intersect with extended geometry
            search_buffer = QgsGeometry.fromPointXY(extended_pt).buffer(tolerance, 5)
            receiver_fids = index.intersects(search_buffer.boundingBox())
            
            best_intersection = None
            best_receiver_fid = None
            
            for receiver_fid in receiver_fids:
                if receiver_fid == dangle_fid:
                    continue
                
                receiver_feat = layer.getFeature(receiver_fid)
                if not receiver_feat.isValid():
                    continue
                
                receiver_geom = receiver_feat.geometry()
                
                # Check if extended line intersects receiver
                if extended_geom.intersects(receiver_geom):
                    intersection = extended_geom.intersection(receiver_geom)
                    if not intersection.isEmpty() and intersection.type() == 0:  # Point
                        # Get intersection point
                        if intersection.isMultipart():
                            int_pt = intersection.asMultiPoint()[0]
                        else:
                            int_pt = intersection.asPoint()
                        
                        int_point = QgsPointXY(int_pt)
                        
                        # Check if intersection is within tolerance from dangle
                        if dangle_pt.distance(int_point) <= tolerance:
                            best_intersection = int_point
                            best_receiver_fid = receiver_fid
                            break
            
            if best_intersection is None:
                continue
            
            # Snap to intersection point (no vertex snapping)
            # The split step will handle cutting the receiver at this point
            snap_point = best_intersection
            
            # DEBUG: Log the extension
            print(f"[DANGLE EXTEND] Dangle at {dangle_pt} extended to intersection {snap_point}")
            print(f"[DANGLE EXTEND] Distance moved: {dangle_pt.distance(snap_point):.6f}m")
            if log_helper:
                log_helper.add_log_point(snap_point, "Extender Dangles", "Extensión a intersección", layer_name)
            
            # Modify dangle geometry
            new_line = list(dangle_line)
            if dangle_is_start:
                new_line[0] = snap_point
            else:
                new_line[-1] = snap_point
            
            new_geom = QgsGeometry.fromPolylineXY(new_line)
            layer.changeGeometry(dangle_fid, new_geom)
            
            # Track this extended dangle
            snap_key = (round(snap_point.x(), 10), round(snap_point.y(), 10))
            extended_nodes.add(snap_key)
        
        layer.commitChanges()
        print(f"[DANGLE EXTEND] Total extended: {len(extended_nodes)} dangles")
        return extended_nodes


def find_optimal_snap_point(cluster, graph, layer, index, tolerance):
    """
    Find the optimal point to snap all cluster members to.
    Returns: (QgsPointXY, target_fid, is_vertex) or None
    
    Logic:
    1. Search candidates within tolerance.
    2. Priority A: Existing Vertex (Degree > 1).
    3. Priority B: Segment Point (Smart Snap logic).
    """
    # Get center of cluster
    center_x = sum(p.x() for p in cluster) / len(cluster)
    center_y = sum(p.y() for p in cluster) / len(cluster)
    center = QgsPointXY(center_x, center_y)
    
    # Search for features near cluster center
    search_geom = QgsGeometry.fromPointXY(center).buffer(tolerance, 5)
    fids = index.intersects(search_geom.boundingBox())
    
    candidates_vertex = []
    candidates_segment = []
    
    for fid in fids:
        feat = layer.getFeature(fid)
        if not feat.isValid(): continue
        geom = feat.geometry()
        
        # Check Vertices
        vertices = geom.vertices()
        while vertices.hasNext():
            v = vertices.next()
            v_pt = QgsPointXY(v.x(), v.y())
            dist = center.distance(v_pt)
            if dist <= tolerance:
                # Check if it's a valid node (degree > 1)
                node_key = (round(v.x(), 10), round(v.y(), 10))
                if node_key in graph.nodes and len(graph.nodes[node_key]) > 1:
                    candidates_vertex.append((dist, v_pt, fid))
        
        # Check Segment Projection
        closest_res = geom.closestSegmentWithContext(center)
        closest_pt = closest_res[1]
        dist_seg = center.distance(closest_pt)
        
        if dist_seg <= tolerance:
            # Check if it is actually a vertex
            is_v = False
            vertices = geom.vertices()
            while vertices.hasNext():
                v = vertices.next()
                if QgsPointXY(v.x(), v.y()).distance(closest_pt) < 0.0001:
                    is_v = True
                    break
            if not is_v:
                candidates_segment.append((dist_seg, closest_pt, fid))

    # Priority 1: Existing Vertex
    if candidates_vertex:
        # Return closest vertex
        best = min(candidates_vertex, key=lambda x: x[0])
        return (best[1], best[2], True)
    
    # Priority 2: Segment Point (Smart Snap)
    if candidates_segment:
        best_seg = min(candidates_segment, key=lambda x: x[0])
        dist, pt, fid = best_seg
        
        # SMART SNAP CHECK: Would splitting here create a short segment?
        feat = layer.getFeature(fid)
        geom = feat.geometry()
        
        # Find nearest vertex on this feature to the split point
        min_v_dist = float('inf')
        nearest_v = None
        vertices = geom.vertices()
        while vertices.hasNext():
            v = vertices.next()
            v_pt = QgsPointXY(v.x(), v.y())
            d = pt.distance(v_pt)
            if d < min_v_dist:
                min_v_dist = d
                nearest_v = v_pt
        
        # If split point is too close to a vertex (< tolerance)
        if min_v_dist < tolerance:
            # Check if we can snap to that vertex instead (allow up to 2x tolerance from original center)
            dist_to_center = center.distance(nearest_v)
            if dist_to_center <= (2 * tolerance):
                # YES: Snap to the existing vertex instead of creating a short segment
                return (nearest_v, fid, True)
            else:
                # NO: Too far, must split here (creates short segment, but unavoidable)
                return (pt, fid, False)
        
        return (pt, fid, False)
    
    # Priority 3: Center (No target feature)
    # We return the center but no target FID, so no split will happen.
    return (center, None, False)


def split_feature_at_point(layer, fid, point):
    """
    Splits the feature with ID `fid` at the given `point` into two separate features.
    Handles both single-part and multi-part geometries.
    """
    feat = layer.getFeature(fid)
    if not feat.isValid(): return
    
    geom = feat.geometry()
    
    # We need to find where the point is on the geometry
    # closestSegmentWithContext returns (sqrDist, minDistPoint, afterVertexIndex, leftOf)
    # afterVertexIndex is the index of the vertex *after* the segment.
    closest = geom.closestSegmentWithContext(point)
    pt_proj = closest[1]
    after_vertex = closest[2]
    
    if after_vertex < 1: return # Should be at least 1 (segment 0 is between 0 and 1)
    
    # Extract original points
    if geom.isMultipart():
        parts = geom.asMultiPolyline()
        
        # Identify which part contains the split point
        target_part_index = -1
        min_dist = float('inf')
        
        for i, part in enumerate(parts):
            # Check if point is on this part (using a small buffer/distance check)
            # Since we don't have part index from closestSegmentWithContext easily for multipart,
            # we re-check distance to each part.
            part_geom = QgsGeometry.fromPolylineXY(part)
            dist = part_geom.distance(QgsGeometry.fromPointXY(point))
            if dist < min_dist:
                min_dist = dist
                target_part_index = i
        
        if target_part_index == -1 or min_dist > 0.001:
            return # Could not identify part
            
        polyline = parts[target_part_index]
        
        # Recalculate vertex index for this specific part
        part_geom = QgsGeometry.fromPolylineXY(polyline)
        closest_part = part_geom.closestSegmentWithContext(point)
        after_vertex = closest_part[2]
        
    else:
        polyline = geom.asPolyline()
        target_part_index = -1 # Single part
    
    # Check if point is an endpoint (Start or End)
    # Use a small tolerance for comparison
    if QgsPointXY(polyline[0]).distance(point) < 0.0001 or \
       QgsPointXY(polyline[-1]).distance(point) < 0.0001:
        return # Do not split at endpoints
    
    # Create two new point lists
    # Segment index is after_vertex - 1.
    # Points 0 to (after_vertex - 1) are first part.
    # Point 'point' is the split.
    # Points (after_vertex) to end are second part.
    
    # Part 1: Start -> ... -> Vertex Before -> Split Point
    part1_line = polyline[:after_vertex]
    part1_line.append(point)
    
    # Part 2: Split Point -> Vertex After -> ... -> End
    part2_line = [point]
    part2_line.extend(polyline[after_vertex:])
    
    # Create new features
    # We copy attributes from original
    attrs = feat.attributes()
    
    if geom.isMultipart():
        # For multipart, we keep the original parts + the two new split parts
        # Actually, usually we want to split the FEATURE into two FEATURES.
        # But if it's multipart, does it mean one feature with multiple lines?
        # Yes. So if we split one line, we might want to keep the other lines attached to one of the new features,
        # or split the feature into two features where one has (original_parts + part1) and other has (part2).
        # OR, more commonly in GIS topology cleaning:
        # The goal is to have simple lines. So maybe we should explode multipart?
        # But here we want to be minimally invasive.
        
        # Strategy:
        # Feature 1: All original parts except target, plus part1_line
        # Feature 2: part2_line (new single part feature)
        # This seems inconsistent.
        
        # Better Strategy for "Split":
        # Create Feature 1 with part1_line
        # Create Feature 2 with part2_line
        # AND we must handle the "other" parts of the original multipart feature.
        # Usually, "Split" on a line means breaking continuity.
        # If we have a multipart line, and we cut one part, we effectively have:
        # (Other Parts) + (Part 1) + (Part 2).
        # We should probably leave (Other Parts) with Feature 1.
        
        new_parts_1 = [list(p) for i, p in enumerate(parts) if i != target_part_index]
        new_parts_1.append(part1_line)
        
        # Feature 1 (Original + Part 1)
        f1 = QgsFeature(layer.fields())
        f1.setAttributes(attrs)
        f1.setGeometry(QgsGeometry.fromMultiPolylineXY(new_parts_1))
        
        # Feature 2 (Part 2 only - separated)
        f2 = QgsFeature(layer.fields())
        f2.setAttributes(attrs)
        f2.setGeometry(QgsGeometry.fromPolylineXY(part2_line))
        
    else:
        # Single part case
        # Feature 1
        f1 = QgsFeature(layer.fields())
        f1.setAttributes(attrs)
        f1.setGeometry(QgsGeometry.fromPolylineXY(part1_line))
        
        # Feature 2
        f2 = QgsFeature(layer.fields())
        f2.setAttributes(attrs)
        f2.setGeometry(QgsGeometry.fromPolylineXY(part2_line))
    
    # Add new features
    layer.addFeatures([f1, f2])
    
    # Delete original feature
    layer.deleteFeature(fid) 


def move_endpoint(layer, index, old_pt, new_pt, tolerance):
    """Move an endpoint from old_pt to new_pt."""
    # Use tolerance for searching the point to move
    search_tol = tolerance if tolerance > 0.000001 else 0.001
    search_rect = QgsRectangle(old_pt.x()-search_tol, old_pt.y()-search_tol, 
                                old_pt.x()+search_tol, old_pt.y()+search_tol)
    fids = index.intersects(search_rect)
    
    moved = False
    for fid in fids:
        feat = layer.getFeature(fid)
        if not feat.isValid():
            continue
        
        geom = feat.geometry()
        if geom.isMultipart():
            parts = geom.asMultiPolyline()
        else:
            parts = [geom.asPolyline()]
        
        modified = False
        new_parts = []
        
        for poly in parts:
            if not poly or len(poly) < 2:
                if poly:
                    new_parts.append(poly)
                continue
            
            new_poly = list(poly)
            
            # Check start and end using tolerance
            if QgsPointXY(poly[0]).distance(old_pt) < search_tol:
                new_poly[0] = new_pt
                modified = True
            elif QgsPointXY(poly[-1]).distance(old_pt) < search_tol:
                new_poly[-1] = new_pt
                modified = True
            
            new_parts.append(new_poly)
        
        if modified and new_parts:
            if geom.isMultipart():
                new_geom = QgsGeometry.fromMultiPolylineXY(new_parts)
            else:
                new_geom = QgsGeometry.fromPolylineXY(new_parts[0])
            
            layer.changeGeometry(fid, new_geom)
            moved = True
    
    return moved


def get_info(pt, layer, index):
    """Get L and N info for a point. Returns (info_str, fid)."""
    # Use a small fixed tolerance for info lookup, or pass tolerance if needed.
    # For info, 0.01 is usually fine, but let's make it slightly robust.
    search_tol = 0.01 
    search_rect = QgsRectangle(pt.x() - search_tol, pt.y() - search_tol, 
                                pt.x() + search_tol, pt.y() + search_tol)
    fids = index.intersects(search_rect)
    
    for fid in fids:
        feat = layer.getFeature(fid)
        if not feat.isValid():
            continue
        geom = feat.geometry()
        
        if geom.isMultipart():
            parts = geom.asMultiPolyline()
        else:
            parts = [geom.asPolyline()]
        
        for poly in parts:
            if not poly:
                continue
            if QgsPointXY(poly[0]).distance(pt) < search_tol or QgsPointXY(poly[-1]).distance(pt) < search_tol:
                L = geom.length()
                N = sum(len(p) for p in parts)
                return (f" (L={L:.2f}, N={N})", fid)
    
    return (" (L=?, N=?)", None)


def calculate_line_intersection(p1, dir1, p2, dir2, max_distance):
    """
    Calculate intersection of two rays defined by point + direction.
    Returns None if lines are parallel or intersection is invalid.
    
    Args:
        p1: QgsPointXY - Starting point of first ray
        dir1: QgsVector - Direction of first ray (normalized)
        p2: QgsPointXY - Starting point of second ray
        dir2: QgsVector - Direction of second ray (normalized)
        max_distance: Maximum allowed distance from intersection to either point
    
    Returns:
        QgsPointXY - Intersection point, or None if invalid
    """
    # Calculate determinant to check if lines are parallel
    det = dir1.x() * (-dir2.y()) - dir1.y() * (-dir2.x())
    
    if abs(det) < 0.0001:  # Lines are parallel
        return None
    
    dx = p2.x() - p1.x()
    dy = p2.y() - p1.y()
    
    # Calculate parameter t1 for first ray
    t1 = (dx * (-dir2.y()) - dy * (-dir2.x())) / det
    
    # Calculate intersection point
    intersection = QgsPointXY(p1.x() + t1 * dir1.x(), p1.y() + t1 * dir1.y())
    
    # Validate intersection distance from both points
    dist1 = intersection.distance(p1)
    dist2 = intersection.distance(p2)
    
    # Intersection must be within reasonable distance (2x tolerance)
    if dist1 > max_distance * 2 or dist2 > max_distance * 2:
        return None
    
    # Intersection must be forward (not backward) from p1
    if t1 < 0:
        return None
    
    return intersection


def find_dangle_pair_intersection(cluster, graph, layer, index, tolerance):
    """
    Detect if a cluster of 2 dangles can be corrected by moving both to their intersection.
    
    Args:
        cluster: List of 2 QgsPointXY representing the dangle endpoints
        graph: Graph object with topology information
        layer: QgsVectorLayer
        index: QgsSpatialIndex
        tolerance: Maximum distance for intersection validity
    
    Returns:
        QgsPointXY - Intersection point if valid, None otherwise
    """
    if len(cluster) != 2:
        return None
    
    pt1, pt2 = cluster
    
    # Get direction vectors for both dangles
    dir1 = get_dangle_direction(pt1, layer, index)
    dir2 = get_dangle_direction(pt2, layer, index)
    
    if dir1 is None or dir2 is None:
        return None
    
    # Calculate intersection
    intersection = calculate_line_intersection(pt1, dir1, pt2, dir2, tolerance)
    
    if intersection is None:
        return None
    
    # Validate that intersection is within tolerance for both points
    if pt1.distance(intersection) > tolerance or pt2.distance(intersection) > tolerance:
        return None
    
    return intersection


def get_dangle_direction(point, layer, index):
    """
    Get the direction vector of a dangle endpoint.
    
    Args:
        point: QgsPointXY - The dangle endpoint
        layer: QgsVectorLayer
        index: QgsSpatialIndex
    
    Returns:
        QgsVector - Normalized direction vector, or None if not found
    """
    search_tol = 0.001
    search_rect = QgsRectangle(point.x()-search_tol, point.y()-search_tol,
                               point.x()+search_tol, point.y()+search_tol)
    fids = index.intersects(search_rect)
    
    for fid in fids:
        feat = layer.getFeature(fid)
        if not feat.isValid():
            continue
        
        geom = feat.geometry()
        if geom.isMultipart():
            parts = geom.asMultiPolyline()
        else:
            parts = [geom.asPolyline()]
        
        for part in parts:
            if len(part) < 2:
                continue
            
            start = QgsPointXY(part[0])
            end = QgsPointXY(part[-1])
            
            # Check if this is the start point
            if start.distance(point) < search_tol:
                # Direction is from second point to first point (outward)
                direction = QgsVector(start.x() - part[1].x(), start.y() - part[1].y())
                length = direction.length()
                if length > 0.0001:
                    return QgsVector(direction.x() / length, direction.y() / length)
            
            # Check if this is the end point
            elif end.distance(point) < search_tol:
                # Direction is from second-to-last point to last point (outward)
                direction = QgsVector(end.x() - part[-2].x(), end.y() - part[-2].y())
                length = direction.length()
                if length > 0.0001:
                    return QgsVector(direction.x() / length, direction.y() / length)
    
    return None

