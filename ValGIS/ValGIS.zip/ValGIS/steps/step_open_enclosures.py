import processing
from qgis.core import QgsGeometry

class StepOpenEnclosures:
    def __init__(self):
        pass

    def run(self, layer):
        """
        Detecta líneas que no forman bucles cerrados (verificación de Poligonización).
        Devuelve lista de dicts de error.
        """
        # Intentar poligonizar
        params = {
            'INPUT': layer,
            'OUTPUT': 'memory:',
            'KEEP_FIELDS': False
        }
        # Esto crea polígonos. Las líneas que no formaron polígonos NO están en la salida.
        # Pero queremos encontrar las líneas que FALLARON.
        # "Polygonize" no devuelve líneas fallidas directamente.
        
        # Alternativa: ¿Usar "Lines to polygons" y verificar validez?
        # O más simple: ¿Verificar dangles de nuevo? Si hay dangles, hay recintos abiertos.
        # El usuario quiere "Recintos abiertos".
        
        # Intentemos: Poligonizar -> Convertir Polígonos a Líneas -> Diferencia con Original?
        # Eso da líneas que participaron en polígonos. El resto son "abiertas".
        
        polys = processing.run("native:polygonize", params)['OUTPUT']
        
        # Extraer líneas de contorno de los polígonos
        params_lines = {
            'INPUT': polys,
            'OUTPUT': 'memory:'
        }
        poly_lines = processing.run("native:polygons_to_lines", params_lines)['OUTPUT']
        
        # Seleccionar líneas originales que intersectan con poly_lines
        # Esto es costoso.
        
        # Heurística: Si pasamos el Paso 8 (Dangles), no debería haber recintos abiertos 
        # a menos que haya auto-intersecciones complejas o huecos < tolerancia.
        
        # Por ahora, devolvamos una lista vacía o implementemos una verificación básica si es necesario.
        # El requisito del usuario implica encontrar cosas que *parecen* que deberían estar cerradas pero no lo están.
        # ¿Tal vez solo re-ejecutar verificación de dangles?
        
        return [] 
