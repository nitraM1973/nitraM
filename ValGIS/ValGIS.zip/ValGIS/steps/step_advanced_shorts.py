from qgis.core import QgsGeometry

class StepAdvancedShorts:
    def __init__(self):
        pass

    def run(self, layer, min_length, callback=None, log_helper=None):
        """
        Identifies and auto-fixes short segments within polylines.
        Returns (list_of_remaining_errors, fixed_count).
        """
        errors = []
        fixed_count = 0
        
        layer.startEditing()
        layer_name = layer.name()
        
        to_delete = []
        
        features = list(layer.getFeatures())
        total = len(features)
        for i, feature in enumerate(features):
            if callback and i % 5 == 0: callback(i, total)
            geom = feature.geometry()
            
            # Check if whole feature is short - delete it
            if geom.length() < min_length:
                to_delete.append(feature.id())
                fixed_count += 1
                if log_helper:
                    centroid = geom.centroid().asPoint()
                    log_helper.add_log_point(centroid, "Segmentos Cortos", f"Feature corto eliminado (L={geom.length():.4f})", layer_name)
                continue

            # Check segments and fix them
            if geom.isMultipart():
                parts = geom.asMultiPolyline()
            else:
                parts = [geom.asPolyline()]
            
            modified = False
            new_parts = []
            
            for part_idx, part in enumerate(parts):
                if len(part) < 2:
                    new_parts.append(part)
                    continue
                
                # Build new part by skipping vertices that create short segments
                new_part = [part[0]]  # Always keep first vertex
                
                for i in range(1, len(part)):
                    # Check distance from last kept vertex to current
                    dist = new_part[-1].distance(part[i])
                    
                    if dist >= min_length:
                        # Keep this vertex
                        new_part.append(part[i])
                    else:
                        # Skip this vertex (too close to previous kept vertex)
                        modified = True
                        fixed_count += 1
                        if log_helper:
                            log_helper.add_log_point(part[i], "Segmentos Cortos", f"Vértice eliminado (dist={dist:.4f})", layer_name)
                        
                        # But if it's the last vertex, we must keep it to preserve endpoint
                        if i == len(part) - 1:
                            # Replace last kept vertex with this endpoint
                            new_part[-1] = part[i]
                            if log_helper:
                                log_helper.add_log_point(part[i], "Segmentos Cortos", "Vértice final mantenido (reemplazo)", layer_name)
                
                # Only keep parts with at least 2 vertices
                if len(new_part) >= 2:
                    new_parts.append(new_part)
                else:
                    modified = True
            
            # Update geometry if modified
            if modified and new_parts:
                if geom.isMultipart():
                    new_geom = QgsGeometry.fromMultiPolylineXY(new_parts)
                else:
                    if new_parts:
                        new_geom = QgsGeometry.fromPolylineXY(new_parts[0])
                    else:
                        # Entire feature became invalid
                        to_delete.append(feature.id())
                        continue
                        
                layer.changeGeometry(feature.id(), new_geom)
        
        # Delete short features
        if to_delete:
            layer.deleteFeatures(to_delete)
        
        layer.commitChanges()
        
        return errors, fixed_count
