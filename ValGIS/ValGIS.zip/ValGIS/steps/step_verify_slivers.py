from qgis.core import (
    QgsProcessing, 
    QgsProcessingAlgorithm, 
    QgsProcessingParameterVectorLayer, 
    QgsProcessingParameterFeatureSink,
    QgsProcessingFeatureSourceDefinition
)
import processing

class StepVerifySlivers:
    def __init__(self):
        pass

    def run(self, layer, log_helper=None):
        """
        Verifica poligonos astilla ejecutando una poligonizacion en memoria.
        Devuelve una lista de errores si se encuentran astillas.
        """
        try:
            # Preparar entrada: forzar features seleccionadas si hay una seleccion
            input_layer = layer
            if layer.selectedFeatureCount() > 0:
                input_layer = QgsProcessingFeatureSourceDefinition(layer.id(), True)

            params = {
                'INPUT': input_layer,
                'KEEP_FIELDS': False,
                'OUTPUT': 'memory:'
            }
            result = processing.run("native:polygonize", params)
            poly_layer = result['OUTPUT']
            
            errors = []
            for feat in poly_layer.getFeatures():
                geom = feat.geometry()
                if not geom: continue
                
                area = geom.area()
                perimeter = geom.length()
                
                if perimeter == 0: continue
                
                ratio = area / perimeter
                
                # Criterio para astilla: Area muy pequena O muy delgada (ratio area/perimetro bajo)
                is_sliver = False
                msg = ""
                
                if area < 0.1: # 0.1 m2
                    is_sliver = True
                    msg = f"Posible Astilla (Area muy pequena: {area:.4f} m2)"
                elif ratio < 0.01: # 1cm ancho promedio aprox
                    is_sliver = True
                    msg = f"Posible Astilla (Muy delgada, Ratio: {ratio:.4f})"
                
                if is_sliver:
                    # Encontrar un punto en el poligono para reportar error
                    pt = geom.pointOnSurface().asPoint()
                    errors.append({
                        'point': pt,
                        'type': 'sliver',
                        'msg': msg
                    })
            
            return errors
            
        except Exception as e:
            # Si la poligonizacion falla por alguna razon, solo devolver lista vacia
            # No queremos bloquear al usuario si esta verificacion falla tecnicamente
            if log_helper:
                log_helper.log_message(f"Error checking slivers: {e}")
            return []
