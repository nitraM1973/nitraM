from ..cleaning.algorithms import find_invalid_geometries

class StepFinalCheck:
    def __init__(self):
        pass

    def run(self, layer):
        """
        Verifica la capa de poligonos final para validez.
        """
        return find_invalid_geometries(layer)
