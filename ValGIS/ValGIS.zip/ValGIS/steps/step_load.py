from qgis.core import QgsVectorLayer, QgsField
from PyQt5.QtCore import QVariant
import os
import uuid
from ..helpers.layer_utils import clean_and_save_layer, purge_zero_length_features

class StepLoad:
    def __init__(self):
        pass

    def run(self, layer, output_dir, filename="01_00_Carga.shp", log_callback=None, callback=None):
        """
        Carga la capa y guarda una copia en el directorio de salida.
        Crea el campo UUID y lo puebla con EntityHandle o genera UUID4.
        Devuelve tupla (layer, errors).
        """
        # 1. Verificar si el campo EntityHandle existe
        has_entity_handle = False
        for field in layer.fields():
            if field.name() == 'EntityHandle':
                has_entity_handle = True
                break
        
        # 2. Guardar capa ORIGINAL (DXF) a Shapefile de trabajo
        # Los campos UUID y valNUL se crean automáticamente en clean_and_save_layer si faltan.
        output_path = os.path.join(output_dir, filename)
        result_layer, errors = clean_and_save_layer(layer, output_path)
        
        # 3. Purgar geometrías de longitud 0 SOBRE EL SHAPEFILE (editable de forma segura)
        purge_zero_length_features(result_layer, step_label="Cargar DXF", log_callback=log_callback, callback=callback)
        
        return result_layer, errors
