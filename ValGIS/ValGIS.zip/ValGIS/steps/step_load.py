from qgis.core import QgsVectorLayer, QgsField
from PyQt5.QtCore import QVariant
import os
import uuid
from ..helpers.layer_utils import clean_and_save_layer

class StepLoad:
    def __init__(self):
        pass

    def run(self, layer, output_dir, filename="01_00_Carga.shp"):
        """
        Carga la capa y guarda una copia en el directorio de salida.
        Crea el campo UUID y lo puebla con EntityHandle o genera UUID4.
        Devuelve tupla (layer, errors).
        """
        # 1. Verificar si el campo EntityHandle existe
        has_entity_handle = False
        for field in layer.fields():
            if field.name() == 'EntityHandle':
                has_entity_handle = True
                break
        
        # 2. Crear campo UUID si no existe
        uuid_field_exists = False
        for field in layer.fields():
            if field.name() == 'UUID':
                uuid_field_exists = True
                break
        
        if not uuid_field_exists:
            layer.startEditing()
            layer.addAttribute(QgsField("UUID", QVariant.String, len=50))
            layer.commitChanges()
        
        # 3. Poblar campo UUID
        # OBSOLETO: Los UUIDs ahora se generan/regeneran automáticamente en clean_and_save_layer
        # para asegurar unicidad en cada paso.
        # Solo necesitamos asegurar que la definición del campo existe aquí.
        pass
        
        # 4. Guardar capa
        output_path = os.path.join(output_dir, filename)
        result_layer, errors = clean_and_save_layer(layer, output_path)
        return result_layer, errors
