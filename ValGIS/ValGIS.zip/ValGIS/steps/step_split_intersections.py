import processing
import os
import time
from qgis.core import QgsGeometry, QgsVectorLayer, QgsFeature, QgsSpatialIndex, QgsRectangle
from ..helpers.layer_utils import clean_and_save_layer

class StepSplitIntersections:
    def __init__(self):
        pass

    def run(self, layer, output_dir, filename="Split.shp", log_callback=None, log_helper=None, recintos_layers=None, clases_layers=None):
        """
        Divide líneas SOLO en puntos de intersección con otras líneas.
        NO divide en vértices intermedios.
        
        VERSIÓN OPTIMIZADA con mejoras de rendimiento:
        - Geometrías pre-calculadas
        - Caché de operaciones costosas
        - Validación temprana
        - Indexación espacial bidireccional
        - Extracción optimizada de subcadenas
        - Medición de rendimiento
        - AISLAMIENTO DE GRUPOS: Capas solo-Recintos y solo-Clases no interactúan.
        """
        start_time = time.time()
        
        def log(msg):
            if log_callback:
                log_callback(msg)
        
        layer_name = layer.name()

        # 1. Reparar Geometrías
        fixed = processing.run("native:fixgeometries", {
            'INPUT': layer,
            'OUTPUT': 'memory:'
        })['OUTPUT']
        
        log(f"Features antes de cortar: {fixed.featureCount()}")
        
        # 2. Encontrar Intersecciones con Aislamiento de Grupos
        # Si se proporcionan grupos, filtramos intersecciones.
        intersections = None
        
        if recintos_layers is not None and clases_layers is not None:
            log("Aplicando aislamiento de grupos (Recintos vs Clases)...")
            
            # Identificar conjuntos
            set_r = set(recintos_layers)
            set_c = set(clases_layers)
            set_common = set_r.intersection(set_c)
            set_r_only = set_r - set_common
            set_c_only = set_c - set_common
            
            log(f"  Capas Recintos-Only: {len(set_r_only)}")
            log(f"  Capas Clases-Only: {len(set_c_only)}")
            log(f"  Capas Comunes: {len(set_common)}")
            
            # Función auxiliar para obtener subconjunto
            def get_subset(source_layer, layer_names):
                if not layer_names:
                    return None
                # Escapar nombres para expresión
                escaped_names = [n.replace("'", "''") for n in layer_names]
                expr = f"\"Layer\" IN ('{'\',\''.join(escaped_names)}')"
                subset = processing.run("native:extractbyexpression", {
                    'INPUT': source_layer,
                    'EXPRESSION': expr,
                    'OUTPUT': 'memory:'
                })['OUTPUT']
                return subset if subset.featureCount() > 0 else None

            # Crear subconjuntos
            # Necesitamos:
            # Grupo A: Solo_R + Comunes
            # Grupo B: Solo_C + Comunes
            
            group_a_names = list(set_r_only.union(set_common))
            group_b_names = list(set_c_only.union(set_common))
            
            subset_a = get_subset(fixed, group_a_names)
            subset_b = get_subset(fixed, group_b_names)
            
            points_layers = []
            
            # Intersecciones dentro del Grupo A (R-R, R-Com, Com-Com)
            if subset_a:
                log("  Buscando intersecciones en Grupo Recintos+Comunes...")
                pts_a = processing.run("native:lineintersections", {
                    'INPUT': subset_a,
                    'INTERSECT': subset_a,
                    'INPUT_FIELDS': [],
                    'INTERSECT_FIELDS': [],
                    'OUTPUT': 'memory:'
                })['OUTPUT']
                if pts_a.featureCount() > 0:
                    points_layers.append(pts_a)
            
            # Intersecciones dentro del Grupo B (C-C, C-Com, Com-Com)
            if subset_b:
                log("  Buscando intersecciones en Grupo Clases+Comunes...")
                pts_b = processing.run("native:lineintersections", {
                    'INPUT': subset_b,
                    'INTERSECT': subset_b,
                    'INPUT_FIELDS': [],
                    'INTERSECT_FIELDS': [],
                    'OUTPUT': 'memory:'
                })['OUTPUT']
                if pts_b.featureCount() > 0:
                    points_layers.append(pts_b)
            
            if points_layers:
                # Fusionar puntos
                if len(points_layers) > 1:
                    intersections = processing.run("native:mergevectorlayers", {
                        'LAYERS': points_layers,
                        'CRS': fixed.crs(),
                        'OUTPUT': 'memory:'
                    })['OUTPUT']
                else:
                    intersections = points_layers[0]
                    
                # Eliminar puntos duplicados (mismas coordenadas)
                intersections = processing.run("native:deleteduplicategeometries", {
                    'INPUT': intersections,
                    'OUTPUT': 'memory:'
                })['OUTPUT']
                
            else:
                # Crear capa vacía
                intersections = QgsVectorLayer(f"Point?crs={fixed.crs().authid()}", "empty", "memory")

        else:
            # Comportamiento estándar (todos vs todos)
            intersections = processing.run("native:lineintersections", {
                'INPUT': fixed,
                'INTERSECT': fixed,
                'INPUT_FIELDS': [],
                'INTERSECT_FIELDS': [],
                'OUTPUT': 'memory:'
            })['OUTPUT']
        
        log(f"Puntos de intersección encontrados: {intersections.featureCount()}")
        
        if log_helper:
            for feat in intersections.getFeatures():
                geom = feat.geometry()
                if geom:
                    pt = geom.asPoint()
                    log_helper.add_log_point(pt, "Cortar Intersecciones", "Corte en intersección", layer_name)
        
        # 3. Dividir líneas
        try:
            # Intentar primero el algoritmo moderno y más limpio
            log("Intentando usar native:splitlinesatpoints...")
            split = processing.run("native:splitlinesatpoints", {
                'INPUT': fixed,
                'POINTS': intersections,
                'TOLERANCE': 0.0001,
                'OUTPUT': 'memory:'
            })['OUTPUT']
        except Exception as e:
            log(f"native:splitlinesatpoints no disponible o falló ({str(e)}). Usando método manual optimizado...")
            
            # Alternativa: División manual optimizada
            split_start = time.time()
            split = self.manual_split_at_points(fixed, intersections, log_callback)
            split_elapsed = time.time() - split_start
            log(f"⏱️ Tiempo de corte manual: {split_elapsed:.2f}s")
        
        log(f"Features después de cortar: {split.featureCount()}")
        
        # 4. Multipartes a partes simples
        single = processing.run("native:multiparttosingleparts", {
            'INPUT': split,
            'OUTPUT': 'memory:'
        })['OUTPUT']
        
        log(f"Features finales: {single.featureCount()}")
        
        # 5. Asegurar que el campo UUID existe y asignar UUIDs a todas las features
        import uuid
        from qgis.core import QgsField
        from PyQt5.QtCore import QVariant
        
        # Verificar si el campo UUID existe
        uuid_field_exists = False
        for field in single.fields():
            if field.name() == 'UUID':
                uuid_field_exists = True
                break
        
        # Añadir campo UUID si falta
        if not uuid_field_exists:
            single.startEditing()
            single.addAttribute(QgsField("UUID", QVariant.String, len=50))
            single.commitChanges()
        
        # Asignar UUID a todas las features (nuevas divisiones no tendrán UUID)
        single.startEditing()
        uuid_field_idx = single.fields().indexOf('UUID')
        for feature in single.getFeatures():
            if not feature['UUID']:  # Solo asignar si UUID está vacío/nulo
                single.changeAttributeValue(feature.id(), uuid_field_idx, str(uuid.uuid4()))
        single.commitChanges()
        
        output_path = os.path.join(output_dir, filename)
        result_layer, _ = clean_and_save_layer(single, output_path)
        
        # Registrar tiempo total de ejecución
        total_elapsed = time.time() - start_time
        log(f"⏱️ Tiempo total del paso de corte: {total_elapsed:.2f}s ({layer.featureCount()} líneas → {result_layer.featureCount()} segmentos)")
        
        return result_layer

    def manual_split_at_points(self, line_layer, point_layer, log_callback=None):
        """
        OPTIMIZED: Manually splits lines at specified points.
        
        Optimizations:
        - Pre-calculated point geometries (avoid repeated QgsGeometry creation)
        - Caching of lineLocatePoint results
        - Early validation (before feature creation)
        - Bidirectional spatial indexing
        """
        import uuid
        from qgis.core import QgsField
        from PyQt5.QtCore import QVariant
        
        def log(msg):
            if log_callback:
                log_callback(msg)
        
        # Create output layer
        crs = line_layer.crs().authid()
        out_layer = QgsVectorLayer(f"LineString?crs={crs}", "manual_split", "memory")
        out_layer.startEditing()
        dp = out_layer.dataProvider()
        dp.addAttributes(line_layer.fields())
        
        # Ensure UUID field exists
        uuid_field_exists = False
        for field in line_layer.fields():
            if field.name() == 'UUID':
                uuid_field_exists = True
                break
        
        if not uuid_field_exists:
            dp.addAttributes([QgsField("UUID", QVariant.String, len=50)])
        
        out_layer.updateFields()
        
        # OPTIMIZATION 1: Pre-calculate point geometries (avoid repeated creation)
        points_geom_map = {}
        points_map = {}
        for f in point_layer.getFeatures():
            geom = f.geometry()
            points_geom_map[f.id()] = geom
            points_map[f.id()] = geom.asPoint()
        
        # Build spatial index for points
        pt_index = QgsSpatialIndex(point_layer.getFeatures())
        
        # OPTIMIZATION 2: Cache for lineLocatePoint results
        locate_cache = {}
        
        new_features = []
        uuid_field_idx = out_layer.fields().indexOf('UUID')
        
        processed_lines = 0
        total_lines = line_layer.featureCount()
        
        for feature in line_layer.getFeatures():
            processed_lines += 1
            if processed_lines % 1000 == 0 and log_callback:
                log(f"  Procesando línea {processed_lines}/{total_lines}...")
            
            geom = feature.geometry()
            if not geom.isMultipart():
                parts = [geom.asPolyline()]
            else:
                parts = geom.asMultiPolyline()
                
            for poly in parts:
                if not poly: 
                    continue
                
                # Reconstruct geometry for this part
                part_geom = QgsGeometry.fromPolylineXY(poly)
                
                # Find points intersecting this line
                search_rect = part_geom.boundingBox()
                search_rect.grow(0.001)
                pt_ids = pt_index.intersects(search_rect)
                
                split_distances = [0.0, part_geom.length()]
                
                for pid in pt_ids:
                    # OPTIMIZATION 1: Use pre-calculated geometry
                    pt_geom = points_geom_map[pid]
                    
                    # Check if point is actually on the line (within tolerance)
                    if part_geom.distance(pt_geom) < 0.001:
                        # OPTIMIZATION 2: Check cache first
                        cache_key = (feature.id(), pid)
                        if cache_key in locate_cache:
                            dist = locate_cache[cache_key]
                        else:
                            dist = part_geom.lineLocatePoint(pt_geom)
                            locate_cache[cache_key] = dist
                        
                        if dist > 0.001 and dist < part_geom.length() - 0.001:
                            split_distances.append(dist)
                
                # Sort and unique distances
                split_distances = sorted(list(set(split_distances)))
                
                # Create segments
                for i in range(len(split_distances) - 1):
                    start = split_distances[i]
                    end = split_distances[i+1]
                    
                    if end - start < 0.001: 
                        continue  # Skip tiny segments
                    
                    # OPTIMIZATION 4: Use optimized substring extraction
                    segment = self.get_substring_optimized(part_geom, start, end)
                    
                    # OPTIMIZATION 3: Early validation (before creating feature)
                    if not segment or segment.isEmpty():
                        continue
                    
                    if not segment.isGeosValid():
                        continue
                    
                    # Only create feature if geometry is valid
                    new_feat = QgsFeature(feature)
                    new_feat.setGeometry(segment)
                    new_feat.setAttribute(uuid_field_idx, str(uuid.uuid4()))
                    new_features.append(new_feat)
                        
        dp.addFeatures(new_features)
        out_layer.commitChanges()
        return out_layer

    def get_substring_optimized(self, geom, start_dist, end_dist):
        """
        OPTIMIZED: Extracts a substring from a geometry between two distances.
        
        Optimizations:
        - Pre-calculation of cumulative distances
        - Binary search for vertex range (instead of linear iteration)
        - Reduced vertex iterations
        """
        if start_dist >= end_dist:
            return None
        
        vertices = geom.asPolyline()
        if not vertices or len(vertices) < 2:
            return None
        
        # OPTIMIZATION: Pre-calculate cumulative distances
        cumulative_dists = [0.0]
        for i in range(len(vertices) - 1):
            seg_len = vertices[i].distance(vertices[i+1])
            cumulative_dists.append(cumulative_dists[-1] + seg_len)
        
        # Get start and end points
        start_point = geom.interpolate(start_dist).asPoint()
        end_point = geom.interpolate(end_dist).asPoint()
        
        new_points = [start_point]
        
        # OPTIMIZATION: Use binary search to find relevant vertex range
        import bisect
        start_idx = bisect.bisect_left(cumulative_dists, start_dist)
        end_idx = bisect.bisect_right(cumulative_dists, end_dist)
        
        # Add intermediate vertices only in the relevant range
        for i in range(max(0, start_idx), min(len(vertices), end_idx)):
            vertex_dist = cumulative_dists[i]
            # Only add vertices strictly inside the range
            if vertex_dist > start_dist + 0.0001 and vertex_dist < end_dist - 0.0001:
                new_points.append(vertices[i])
        
        new_points.append(end_point)
        
        return QgsGeometry.fromPolylineXY(new_points)

    def get_substring(self, geom, start_dist, end_dist):
        """
        DEPRECATED: Use get_substring_optimized instead.
        Kept for backward compatibility.
        """
        return self.get_substring_optimized(geom, start_dist, end_dist)
