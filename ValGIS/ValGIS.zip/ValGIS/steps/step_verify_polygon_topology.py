from qgis.core import QgsPointXY, QgsWkbTypes
from qgis.PyQt.QtWidgets import QMessageBox, QPushButton
from qgis.PyQt.QtCore import Qt


class StepVerifyPolygonTopology:
    """
    Verifica la topología de polígonos cerrados (REC_POLCERRADOS y CLA_POLCERRADOS)
    antes de la exportación a DXF.
    
    Detecta:
    - Nodos duplicados consecutivos (coordenadas exactamente iguales)
    - Primer vértice = Último vértice (cierre geométrico redundante)
    """
    
    def __init__(self):
        pass
    
    def detect_issues_in_polygon(self, geom):
        """
        Detecta problemas de topología en un polígono individual.
        
        Args:
            geom: QgsGeometry del polígono
        
        Returns:
            dict: {
                'has_issues': bool,
                'duplicate_nodes': [(idx, QgsPointXY), ...],
                'is_closed_geom': bool
            }
        """
        issues = {
            'has_issues': False,
            'duplicate_nodes': [],
            'is_closed_geom': False
        }
        
        # Extraer anillo exterior
        exterior_ring = None
        
        if geom.isMultipart():
            polygons = geom.asMultiPolygon()
            if not polygons or len(polygons) == 0:
                return issues
            if len(polygons[0]) == 0:
                return issues
            exterior_ring = polygons[0][0]  # Primer polígono, anillo exterior
        else:
            polygon = geom.asPolygon()
            if not polygon or len(polygon) == 0:
                return issues
            exterior_ring = polygon[0]  # Anillo exterior
        
        if not exterior_ring or len(exterior_ring) < 2:
            return issues
        
        # Detectar nodos duplicados consecutivos (comparación exacta)
        for i in range(len(exterior_ring) - 1):
            p1 = exterior_ring[i]
            p2 = exterior_ring[i + 1]
            
            # Comparación exacta (tolerancia 0.0)
            if p1.x() == p2.x() and p1.y() == p2.y():
                issues['duplicate_nodes'].append((i, p1))
                issues['has_issues'] = True
        
        # Detectar cierre geométrico (primer == último)
        if len(exterior_ring) >= 2:
            first = exterior_ring[0]
            last = exterior_ring[-1]
            
            # Comparación exacta
            if first.x() == last.x() and first.y() == last.y():
                issues['is_closed_geom'] = True
                issues['has_issues'] = True
        
        return issues
    
    def analyze_layer(self, layer, layer_name, log_helper=None, log_callback=None):
        """
        Analiza una capa de polígonos y detecta problemas.
        
        Args:
            layer: QgsVectorLayer
            layer_name: Nombre de la capa (para logging)
            log_helper: Helper para crear puntos LOG
            log_callback: Función de logging
        
        Returns:
            dict: {
                'fids_with_issues': [fid1, fid2, ...],
                'duplicate_count': int,
                'closed_geom_count': int
            }
        """
        result = {
            'fids_with_issues': [],
            'duplicate_count': 0,
            'closed_geom_count': 0
        }
        
        if not layer or not layer.isValid():
            return result
        
        if log_callback:
            log_callback(f"Analizando {layer_name}...")
        
        for feat in layer.getFeatures():
            geom = feat.geometry()
            
            if not geom or geom.isEmpty():
                continue
            
            issues = self.detect_issues_in_polygon(geom)
            
            if issues['has_issues']:
                fid = feat.id()
                result['fids_with_issues'].append(fid)
                
                # Contar tipos de problemas
                if issues['duplicate_nodes']:
                    result['duplicate_count'] += len(issues['duplicate_nodes'])
                
                if issues['is_closed_geom']:
                    result['closed_geom_count'] += 1
                
                # Crear puntos LOG en AZUL para cada problema
                if log_helper:
                    centroid = geom.centroid().asPoint()
                    
                    # Log para nodos duplicados
                    if issues['duplicate_nodes']:
                        for idx, point in issues['duplicate_nodes']:
                            log_helper.add_log_point(
                                point,
                                "Topología Polígonos",
                                f"{layer_name}: Nodo duplicado en índice {idx} (FID {fid})",
                                layer_name
                            )
                    
                    # Log para cierre geométrico
                    if issues['is_closed_geom']:
                        log_helper.add_log_point(
                            centroid,
                            "Topología Polígonos",
                            f"{layer_name}: Primer vértice = Último vértice (FID {fid})",
                            layer_name
                        )
        
        if log_callback:
            log_callback(f"  - Polígonos con problemas: {len(result['fids_with_issues'])}")
            log_callback(f"  - Nodos duplicados: {result['duplicate_count']}")
            log_callback(f"  - Cierres geométricos: {result['closed_geom_count']}")
        
        return result
    
    def show_warning_dialog(self, rec_stats, cla_stats):
        """
        Muestra diálogo de advertencia con estadísticas de problemas.
        
        Args:
            rec_stats: Estadísticas de REC_POLCERRADOS
            cla_stats: Estadísticas de CLA_POLCERRADOS
        
        Returns:
            str: 'continue', 'view', o 'cancel'
        """
        total_rec = len(rec_stats['fids_with_issues'])
        total_cla = len(cla_stats['fids_with_issues'])
        total_issues = total_rec + total_cla
        
        if total_issues == 0:
            return 'continue'  # Sin problemas, continuar automáticamente
        
        # Construir mensaje
        msg = "Se detectaron problemas en los contornos cerrados:\n\n"
        msg += "📊 Resumen:\n"
        
        if total_rec > 0:
            msg += f"  • REC_POLCERRADOS: {total_rec} polígonos con problemas\n"
        if total_cla > 0:
            msg += f"  • CLA_POLCERRADOS: {total_cla} polígonos con problemas\n"
        
        msg += "\n🔍 Detalles:\n"
        total_dup = rec_stats['duplicate_count'] + cla_stats['duplicate_count']
        total_closed = rec_stats['closed_geom_count'] + cla_stats['closed_geom_count']
        
        if total_dup > 0:
            msg += f"  • Nodos duplicados: {total_dup} casos\n"
        if total_closed > 0:
            msg += f"  • Primer/Último vértice coincidente: {total_closed} casos\n"
        
        msg += "\nℹ️  Estos problemas se corregirán automáticamente\n"
        msg += "    durante la exportación a DXF.\n\n"
        msg += "Los puntos de error se han marcado en la capa LOG (AZUL)."
        
        # Crear diálogo
        msgBox = QMessageBox()
        msgBox.setIcon(QMessageBox.Warning)
        msgBox.setWindowTitle("⚠️ Problemas de Topología en Polígonos Cerrados")
        msgBox.setText(msg)
        
        # Botones personalizados
        btn_view = msgBox.addButton("Ver en Mapa", QMessageBox.ActionRole)
        btn_continue = msgBox.addButton("Continuar de Todos Modos", QMessageBox.AcceptRole)
        btn_cancel = msgBox.addButton("Cancelar", QMessageBox.RejectRole)
        
        msgBox.setDefaultButton(btn_continue)
        msgBox.exec_()
        
        clicked = msgBox.clickedButton()
        
        if clicked == btn_view:
            return 'view'
        elif clicked == btn_continue:
            return 'continue'
        else:
            return 'cancel'
    
    def run(self, rec_layer, cla_layer, output_dir, log_helper=None, log_callback=None):
        """
        Ejecuta la verificación de topología en polígonos cerrados.
        
        Args:
            rec_layer: Capa REC_POLCERRADOS (puede ser None)
            cla_layer: Capa CLA_POLCERRADOS (puede ser None)
            output_dir: Directorio de salida
            log_helper: Helper para crear puntos LOG
            log_callback: Función de logging
        
        Returns:
            dict: {
                'has_issues': bool,
                'rec_issues': [fid1, fid2, ...],
                'cla_issues': [fid1, fid2, ...],
                'stats': {'duplicate_nodes': int, 'closed_geom': int},
                'user_action': 'continue' | 'view' | 'cancel'
            }
        """
        if log_callback:
            log_callback("=== VERIFICACIÓN DE TOPOLOGÍA DE POLÍGONOS CERRADOS ===")
            log_callback("")
        
        # Analizar REC_POLCERRADOS
        rec_stats = {'fids_with_issues': [], 'duplicate_count': 0, 'closed_geom_count': 0}
        if rec_layer and rec_layer.isValid():
            rec_stats = self.analyze_layer(
                rec_layer, 
                "REC_POLCERRADOS", 
                log_helper, 
                log_callback
            )
        
        # Analizar CLA_POLCERRADOS
        cla_stats = {'fids_with_issues': [], 'duplicate_count': 0, 'closed_geom_count': 0}
        if cla_layer and cla_layer.isValid():
            cla_stats = self.analyze_layer(
                cla_layer, 
                "CLA_POLCERRADOS", 
                log_helper, 
                log_callback
            )
        
        # Estadísticas totales
        total_issues = len(rec_stats['fids_with_issues']) + len(cla_stats['fids_with_issues'])
        
        if log_callback:
            log_callback("")
            if total_issues > 0:
                log_callback(f"⚠️  Total de polígonos con problemas: {total_issues}")
            else:
                log_callback("✓ No se detectaron problemas de topología.")
        
        # Mostrar diálogo si hay problemas
        user_action = 'continue'
        if total_issues > 0:
            user_action = self.show_warning_dialog(rec_stats, cla_stats)
            
            if log_callback:
                if user_action == 'cancel':
                    log_callback("Usuario canceló el proceso.")
                elif user_action == 'view':
                    log_callback("Usuario solicitó ver errores en el mapa.")
                    log_callback("Revise los puntos LOG en color AZUL.")
                    log_callback("Presione 'Siguiente' cuando esté listo para continuar.")
                else:
                    log_callback("Usuario decidió continuar con la corrección automática.")
        
        return {
            'has_issues': total_issues > 0,
            'rec_issues': rec_stats['fids_with_issues'],
            'cla_issues': cla_stats['fids_with_issues'],
            'stats': {
                'duplicate_nodes': rec_stats['duplicate_count'] + cla_stats['duplicate_count'],
                'closed_geom': rec_stats['closed_geom_count'] + cla_stats['closed_geom_count']
            },
            'user_action': user_action
        }
