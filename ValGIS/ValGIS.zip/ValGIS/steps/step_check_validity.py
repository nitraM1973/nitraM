from ..cleaning.algorithms import find_invalid_geometries

class StepCheckValidity:
    def __init__(self):
        pass

    def run(self, layer):
        """Verifica geometrias invalidas y devuelve errores detallados."""
        # Devuelve lista de {'id': fid, 'msg': msg, 'point': point}
        return find_invalid_geometries(layer)
