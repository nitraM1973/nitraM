import os
from qgis.core import (
    QgsVectorLayer, 
    QgsFeature, 
    QgsGeometry, 
    QgsField, 
    QgsVectorFileWriter, 
    QgsProject,
    QgsWkbTypes
)
from qgis.PyQt.QtCore import QVariant

class StepExportDXF:
    def __init__(self):
        pass
    
    def clean_polygon_ring(self, ring_points):
        """
        Limpia un anillo de polígono:
        1. Elimina nodos duplicados consecutivos
        2. Elimina el último vértice si coincide con el primero
        
        Args:
            ring_points: Lista de QgsPointXY
        
        Returns:
            Lista limpia de QgsPointXY
        """
        if not ring_points or len(ring_points) < 3:
            return ring_points
        
        cleaned = []
        
        # Eliminar duplicados consecutivos (comparación exacta)
        for i, point in enumerate(ring_points):
            if i == 0:
                cleaned.append(point)
            else:
                prev = cleaned[-1]
                # Comparación exacta (tolerancia 0.0)
                if not (point.x() == prev.x() and point.y() == prev.y()):
                    cleaned.append(point)
        
        # Eliminar último vértice si coincide con el primero
        if len(cleaned) >= 2:
            first = cleaned[0]
            last = cleaned[-1]
            if first.x() == last.x() and first.y() == last.y():
                cleaned = cleaned[:-1]  # Eliminar último
        
        return cleaned
    
    def run(self, lines_layer, polygons_input, output_dir, log_callback=None):
        """
        Exports original lines and generated polygon contours to a single DXF file.
        
        Args:
            lines_layer: Original lines layer (pre-polygonization)
            polygons_input: Single QgsVectorLayer OR list of dicts [{'layer': layer, 'dxf_layer': 'Name'}]
            output_dir: Directory to save the DXF
            log_callback: Logging function
            
        Returns:
            str: Path to the generated DXF file, or None if failed
        """
        def log(msg):
            if log_callback:
                log_callback(msg)
        
        log("=== EXPORTACIÓN A DXF (Revertido a OGR) ===")
        log("")
        
        if not lines_layer or not lines_layer.isValid():
            log("ERROR: Capa de líneas inválida.")
            return None
            
        # Normalize polygons_input to list
        poly_layers = []
        if isinstance(polygons_input, list):
            poly_layers = polygons_input
        elif polygons_input and polygons_input.isValid():
            poly_layers = [{'layer': polygons_input, 'dxf_layer': 'TopoCADGIS_PolCerrados'}]
            
        # Output path
        dxf_path = os.path.join(output_dir, "Resultado_Final.dxf")
        
        # Create a temporary memory layer to merge everything
        # We use LineString as geometry type because we are converting polygons to boundaries
        crs = lines_layer.crs()
        temp_layer = QgsVectorLayer(f"LineString?crs={crs.authid()}", "Temp_Export", "memory")
        pr = temp_layer.dataProvider()
        
        # Add only 'Layer' field for DXF layer mapping
        # DXF driver doesn't support arbitrary fields, only 'Layer'
        pr.addAttributes([QgsField("Layer", QVariant.String)])
        temp_layer.updateFields()
        
        layer_idx = temp_layer.fields().indexOf("Layer")
        
        # 1. Process Original Lines
        log(f"Procesando líneas originales de: {lines_layer.name()}...")
        lines_count = 0
        
        # Check if source has 'LAYER' field
        source_layer_idx = lines_layer.fields().indexOf("LAYER")
        if source_layer_idx == -1:
            # Try case-insensitive search
            for i, field in enumerate(lines_layer.fields()):
                if field.name().upper() == "LAYER":
                    source_layer_idx = i
                    break
        
        features_to_add = []
        for feat in lines_layer.getFeatures():
            new_feat = QgsFeature(temp_layer.fields())
            new_feat.setGeometry(feat.geometry())
            
            # Get layer name
            layer_name = "0" # Default
            if source_layer_idx >= 0:
                val = feat.attributes()[source_layer_idx]
                if val:
                    layer_name = str(val)
            
            new_feat.setAttribute(layer_idx, layer_name)
            features_to_add.append(new_feat)
            lines_count += 1
            
        # 2. Process Polygons (Convert to Contours)
        polys_count = 0
        
        import processing
        
        for p_info in poly_layers:
            p_layer = p_info.get('layer')
            dxf_layer_name = p_info.get('dxf_layer', 'TopoCADGIS_PolCerrados')
            
            if not p_layer or not p_layer.isValid():
                continue
                
            log(f"Procesando polígonos de: {p_layer.name()} -> Capa DXF: {dxf_layer_name}...")
            
            # First, convert MultiPolygon to single parts for efficiency
            exploded_result = processing.run("native:multiparttosingleparts", {
                'INPUT': p_layer,
                'OUTPUT': 'memory:'
            })
            
            exploded_layer = exploded_result['OUTPUT']
            
            for feat in exploded_layer.getFeatures():
                geom = feat.geometry()
                
                # Now all geometries are single-part Polygons
                if geom.type() == QgsWkbTypes.PolygonGeometry and not geom.isMultipart():
                    polygon = geom.asPolygon()
                    if polygon and len(polygon) > 0:
                        # polygon[0] is the exterior ring
                        exterior_ring = polygon[0]
                        
                        # Limpiar el anillo antes de convertir
                        cleaned_ring = self.clean_polygon_ring(exterior_ring)
                        
                        # Verificar que queden suficientes puntos
                        if len(cleaned_ring) < 2:
                            continue
                        
                        # Create a LineString from the exterior ring limpio
                        boundary = QgsGeometry.fromPolylineXY(cleaned_ring)
                        
                        if boundary.isEmpty():
                            continue
                            
                        new_feat = QgsFeature(temp_layer.fields())
                        new_feat.setGeometry(boundary)
                        new_feat.setAttribute(layer_idx, dxf_layer_name)
                        features_to_add.append(new_feat)
                        polys_count += 1
            
            if log_callback:
                log(f"  - {p_layer.name()}: {p_layer.featureCount()} polígonos -> {polys_count} contornos generados (Capa DXF: {dxf_layer_name})")
            
        # Bulk add features
        pr.addFeatures(features_to_add)
        log(f"Total elementos a exportar: {len(features_to_add)} ({lines_count} líneas, {polys_count} contornos)")
        
        # 3. Export to DXF
        log(f"Generando archivo DXF: {dxf_path}...")
        
        options = QgsVectorFileWriter.SaveVectorOptions()
        options.driverName = "DXF"
        options.layerName = "TopoCADGIS_Export"
        options.fileEncoding = "UTF-8"  # Forzar UTF-8 para evitar problemas de codificación
        
        error = QgsVectorFileWriter.writeAsVectorFormatV3(
            temp_layer,
            dxf_path,
            QgsProject.instance().transformContext(),
            options
        )
        
        if error[0] == QgsVectorFileWriter.NoError:
            log("")
            log("✓ Exportación completada exitosamente.")
            log("")
            log("El DXF exportado contiene:")
            log(f"  - {lines_count} líneas originales (organizadas por capa)")
            log(f"  - {polys_count} contornos de polígonos")
            log("")
            log("ℹ️  Nota: Los polígonos se han exportado como polilíneas.")
            log("    Se han eliminado nodos duplicados y el vértice de cierre.")
            return dxf_path
        else:
            log(f"ERROR al exportar DXF: {error[1]}")
            return None
