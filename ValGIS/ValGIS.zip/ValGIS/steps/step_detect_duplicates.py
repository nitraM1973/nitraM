from qgis.core import QgsFeatureRequest

class StepDetectDuplicates:
    def __init__(self):
        pass

    def run(self, layer, callback=None, log_helper=None):
        """
        Identifica y elimina automáticamente geometrías duplicadas.
        Devuelve (errors, fixed_count).
        """
        errors = []
        fixed_count = 0
        geoms_map = {} # wkt -> [lista de (id_type, id_value)]
        layer_name = layer.name()
        
        # Verificar si el campo UUID existe
        has_uuid = False
        for field in layer.fields():
            if field.name() == 'UUID':
                has_uuid = True
                break
        
        # 1. Recopilar todas las geometrías
        features = list(layer.getFeatures())
        total = len(features)
        for i, feature in enumerate(features):
            if callback and i % 5 == 0: callback(i, total)
            geom = feature.geometry()
            
            # Normalizar WKT para comparación independiente de dirección
            # Almacenamos el WKT "canónico" (ej: puntos siempre ordenados para líneas)
            # O más simple: verificar ambas direcciones. 
            # Mejor enfoque: Usar representación canónica donde P1 < Pn
            if geom.isMultipart():
                parts = geom.asMultiPolyline()
            else:
                parts = [geom.asPolyline()]
            
            # Crear una clave canónica para la geometría
            # Para cada parte, si inicio > fin, invertirla
            canonical_parts = []
            for part in parts:
                if not part: continue
                # Usar coordenadas redondeadas para verificación de dirección para ser consistente
                p0_x, p0_y = round(part[0].x(), 6), round(part[0].y(), 6)
                p1_x, p1_y = round(part[-1].x(), 6), round(part[-1].y(), 6)
                
                if p0_x > p1_x or (p0_x == p1_x and p0_y > p1_y):
                    canonical_parts.append(list(reversed(part)))
                else:
                    canonical_parts.append(part)
            
            # Ordenar partes para manejar diferencias de orden en multipartes
            # Ordenar por primer punto redondeado
            canonical_parts.sort(key=lambda p: (round(p[0].x(), 6), round(p[0].y(), 6)))
            
            # Reconstruir geometría para obtener clave tipo WKT con coordenadas REDONDEADAS
            # Formato: "x1,y1;x2,y2|x3,y3;x4,y4"
            key_parts = []
            for part in canonical_parts:
                pts_str = []
                for pt in part:
                    pts_str.append(f"{pt.x():.6f},{pt.y():.6f}")
                key_parts.append(";".join(pts_str))
            
            wkt_key = "|".join(key_parts)
            
            if wkt_key not in geoms_map:
                geoms_map[wkt_key] = []
            
            # Almacenar UUID si está disponible, sino FID
            if has_uuid:
                uuid_value = feature['UUID']
                geoms_map[wkt_key].append(('uuid', uuid_value))
            else:
                geoms_map[wkt_key].append(('fid', feature.id()))
            
        # 2. Identificar y Eliminar duplicados
        to_delete = []
        critical_errors = []
        
        for wkt, identifiers in geoms_map.items():
            count = len(identifiers)
            if count > 1:
                # Verificar consistencia de LAYER
                # Necesitamos obtener features para verificar el campo Layer
                # Esto es ligeramente costoso pero necesario
                
                # Agrupar identificadores por valor de Layer
                layer_groups = {}
                all_feats_info = [] # lista de (fid, layer_val, uuid)
                
                for id_type, id_value in identifiers:
                    feat = None
                    if id_type == 'uuid':
                        req = QgsFeatureRequest()
                        req.setFilterExpression(f"\"UUID\" = '{id_value}'")
                        it = layer.getFeatures(req)
                        if it: feat = next(it)
                    else:
                        feat = layer.getFeature(id_value)
                    
                    if feat and feat.isValid():
                        # Obtener valor de Layer
                        # Asumiendo que el nombre del campo es 'Layer', pero deberíamos hacerlo flexible
                        # Por ahora, verificar 'Layer' o 'LAYER'
                        layer_val = "Unknown"
                        idx = feat.fields().indexOf('Layer')
                        if idx == -1: idx = feat.fields().indexOf('LAYER')
                        
                        if idx != -1:
                            layer_val = feat.attributes()[idx]
                        
                        if layer_val not in layer_groups:
                            layer_groups[layer_val] = []
                        layer_groups[layer_val].append(feat.id())
                        all_feats_info.append((feat.id(), layer_val, feat['UUID'] if has_uuid else str(feat.id())))

                # Lógica:
                # Si múltiples capas involucradas -> ERROR CRÍTICO
                if len(layer_groups) > 1:
                    # Reportar error para CADA feature involucrada
                    layers_str = ", ".join([str(k) for k in layer_groups.keys()])
                    msg = f"CRÍTICO: Geometría duplicada entre capas distintas ({layers_str}). Debe resolverlo manualmente."
                    
                    for fid, l_val, uuid_val in all_feats_info:
                        error_dict = {
                            'point': layer.getFeature(fid).geometry().centroid().asPoint(),
                            'type': 'duplicate_cross_layer',
                            'msg': msg,
                            'id': fid,
                            'uuid': uuid_val
                        }
                        errors.append(error_dict)
                        critical_errors.append(error_dict)
                        
                        if log_helper:
                            log_helper.add_log_point(error_dict['point'], "Error Crítico", msg, layer_name)
                    
                    continue # No eliminar nada para este grupo
                
                # Si solo una capa involucrada -> Seguro eliminar duplicados
                # Ordenar identificadores para asegurar selección determinista (mantener ID más bajo)
                identifiers.sort(key=lambda x: str(x[1]))
                
                # Mantener primero, eliminar resto
                duplicates = identifiers[1:]
                
                for id_type, id_value in duplicates:
                    if id_type == 'uuid':
                        # Encontrar feature por UUID
                        req = QgsFeatureRequest()
                        req.setFilterExpression(f"\"UUID\" = '{id_value}'")
                        for feat in layer.getFeatures(req):
                            to_delete.append(feat.id())
                            fixed_count += 1
                            if log_helper:
                                msg = f"Duplicado exacto de ID {identifiers[0][1]} (Misma capa)"
                                centroid = feat.geometry().centroid().asPoint()
                                log_helper.add_log_point(centroid, "Eliminar Duplicados", msg, layer_name)
                            break 
                    else:
                        to_delete.append(id_value)
                        fixed_count += 1
                        if log_helper:
                            feat = layer.getFeature(id_value)
                            if feat.isValid():
                                msg = f"Duplicado exacto de ID {identifiers[0][1]} (Misma capa)"
                                centroid = feat.geometry().centroid().asPoint()
                                log_helper.add_log_point(centroid, "Eliminar Duplicados", msg, layer_name)
                
        if to_delete:
            layer.startEditing()
            layer.deleteFeatures(to_delete)
            layer.commitChanges()
            
        # Si se encontraron errores críticos, devolverlos inmediatamente
        if critical_errors:
            return errors, fixed_count
            
        # 3. Fase 3: Verificación de Contención Espacial (Línea dentro de Línea)
        # Re-construir índice con features restantes
        from qgis.core import QgsSpatialIndex
        
        # Necesitamos iterar de nuevo porque algunas features fueron eliminadas
        remaining_features = {f.id(): f for f in layer.getFeatures()}
        index = QgsSpatialIndex(layer.getFeatures())
        
        contained_to_delete = []
        
        for fid, feature in remaining_features.items():
            if fid in contained_to_delete:
                continue
                
            geom = feature.geometry()
            bbox = geom.boundingBox()
            
            # Encontrar candidatos que intersectan nuestro bbox
            candidate_ids = index.intersects(bbox)
            
            for cand_id in candidate_ids:
                if cand_id == fid:
                    continue
                if cand_id in contained_to_delete:
                    continue
                
                candidate = remaining_features.get(cand_id)
                if not candidate: continue
                
                cand_geom = candidate.geometry()
                
                # Verificar si 'feature' está contenida en 'candidate'
                if geom.within(cand_geom):
                    # Feature está dentro de Candidate -> Eliminar Feature
                    contained_to_delete.append(fid)
                    fixed_count += 1
                    
                    # Registrar en capa espacial si está disponible
                    if log_helper:
                        # Obtener UUID del contenedor si está disponible
                        container_uuid = "Unknown"
                        if has_uuid:
                            container_uuid = candidate['UUID']
                        else:
                            container_uuid = str(cand_id)
                            
                        msg = f"Geometría contenida en otra (ID {container_uuid})"
                        centroid = geom.centroid().asPoint()
                        log_helper.add_log_point(centroid, "Eliminar Duplicados", msg, layer_name)
                    break # Feature está marcada para eliminación, detener verificación de candidatos
                    
        if contained_to_delete:
            layer.startEditing()
            layer.deleteFeatures(contained_to_delete)
            layer.commitChanges()
                
        return errors, fixed_count
