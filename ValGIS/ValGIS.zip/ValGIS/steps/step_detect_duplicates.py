from qgis.core import QgsFeatureRequest, QgsSpatialIndex, QgsGeometry, QgsPointXY
import time
from ..helpers.layer_utils import purge_zero_length_features

class StepDetectDuplicates:
    def __init__(self):
        pass

    def run(self, layer, auto_fix=True, callback=None, log_helper=None, log_callback=None):
        """
        Identifica y elimina geometrías duplicadas o contenidas.
        VERSIÓN ULTRA-OPTIMIZADA (V3):
        - Hashing geométrico eficiente.
        - Una sola pasada de atributos.
        - Protección de Capas Distintas.
        - Parámetro auto_fix: Si es False, solo detecta errores para revisión manual.
        """
        start_time = time.time()
        errors = []
        fixed_count = 0
        layer_name = layer.name()
        
        def log(msg):
            if log_callback:
                log_callback(msg)

        # 1. Pre-limpieza
        purge_zero_length_features(layer, step_label="Detectar Duplicados", log_callback=log_callback, callback=callback)

        fields = layer.fields().names()
        layer_field = next((f for f in fields if f.upper() == 'LAYER'), None)
        has_uuid = 'UUID' in fields

        # 2. Recopilación
        geoms_map = {} 
        all_features_data = {} 
        
        features = list(layer.getFeatures())
        total = len(features)
        
        log(f"Analizando {total} objetos...")
        
        for i, feat in enumerate(features):
            if callback and i % 100 == 0: callback(i, total * 2)
            
            fid = feat.id()
            geom = feat.geometry()
            if not geom or geom.isEmpty(): continue
            
            l_val = feat[layer_field] if layer_field else "Default"
            u_val = feat['UUID'] if has_uuid else str(fid)
            length = geom.length()
            
            # Normalización canónica de vértices
            if geom.isMultipart():
                parts = geom.asMultiPolyline()
            else:
                parts = [geom.asPolyline()]
            
            canonical_parts = []
            for part in parts:
                if not part: continue
                p0 = (round(part[0].x(), 5), round(part[0].y(), 5))
                pn = (round(part[-1].x(), 5), round(part[-1].y(), 5))
                if p0 > pn:
                    normalized_part = [ (round(p.x(), 5), round(p.y(), 5)) for p in reversed(part) ]
                else:
                    normalized_part = [ (round(p.x(), 5), round(p.y(), 5)) for p in part ]
                canonical_parts.append(tuple(normalized_part))
            
            canonical_parts.sort()
            geom_key = tuple(canonical_parts)
            
            if geom_key not in geoms_map:
                geoms_map[geom_key] = []
            
            feat_data = {
                'fid': fid,
                'layer': l_val,
                'uuid': u_val,
                'length': length,
                'geom': geom 
            }
            geoms_map[geom_key].append(feat_data)
            all_features_data[fid] = feat_data

        # 3. Procesar Duplicados Exactos
        to_delete = set()
        
        for geom_key, group in geoms_map.items():
            if len(group) <= 1: continue
            
            layers_in_group = {}
            for data in group:
                l = data['layer']
                if l not in layers_in_group: layers_in_group[l] = []
                layers_in_group[l].append(data)
            
            if len(layers_in_group) > 1:
                # Caso Diferentes Capas -> ERROR
                l_names = ", ".join(layers_in_group.keys())
                
                # Reportar un solo error por grupo físico para no saturar la tabla
                data = group[0]
                fids = [str(d['fid']) for d in group]
                
                # Dar prioridad visual profunda a las capas afectadas antes que a los IDs
                msg_full = f"CRÍTICO - Solape entre capas: [{l_names}] (FIDs: {', '.join(fids)})"
                msg_log = f"Geometría idéntica en múltiples capas: {l_names}"
                
                err = {
                    'point': data['geom'].centroid().asPoint(),
                    'type': 'duplicate_cross_layer',
                    'msg': msg_full,
                    'id': data['fid'],
                    'uuid': data['uuid']
                }
                errors.append(err)
                if log_helper:
                    log_helper.add_log_point(err['point'], "Conflicto de Capas", msg_log, layer_name)
            else:
                # Caso Misma Capa → SIEMPRE eliminar (son idénticos, no requiere decisión del usuario)
                group.sort(key=lambda x: x['fid'])
                keep = group[0]
                for dup in group[1:]:
                    to_delete.add(dup['fid'])
                    fixed_count += 1
                    if log_helper:
                        msg = f"Duplicado exacto eliminado (Capa: {keep['layer']})"
                        log_helper.add_log_point(dup['geom'].centroid().asPoint(), "Limpieza", msg, layer_name)

        # 4. Procesar Líneas Contenidas
        remaining_fids = [fid for fid in all_features_data if fid not in to_delete]
        if remaining_fids:
            index = QgsSpatialIndex(layer.getFeatures(QgsFeatureRequest().setFilterFids(remaining_fids)))
            total_rem = len(remaining_fids)
            
            for j, fid in enumerate(remaining_fids):
                if callback and j % 100 == 0: callback(total + j, total * 2) 
                if fid in to_delete: continue
                
                feat_a = all_features_data[fid]
                geom_a = feat_a['geom']
                len_a = feat_a['length']
                
                candidate_ids = index.intersects(geom_a.boundingBox())
                for c_id in candidate_ids:
                    if c_id == fid or c_id in to_delete: continue
                    feat_b = all_features_data[c_id]
                    if len_a > feat_b['length'] + 0.001: continue
                        
                    if geom_a.within(feat_b['geom']):
                        if feat_a['layer'] == feat_b['layer']:
                            # Objeto corto sobre uno más largo de la misma capa = SOLAPE
                            # NO se borra automáticamente, el usuario debe decidir
                            if not any(e['id'] == fid for e in errors):
                                msg = f"Solape: línea corta ({len_a:.3f}m) contenida en otra más larga ({feat_b['length']:.3f}m) de capa '{feat_a['layer']}'."
                                errors.append({
                                    'point': geom_a.centroid().asPoint(),
                                    'type': 'solape',
                                    'msg': msg,
                                    'id': fid,
                                    'uuid': feat_a['uuid']
                                })
                                if log_helper:
                                    log_helper.add_log_point(geom_a.centroid().asPoint(), "Solape", msg, layer_name)
                            break
                        else:
                            msg = f"Línea contenida en objeto de capa distinta ({feat_b['layer']}). No borrada."
                            if not any(e['id'] == fid for e in errors):
                                errors.append({
                                    'point': geom_a.centroid().asPoint(),
                                    'type': 'contained_cross_layer',
                                    'msg': msg,
                                    'id': fid,
                                    'uuid': feat_a['uuid']
                                })
                            if log_helper:
                                log_helper.add_log_point(geom_a.centroid().asPoint(), "Conflicto Capas (Contenido)", msg, layer_name)

        # 5. Aplicar Eliminaciones
        if to_delete and auto_fix:
            layer.startEditing()
            layer.deleteFeatures(list(to_delete))
            layer.commitChanges()

        elapsed = time.time() - start_time
        log(f"⏱️ Detección completada en {elapsed:.2f}s.")
        if auto_fix:
            log(f"🧹 Corregidos: {fixed_count} | ⚠️ Errores manuales: {len(errors)}")
        else:
            log(f"📋 Modo Manual: {len(errors)} candidatos detectados.")

        return errors, fixed_count
