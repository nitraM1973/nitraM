import os
import math
import traceback
import time
import numpy as np
from qgis.core import (
    QgsProject, 
    QgsVectorLayer, 
    QgsFeature, 
    QgsGeometry, 
    QgsField, 
    QgsSpatialIndex, 
    QgsPointXY, 
    QgsWkbTypes,
    QgsFeatureRequest,
    edit
)
from qgis.PyQt.QtCore import QVariant
from collections import defaultdict, Counter
import processing

try:
    from shapely.geometry import shape, mapping, MultiLineString, LineString, Point, Polygon, MultiPoint
    from shapely.ops import linemerge, unary_union, split, voronoi_diagram, substring
    from shapely.strtree import STRtree
    from shapely.wkt import loads as load_wkt
except ImportError:
    # Si falla shapely en algún entorno, usaremos alternativas QGIS
    pass

class StepGenerateViales:
    # --- CONSTANTES DE DISEÑO (Opción C) ---
    DENSIFICACION_METROS = 1.0  # m - distancia entre puntos para Voronoi
    SNAP_TOLERANCE       = 0.1  # m - para conectar ejes
    MIN_LONGITUD_EJE    = 0.5  # m - descartar ejes espurios

    def __init__(self):
        pass

    def run(self, recintos_layer, output_dir, densificacion_metros=1.0, log_callback=None, callback=None):
        def log(m):
            if log_callback: log_callback(m)
        def progress(curr, total):
            if callback: callback(curr, total)
            
        from ..helpers.layer_utils import clean_and_save_layer
        crs_id = recintos_layer.crs().authid()
        
        # --- PREPARACIÓN DE AUDITORÍA (GRUPO VIALES) ---
        root = QgsProject.instance().layerTreeRoot()
        grupo_viales = root.findGroup("VIALES")
        if grupo_viales: root.removeChildNode(grupo_viales)
        grupo_viales = root.addGroup("VIALES")

        def add_audit_layer(lyr, name=None):
            if not lyr: return
            if name: lyr.setName(name)
            QgsProject.instance().addMapLayer(lyr, False)
            grupo_viales.insertLayer(0, lyr)

        # --- FASE A: EXTRACCIÓN DE ZONAS VIALES ---
        log("FASE A: Extrayendo Zonas Viales (Envolvente - Manzanas)...")
        
        # 1. Crear Manzanas (Disueltas Globalmente)
        progress(5, 100)
        res_diss = processing.run("native:dissolve", {'INPUT': recintos_layer, 'OUTPUT': 'memory:manzanas_diss'})
        res_single = processing.run("native:multiparttosingleparts", {'INPUT': res_diss['OUTPUT'], 'OUTPUT': 'memory:manzanas_single'})
        manzanas_saved = res_single['OUTPUT']
        add_audit_layer(manzanas_saved, "01_Manzanas")
        
        # Preparar perímetros de manzanas para clasificación rápida
        res_peri = processing.run("native:polygonstolines", {'INPUT': manzanas_saved, 'OUTPUT': 'memory:peri_manz'})
        geom_peri_manz = QgsGeometry()
        for f in res_peri['OUTPUT'].getFeatures():
            if geom_peri_manz.isEmpty(): geom_peri_manz = f.geometry()
            else: geom_peri_manz = geom_peri_manz.combine(f.geometry())
        # Buffer de 2cm para detección de contacto
        zona_contacto_manz = geom_peri_manz.buffer(0.02, 3)
        
        # 2. Crear Envolvente
        progress(10, 100)
        res_dilat = processing.run("native:buffer", {'INPUT': manzanas_saved, 'DISTANCE': 10.0, 'DISSOLVE': True, 'OUTPUT': 'memory:dilat'})
        res_solida = processing.run("native:deleteholes", {'INPUT': res_dilat['OUTPUT'], 'OUTPUT': 'memory:solida'})
        res_env = processing.run("native:buffer", {'INPUT': res_solida['OUTPUT'], 'DISTANCE': -9.75, 'DISSOLVE': True, 'OUTPUT': 'memory:envolvente'})
        capa_envolvente = res_env['OUTPUT']
        add_audit_layer(capa_envolvente, "02_Envolvente")

        # Zona de exclusión perimetral (Borde del buffer interior de 1cm)
        # Se crea un buffer a -0.01m y se usa SU LÍNEA EXTERIOR para seleccionar y borrar lo que la corte
        res_env_int = processing.run("native:buffer", {'INPUT': capa_envolvente, 'DISTANCE': -0.01, 'DISSOLVE': True, 'OUTPUT': 'memory:env_int'})
        res_env_int_lines = processing.run("native:polygonstolines", {'INPUT': res_env_int['OUTPUT'], 'OUTPUT': 'memory:env_int_lines'})
        
        zona_exclusion_env = QgsGeometry()
        for f in res_env_int_lines['OUTPUT'].getFeatures():
            if zona_exclusion_env.isEmpty(): zona_exclusion_env = f.geometry()
            else: zona_exclusion_env = zona_exclusion_env.combine(f.geometry())
        # Pequeño buffer de 1mm a la línea para asegurar la intersección en la consulta
        zona_exclusion_env = zona_exclusion_env.buffer(0.001, 3)

        # 3. Zona Viaria = Envolvente - Manzanas
        progress(15, 100)
        res_diff = processing.run("native:difference", {
            'INPUT': capa_envolvente,
            'OVERLAY': manzanas_saved,
            'OUTPUT': 'memory:zona_viaria'
        })
        # Convertir a partes simples para procesar calle por calle
        res_zona_single = processing.run("native:multiparttosingleparts", {'INPUT': res_diff['OUTPUT'], 'OUTPUT': 'memory:zona_viaria_single'})
        capa_zona_viaria = res_zona_single['OUTPUT']
        add_audit_layer(capa_zona_viaria, "03_Zona_Viaria")
        log(f"   ✓ {capa_zona_viaria.featureCount()} polígonos de zona viaria generados.")

        # --- FASE B & C: MAPEO DE CORREDORES Y EJE MEDIAL (VORONOI GLOBAL) ---
        log("FASE B/C: Calculando Ejes Mediales (Optimización Global)...")
        
        # 1. Recolectar TODOS los puntos de fachadas de una sola vez
        log("   - Densificando perímetros de manzanas...")
        res_peri = processing.run("native:polygonstolines", {'INPUT': manzanas_saved, 'OUTPUT': 'memory:peri_manz'})
        peri_manz = res_peri['OUTPUT']
        
        all_pts_set = set()
        pt_to_block = {} # (x,y) -> block_id
        
        for feat_m in manzanas_saved.getFeatures():
            m_id = feat_m.id()
            geom = feat_m.geometry()
            # Densificar perímetros de esta manzana específica
            # Extraer líneas del perímetro
            if geom.isMultipart():
                parts = geom.asMultiPolygon()
            else:
                parts = [geom.asPolygon()]
                
            for part in parts:
                for ring in part:
                    ring_geom = QgsGeometry.fromPolylineXY(ring)
                    # Asegurar esquinas
                    for v in ring_geom.vertices():
                        key = (round(v.x(), 4), round(v.y(), 4))
                        all_pts_set.add(key)
                        pt_to_block[key] = m_id
                    # Densificar
                    densificada = ring_geom.densifyByDistance(densificacion_metros)
                    for v in densificada.vertices():
                        key = (round(v.x(), 4), round(v.y(), 4))
                        all_pts_set.add(key)
                        pt_to_block[key] = m_id
        
        all_pts_voronoi = list(all_pts_set)
        
        # AUDITORÍA: Capa de Puntos para Voronoi
        capa_puntos = QgsVectorLayer(f"Point?crs={crs_id}", "02_Puntos_Voronoi", "memory")
        pr_pts = capa_puntos.dataProvider()
        pr_pts.addAttributes([QgsField("BlockID", QVariant.Int)])
        capa_puntos.updateFields()
        
        feats_p = []
        for x, y in all_pts_voronoi:
            f = QgsFeature(capa_puntos.fields())
            f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(x, y)))
            f.setAttributes([pt_to_block.get((x, y), -1)])
            feats_p.append(f)
        pr_pts.addFeatures(feats_p)
        add_audit_layer(capa_puntos, "02_Puntos_Voronoi")
        
        if len(all_pts_voronoi) < 4:
            log("   ! Error: No hay suficientes puntos para Voronoi.")
            return manzanas_saved, capa_envolvente, None

        log(f"   - Generando Diagrama de Voronoi Global para {len(all_pts_voronoi)} puntos...")
        progress(40, 100)
        try:
            mp = MultiPoint(all_pts_voronoi)
            vor_collection = voronoi_diagram(mp)
            
            log("   - Extrayendo y clasificando aristas del eje medial...")
            todas_las_aristas_raw = []
            for cell in vor_collection.geoms:
                if cell.boundary.geom_type == 'LineString':
                    todas_las_aristas_raw.append(cell.boundary)
                elif cell.boundary.geom_type == 'MultiLineString':
                    for part in cell.boundary.geoms:
                        todas_las_aristas_raw.append(part)
            
            tree_vor = STRtree(todas_las_aristas_raw)
            ejes_geoms_con_tipo = []
            
            total_zv = capa_zona_viaria.featureCount()
            feats_zv = list(capa_zona_viaria.getFeatures())
            for i, feat_zv in enumerate(feats_zv):
                if i % 50 == 0: progress(45 + int(i/total_zv * 25), 100)
                geom_zv = feat_zv.geometry()
                geom_zv_shapely = load_wkt(geom_zv.asWkt())
                indices_candidatos = tree_vor.query(geom_zv_shapely)
                
                for idx in indices_candidatos:
                    arista = todas_las_aristas_raw[idx]
                    inter = arista.intersection(geom_zv_shapely)
                    if not inter.is_empty:
                        parts = [inter] if inter.geom_type == 'LineString' else inter.geoms
                        for part in parts:
                            if part.geom_type == 'LineString' and part.length > self.MIN_LONGITUD_EJE:
                                # CLASIFICACIÓN POR CONTACTO CON MANZANA
                                q_part = QgsGeometry.fromWkt(part.wkt)
                                if q_part.intersects(zona_contacto_manz):
                                    tipo = "TRANSVERSAL"
                                else:
                                    tipo = "EJE"
                                ejes_geoms_con_tipo.append((q_part, tipo))
                    
        except Exception as e:
            log(f"   ! Error en Voronoi Global: {str(e)}")
            return manzanas_saved, capa_envolvente, None

        # --- FASE D: ENSAMBLADO ---
        log("FASE D: Ensamblando y simplificando red de ejes...")
        
        # Unir todos los ejes y disolver para limpiar duplicados
        capa_ejes_raw = QgsVectorLayer(f"LineString?crs={crs_id}", "Ejes_Raw", "memory")
        pr_e = capa_ejes_raw.dataProvider()
        pr_e.addAttributes([QgsField("TIPO", QVariant.String)])
        capa_ejes_raw.updateFields()
        
        feats_e = []
        for g, tipo in ejes_geoms_con_tipo:
            f = QgsFeature(capa_ejes_raw.fields())
            f.setGeometry(g)
            f.setAttributes([tipo])
            feats_e.append(f)
        pr_e.addFeatures(feats_e)
        add_audit_layer(capa_ejes_raw, "04_Ejes_Brutos")
        
        # Disolver y unir segmentos contiguos usando Shapely para máxima robustez
        log("   - Limpiando topología de la red (Filtrando basura en bordes)...")
        progress(75, 100)
        try:
            shapely_ejes = []
            for feat in capa_ejes_raw.getFeatures():
                geom = feat.geometry()
                if geom.intersects(zona_exclusion_env):
                    continue
                shapely_ejes.append(load_wkt(geom.asWkt()))
            
            # Unir todo en una sola red
            red_unida = unary_union(shapely_ejes)
            
            # Convertir de vuelta a capa QGIS
            capa_ejes_clean = QgsVectorLayer(f"LineString?crs={crs_id}", "Ejes_Limpios", "memory")
            pr_c = capa_ejes_clean.dataProvider()
            
            feats_c = []
            if red_unida.geom_type == 'LineString':
                f = QgsFeature(); f.setGeometry(QgsGeometry.fromWkt(red_unida.wkt)); feats_c.append(f)
            elif red_unida.geom_type in ['MultiLineString', 'GeometryCollection']:
                for part in red_unida.geoms:
                    if part.geom_type == 'LineString':
                        f = QgsFeature(); f.setGeometry(QgsGeometry.fromWkt(part.wkt)); feats_c.append(f)
            
            pr_c.addFeatures(feats_c)
            res_merged_lyr = capa_ejes_clean
        except Exception as e:
            log(f"   ! Error en limpieza Shapely: {str(e)}")
            res_diss_e = processing.run("native:dissolve", {'INPUT': capa_ejes_raw, 'OUTPUT': 'memory:ejes_diss'})
            res_merged_lyr = res_diss_e['OUTPUT']
        
        # --- FASE E: SEGMENTACIÓN DE RAMALES Y CRUCES ---
        log("FASE E: Segmentando ramales e identificando cruces...")
        progress(85, 100)
        
        # AUDITORÍA: Red Descompuesta (Resultado de Unary Union sin duplicados)
        capa_descomp = QgsVectorLayer(f"LineString?crs={crs_id}", "04b_Red_Descompuesta", "memory")
        pr_d = capa_descomp.dataProvider()
        pr_d.addAttributes([QgsField("TIPO", QVariant.String), 
                            QgsField("ExtremoA", QVariant.Int), 
                            QgsField("ExtremoB", QVariant.Int)])
        capa_descomp.updateFields()
        
        feats_d = []
        if 'red_unida' in locals():
            sub_geoms = []
            if red_unida.geom_type == 'LineString': sub_geoms = [red_unida]
            elif red_unida.geom_type in ['MultiLineString', 'GeometryCollection']:
                sub_geoms = [g for g in red_unida.geoms if g.geom_type == 'LineString']
            
            # Pre-clasificación para contar conectividad
            temp_data = []
            trans_node_counts = Counter()
            for g in sub_geoms:
                q_g = QgsGeometry.fromWkt(g.wkt)
                tipo = "TRANSVERSAL" if q_g.intersects(zona_contacto_manz) else "EJE"
                temp_data.append((g, tipo))
                if tipo == "TRANSVERSAL":
                    for pt in [g.coords[0], g.coords[-1]]:
                        key = (round(pt[0], 3), round(pt[1], 3))
                        trans_node_counts[key] += 1
            
            for g, tipo in temp_data:
                f = QgsFeature(capa_descomp.fields())
                f.setGeometry(QgsGeometry.fromWkt(g.wkt))
                p1 = (round(g.coords[0][0], 3), round(g.coords[0][1], 3))
                p2 = (round(g.coords[-1][0], 3), round(g.coords[-1][1], 3))
                
                # Contar cuántas TRANSVERSAL hay en cada nudo
                c_a = trans_node_counts[p1]
                c_b = trans_node_counts[p2]
                
                # Si la propia línea es TRANSVERSAL, se descuenta a sí misma
                ext_a = (c_a - 1) if tipo == "TRANSVERSAL" else c_a
                ext_b = (c_b - 1) if tipo == "TRANSVERSAL" else c_b
                
                f.setAttributes([tipo, max(0, ext_a), max(0, ext_b)])
                feats_d.append(f)
                
        pr_d.addFeatures(feats_d)
        add_audit_layer(capa_descomp, "04b_Red_Descompuesta")
        
        # --- FASE F: DEPURACIÓN ITERATIVA DE FALSOS EJES ---
        log("FASE F: Podando ramales falsos (Detección de horquillas)...")
        
        # Iterar para podar ramales que terminan en horquillas
        for it_poda in range(5):
            eje_counts = Counter()
            for g, tipo in temp_data:
                if tipo == "EJE":
                    for pt in [g.coords[0], g.coords[-1]]:
                        eje_counts[(round(pt[0], 3), round(pt[1], 3))] += 1
            
            cambios_poda = 0
            for i, (g, tipo) in enumerate(temp_data):
                if tipo == "EJE":
                    for pt_coords in [g.coords[0], g.coords[-1]]:
                        node = (round(pt_coords[0], 3), round(pt_coords[1], 3))
                        n_ejes = eje_counts[node]
                        n_trans = trans_node_counts[node]
                        
                        # REGLA: Si soy el único eje en este nudo y hay horquilla de transversales
                        if n_ejes == 1 and n_trans > 1:
                            temp_data[i] = (g, "EJE_falso")
                            cambios_poda += 1
                            break
            if cambios_poda == 0: break
            log(f"   - Pase {it_poda+1}: {cambios_poda} tramos podados.")

        # AUDITORÍA: Red Depurada (05)
        capa_depurada = QgsVectorLayer(f"LineString?crs={crs_id}", "05_Red_Depurada", "memory")
        pr_dep = capa_depurada.dataProvider()
        pr_dep.addAttributes([QgsField("TIPO", QVariant.String), QgsField("ExtA_T", QVariant.Int), QgsField("ExtB_T", QVariant.Int)])
        capa_depurada.updateFields()
        
        feats_dep = []
        for g, tipo in temp_data:
            f = QgsFeature(capa_depurada.fields()); f.setGeometry(QgsGeometry.fromWkt(g.wkt))
            p1 = (round(g.coords[0][0], 3), round(g.coords[0][1], 3)); p2 = (round(g.coords[-1][0], 3), round(g.coords[-1][1], 3))
            f.setAttributes([tipo, trans_node_counts[p1], trans_node_counts[p2]])
            feats_dep.append(f)
        pr_dep.addFeatures(feats_dep)
        add_audit_layer(capa_depurada, "05_Red_Depurada")

        # --- FASE G: UNIÓN DE RAMALES DE EJE (SHAPELY VECTORIZADO) ---
        log("FASE G: Uniendo tramos contiguos de EJE...")
        
        eje_geoms = [g for g, tipo in temp_data if tipo == "EJE"]
        lista_ejes_final = []
        
        if eje_geoms:
            # 1. Unary Union (Limpia la topología y crea nodos en intersecciones)
            red_ejes_limpia = unary_union(eje_geoms)
            # 2. Linemerge (Une tramos contiguos respetando bifurcaciones)
            ejes_fusionados = linemerge(red_ejes_limpia)
            
            if ejes_fusionados.geom_type == 'LineString':
                lista_ejes_final = [ejes_fusionados]
            elif ejes_fusionados.geom_type in ['MultiLineString', 'GeometryCollection']:
                lista_ejes_final = [g for g in ejes_fusionados.geoms if g.geom_type == 'LineString']
            
            # AUDITORÍA: Ejes Unidos (06)
            capa_unidos = QgsVectorLayer(f"LineString?crs={crs_id}", "06_Ejes_Unidos", "memory")
            pr_uni = capa_unidos.dataProvider()
            pr_uni.addAttributes([QgsField("ID", QVariant.Int), QgsField("Longitud", QVariant.Double)])
            capa_unidos.updateFields()
            for i, g in enumerate(lista_ejes_final):
                f = QgsFeature(capa_unidos.fields()); f.setGeometry(QgsGeometry.fromWkt(g.wkt)); f.setAttributes([i, g.length]); pr_uni.addFeatures([f])
            add_audit_layer(capa_unidos, "06_Ejes_Unidos")
            log(f"   - Red consolidada: {len(lista_ejes_final)} ramales generados.")

        # --- FASE H: GENERACIÓN DE RADIOS DE CIERRE (TOPOLÓGICOS) ---
        log("FASE H: Generando radios de cierre topológicos...")
        
        # 1. Obtener todos los nudos de interés (Bifurcaciones y Finales) sobre la red consolidada
        nodos_interes = defaultdict(int)
        for g in lista_ejes_final:
            p1 = (round(g.coords[0][0], 3), round(g.coords[0][1], 3))
            p2 = (round(g.coords[-1][0], 3), round(g.coords[-1][1], 3))
            nodos_interes[p1] += 1
            nodos_interes[p2] += 1
        
        # 2. Preparar búsqueda espacial de puntos de control (Capa 02)
        pts_control_shapely = []
        pts_metadata = [] # lista de (block_id) coincidente con pts_control_shapely
        for (px, py), b_id in pt_to_block.items():
            pts_control_shapely.append(Point(px, py))
            pts_metadata.append(b_id)
            
        tree_pts = STRtree(pts_control_shapely)
        
        capa_radios = QgsVectorLayer(f"LineString?crs={crs_id}", "07_Radios_Cierre", "memory")
        pr_rad = capa_radios.dataProvider()
        pr_rad.addAttributes([QgsField("Grado", QVariant.Int), QgsField("BlockID", QVariant.Int)])
        capa_radios.updateFields()
        
        feats_rad = []
        for (nx, ny), grado in nodos_interes.items():
            if grado != 2: # Solo bifurcaciones o finales
                p_nodo = Point(nx, ny)
                idx_nearest = tree_pts.nearest(p_nodo)
                d_min = p_nodo.distance(pts_control_shapely[idx_nearest])
                
                # Buscar puntos equidistantes (margen 5cm)
                indices_cercanos = tree_pts.query(p_nodo.buffer(d_min + 0.05))
                
                # AGRUPAR POR MANZANA (Seleccionar solo el mejor punto por cada masa)
                mejor_punto_por_bloque = {} # block_id -> (distancia, punto_shapely)
                
                for idx in indices_cercanos:
                    pt = pts_control_shapely[idx]
                    b_id = pts_metadata[idx]
                    dist = p_nodo.distance(pt)
                    
                    if dist < d_min + 0.05:
                        if b_id not in mejor_punto_por_bloque or dist < mejor_punto_por_bloque[b_id][0]:
                            mejor_punto_por_bloque[b_id] = (dist, pt)
                
                # Crear los radios finales (uno por bloque)
                for b_id, (dist, pt) in mejor_punto_por_bloque.items():
                    f = QgsFeature(capa_radios.fields())
                    f.setGeometry(QgsGeometry.fromWkt(LineString([p_nodo, pt]).wkt))
                    f.setAttributes([grado, b_id])
                    feats_rad.append(f)
        
        pr_rad.addFeatures(feats_rad)
        add_audit_layer(capa_radios, "07_Radios_Cierre")
        
        log(f"   - Se han generado {len(feats_rad)} radios de cierre topológicos.")
        log("✓ Proceso pausado en Radios de Cierre (07).")
        return manzanas_saved, capa_envolvente, capa_radios
