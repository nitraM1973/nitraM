import processing
import os
from ..helpers.layer_utils import clean_and_save_layer

class StepGeneratePolygons:
    def __init__(self):
        pass

    def run(self, layer, output_dir, filename="Polygons.shp", log_helper=None, log_callback=None):
        """
        Genera polígonos a partir de líneas usando native:polygonize.
        """
        from qgis.core import QgsVectorLayer
        
        # Asegurar que estamos trabajando con una capa válida
        if not layer or not layer.isValid():
            raise ValueError("Invalid input layer for polygonization")
        
        # Verificar si la capa tiene features
        feature_count = layer.featureCount()
        selected_count = layer.selectedFeatureCount()
        
        if log_callback:
            log_callback(f"Capa de entrada: {layer.name()}")
            log_callback(f"Total de features: {feature_count}")
            log_callback(f"Features seleccionadas: {selected_count}")
            log_callback(f"Tipo de geometría: {layer.geometryType()}")
            
        if feature_count == 0:
            raise ValueError("Input layer is empty, cannot generate polygons")
        
        # Usar archivo temporal para salida en lugar de memoria para evitar problemas potenciales
        import tempfile
        temp_dir = tempfile.gettempdir()
        temp_output = os.path.join(temp_dir, f"temp_polygons_{os.getpid()}.shp")
        
        if log_callback:
            log_callback(f"Archivo temporal: {temp_output}")
        
        # Si hay una selección, usar SOLO features seleccionadas
        # La forma más robusta es materializarlas en una capa de memoria
        input_layer = layer
        if selected_count > 0:
            if log_callback:
                log_callback(f"Usando {selected_count} features seleccionadas para poligonización...")
            
            input_layer = processing.run("native:saveselectedfeatures", {
                'INPUT': layer,
                'OUTPUT': 'memory:'
            })['OUTPUT']
        
        params = {
            'INPUT': input_layer,
            'KEEP_FIELDS': True,
            'OUTPUT': temp_output
        }
        
        try:
            if log_callback:
                log_callback("Ejecutando native:polygonize...")
                
            result = processing.run("native:polygonize", params)
            
            if log_callback:
                log_callback(f"Resultado de processing.run: {type(result)}")
                log_callback(f"Claves en resultado: {list(result.keys()) if isinstance(result, dict) else 'No es dict'}")
            
            # Cargar la capa de salida desde la ruta del archivo
            output_path = result['OUTPUT']
            
            if log_callback:
                log_callback(f"OUTPUT path: {output_path}")
                log_callback(f"Tipo de OUTPUT: {type(output_path)}")
                log_callback(f"¿Archivo existe?: {os.path.exists(output_path) if isinstance(output_path, str) else 'N/A'}")
            
            if isinstance(output_path, str):
                polygons = QgsVectorLayer(output_path, "temp_polygons", "ogr")
                if log_callback:
                    log_callback(f"Capa cargada desde archivo. ¿Es válida?: {polygons.isValid()}")
            else:
                polygons = output_path
                if log_callback:
                    log_callback(f"OUTPUT ya es una capa. ¿Es válida?: {polygons.isValid()}")
            
            if not polygons.isValid():
                if log_callback:
                    log_callback(f"ERROR: La capa de polígonos no es válida")
                    log_callback(f"Error de capa: {polygons.error().message() if hasattr(polygons, 'error') else 'N/A'}")
                raise RuntimeError("Failed to load polygonized layer")
            
            # Verificar si la poligonización produjo resultados
            poly_count = polygons.featureCount()
            
            if log_callback:
                log_callback(f"Polígonos generados por native:polygonize: {poly_count}")
            
            if poly_count == 0:
                if log_callback:
                    log_callback("native:polygonize no generó polígonos. Intentando qgis:polygonize...")
                
                # Fallback a qgis:polygonize con salida en memoria
                params['OUTPUT'] = 'memory:'
                result = processing.run("qgis:polygonize", params)
                polygons = result['OUTPUT']
                
                if isinstance(polygons, str):
                    polygons = QgsVectorLayer(polygons, "temp_polygons", "ogr")
                
                poly_count = polygons.featureCount()
                
                if log_callback:
                    log_callback(f"Polígonos generados por qgis:polygonize: {poly_count}")

            if poly_count == 0:
                if log_helper:
                    layer_name = layer.name()
                    log_helper.add_log_point(
                        layer.extent().center(), 
                        "Generar Polígonos", 
                        f"ADVERTENCIA: No se generaron polígonos. Verifica que las líneas formen áreas cerradas.", 
                        layer_name
                    )
                if log_callback:
                    log_callback("ADVERTENCIA: No se generaron polígonos después de ambos intentos.")
                    log_callback("Posibles causas:")
                    log_callback("  1. Las líneas no forman áreas completamente cerradas")
                    log_callback("  2. Existen micro-gaps entre líneas")
                    log_callback("  3. Geometrías problemáticas en la capa de entrada")
            else:
                if log_callback:
                    log_callback(f"✓ Se generaron {poly_count} polígonos exitosamente.")
            
            if log_callback:
                log_callback(f"Guardando resultado en: {os.path.join(output_dir, filename)}")
                
            output_path = os.path.join(output_dir, filename)
            result_layer, _ = clean_and_save_layer(polygons, output_path)
            
            if log_callback:
                log_callback(f"Capa guardada. Features finales: {result_layer.featureCount()}")
            
            # Limpiar archivo temporal
            if os.path.exists(temp_output):
                try:
                    # QGIS podría mantener un bloqueo, así que ignorar errores aquí
                    for ext in ['.shp', '.shx', '.dbf', '.prj', '.cpg']:
                        f = temp_output.replace('.shp', ext)
                        if os.path.exists(f): 
                            os.remove(f)
                except: 
                    pass
            
            # --- NUEVO: Poligonización Dividida (Corregir Islas) ---
            # Detectar y corregir automáticamente islas (anillos interiores) dividiéndolas
            from .step_fix_islands import StepFixIslands
            island_fixer = StepFixIslands()
            
            if log_callback:
                log_callback("Verificando islas (split polygonization)...")
                
            # Detectar islas
            islands = island_fixer.detect(polygons, log_callback=None) # Sin log verbose para detección
            
            if islands:
                if log_callback:
                    log_callback(f"  Detectadas {len(islands)} islas. Aplicando corrección automática (split)...")
                
                fixed_count = 0
                polygons.startEditing()
                
                # Ordenar islas por ID para asegurar orden determinístico si es necesario, aunque usualmente no es crítico
                # Iteramos hacia atrás o cuidadosamente porque corregir una podría afectar otras? 
                # StepFixIslands.fix modifica la capa in situ.
                
                for island in islands:
                    # La lógica de corrección maneja la división
                    if island_fixer.fix(polygons, island['id'], island):
                        fixed_count += 1
                
                polygons.commitChanges()
                
                if log_callback:
                    log_callback(f"  ✓ Se corrigieron (dividieron) {fixed_count} islas.")
            else:
                if log_callback:
                    log_callback("  ✓ No se detectaron islas.")
            # -----------------------------------------------

            return result_layer
            
        except Exception as e:
            if log_callback:
                log_callback(f"EXCEPCIÓN durante poligonización: {str(e)}")
                log_callback(f"Tipo de excepción: {type(e).__name__}")
            raise RuntimeError(f"Error durante la poligonización: {str(e)}")
