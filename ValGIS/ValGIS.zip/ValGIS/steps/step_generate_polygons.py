import processing
import os
from ..helpers.layer_utils import clean_and_save_layer, purge_zero_length_features, get_feedback
from qgis.core import QgsVectorLayer, QgsGeometry, QgsPointXY, QgsFeature, QgsSpatialIndex, QgsRectangle

class StepGeneratePolygons:
    def __init__(self):
        pass

    def run(self, layer, output_dir, filename="Polygons.shp", log_helper=None, log_callback=None, callback=None):
        """
        Genera polígonos a partir de líneas usando native:polygonize.
        """
        from qgis.core import QgsVectorLayer
        
        # Asegurar que estamos trabajando con una capa válida
        if not layer or not layer.isValid():
            raise ValueError("Invalid input layer for polygonization")
        
        # Verificar si la capa tiene features
        feature_count = layer.featureCount()
        selected_count = layer.selectedFeatureCount()
        
        if log_callback:
            log_callback(f"Capa de entrada: {layer.name()}")
            log_callback(f"Total de features: {feature_count}")
            log_callback(f"Features seleccionadas: {selected_count}")
            log_callback(f"Tipo de geometría: {layer.geometryType()}")
            
        if feature_count == 0:
            raise ValueError("Input layer is empty, cannot generate polygons")
        
        # Usar archivo temporal único para evitar colisiones entre grupos (Recintos/Clases)
        import tempfile
        import random
        import string
        suffix = ''.join(random.choices(string.ascii_lowercase + string.digits, k=6))
        temp_dir = tempfile.gettempdir()
        temp_output = os.path.join(temp_dir, f"valgis_poly_{os.getpid()}_{suffix}.shp")
        
        if log_callback:
            log_callback(f"Archivo temporal: {temp_output}")
        
        # Si hay una selección, usar SOLO features seleccionadas
        # La forma más robusta es materializarlas en una capa de memoria
        input_layer = layer
        if selected_count > 0:
            if log_callback:
                log_callback(f"Usando {selected_count} features seleccionadas para poligonización...")
            
            input_layer = processing.run("native:saveselectedfeatures", {
                'INPUT': layer,
                'OUTPUT': 'memory:'
            }, feedback=get_feedback(callback))['OUTPUT']

        # Purgar geometrías de longitud exactamente 0 antes de poligonizar
        purge_zero_length_features(input_layer, step_label="Generar Polígonos", log_callback=log_callback)

        params = {
            'INPUT': input_layer,
            'KEEP_FIELDS': True,
            'OUTPUT': temp_output
        }
        
        try:
            if log_callback:
                log_callback("Ejecutando native:polygonize...")
                
            # Usar feedback para el proceso de poligonización (puede ser muy lento)
            feedback = get_feedback(callback)
            result = processing.run("native:polygonize", params, feedback=feedback)
            
            if log_callback:
                log_callback(f"Resultado de processing.run: {type(result)}")
                log_callback(f"Claves en resultado: {list(result.keys()) if isinstance(result, dict) else 'No es dict'}")
            
            # Cargar la capa de salida desde la ruta del archivo
            output_path = result['OUTPUT']
            
            if log_callback:
                log_callback(f"OUTPUT path: {output_path}")
                log_callback(f"Tipo de OUTPUT: {type(output_path)}")
                log_callback(f"¿Archivo existe?: {os.path.exists(output_path) if isinstance(output_path, str) else 'N/A'}")
            
            if isinstance(output_path, str):
                polygons = QgsVectorLayer(output_path, "temp_polygons", "ogr")
                if log_callback:
                    log_callback(f"Capa cargada desde archivo. ¿Es válida?: {polygons.isValid()}")
            else:
                polygons = output_path
                if log_callback:
                    log_callback(f"OUTPUT ya es una capa. ¿Es válida?: {polygons.isValid()}")
            
            if not polygons.isValid():
                if log_callback:
                    log_callback(f"ERROR: La capa de polígonos no es válida")
                    log_callback(f"Error de capa: {polygons.error().message() if hasattr(polygons, 'error') else 'N/A'}")
                raise RuntimeError("Failed to load polygonized layer")
            
            # Verificar si la poligonización produjo resultados
            poly_count = polygons.featureCount()
            
            if log_callback:
                log_callback(f"Polígonos generados por native:polygonize: {poly_count}")
            
            if poly_count == 0:
                if log_callback:
                    log_callback("native:polygonize no generó polígonos. Intentando qgis:polygonize...")
                
                # Fallback a qgis:polygonize con salida en memoria
                params['OUTPUT'] = 'memory:'
                result = processing.run("qgis:polygonize", params, feedback=feedback)
                polygons = result['OUTPUT']
                
                if isinstance(polygons, str):
                    polygons = QgsVectorLayer(polygons, "temp_polygons", "ogr")
                
                poly_count = polygons.featureCount()
                
                if log_callback:
                    log_callback(f"Polígonos generados por qgis:polygonize: {poly_count}")

            if poly_count == 0:
                if log_helper:
                    layer_name = layer.name()
                    log_helper.add_log_point(
                        layer.extent().center(), 
                        "Generar Polígonos", 
                        f"ADVERTENCIA: No se generaron polígonos. Verifica que las líneas formen áreas cerradas.", 
                        layer_name
                    )
                if log_callback:
                    log_callback("ADVERTENCIA: No se generaron polígonos después de ambos intentos.")
                    log_callback("Posibles causas:")
                    log_callback("  1. Las líneas no forman áreas completamente cerradas")
                    log_callback("  2. Existen micro-gaps entre líneas")
                    log_callback("  3. Geometrías problemáticas en la capa de entrada")
            else:
                if log_callback:
                    log_callback(f"✓ Se generaron {poly_count} polígonos exitosamente.")
            
            if log_callback:
                log_callback(f"Guardando resultado en: {os.path.join(output_dir, filename)}")
                
            output_path = os.path.join(output_dir, filename)
            result_layer, _ = clean_and_save_layer(polygons, output_path)
            
            if log_callback:
                log_callback(f"Capa guardada. Features finales: {result_layer.featureCount()}")
            
            # Limpiar archivo temporal
            if os.path.exists(temp_output):
                try:
                    # QGIS podría mantener un bloqueo, así que ignorar errores aquí
                    for ext in ['.shp', '.shx', '.dbf', '.prj', '.cpg']:
                        f = temp_output.replace('.shp', ext)
                        if os.path.exists(f): 
                            os.remove(f)
                except: 
                    pass
            
            # --- NUEVO: Poligonización Dividida (Corregir Islas) ---
            # Detectar y corregir automáticamente islas (anillos interiores) dividiéndolas
            from .step_fix_islands import StepFixIslands
            island_fixer = StepFixIslands()
            
            if log_callback:
                log_callback("Verificando islas (split polygonization)...")
                
            # Detectar islas
            islands = island_fixer.detect(polygons, log_callback=None) # Sin log verbose para detección
            
            if islands:
                if log_callback:
                    log_callback(f"  Detectadas {len(islands)} islas. Aplicando corrección automática (split)...")
                
                fixed_count = 0
                polygons.startEditing()
                
                # Ordenar islas por ID para asegurar orden determinístico si es necesario, aunque usualmente no es crítico
                # Iteramos hacia atrás o cuidadosamente porque corregir una podría afectar otras? 
                # StepFixIslands.fix modifica la capa in situ.
                
                for island in islands:
                    # La lógica de corrección maneja la división
                    if island_fixer.fix(polygons, island['id'], island):
                        fixed_count += 1
                
                polygons.commitChanges()
                
                if log_callback:
                    log_callback(f"  ✓ Se corrigieron (dividieron) {fixed_count} islas.")
            else:
                if log_callback:
                    log_callback("  ✓ No se detectaron islas.")
            # -----------------------------------------------

            # --- NUEVO: Verificación de Fugas (Líneas Interiores) ---
            if log_callback:
                log_callback("Verificando integridad (buscando líneas interiores/fugas)...")
            
            internal_errors = self.verify_internal_lines(input_layer, result_layer, log_callback)

            return result_layer, internal_errors
        except Exception as e:
            if log_callback:
                log_callback(f"EXCEPCIÓN durante poligonización: {str(e)}")
            raise RuntimeError(f"Error durante la poligonización: {str(e)}")

    def verify_internal_lines(self, lines_layer, polygons_layer, log_callback=None):
        """
        Detecta polígonos que contienen líneas en su interior (fugas).
        Registra el polígono afectado en lugar de cada línea individual.
        """
        if not polygons_layer or polygons_layer.featureCount() == 0:
            return []

        # Usar un diccionario para registrar cada polígono afectado solo una vez
        fuga_polygons = {} # {poly_id: error_data}
        
        # 1. Crear índice espacial de polígonos
        poly_index = QgsSpatialIndex(polygons_layer.getFeatures())
        polygons = {f.id(): f for f in polygons_layer.getFeatures()}
        
        # 2. Analizar cada línea
        for line_feat in lines_layer.getFeatures():
            line_geom = line_feat.geometry()
            if not line_geom or line_geom.isEmpty(): continue
            
            # Solo nos interesan líneas con longitud significativa (>5cm)
            if line_geom.length() < 0.05: continue
            
            # Buscar polígonos candidatos por Bounding Box
            candidates = poly_index.intersects(line_geom.boundingBox())
            
            for pid in candidates:
                if pid in fuga_polygons: continue # Ya marcado como fuga
                
                poly_feat = polygons[pid]
                poly_geom = poly_feat.geometry()
                
                # Definir el "interior" del polígono (encogido 1cm)
                interior = poly_geom.buffer(-0.01, 4)
                if interior.isEmpty(): continue
                
                # Calcular intersección de la línea con el interior del polígono
                overlap = line_geom.intersection(interior)
                
                if not overlap.isEmpty() and overlap.length() > 0.05:
                    # ¡Fuga detectada! Registramos el POLÍGONO
                    poly_centroid = poly_geom.centroid().asPoint()
                    fuga_polygons[pid] = {
                        'point': poly_centroid,
                        'bbox': poly_geom.boundingBox(), # Capturamos la caja para el zoom
                        'type': 'internal_line',
                        'msg': f"[FUGA] Polígono fusionado (contiene líneas interiores)",
                        'id': pid, # ID del polígono para identificarlo
                        'layer_id': polygons_layer.id() # ID de la capa (Recintos o Clases)
                    }
                    break # Pasamos a la siguiente línea
                    
        errors = list(fuga_polygons.values())
        
        if log_callback and errors:
            log_callback(f"  ⚠️ Se detectaron {len(errors)} polígonos con posibles fugas.")
            
        return errors
