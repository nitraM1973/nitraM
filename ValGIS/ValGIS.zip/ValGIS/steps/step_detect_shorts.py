from qgis.core import QgsSpatialIndex

class StepDetectShorts:
    def __init__(self):
        pass

    def run(self, layer, min_length, tolerance=0.0001, callback=None, log_helper=None):
        """
        Identifica y auto-elimina TODAS las features cortas (aisladas o conectadas).
        Dado que estan dentro de la tolerancia, los pasos posteriores manejaran la topologia correctamente.
        Devuelve (lista_de_errores, contador_corregidos).
        """
        errors = []
        fixed_count = 0
        
        features = list(layer.getFeatures())
        layer_name = layer.name()
        
        layer.startEditing()
        
        to_delete = []
        
        total = len(features)
        for i, feature in enumerate(features):
            if callback and i % 5 == 0: callback(i, total)
            geom = feature.geometry()
            length = geom.length()
            
            if length < min_length:
                # Auto-eliminar TODOS los objetos cortos (aislados o conectados)
                to_delete.append(feature.id())
                fixed_count += 1
                
                if log_helper:
                    centroid = geom.centroid().asPoint()
                    log_helper.add_log_point(centroid, "Eliminar Cortos", f"Objeto corto eliminado (L={length:.4f})", layer_name)
        
        if to_delete:
            layer.deleteFeatures(to_delete)
            
        layer.commitChanges()
        
        return errors, fixed_count
