from qgis.core import QgsGeometry

def find_invalid_geometries(layer):
    """Returns a list of dicts with details of invalid geometries."""
    errors = []
    
    # Check if UUID field exists
    has_uuid = False
    for field in layer.fields():
        if field.name() == 'UUID':
            has_uuid = True
            break
    
    for feature in layer.getFeatures():
        geom = feature.geometry()
        if not geom.isGeosValid():
            msg = "Geometría inválida (General)"
            loc = geom.centroid().asPoint()
            
            # Attempt to get specific error details safely
            try:
                validation_errors = geom.validateGeometry()
                if validation_errors:
                    # Take the first error found
                    err = validation_errors[0]
                    msg = err.what()
                    
                    # Translate common GEOS messages to Spanish
                    if "Self-intersection" in msg:
                        msg = "Auto-intersección: La línea se cruza a sí misma."
                    elif "Nested shells" in msg:
                        msg = "Anillos anidados: Polígono con huecos mal formados."
                    elif "Ring Self-intersection" in msg:
                        msg = "Auto-intersección de anillo."
                    
                    # Try to get location safely
                    try:
                        if hasattr(err, 'hasLocation') and err.hasLocation():
                            loc = err.where()
                        elif hasattr(err, 'where'):
                             loc = err.where()
                    except:
                        pass # Keep centroid
            except Exception as e:
                # Fallback if validation crashes
                msg = f"Geometría inválida (Error al analizar: {str(e)})"
            
            error_dict = {
                'id': feature.id(),
                'msg': msg,
                'point': loc
            }
            
            # Add UUID if available
            if has_uuid:
                error_dict['uuid'] = feature['UUID']
            
            errors.append(error_dict)
    return errors

def find_short_segments(layer, min_length):
    """Returns a list of feature IDs shorter than min_length."""
    short_ids = []
    for feature in layer.getFeatures():
        if feature.geometry().length() < min_length:
            short_ids.append(feature.id())
    return short_ids
