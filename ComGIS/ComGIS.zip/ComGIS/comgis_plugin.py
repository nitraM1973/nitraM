import os
from qgis.PyQt.QtWidgets import QAction, QDockWidget, QToolBar, QMenu
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtCore import Qt
from .ui.dock_widget import ComGISDockWidget

class ComGISPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.dock_widget = None
        self.action = None

    def initGui(self):
        icon_path = os.path.join(self.plugin_dir, 'icon.svg')
        self.action = QAction(QIcon(icon_path), 'ComGIS', self.iface.mainWindow())
        self.action.setObjectName("ComGISAction")
        self.action.triggered.connect(self.run)
        
        # Configuracion de la barra de herramientas
        self.toolbar = None
        # Comprobar si existe la barra de herramientas ValCAD
        toolbars = self.iface.mainWindow().findChildren(QToolBar)
        for tb in toolbars:
            if tb.windowTitle() == 'ValCAD':
                self.toolbar = tb
                break
        
        # Crear si no existe
        if not self.toolbar:
            self.toolbar = self.iface.addToolBar('ValCAD')
            self.toolbar.setObjectName('ValCADToolbar')
        
        self.toolbar.addAction(self.action)

        # Configuracion del menu
        self.valcad_menu = None
        plugin_menu = self.iface.pluginMenu()
        
        # Comprobar si existe el submenu ValCAD
        for action in plugin_menu.actions():
            if action.text() == 'ValCAD' and action.menu():
                self.valcad_menu = action.menu()
                break
                
        # Create if not exists
        if not self.valcad_menu:
            self.valcad_menu = QMenu('ValCAD', plugin_menu)
            plugin_menu.addMenu(self.valcad_menu)
            
        self.valcad_menu.addAction(self.action)

    def unload(self):
        if self.dock_widget:
            self.iface.removeDockWidget(self.dock_widget)
            
        if hasattr(self, 'toolbar') and self.toolbar:
            self.toolbar.removeAction(self.action)
            
        if hasattr(self, 'valcad_menu') and self.valcad_menu:
            self.valcad_menu.removeAction(self.action)
            
    def run(self):
        if not self.dock_widget:
            self.dock_widget = ComGISDockWidget(self.iface)
            self.iface.addDockWidget(Qt.RightDockWidgetArea, self.dock_widget)
        
        self.dock_widget.show()
