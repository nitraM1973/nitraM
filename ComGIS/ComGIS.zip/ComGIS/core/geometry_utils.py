from qgis.core import QgsGeometry, QgsWkbTypes

class GeometryUtils:
    def __init__(self, logger):
        self.logger = logger

    def fix_geometry(self, geometry):
        if geometry.isGeosValid():
            return geometry
        
        # Intentar makeValid
        fixed = geometry.makeValid()
        if fixed.isGeosValid():
            return fixed
            
        # Si sigue siendo invalido, intentar buffer(0)
        fixed = geometry.buffer(0, 5)
        if fixed.isGeosValid():
            return fixed
            
        self.logger.log("No se pudo corregir la geometría.")
        return geometry

    def polygon_to_lines(self, geometry):
        if geometry.type() != QgsWkbTypes.PolygonGeometry:
            return geometry
        
        # Convertir a multilinestring
        return geometry.convertToType(QgsWkbTypes.LineGeometry)
