import os
import json
from datetime import datetime

class HtmlGenerator:
    def __init__(self, logger):
        self.logger = logger

    def generate_report(self, differences, output_path):
        self.logger.log(f"Generando reporte HTML en: {output_path}")
        
        # Calcular estadisticas
        stats = self._calculate_statistics(differences)
        
        # Generar HTML
        html_content = self._generate_html(differences, stats)
        
        try:
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(html_content)
            return True
        except Exception as e:
            self.logger.log(f"Error al escribir HTML: {str(e)}")
            return False

    def _calculate_statistics(self, differences):
        """Calcular estadisticas de diferencias."""
        stats = {
            'total': len(differences),
            'by_category': {},
            'distances': [],
            'avg_distance': 0.0,
            'max_distance': 0.0,
            'min_distance': 0.0
        }
        
        # Contar por categoria y recolectar distancias
        for diff in differences:
            category = diff['type']
            stats['by_category'][category] = stats['by_category'].get(category, 0) + 1
            
            if diff.get('distance') is not None:
                stats['distances'].append(diff['distance'])
        
        # Calcular estadisticas de distancia
        if stats['distances']:
            stats['avg_distance'] = sum(stats['distances']) / len(stats['distances'])
            stats['max_distance'] = max(stats['distances'])
            stats['min_distance'] = min(stats['distances'])
        
        return stats

    def _generate_html(self, differences, stats):
        """Generar reporte HTML completo."""
        
        # Preparar datos para graficos
        chart_data = self._prepare_chart_data(stats)
        
        # Generar filas de tabla
        table_rows = self._generate_table_rows(differences)
        
        html = f"""<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reporte de Diferencias - ComGIS</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }}
        
        .container {{
            max-width: 1400px;
            margin: 0 auto;
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            overflow: hidden;
        }}
        
        header {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 40px;
            text-align: center;
        }}
        
        header h1 {{
            font-size: 2.5rem;
            margin-bottom: 10px;
            font-weight: 700;
        }}
        
        header p {{
            font-size: 1.1rem;
            opacity: 0.9;
        }}
        
        .summary-cards {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            padding: 40px;
            background: #f8f9fa;
        }}
        
        .card {{
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }}
        
        .card:hover {{
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        }}
        
        .card-title {{
            font-size: 0.9rem;
            color: #6c757d;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 10px;
        }}
        
        .card-value {{
            font-size: 2.5rem;
            font-weight: 700;
            color: #667eea;
        }}
        
        .charts-section {{
            padding: 40px;
        }}
        
        .charts-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
            gap: 30px;
            margin-bottom: 30px;
        }}
        
        .chart-container {{
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }}
        
        .chart-title {{
            font-size: 1.3rem;
            font-weight: 600;
            margin-bottom: 20px;
            color: #333;
        }}
        
        .table-section {{
            padding: 40px;
            background: #f8f9fa;
        }}
        
        .search-box {{
            width: 100%;
            padding: 15px 20px;
            font-size: 1rem;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            margin-bottom: 20px;
            transition: border-color 0.3s ease;
        }}
        
        .search-box:focus {{
            outline: none;
            border-color: #667eea;
        }}
        
        table {{
            width: 100%;
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }}
        
        thead {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }}
        
        th {{
            padding: 15px;
            text-align: left;
            font-weight: 600;
            cursor: pointer;
            user-select: none;
        }}
        
        th:hover {{
            background: rgba(255,255,255,0.1);
        }}
        
        td {{
            padding: 15px;
            border-bottom: 1px solid #e0e0e0;
        }}
        
        tbody tr:hover {{
            background: #f8f9fa;
        }}
        
        .badge {{
            display: inline-block;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
            color: white;
        }}
        
        .badge-added {{ background: #10b981; }}
        .badge-deleted {{ background: #ef4444; }}
        .badge-displaced {{ background: #f59e0b; }}
        .badge-new {{ background: #3b82f6; }}
        .badge-removed {{ background: #8b5cf6; }}
        
        footer {{
            text-align: center;
            padding: 30px;
            color: #6c757d;
            font-size: 0.9rem;
        }}
        
        @media print {{
            body {{
                background: white;
                padding: 0;
            }}
            .container {{
                box-shadow: none;
            }}
            .search-box {{
                display: none;
            }}
            .chart-container {{
                page-break-inside: avoid;
            }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>📊 Análisis de Diferencias Espaciales</h1>
            <p>Reporte generado el {datetime.now().strftime('%d/%m/%Y a las %H:%M:%S')}</p>
        </header>
        
        <div class="summary-cards">
            <div class="card">
                <div class="card-title">Total Diferencias</div>
                <div class="card-value">{stats['total']}</div>
            </div>
            <div class="card">
                <div class="card-title">Distancia Promedio</div>
                <div class="card-value">{stats['avg_distance']:.2f}m</div>
            </div>
            <div class="card">
                <div class="card-title">Distancia Máxima</div>
                <div class="card-value">{stats['max_distance']:.2f}m</div>
            </div>
            <div class="card">
                <div class="card-title">Categorías</div>
                <div class="card-value">{len(stats['by_category'])}</div>
            </div>
        </div>
        
        <div class="charts-section">
            <div class="charts-grid">
                <div class="chart-container">
                    <div class="chart-title">Diferencias por Categoría</div>
                    <canvas id="categoryChart"></canvas>
                </div>
                <div class="chart-container">
                    <div class="chart-title">Distribución Porcentual</div>
                    <canvas id="pieChart"></canvas>
                </div>
            </div>
            <div class="chart-container">
                <div class="chart-title">Histograma de Distancias de Desplazamiento</div>
                <canvas id="distanceChart"></canvas>
            </div>
        </div>
        
        <div class="table-section">
            <input type="text" id="searchBox" class="search-box" placeholder="🔍 Buscar diferencias...">
            <table id="differencesTable">
                <thead>
                    <tr>
                        <th onclick="sortTable(0)">ID ↕</th>
                        <th onclick="sortTable(1)">Tipo ↕</th>
                        <th onclick="sortTable(2)">Descripción ↕</th>
                        <th onclick="sortTable(3)">Distancia (m) ↕</th>
                        <th onclick="sortTable(4)">Origen ↕</th>
                    </tr>
                </thead>
                <tbody id="tableBody">
                    {table_rows}
                </tbody>
            </table>
        </div>
        
        <footer>
            <p>Generado por <strong>ComGIS Plugin</strong> para QGIS</p>
            <p>© 2025 - Análisis Espacial Profesional</p>
        </footer>
    </div>
    
    <script>
        // Datos del grafico
        const chartData = {chart_data};
        
        // Grafico de categorias
        new Chart(document.getElementById('categoryChart'), {{
            type: 'bar',
            data: {{
                labels: chartData.categories,
                datasets: [{{
                    label: 'Número de Diferencias',
                    data: chartData.counts,
                    backgroundColor: chartData.colors,
                    borderRadius: 8
                }}]
            }},
            options: {{
                responsive: true,
                plugins: {{
                    legend: {{ display: false }}
                }},
                scales: {{
                    y: {{ beginAtZero: true }}
                }}
            }}
        }});
        
        // Grafico circular
        new Chart(document.getElementById('pieChart'), {{
            type: 'doughnut',
            data: {{
                labels: chartData.categories,
                datasets: [{{
                    data: chartData.counts,
                    backgroundColor: chartData.colors
                }}]
            }},
            options: {{
                responsive: true,
                plugins: {{
                    legend: {{ position: 'bottom' }}
                }}
            }}
        }});
        
        // Histograma de distancia
        if (chartData.distances.length > 0) {{
            new Chart(document.getElementById('distanceChart'), {{
                type: 'line',
                data: {{
                    labels: chartData.distances.map((_, i) => i + 1),
                    datasets: [{{
                        label: 'Distancia (m)',
                        data: chartData.distances,
                        borderColor: '#f59e0b',
                        backgroundColor: 'rgba(245, 158, 11, 0.1)',
                        fill: true,
                        tension: 0.4
                    }}]
                }},
                options: {{
                    responsive: true,
                    plugins: {{
                        legend: {{ display: false }}
                    }},
                    scales: {{
                        y: {{ beginAtZero: true }}
                    }}
                }}
            }});
        }}
        
        // Funcionalidad de busqueda
        document.getElementById('searchBox').addEventListener('input', function(e) {{
            const searchTerm = e.target.value.toLowerCase();
            const rows = document.querySelectorAll('#tableBody tr');
            
            rows.forEach(row => {{
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(searchTerm) ? '' : 'none';
            }});
        }});
        
        // Ordenacion de tabla
        function sortTable(columnIndex) {{
            const table = document.getElementById('differencesTable');
            const tbody = table.querySelector('tbody');
            const rows = Array.from(tbody.querySelectorAll('tr'));
            
            rows.sort((a, b) => {{
                const aText = a.cells[columnIndex].textContent;
                const bText = b.cells[columnIndex].textContent;
                
                // Intentar comparacion numerica primero
                const aNum = parseFloat(aText);
                const bNum = parseFloat(bText);
                
                if (!isNaN(aNum) && !isNaN(bNum)) {{
                    return aNum - bNum;
                }}
                
                return aText.localeCompare(bText);
            }});
            
            rows.forEach(row => tbody.appendChild(row));
        }}
    </script>
</body>
</html>"""
        
        return html

    def _prepare_chart_data(self, stats):
        """Preparar datos para graficos Chart.js."""
        color_map = {
            'Vértice Añadido': '#10b981',
            'Vértice Eliminado': '#ef4444',
            'Vértice Desplazado': '#f59e0b',
            'Geometría Nueva': '#3b82f6',
            'Geometría Eliminada': '#8b5cf6'
        }
        
        categories = list(stats['by_category'].keys())
        counts = [stats['by_category'][cat] for cat in categories]
        colors = [color_map.get(cat, '#6c757d') for cat in categories]
        
        data = {
            'categories': categories,
            'counts': counts,
            'colors': colors,
            'distances': sorted(stats['distances'])
        }
        
        return json.dumps(data)

    def _generate_table_rows(self, differences):
        """Generar filas de tabla HTML."""
        badge_map = {
            'Vértice Añadido': 'badge-added',
            'Vértice Eliminado': 'badge-deleted',
            'Vértice Desplazado': 'badge-displaced',
            'Geometría Nueva': 'badge-new',
            'Geometría Eliminada': 'badge-removed'
        }
        
        rows = []
        for i, diff in enumerate(differences):
            badge_class = badge_map.get(diff['type'], 'badge-added')
            distance_str = f"{diff['distance']:.3f}" if diff.get('distance') is not None else '-'
            origin = diff.get('capa_orig', '-')
            
            row = f"""
                <tr>
                    <td>{i+1}</td>
                    <td><span class="badge {badge_class}">{diff['type']}</span></td>
                    <td>{diff['description']}</td>
                    <td>{distance_str}</td>
                    <td>{origin}</td>
                </tr>
            """
            rows.append(row)
        
        return ''.join(rows)
