import os
from qgis.core import QgsProject, QgsField, QgsWkbTypes
from qgis.core import (
    QgsProject, QgsField, QgsWkbTypes, QgsFeature, QgsGeometry,
    QgsCategorizedSymbolRenderer, QgsRendererCategory, QgsSymbol,
    QgsSimpleMarkerSymbolLayer
)
from qgis.PyQt.QtGui import QColor
from qgis.PyQt.QtCore import QObject, QVariant
from qgis.PyQt.QtWidgets import QApplication

from .logger import Logger
from .layer_manager import LayerManager
from .geometry_utils import GeometryUtils
from .comparator import Comparator
from .html_generator import HtmlGenerator



class Controller:
    def __init__(self, ui_logger):
        self.logger = ui_logger # Instancia del Logger conectada a la UI
        self.layer_manager = LayerManager(self.logger)
        self.geo_utils = GeometryUtils(self.logger)
        self.comparator = Comparator(self.logger, self.geo_utils)
        self.html_gen = HtmlGenerator(self.logger)


    def start_comparison(self, layer1, layer2, on_finish_callback):
        self.on_finish = on_finish_callback
        
        # Ejecutar en hilo principal (con processEvents para mantener la UI activa)
        try:
            QApplication.processEvents()
            output_paths = self.run_process(layer1, layer2)
            self._process_finished(output_paths)
        except Exception as e:
            self._process_error(str(e))

    def run_process(self, layer1, layer2):
        # 1. Crear directorio temporal
        base_path = os.path.dirname(layer1.source()) if os.path.exists(os.path.dirname(layer1.source())) else os.path.expanduser("~")
        temp_dir = self.layer_manager.create_temp_dir(base_path)
        
        # 2. Comparar
        results = []
        
        # Comparacion inicial (Bidireccional)
        self.logger.log(f"Comparando {layer1.name()} -> {layer2.name()}...")
        results.extend(self.comparator.compare(layer1, layer2))
        
        self.logger.log(f"Comparando {layer2.name()} -> {layer1.name()}...")
        results.extend(self.comparator.compare(layer2, layer1))
        
        # Si son poligonos, convertir a lineas y comparar de nuevo (Bidireccional tambien?)
        # La logica original solo lo hacia de L1 a L2 con lineas convertidas.
        # Asumiremos que si es bidireccional, deberiamos hacerlo en ambos sentidos tambien para lineas.
        
        if layer1.geometryType() == QgsWkbTypes.PolygonGeometry and layer2.geometryType() == QgsWkbTypes.PolygonGeometry:
            self.logger.log("Detectados polígonos. Convirtiendo a líneas para segunda comparación...")
            l1_lines = self.layer_manager.convert_polygon_layer_to_line_layer(layer1, add_to_registry=False)
            l2_lines = self.layer_manager.convert_polygon_layer_to_line_layer(layer2, add_to_registry=False)
            
            if l1_lines and l2_lines:
                self.logger.log(f"Comparando líneas (Polígonos): {layer1.name()} -> {layer2.name()}...")
                line_results1 = self.comparator.compare(l1_lines, l2_lines)
                for res in line_results1:
                    res['type'] += " (Líneas)"
                results.extend(line_results1)
                
                self.logger.log(f"Comparando líneas (Polígonos): {layer2.name()} -> {layer1.name()}...")
                line_results2 = self.comparator.compare(l2_lines, l1_lines)
                for res in line_results2:
                    res['type'] += " (Líneas)"
                results.extend(line_results2)
        
        if not results:
            self.logger.log("No se encontraron diferencias.")
            # Aunque este vacio, quizas queramos generar reportes vacios?
            # Pero procedamos a generar capas vacias al menos.

        # Deduplicar resultados identicos
        results = self._deduplicate_strict(results)

        # 3. Generar capas de salida
        # Capa de diferencias (Puntos por ahora segun requisito "shape de puntos")
        # Espera, el requisito dice: "SHAPE de la tipología que sea para que se vean las diferencias y un shape de puntos"
        
        # Crear capa de registro de puntos
        fields = [
            QgsField("ID", QVariant.Int),
            QgsField("TIPO", QVariant.String, len=30),
            QgsField("DESC", QVariant.String, len=254),
            QgsField("DISTANCIA", QVariant.Double),
            QgsField("CAPA_ORIG", QVariant.String, len=20),
            QgsField("FID_ORIG", QVariant.Int)
        ]
        crs = layer1.crs()
        log_layer = self.layer_manager.create_memory_layer("LOG", "Point", fields, crs, add_to_registry=False)
        
        # Capa de geometria de diferencias (Lineas o Poligonos)
        # Se llamara DIFERENCIAS
        # Usar MultiLineString/MultiPolygon para asegurar compatibilidad con resultados de diferencias complejas
        diff_geom_type = "MultiLineString" if layer1.geometryType() == QgsWkbTypes.LineGeometry else "MultiPolygon"
        diff_layer = self.layer_manager.create_memory_layer("DIFERENCIAS", diff_geom_type, fields, crs, add_to_registry=False)
        
        log_layer.startEditing()
        diff_layer.startEditing()
        
        for i, diff in enumerate(results):
            # Anadir a capa de registro (Geometria de punto - ya es un punto o centroide)
            feat_log = QgsFeature(log_layer.fields())
            feat_log.setAttribute("ID", i+1)
            feat_log.setAttribute("TIPO", diff['type'])
            feat_log.setAttribute("DESC", diff['description'])
            feat_log.setAttribute("DISTANCIA", diff.get('distance'))
            feat_log.setAttribute("CAPA_ORIG", diff.get('capa_orig', ''))
            feat_log.setAttribute("FID_ORIG", diff.get('fid_orig'))
            # La geometria ya es un punto para diferencias de vertices
            if diff['geometry'].type() == QgsWkbTypes.PointGeometry:
                feat_log.setGeometry(diff['geometry'])
            else:
                feat_log.setGeometry(diff['geometry'].centroid())
            log_layer.addFeature(feat_log)
            
            # Anadir a capa de diferencias (solo para geometrias no puntuales)
            if diff['geometry'].type() != QgsWkbTypes.PointGeometry:
                feat_diff = QgsFeature(diff_layer.fields())
                feat_diff.setAttribute("ID", i+1)
                feat_diff.setAttribute("TIPO", diff['type'])
                feat_diff.setAttribute("DESC", diff['description'])
                feat_diff.setAttribute("DISTANCIA", diff.get('distance'))
                feat_diff.setAttribute("CAPA_ORIG", diff.get('capa_orig', ''))
                feat_diff.setAttribute("FID_ORIG", diff.get('fid_orig'))
                feat_diff.setGeometry(diff['geometry'])
                if not diff_layer.addFeature(feat_diff):
                    self.logger.log(f"Error al añadir característica a DIFERENCIAS (ID: {i+1}). Posible geometría inválida.")
            
        log_layer.commitChanges()
        diff_layer.commitChanges()
        
        # Guardar en archivo
        log_path = self.layer_manager.save_layer_to_file(log_layer, "LOG.shp")
        
        diff_path = None
        if diff_layer.featureCount() > 0:
            diff_path = self.layer_manager.save_layer_to_file(diff_layer, "DIFERENCIAS.shp")
        else:
            self.logger.log("Capa DIFERENCIAS vacía. No se guardará archivo.")

        # 4. Generar reporte HTML
        html_path = os.path.join(temp_dir, "Diferencias.html")
        self.html_gen.generate_report(results, html_path)
        
        # Abrir reporte en navegador web
        import webbrowser
        self.logger.log(f"Abriendo reporte en: {html_path}")
        try:
            webbrowser.open(f'file:///{html_path}')
        except Exception as e:
            self.logger.log(f"No se pudo abrir el navegador automáticamente: {e}")
        
        self.logger.log("Proceso completado exitosamente.")
        return [log_path, diff_path]

    def _process_finished(self, output_paths):
        # Cargar capas en hilo principal
        loaded_layers = []
        if output_paths:
            for path in output_paths:
                if path:
                    layer = self.layer_manager.load_layer(path, os.path.basename(path))
                    if layer:
                        loaded_layers.append(layer)
                        if "LOG" in layer.name():
                             self._apply_log_style(layer)

        # Mover capas al tope
        # Iteramos en orden inverso para que la primera (LOG) quede al final en la posicion 0
        if loaded_layers:
            root = QgsProject.instance().layerTreeRoot()
            for layer in reversed(loaded_layers):
                node = root.findLayer(layer.id())
                if node:
                    clone = node.clone()
                    root.insertChildNode(0, clone)
                    root.removeChildNode(node)

        if self.on_finish:
            self.on_finish()

    def _process_error(self, error_msg):
        self.logger.log(f"ERROR CRÍTICO: {error_msg}")
        if self.on_finish:
            self.on_finish()

    def reset(self, keep_layers):
        self.layer_manager.cleanup(keep_layers)

    def _apply_log_style(self, layer):
        categories = []
        
        # Helper to create category
        def create_category(value, color, label):
            symbol = QgsSymbol.defaultSymbol(layer.geometryType())
            symbol.setColor(QColor(color))
            # Make sure points are visible
            if layer.geometryType() == QgsWkbTypes.PointGeometry:
                 symbol.setSize(4)
            return QgsRendererCategory(value, symbol, label)

        # Definir categorias
        categories.append(create_category("Vértice Añadido", "#00ff00", "Vértice Añadido"))
        categories.append(create_category("Vértice Añadido (Líneas)", "#00ff00", "Vértice Añadido (Líneas)"))
        
        categories.append(create_category("Vértice Eliminado", "#ff0000", "Vértice Eliminado"))
        categories.append(create_category("Vértice Eliminado (Líneas)", "#ff0000", "Vértice Eliminado (Líneas)"))
        
        categories.append(create_category("Vértice Desplazado", "#ffaa00", "Vértice Desplazado"))
        categories.append(create_category("Vértice Desplazado (Líneas)", "#ffaa00", "Vértice Desplazado (Líneas)"))

        categories.append(create_category("Geometría Nueva", "#0000ff", "Geometría Nueva"))
        categories.append(create_category("Geometría Eliminada", "#000000", "Geometría Eliminada"))
        
        categories.append(create_category("Diferencia Geométrica", "#ff00ff", "Diferencia Geométrica"))

        renderer = QgsCategorizedSymbolRenderer("TIPO", categories)
        layer.setRenderer(renderer)
        layer.triggerRepaint()

    def _deduplicate_strict(self, results):
        unique_results = []
        seen = set()
        
        for res in results:
            geom = res['geometry']
            # Usar centroide para asegurar consistencia si es geometria no puntual (aunque la logica de resultados usa centroide o punto)
            if geom.type() != QgsWkbTypes.PointGeometry:
                pt = geom.centroid().asPoint()
            else:
                pt = geom.asPoint()
                
            # Clave: (x redondeado, y redondeado, tipo)
            # Redondear a 4 decimales (aprox sub-milimetro) para evitar errores de punto flotante
            key = (round(pt.x(), 4), round(pt.y(), 4), res['type'])
            
            if key not in seen:
                seen.add(key)
                unique_results.append(res)
                
        return unique_results
