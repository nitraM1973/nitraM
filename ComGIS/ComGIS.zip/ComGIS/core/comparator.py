from qgis.core import QgsGeometry, QgsFeature, QgsWkbTypes, QgsSpatialIndex
import math

class Comparator:
    def __init__(self, logger, geometry_utils):
        self.logger = logger
        self.geo_utils = geometry_utils
        self.tolerance = 0.01  # Tolerancia predeterminada de 1cm

    def compare(self, layer1, layer2):
        """
        Compara dos capas con deteccion a nivel de vertice.
        Devuelve una lista de diccionarios de diferencias.
        """
        type1 = layer1.geometryType()
        type2 = layer2.geometryType()
        
        if type1 != type2:
            self.logger.log("Error: Las capas deben ser del mismo tipo.")
            return []

        differences = []
        
        # Comparar geometrias
        self.logger.log("Comparando geometrías...")
        differences.extend(self._compare_geometries(layer1, layer2))
        
        return differences

    def _compare_geometries(self, layer1, layer2):
        """Comparar geometrias y detectar diferencias a nivel de vertice."""
        diffs = []
        
        # Construir indice espacial para capa 2
        index2 = QgsSpatialIndex(layer2.getFeatures())
        
        # Rastrear elementos coincidentes para encontrar los no coincidentes mas tarde
        matched_fids_layer2 = set()
        
        # Comparar elementos de capa 1
        for feat1 in layer1.getFeatures():
            geom1 = self.geo_utils.fix_geometry(feat1.geometry())
            
            # Encontrar geometria similar en capa 2
            similar_feat, similarity = self._find_similar_geometry(feat1, geom1, layer2, index2)
            
            if similar_feat:
                matched_fids_layer2.add(similar_feat.id())
                geom2 = self.geo_utils.fix_geometry(similar_feat.geometry())
                
                # 1. Comprobacion Geometrica Global (Huecos, Areas sobran/faltan)
                geom_diffs = self._check_geometric_difference(geom1, geom2, feat1.id(), similar_feat.id())
                diffs.extend(geom_diffs)
                
                # 2. Comparar vertices si las geometrias son similares pero no identicas
                if not geom1.equals(geom2):
                    vertex_diffs = self._compare_vertices(geom1, geom2, feat1.id(), similar_feat.id())
                    diffs.extend(vertex_diffs)
            else:
                # No se encontro geometria similar - la geometria completa ha sido eliminada
                msg = (f"La geometría completa con ID {feat1.id()} presente en la Capa 1 NO ha sido encontrada en la Capa 2. "
                       f"Esto indica que el elemento ha sido eliminado o desplazado significativamente.")
                diffs.append({
                    'geometry': geom1.centroid(),
                    'type': 'Geometría Eliminada',
                    'description': msg,
                    'distance': None,
                    'capa_orig': 'Capa 1',
                    'fid_orig': feat1.id()
                })
        
        # Encontrar nuevas geometrias en capa 2 (no coincidentes)
        for feat2 in layer2.getFeatures():
            if feat2.id() not in matched_fids_layer2:
                geom2 = self.geo_utils.fix_geometry(feat2.geometry())
                msg = (f"Se ha detectado una nueva geometría con ID {feat2.id()} en la Capa 2 que NO existía en la Capa 1. "
                       f"Se trata de un elemento nuevo añadido al conjunto de datos.")
                diffs.append({
                    'geometry': geom2.centroid(),
                    'type': 'Geometría Nueva',
                    'description': msg,
                    'distance': None,
                    'capa_orig': 'Capa 2',
                    'fid_orig': feat2.id()
                })
        
        return diffs

    def _find_similar_geometry(self, feat1, geom1, layer2, index2):
        """Encontrar la geometria mas similar en la capa 2."""
        # Obtener candidatos del indice espacial
        candidates = index2.intersects(geom1.boundingBox())
        
        if not candidates:
            return None, 0.0
        
        best_match = None
        best_similarity = 0.0
        
        for fid in candidates:
            feat2 = layer2.getFeature(fid)
            geom2 = self.geo_utils.fix_geometry(feat2.geometry())
            
            # Calcular similitud basada en solapamiento y conteo de vertices
            similarity = self._calculate_similarity(geom1, geom2)
            
            if similarity > best_similarity and similarity > 0.7:  # Umbral del 70%
                best_similarity = similarity
                best_match = feat2
        
        return best_match, best_similarity

    def _calculate_similarity(self, geom1, geom2):
        """Calcular puntuacion de similitud entre dos geometrias (0.0 a 1.0)."""
        try:
            # Para poligonos, usar solapamiento de area
            if geom1.type() == QgsWkbTypes.PolygonGeometry:
                intersection = geom1.intersection(geom2)
                union = geom1.combine(geom2)
                
                if union.area() > 0:
                    return intersection.area() / union.area()
            
            # Para lineas, usar solapamiento de longitud y distancia al centroide
            elif geom1.type() == QgsWkbTypes.LineGeometry:
                centroid_dist = geom1.centroid().distance(geom2.centroid())
                max_dist = max(geom1.length(), geom2.length())
                
                if max_dist > 0:
                    return 1.0 - min(centroid_dist / max_dist, 1.0)
            
            return 0.0
        except:
            return 0.0

    def _compare_vertices(self, geom1, geom2, fid1, fid2):
        """Comparar vertices entre dos geometrias similares."""
        diffs = []
        
        vertices1 = self._extract_vertices(geom1)
        vertices2 = self._extract_vertices(geom2)
        
        # Rastrear vertices coincidentes
        matched_v2 = set()
        
        # Comprobar vertices de geom1
        for i, v1 in enumerate(vertices1):
            closest_v2, closest_idx, distance = self._find_closest_vertex(v1, vertices2)
            
            if distance <= self.tolerance:
                # Vertice coincide (dentro de tolerancia)
                matched_v2.add(closest_idx)
            elif distance <= self.tolerance * 10:
                # Vertice desplazado
                matched_v2.add(closest_idx)
                msg = (f"Vértice movido de su posición original. "
                       f"Estaba en ({v1.x():.2f}, {v1.y():.2f}) en la Capa 1 y ahora se encuentra en "
                       f"({closest_v2.x():.2f}, {closest_v2.y():.2f}) en la Capa 2. "
                       f"El desplazamiento es de {distance:.3f} metros.")
                diffs.append({
                    'geometry': QgsGeometry.fromPointXY(v1),
                    'type': 'Vértice Desplazado',
                    'description': msg,
                    'distance': distance,
                    'capa_orig': 'Ambas',
                    'fid_orig': fid1
                })
            else:
                # Vertice eliminado (sin coincidencia cercana)
                msg = (f"El vértice en la posición ({v1.x():.2f}, {v1.y():.2f}) de la Capa 1 NO existe en la Capa 2. "
                       f"Ha sido eliminado o la geometría ha sido simplificada en esta zona.")
                diffs.append({
                    'geometry': QgsGeometry.fromPointXY(v1),
                    'type': 'Vértice Eliminado',
                    'description': msg,
                    'distance': None,
                    'capa_orig': 'Capa 1',
                    'fid_orig': fid1
                })
        
        # Comprobar vertices anadidos en geom2
        for i, v2 in enumerate(vertices2):
            if i not in matched_v2:
                msg = (f"Se ha encontrado un nuevo vértice en la posición ({v2.x():.2f}, {v2.y():.2f}) de la Capa 2 "
                       f"que NO estaba presente en la Capa 1. Se ha añadido detalle a la geometría.")
                diffs.append({
                    'geometry': QgsGeometry.fromPointXY(v2),
                    'type': 'Vértice Añadido',
                    'description': msg,
                    'distance': None,
                    'capa_orig': 'Capa 2',
                    'fid_orig': fid2
                })
        
        return diffs

    def _extract_vertices(self, geometry):
        """Extraer todos los vertices de una geometria como una lista de QgsPointXY."""
        vertices = []
        
        if geometry.isMultipart():
            # Manejar geometrias multiparte
            if geometry.type() == QgsWkbTypes.PolygonGeometry:
                multipolygon = geometry.asMultiPolygon()
                for polygon in multipolygon:
                    for ring in polygon:
                        vertices.extend(ring)
            elif geometry.type() == QgsWkbTypes.LineGeometry:
                multiline = geometry.asMultiPolyline()
                for line in multiline:
                    vertices.extend(line)
        else:
            # Manejar geometrias de una sola parte
            if geometry.type() == QgsWkbTypes.PolygonGeometry:
                polygon = geometry.asPolygon()
                for ring in polygon:
                    vertices.extend(ring)
            elif geometry.type() == QgsWkbTypes.LineGeometry:
                line = geometry.asPolyline()
                vertices.extend(line)
        
        return vertices

    def _find_closest_vertex(self, point, vertices):
        """Encontrar el vertice mas cercano a un punto dado."""
        if not vertices:
            return None, -1, float('inf')
        
        min_distance = float('inf')
        closest_vertex = None
        closest_idx = -1
        
        for i, vertex in enumerate(vertices):
            distance = math.sqrt((point.x() - vertex.x())**2 + (point.y() - vertex.y())**2)
            if distance < min_distance:
                min_distance = distance
                closest_vertex = vertex
                closest_idx = i
        
        return closest_vertex, closest_idx, min_distance

    def _check_geometric_difference(self, geom1, geom2, fid1, fid2):
        """
        Calcula la diferencia simetrica para detectar cambios topologicos (huecos, expansiones).
        """
        diffs = []
        
        # Solo tiene sentido si son del mismo tipo (o compatibles area-area)
        if geom1.type() != geom2.type():
            return []
            
        try:
            # Diferencia Simetrica (A XOR B) = partes que NO coinciden
            # Implementacion manual compatible: (A - B) U (B - A)
            diff1 = geom1.difference(geom2)
            diff2 = geom2.difference(geom1)
            sym_diff = diff1.combine(diff2)
            
            if sym_diff and not sym_diff.isEmpty() and sym_diff.area() > (self.tolerance * self.tolerance): # Tolerancia cuadrada para area
                msg = (f"Diferencia geométrica detectada (área: {sym_diff.area():.4f} m²). "
                       f"Puede indicar huecos rellenados, expansiones o recortes.")
                
                # Separar en partes si es multiparte para reportar mejor?
                # Por simplicidad, reportamos la geometria completa de la diferencia
                diffs.append({
                    'geometry': sym_diff,
                    'type': 'Diferencia Geométrica',
                    'description': msg,
                    'distance': math.sqrt(sym_diff.area()), # Usar raiz del area como 'distancia' aprox
                    'capa_orig': 'Ambas',
                    'fid_orig': fid1
                })
        except Exception as e:
            self.logger.log(f"Error al calcular diferencia geométrica: {e}")
            
        return diffs
