import os
import shutil
from qgis.core import QgsProject, QgsVectorLayer, QgsField, QgsWkbTypes, QgsGeometry, QgsFeature
from qgis.PyQt.QtCore import QVariant

class LayerManager:
    def __init__(self, logger):
        self.logger = logger
        self.temp_dir = None
        self.created_layers = []

    def create_temp_dir(self, base_path):
        i = 1
        while True:
            dir_name = f"temp{i:03d}"
            full_path = os.path.join(base_path, dir_name)
            if not os.path.exists(full_path):
                os.makedirs(full_path)
                self.temp_dir = full_path
                self.logger.log(f"Directorio temporal creado: {full_path}")
                return full_path
            i += 1

    def load_layer(self, path, name, add_to_registry=True):
        layer = QgsVectorLayer(path, name, "ogr")
        if not layer.isValid():
            self.logger.log(f"Error al cargar la capa: {path}")
            return None
        if add_to_registry:
            QgsProject.instance().addMapLayer(layer)
            self.created_layers.append(layer.id())
        return layer

    def create_memory_layer(self, name, geometry_type, fields=None, crs=None, add_to_registry=True):
        # geometry_type: "Point", "LineString", "Polygon"
        uri = f"{geometry_type}?crs={crs.authid()}" if crs else f"{geometry_type}"
        layer = QgsVectorLayer(uri, name, "memory")
        if fields:
            layer.dataProvider().addAttributes(fields)
            layer.updateFields()
        
        if not layer.isValid():
            self.logger.log(f"Error al crear capa en memoria: {name}")
            return None
            
        if add_to_registry:
            QgsProject.instance().addMapLayer(layer)
            self.created_layers.append(layer.id())
        return layer

    def save_layer_to_file(self, layer, filename):
        if not self.temp_dir:
            self.logger.log("No hay directorio temporal definido.")
            return None
            
        path = os.path.join(self.temp_dir, filename)
        
        from qgis.core import QgsVectorFileWriter
        
        # Intentar API moderna primero (QGIS 3.20+)
        if hasattr(QgsVectorFileWriter, 'writeAsVectorFormatV3'):
            options = QgsVectorFileWriter.SaveVectorOptions()
            options.driverName = "ESRI Shapefile"
            
            res = QgsVectorFileWriter.writeAsVectorFormatV3(
                layer,
                path,
                QgsProject.instance().transformContext(),
                options
            )
            
            # Manejar valores de retorno variables (2, 3 o 4 dependiendo de la version de QGIS)
            if len(res) >= 2:
                error, error_msg = res[0], res[1]
            else:
                error, error_msg = res[0], ""
        else:
            # Usar API heredada (QGIS 3.0-3.16)
            error = QgsVectorFileWriter.writeAsVectorFormat(
                layer,
                path,
                "UTF-8",
                layer.crs(),
                "ESRI Shapefile"
            )
            error_msg = ""
        
        if error != QgsVectorFileWriter.NoError:
            self.logger.log(f"Error al guardar capa {filename}: {error_msg}")
            return None
            
        self.logger.log(f"Capa guardada: {path}")
        return path

    def cleanup(self, keep_inputs=[]):
        # 1. Identificar capas rastreadas para eliminar
        to_remove = set([lid for lid in self.created_layers if lid not in keep_inputs])
        
        # 2. Búsqueda robusta por nombre (para casos donde se perdió el rastreo o reinicio)
        # Nombres generados por el plugin (actuales y enteriores)
        target_names = {
            "LOG", "DIFERENCIAS", 
            "LOG.shp", "DIFERENCIAS.shp",
            "LOG_Diferencias", "RESULTADO_Diferencias",
            "LOG_Diferencias.shp", "RESULTADO_Diferencias.shp"
        }
        
        for layer in QgsProject.instance().mapLayers().values():
            if layer.id() not in keep_inputs:
                if layer.name() in target_names:
                    to_remove.add(layer.id())

        # 3. Eliminar
        if to_remove:
            # Convertir a lista para la API de QGIS
            remove_list = list(to_remove)
            QgsProject.instance().removeMapLayers(remove_list)
            
            # Actualizar rastreo interno
            self.created_layers = [lid for lid in self.created_layers if lid not in to_remove]
            
        self.logger.log(f"Limpieza realizada. {len(to_remove)} capas eliminadas.")

    def convert_polygon_layer_to_line_layer(self, layer, add_to_registry=True):
        if layer.geometryType() != QgsWkbTypes.PolygonGeometry:
            return None
            
        crs = layer.crs()
        line_layer = self.create_memory_layer(f"{layer.name()}_lines", "LineString", layer.fields(), crs, add_to_registry=add_to_registry)
        
        line_layer.startEditing()
        for feat in layer.getFeatures():
            geom = feat.geometry()
            if geom.isMultipart():
                lines = geom.asMultiPolygon()
                for poly in lines:
                    for ring in poly:
                        new_geom = QgsGeometry.fromPolylineXY(ring)
                        new_feat = QgsFeature(feat)
                        new_feat.setGeometry(new_geom)
                        line_layer.addFeature(new_feat)
            else:
                poly = geom.asPolygon()
                for ring in poly:
                    new_geom = QgsGeometry.fromPolylineXY(ring)
                    new_feat = QgsFeature(feat)
                    new_feat.setGeometry(new_geom)
                    line_layer.addFeature(new_feat)
                    
        line_layer.commitChanges()
        return line_layer
