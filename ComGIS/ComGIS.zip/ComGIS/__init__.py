def classFactory(iface):
    from .comgis_plugin import ComGISPlugin
    return ComGISPlugin(iface)
