# ComGIS - Plugin de Comparación de Shapes para QGIS

![QGIS Version](https://img.shields.io/badge/QGIS-3.0%2B-589632.svg?style=flat&logo=qgis)
![License](https://img.shields.io/badge/License-GPL%20v3-blue.svg)
![Version](https://img.shields.io/badge/Version-1.0.0-succes)

Este proyecto implementa un plugin para QGIS diseñado para comparar dos capas vectoriales (Shapefiles), identificar sus diferencias geométricas y generar reportes detallados.

## 🎯 Objetivo
El objetivo principal es detectar cambios entre dos versiones de una capa (por ejemplo, modificaciones en parcelas o trazados). El plugin es capaz de:
1.  Comparar **Líneas**: Detecta geometrías que no coinciden espacialmente.
2.  Comparar **Polígonos**: Primero compara las geometrías poligonales. Si son polígonos, realiza una **segunda pasada** convirtiéndolos a líneas para detectar cambios sutiles en los bordes.
3.  Generar **Reportes**: Crea un archivo `Diferencias.html` profesional y capas visuales en QGIS.

## 📂 Estructura del Proyecto

El proyecto está diseñado de forma modular ("atomizada") para facilitar el mantenimiento y la detección de errores.

```text
ComGIS/
├── __init__.py             # Punto de entrada del plugin para QGIS
├── comgis_plugin.py        # Clase principal, inicializa el DockWidget
├── metadata.txt            # Metadatos del plugin (versión, autor, etc.)
├── icon.png                # Icono del plugin
├── ui/                     # Interfaz Gráfica
│   ├── __init__.py
│   ├── dock_widget.ui      # Archivo de Qt Designer (XML)
│   └── dock_widget.py      # Lógica de la UI (conecta señales y slots)
└── core/                   # Lógica del Negocio (Atomizada)
    ├── __init__.py
    ├── controller.py       # ORQUESTADOR: Maneja hilos y flujo principal
    ├── comparator.py       # ALGORITMO: Lógica de comparación espacial
    ├── geometry_utils.py   # UTILIDADES: Corrección y conversión de geometrías
    ├── layer_manager.py    # GESTIÓN: Carga, guarda y limpia capas/archivos
    ├── html_generator.py   # REPORTE: Genera el HTML/CSS
    └── logger.py           # LOGGING: Sistema de mensajes a la UI
```

## ⚙️ Funcionamiento Interno

### 1. Orquestación (`core/controller.py`)
El controlador es el cerebro. Se ejecuta en un **hilo secundario (QThread)** para no congelar la interfaz de QGIS (permitiendo que la etiqueta "TRABAJANDO..." se muestre).
-   Recibe las dos capas seleccionadas.
-   Crea un directorio temporal `tempXXX` (correlativo) en la ubicación de los shapes.
-   Coordina a los demás módulos.

### 2. Gestión de Capas (`core/layer_manager.py`)
-   **Directorios Temporales**: Crea carpetas `temp001`, `temp002`, etc. para guardar los resultados de cada ejecución.
-   **Capas en Memoria**: Crea capas temporales para procesar datos sin escribir en disco constantemente.
-   **Conversión**: Incluye la función `convert_polygon_layer_to_line_layer` que explota polígonos en sus anillos (exterior e interiores) para convertirlos en líneas.

### 3. Comparación (`core/comparator.py`)
-   **Corrección**: Antes de comparar, usa `geometry_utils.py` para intentar arreglar geometrías inválidas (`makeValid`, `buffer(0)`).
-   **Índices Espaciales**: Usa `QgsSpatialIndex` para optimizar la búsqueda de candidatos y no hacer un "todos contra todos" (O(N^2)).
-   **Lógica**:
    -   Busca cada geometría de la Capa A en la Capa B.
    -   Si no encuentra una geometría **idéntica**, marca una diferencia.
    -   Repite el proceso a la inversa (B en A).
    -   **Polígonos**: Si las capas son polígonos, realiza la comparación estándar Y ADEMÁS las convierte a líneas para comparar sus contornos.

### 4. Reportes (`core/html_generator.py`)
-   Genera un HTML con CSS incrustado.
-   **Diseño**:
    -   **Pantalla**: Contenedor centrado, sombras, estilo moderno.
    -   **Impresión (A4)**: Estilos `@media print` para ocultar elementos innecesarios y ajustar tamaños de fuente.

## 🚀 Uso del Plugin

1.  **Cargar Capas**: Abra los dos shapefiles en QGIS.
2.  **Abrir Panel**: El plugin se muestra como un panel acoplable (DockWidget) a la derecha.
3.  **Seleccionar**: Elija la "Capa 1 (Referencia)" y la "Capa 2 (Comparar)".
4.  **Comparar**: Pulse el botón verde **Comparar**.
    -   Se generará una capa de **Puntos** (`LOG`) indicando dónde hay cambios.
    -   Se generará una capa de **Geometrías** (`DIFERENCIAS`) con las formas que difieren (solo si existen).
    -   Se abrirá (o creará) el reporte HTML en la carpeta temporal.
5.  **Reiniciar**: El botón **Reiniciar** (rojo suave) limpia el formulario y el log.
6.  **Ayuda**: El botón **?** abre el manual de usuario en su navegador.


---

## 📦 Instalación

1. Descarga el código como ZIP.
2. En QGIS, ve a **Complementos** > **Administrar e instalar complementos** > **Instalar a partir de ZIP**.
3. Selecciona el archivo descargado.

## 🤝 Contribución

Las contribuciones son bienvenidas. Por favor, abre un Issue o envía un Pull Request en GitHub.

## 📄 Licencia

Este proyecto está licenciado bajo la **GPL-3.0**. Consulta el archivo [LICENSE](LICENSE) para más detalles.

