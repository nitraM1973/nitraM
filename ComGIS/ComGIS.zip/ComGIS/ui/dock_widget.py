import os
from qgis.PyQt import uic
from qgis.PyQt.QtWidgets import QDockWidget, QMessageBox
from qgis.core import QgsProject, QgsMapLayer

FORM_CLASS, _ = uic.loadUiType(os.path.join(os.path.dirname(__file__), 'dock_widget.ui'))

from ..core.controller import Controller
from ..core.logger import Logger

class ComGISDockWidget(QDockWidget, FORM_CLASS):
    def __init__(self, iface, parent=None):
        super(ComGISDockWidget, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface
        
        # Configurar Logger
        self.logger = Logger()
        self.logger.log_signal.connect(self.log)
        
        # Configurar Controlador
        self.controller = Controller(self.logger)
        
        # Conectar senales
        self.btnRun.clicked.connect(self.run_comparison)
        self.btnReset.clicked.connect(self.reset_plugin)
        self.btnHelp.clicked.connect(self.open_help)
        self.cmbLayer1.currentIndexChanged.connect(self.validate_selection)
        self.cmbLayer2.currentIndexChanged.connect(self.validate_selection)
        
        # Inicializar
        self.populate_layers()
        QgsProject.instance().layersAdded.connect(self.populate_layers)
        QgsProject.instance().layersRemoved.connect(self.populate_layers)
        
        self.lblWorking.setVisible(False)

    def populate_layers(self):
        # Guardar seleccion actual
        current_l1_id = self.cmbLayer1.currentData().id() if self.cmbLayer1.currentData() else None
        current_l2_id = self.cmbLayer2.currentData().id() if self.cmbLayer2.currentData() else None

        self.cmbLayer1.blockSignals(True)
        self.cmbLayer2.blockSignals(True)
        self.cmbLayer1.clear()
        self.cmbLayer2.clear()
        
        excluded_names = ["LOG", "DIFERENCIAS", "LOG.shp", "DIFERENCIAS.shp", "LOG_Diferencias", "RESULTADO_Diferencias"]
        
        layers = QgsProject.instance().mapLayers().values()
        for layer in layers:
            if layer.type() == QgsMapLayer.VectorLayer:
                # Filtrar capas de salida del plugin para no ensuciar la lista
                is_excluded = False
                for ex in excluded_names:
                    if ex in layer.name():
                        is_excluded = True
                        break
                
                if not is_excluded:
                    self.cmbLayer1.addItem(layer.name(), layer)
                    self.cmbLayer2.addItem(layer.name(), layer)
        
        # Restaurar seleccion
        if current_l1_id:
            idx = self.cmbLayer1.findData(current_l1_id)
            if idx != -1: 
                self.cmbLayer1.setCurrentIndex(idx)
            else:
                self.cmbLayer1.setCurrentIndex(-1) # Si la capa se borro, dejar vacio
        else:
             self.cmbLayer1.setCurrentIndex(-1)
            
        if current_l2_id:
            idx = self.cmbLayer2.findData(current_l2_id)
            if idx != -1: 
                self.cmbLayer2.setCurrentIndex(idx)
            else:
                self.cmbLayer2.setCurrentIndex(-1)
        else:
             self.cmbLayer2.setCurrentIndex(-1)

        self.cmbLayer1.blockSignals(False)
        self.cmbLayer2.blockSignals(False)

    def validate_selection(self):
        # Validacion basica para habilitar/deshabilitar el boton de ejecutar
        pass

    def run_comparison(self):
        layer1 = self.cmbLayer1.currentData()
        layer2 = self.cmbLayer2.currentData()
        
        if not layer1 or not layer2:
            self.log("Error: Seleccione dos capas válidas.")
            return
            
        if layer1 == layer2:
            self.log("Error: Las capas deben ser diferentes.")
            return

        self.log("Iniciando comparación...")
        self.set_working(True)
        
        self.controller.start_comparison(layer1, layer2, self.on_process_finished)

    def on_process_finished(self):
        self.set_working(False)

    def reset_plugin(self):
        self.log("Reiniciando plugin...")
        
        # Mantener entradas
        keep = []
        l1 = self.cmbLayer1.currentData()
        l2 = self.cmbLayer2.currentData()
        if l1: keep.append(l1.id())
        if l2: keep.append(l2.id())
        
        self.controller.reset(keep)
        self.populate_layers() # Forzar refresco al reiniciar
        self.txtLog.clear()
        self.log("Plugin reiniciado.")

    def set_working(self, working):
        self.lblWorking.setVisible(working)
        self.btnRun.setEnabled(not working)
        self.btnReset.setEnabled(not working)
        self.cmbLayer1.setEnabled(not working)
        self.cmbLayer2.setEnabled(not working)
        self.repaint()

    def log(self, message):
        self.txtLog.append(message)

    def open_help(self):
        import webbrowser
        
        # Asumimos que ayuda.html esta en la raiz del plugin (un nivel arriba de ui/)
        html_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'ayuda.html')
        
        if os.path.exists(html_path):
            webbrowser.open(f'file:///{html_path}')
        else:
            self.log(f"Error: No se encuentra el archivo de ayuda en {html_path}")
            # Intentar buscar en la carpeta actual por si acaso
            html_path_local = os.path.join(os.path.dirname(__file__), 'ayuda.html')
            if os.path.exists(html_path_local):
                webbrowser.open(f'file:///{html_path_local}')
