
def classFactory(iface):
    from .plugin_main import InfCOPPlugin
    return InfCOPPlugin(iface)
