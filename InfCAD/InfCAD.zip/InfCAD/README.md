# InfCAD - QGIS Plugin

**Versión:** 1.0  
**Autor:** José Martín Vázquez Morandeira (nitraM)  
**Descripción:** Herramientas de procesamiento para proyectos InfCOP. Limpieza, integración de edificaciones, conversión a líneas y gestión de atributos LAYER para exportación a CAD.

---

## 📋 Descripción General

Este plugin automatiza el flujo de trabajo para transformar shapefiles de parcelas (`ZONACON`, `ZONACON_PARCELAS`) y edificaciones (`EDIFICACIONES`) en un conjunto de líneas limpias, clasificadas y listas para su uso en software CAD (como ZWCAD).

El plugin es **totalmente autónomo** y no requiere librerías externas de Python, utilizando únicamente la API de QGIS (`qgis.core`, `qgis.gui`) y librerías estándar.

---

## 📂 Estructura del Proyecto

```
InfCAD/
├── core/                   # Lógica de negocio y procesamiento
│   ├── controller.py       # Controlador principal: gestiona el hilo de trabajo (Worker) y el flujo de pasos
│   ├── loader.py           # Escaneo y carga de shapefiles de entrada
│   ├── geometry_fixer.py   # Reparación de geometrías (native:fixgeometries)
│   ├── merger.py           # Fusión de capas y asignación de CODELEM='K' para edificaciones
│   ├── converter.py        # Conversión de Polígonos a Líneas y Explode
│   ├── deduplicator.py     # Lógica crítica: eliminación de duplicados y cálculo de prioridad LAYER
│   ├── line_dissolve.py    # Fusión final de líneas contiguas por atributo LAYER
│   └── utils.py            # Utilidades (gestión de carpetas temporales TempXXX)
├── gui/                    # Interfaz de Usuario
│   ├── dock_widget.py      # Lógica de la ventana acoplable (DockWidget)
│   └── dock_widget.ui      # Diseño visual (Qt Designer)
├── icon.svg                # Icono vectorial oficial (Rojo -> Verde -> Azul)
├── icon.png                # Icono raster (legacy/compatibilidad)
├── metadata.txt            # Metadatos de instalación de QGIS
├── plugin_main.py          # Punto de entrada: inicialización de menús y toolbars
└── README.md               # Esta documentación
```

---

## ⚙️ Flujo de Trabajo Detallado

El proceso se ejecuta de forma independiente para las capas `ZONACON` y `ZONACON_PARCELAS`. Si existe `EDIFICACIONES`, se integra en el proceso.

### 1. Entrada de Datos
- **Selección**: El usuario selecciona una carpeta.
- **Escaneo**: El plugin busca automáticamente `ZONACON.shp`, `ZONACON_PARCELAS.shp` y `EDIFICACIONES.shp`.
- **UI**: Se muestra una lista con los archivos encontrados.

### 2. Procesamiento (Paso a Paso)

Cada paso genera una nueva capa, la carga en el proyecto y oculta la anterior para mantener el área de trabajo limpia.

#### Paso 0: Corrección de Geometrías
- **Acción**: Aplica `native:fixgeometries` a la capa principal.
- **Salida**: `{CAPA}_fixed.shp`
- **Visibilidad**: Oculta la capa original.

#### Paso 1 & 2: Integración de Edificaciones (Si existe)
- **Acción**:
    1. Corrige geometrías de `EDIFICACIONES` -> `EDIFICACIONES_fixed.shp`.
    2. Asigna atributo `CODELEM = 'K'` a todas las edificaciones.
    3. Fusiona la capa principal corregida con las edificaciones corregidas.
- **Salida**: `{CAPA}_merged.shp`
- **Visibilidad**: Oculta `_fixed` y `EDIFICACIONES_fixed`.

#### Paso 2b: Validación Topológica (¡NUEVO!)
- **Objetivo**: Detectar errores de calidad en los datos fusionados antes de continuar.
- **Acciones**:
    1. **Detección de Gaps (Huecos)**: Identifica espacios vacíos entre polígonos (usando diferencia con Bounding Box).
    2. **Detección de Overlaps (Solapes)**: Identifica áreas donde dos polígonos se superponen.
- **Comportamiento**:
    - **No Bloqueante**: El proceso **continúa** aunque encuentre errores, garantizando que siempre se obtenga un resultado final.
    - **Registro Inmediato**: Si se detectan errores, se generan capas de puntos (`LOG_FINCAS.shp` o `LOG_PARCELAS.shp`) al instante.
    - **Precisión**: Los puntos de error se ubican **exactamente dentro** del hueco o solape (`pointOnSurface`), facilitando su localización.
- **Salida**: Capas `LOG_{TIPO}.shp` (solo si hay errores).

#### Paso 3: Conversión a Líneas
- **Acción**: Convierte polígonos a líneas (`native:polygonstolines`) y explota las líneas (`native:explodelines`) para tener segmentos individuales.
- **Salida**: `{CAPA}_lines.shp`
- **Visibilidad**: Oculta `_merged`.

#### Paso 4: Deduplicación y Lógica LAYER (OPTIMIZADO)
- **Acción**: Elimina líneas duplicadas geométricamente (tolerancia Hausdorff 0.025) y calcula el campo `LAYER` basado en la prioridad de los atributos `CODELEM`.
- **Mejora**: Implementación de **Índice Espacial (Spatial Index)** para acelerar el proceso en capas grandes.
- **Lógica de Prioridad**:
    - **Con Edificaciones**: `K` (Edif) > `V` (Vía) > `H` (Hidro) > `E` (Excluido) > `P`/`F` (Parcela).
    - **Sin Edificaciones**: `K` > `E` > `V` > `H` > `P`/`F`.
- **Salida**: `{CAPA}_deduplicated.shp`
- **Visibilidad**: Oculta `_lines`.

#### Paso 5: Fusión Final (Dissolve)
- **Acción**: Fusiona líneas **contiguas** que tengan el mismo valor de `LAYER` y mismo atributo `CODELEM`.
- **Salida**: `{CAPA}_final.shp` (Ej: `ZONACON_final`)
- **Estilo**: Aplica simbología categorizada por colores (K=Rojo, V=Gris, H=Azul, etc.).
- **Visibilidad**: Oculta `_deduplicated`. **Esta es la única capa que queda visible al final.**

### Requisitos
- QGIS 3.x (Probado en 3.13+)
- Python 3
- Sin dependencias externas

### Instalación
Copiar la carpeta `InfCAD` completa al directorio de plugins de QGIS.
**Nota:** El nombre de la carpeta de instalación no afecta al funcionamiento, gracias a la reciente actualización de portabilidad, pero se recomienda mantener `InfCAD` o similar.

- **Windows**: `%APPDATA%\QGIS\QGIS3\profiles\default\python\plugins\`
- **Linux**: `~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/`
- **macOS**: `~/Library/Application Support/QGIS/QGIS3/profiles/default/python/plugins/`

Luego, en QGIS:
1. Ir a `Complementos > Administrar e instalar complementos`
2. Pestaña "Instalados"
3. Activar "InfCAD"

---

## 🐛 Solución de Problemas

### Error: "No se pudo escribir el objeto en OUTPUT"
- **Causa**: Versiones antiguas del plugin usaban `processing.run` que tenía problemas con rutas de Windows.
- **Solución**: Actualizar a la versión más reciente (0.1+) que usa fusión manual.

### Las capas no se cargan
- **Verificar**: Que los archivos se llamen exactamente `ZONACON.shp`, `ZONACON_PARCELAS.shp` o `EDIFICACIONES.shp`.
- **Verificar**: Que los shapefiles estén completos (`.shp`, `.shx`, `.dbf`, `.prj`).

### El plugin no aparece en el menú
- **Verificar**: Que la carpeta se llame `InfCAD` (no `InfCAD-main` ni otro nombre).
- **Reiniciar**: QGIS después de copiar el plugin.

---

## 📝 Notas de Desarrollo

### Flujo de Datos
```
Input Shapefiles
    ↓
Loader (scan + load)
    ↓
GeometryFixer (native:fixgeometries)
    ↓
LayerMerger (manual merge con QgsVectorFileWriter)
    ↓
LayerConverter (polygons to lines + explode)
    ↓
LineDeduplicator (Hausdorff + priority logic)
    ↓
LineDissolve (dissolve by LAYER)
    ↓
Output: {CAPA}_final.shp
```

### Campos Clave
- **CODELEM**: Código de elemento original (V, H, E, P, F, K).
- **LAYER**: Campo calculado basado en prioridad, usado para simbología CAD.

---

## 📄 Licencia

Este plugin ha sido desarrollado por **José Martín Vázquez Morandeira** para facilitar el procesamiento de datos InfCOP en entornos QGIS/CAD.

---

## 🤝 Contacto y Soporte

Para reportar errores o solicitar mejoras, contactar al autor.
