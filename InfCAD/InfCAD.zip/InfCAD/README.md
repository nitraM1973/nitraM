# InfCAD - QGIS Plugin

**Versión:** 2.3  
**Autor:** José Martín Vázquez Morandeira (nitraM)  
**Descripción:** Herramientas de procesamiento para proyectos InfCOP. Limpieza, integración de edificaciones, conversión a líneas y gestión de atributos LAYER para exportación a CAD.

---

## 🆕 Versión 2.3 (octubre 2026)

- **Distinción edificación / finca excluida en los recintos E** (`core/classify.py`): los E que caen en EDIFICACIONES son 9100 (seguro). Los demás se puntúan por su **forma** (área, rectangularidad respecto al rectángulo orientado mínimo, nº de vértices simplificados, huecos, elongación). Puntuación alta → 9100, baja → 9200, intermedia → **dudosa**. Sin EDIFICACIONES ya no toda `E` es 9100: decide la forma. Con EDIFICACIONES, una E fuera de ellas sigue siendo 9200, pero si su forma parece edificación se marca como dudosa.
- **Nueva pestaña «Revisión E»**: lista los recintos E con sus métricas, la puntuación y el motivo. Marcar/desmarcar «Edificación (9100)» cambia el MiID a 9100/9200; al pulsar «Aplicar cambios» se escribe en `ZONACON_MiID.shp` y `ZONACON_merged.shp`. Al hacer clic en una fila el mapa hace zoom al recinto y lo parpadea. Filtros: solo dudosos / incluir los confirmados por EDIFICACIONES.
- Los umbrales son constantes al principio de `core/classify.py` (están sin calibrar con datos reales; ajústalos tras revisar unas cuantas hojas).
- Los cambios manuales solo afectan al campo MiID; las líneas y el DXF (campo LAYER) no cambian.
- **Edificaciones adosadas** (casilla «Unir edificaciones adosadas», activada por defecto): los recintos con MiID 9100 que comparten pared (≥ `ADOSADO_SHARED_MIN` = 0,30 m; no basta un vértice en común) **y forman una isla dentro de un recinto más grande** (un único recinto los rodea por completo —hueco con su forma o contenedor— y ningún otro toca su contorno; `ISLA_TOL`, `ISLA_COVER`) se unen en **un único recinto por conjunto** en `{ZONA}_adosados.shp`, con un solo `X`, `Y` (punto sobre la superficie de la unión) y `MiID = 9100`. El **contorno exterior** sigue el criterio normal (LAYER `K`, o `E` en modo solo ZONACON) y las **paredes interiores** que dividen los adosados se envían a la capa auxiliar `Aux_` + la de origen (`Aux_K`, `Aux_E`), que en QGIS y DXF se pinta con el color de su capa de origen. Así las topologías se generan con un solo contorno por conjunto. Las líneas se generan a partir de `{ZONA}_adosados.shp` cuando hay conjuntos. Los conjuntos adosados que no son isla se dejan sin tocar. Los demás campos del recinto unido se toman de la primera edificación del conjunto.
- **Contactos puntuales isla/contenedor** (casilla «Detectar contactos de isla»): busca recintos que son isla de otro (dentro de su hueco o contenidos en él) y se apoyan por un solo vértice —un contacto a lo largo de un tramo no cuenta—. Genera la capa de puntos `{ZONA}_contactos` (solo si hay) con `TIPO` = `V=V` (vértice de la isla coincide con un vértice del contenedor), `V/A` (vértice de la isla sobre una arista del contenedor) o `A/V` (vértice del contenedor sobre una arista de la isla), más `ISLA` y `CONTENEDOR` (MiID), X e Y. Tolerancia: `TOLERANCE` (2,5 cm); pared compartida mínima: `ADOSADO_SHARED_MIN`.
- **Cierres de V/H** (casilla «Cerrar envolventes V/H (Aux_Cierres)», activada por defecto; requiere el campo TIPO): corta los viales (9000) y ríos (9300) para que ningún ramal quede envolviendo masas de recintos. (1) **Bocas de ramales**: en cada entronque une con una línea las dos esquinas entrantes de la boca del ramal (en una T se cierra el ramal contra el vial principal; en una X, los cuatro brazos). Criterio: pares de esquinas mutuamente más próximas (≤ `CIERRE_ANCHO_MAX` = 50 m) cuyo segmento va por dentro del vial; con esquinas redondeadas se queda el cierre más corto. Para no cortar tramos sin entronque, en cada esquina de la boca deben cruzarse dos bordes largos: uno que sigue recto en la dirección del cierre (el vial principal, `CIERRE_ALINEA` = 30°) y otro transversal (el ramal, `CIERRE_TRANSV`), de al menos `CIERRE_TRAMO` = 5 m; así los escalones y quiebros del contorno no generan cierres. (1b) **Esquinas sueltas**: las esquinas entrantes que se quedan sin pareja (la punta de una isla triangular en una Y, una horquilla) también se cierran: la punta de isla (cuña ≤ 80°, `CIERRE_SUELTA_*`) lanza una línea perpendicular al eje del brazo a ambos lados hasta el borde opuesto (≤ `CIERRE_ANCHO_MAX`), así todos los brazos de la Y quedan cerrados y no solo uno; una esquina en T sin pareja solo se cierra si enfrente hay un vértice (si no, es el vial principal, que no se corta). En una punta con cierre a ambos lados, si un lado mide más del doble que el otro (un vial estrecho frente a una banda ancha) solo se cierra el estrecho (`CIERRE_ESTRECHO`); los cierres de punta salen del vértice más adelantado del redondeo, y un cierre suelto que repite uno ya existente en el mismo brazo se descarta (`CIERRE_DUP_SUELTA`). Si dos cierres comparten una esquina y forman menos de 60° entre sí (`CIERRE_SLIVER_*`), cierran la misma boca y solo se conserva el más corto. (2) **Huecos aislados**: si un hueco con recintos dentro sigue sin conectar con el exterior (p. ej. una calle que rodea una sola manzana), se une al exterior con la conexión más corta. Todas las líneas van a `Aux_Cierres`, son vértice a vértice (salvo el extremo de un cierre de punta de isla, que puede acabar sobre el borde opuesto sin crear vértice nuevo en él). Además, V y H ya no cuentan como «recinto mayor» al buscar contactos de isla ni al unir adosados (`IGNORAR_CONTENEDOR_VH`).
- Los conjuntos se calculan con el MiID **automático** en el momento de procesar: lo que cambies después en «Revisión E» no regenera adosados ni líneas.

---

## Versión 2.2 (anterior) (octubre 2026)

- **Qué procesar** (panel): `ZONACON + EDIFICACIONES` o `Solo ZONACON`. Si no hay EDIFICACIONES en la carpeta se procesa solo ZONACON.
- **Campos de ZONACON para MiID**: desplegables FINCA y SUBFINCA (solo enteros; se preseleccionan `FINCA` y `SUBFINCA`; SUBFINCA admite `(ninguno)`) y TIPO (cualquier campo; se preselecciona `TIPO`, o `CODELEM` si no existe; admite `(ninguno)`).
- **Campos nuevos X, Y, MiID** en los shapes de trabajo `ZONACON_MiID.shp` y `EDIFICACIONES_MiID.shp` (carpeta `TempXXX`; los originales no se tocan):
  - `X`, `Y` (Double): coordenadas de un *point on surface* de cada entidad.
  - `MiID` (texto), por orden de prioridad: TIPO `V` → `9000`; TIPO `H` → `9300`; TIPO `E` → `9100` si el recinto está en EDIFICACIONES (su punto sobre la superficie cae en una edificación) y `9200` si no lo está (en modo solo ZONACON, o si no hay EDIFICACIONES, toda `E` es `9100`); en cualquier otro caso, FINCA si SUBFINCA es 0 o vacío y `FINCA-SUBFINCA` si no. En EDIFICACIONES siempre `9100`.
  - Los recintos multiparte de ZONACON se dividen en una entidad por parte: todas llevan el mismo `MiID` y cada una calcula su propio `X`, `Y`. Para la regla de TIPO `E`, el recinto cuenta como «en EDIFICACIONES» si alguna de sus partes lo está.
  - Si el shape ya traía X, Y o MiID, se regeneran.
- **Capa fusionada** (modo con EDIFICACIONES): `ZONACON_merged.shp` junta ZONACON y EDIFICACIONES, cada entidad con su `MiID`, `X` e `Y`; las líneas se generan a partir de ella.
- **Sin edificaciones duplicadas**: antes de fusionar, las edificaciones que ya están en ZONACON como recinto `E` (solape de al menos el 90 % en ambos sentidos, constante `OVERLAP_RATIO` en `core/pipeline.py`) no se añaden otra vez; ese recinto pasa a `CODELEM = K` y `MiID = 9100`. Así no aparecen líneas casi coincidentes (microastillas) cuando las huellas difieren más que la tolerancia de 2,5 cm.
- **Al terminar**, se abre el explorador de archivos en la carpeta `TempXXX` de salida.
- **Fiabilidad**: todo el acceso a QgsProject / árbol de capas pasa al hilo principal; el hilo de trabajo solo procesa archivos. Un error ya no deja el hilo colgado.
- **Velocidad**: sin archivos intermedios (fixgeometries, merge, polygonstolines, explode se hacen en memoria; solo se repara lo inválido) y deduplicación por rejilla hash en lugar de comparar con GEOS cada candidato. Mismo resultado que antes.
- Estructura: `core/pipeline.py` sustituye a `geometry_fixer.py`, `merger.py`, `converter.py`, `deduplicator.py` y `line_dissolve.py`.

> Las secciones siguientes describen el flujo de la v1.0; la lógica de prioridad de LAYER y el DXF no han cambiado.

---

## 📋 Descripción General

Este plugin automatiza el flujo de trabajo para transformar shapefiles de parcelas (`ZONACON`, `ZONACON_PARCELAS`) y edificaciones (`EDIFICACIONES`) en un conjunto de líneas limpias, clasificadas y listas para su uso en software CAD (como ZWCAD).

El plugin es **totalmente autónomo** y no requiere librerías externas de Python, utilizando únicamente la API de QGIS (`qgis.core`, `qgis.gui`) y librerías estándar.

---

## 📂 Estructura del Proyecto

```
InfCAD/
├── core/                   # Lógica de negocio y procesamiento
│   ├── controller.py       # Controlador principal: gestiona el hilo de trabajo (Worker) y el flujo de pasos
│   ├── loader.py           # Escaneo y carga de shapefiles de entrada
│   ├── geometry_fixer.py   # Reparación de geometrías (native:fixgeometries)
│   ├── merger.py           # Fusión de capas y asignación de CODELEM='K' para edificaciones
│   ├── converter.py        # Conversión de Polígonos a Líneas y Explode
│   ├── deduplicator.py     # Lógica crítica: eliminación de duplicados y cálculo de prioridad LAYER
│   ├── line_dissolve.py    # Fusión final de líneas contiguas por atributo LAYER
│   └── utils.py            # Utilidades (gestión de carpetas temporales TempXXX)
├── gui/                    # Interfaz de Usuario
│   ├── dock_widget.py      # Lógica de la ventana acoplable (DockWidget)
│   └── dock_widget.ui      # Diseño visual (Qt Designer)
├── icon.svg                # Icono vectorial oficial (Rojo -> Verde -> Azul)
├── icon.png                # Icono raster (legacy/compatibilidad)
├── metadata.txt            # Metadatos de instalación de QGIS
├── plugin_main.py          # Punto de entrada: inicialización de menús y toolbars
└── README.md               # Esta documentación
```

---

## ⚙️ Flujo de Trabajo Detallado

El proceso se ejecuta de forma independiente para las capas `ZONACON` y `ZONACON_PARCELAS`. Si existe `EDIFICACIONES`, se integra en el proceso.

### 1. Entrada de Datos
- **Selección**: El usuario selecciona una carpeta.
- **Escaneo**: El plugin busca automáticamente `ZONACON.shp`, `ZONACON_PARCELAS.shp` y `EDIFICACIONES.shp`.
- **UI**: Se muestra una lista con los archivos encontrados.

### 2. Procesamiento (Paso a Paso)

Cada paso genera una nueva capa, la carga en el proyecto y oculta la anterior para mantener el área de trabajo limpia.

#### Paso 0: Corrección de Geometrías
- **Acción**: Aplica `native:fixgeometries` a la capa principal.
- **Salida**: `{CAPA}_fixed.shp`
- **Visibilidad**: Oculta la capa original.

#### Paso 1 & 2: Integración de Edificaciones (Si existe)
- **Acción**:
    1. Corrige geometrías de `EDIFICACIONES` -> `EDIFICACIONES_fixed.shp`.
    2. Asigna atributo `CODELEM = 'K'` a todas las edificaciones.
    3. Fusiona la capa principal corregida con las edificaciones corregidas.
- **Salida**: `{CAPA}_merged.shp`
- **Visibilidad**: Oculta `_fixed` y `EDIFICACIONES_fixed`.

#### Paso 3: Conversión a Líneas
- **Acción**: Convierte polígonos a líneas (`native:polygonstolines`) y explota las líneas (`native:explodelines`) para tener segmentos individuales.
- **Salida**: `{CAPA}_lines.shp`
- **Visibilidad**: Oculta `_merged`.

#### Paso 4: Deduplicación y Lógica LAYER (Crítico)
- **Acción**: Elimina líneas duplicadas geométricamente (tolerancia Hausdorff 0.025) y calcula el campo `LAYER` basado en la prioridad de los atributos `CODELEM` de las líneas superpuestas.
- **Lógica de Prioridad**:
    - **Con Edificaciones**: `K` (Edif) > `V` (Vía) > `H` (Hidro) > `E` (Excluido) > `P`/`F` (Parcela).
    - **Sin Edificaciones**: `K` > `E` > `V` > `H` > `P`/`F`.
- **Salida**: `{CAPA}_deduplicated.shp`
- **Visibilidad**: Oculta `_lines`.

#### Paso 5: Fusión Final (Dissolve)
- **Acción**: Fusiona líneas **contiguas** que tengan el mismo valor de `LAYER`.
- **Salida**: `{CAPA}_final.shp` (Ej: `ZONACON_final`)
- **Estilo**: Aplica simbología categorizada por colores (K=Rojo, V=Gris, H=Azul, etc.).
- **Visibilidad**: Oculta `_deduplicated`. **Esta es la única capa que queda visible al final.**

---

## 🖥️ Interfaz de Usuario (UI)

- **Ubicación**: Panel acoplable (DockWidget) a la derecha.
- **Acceso**:
    - Barra de Herramientas: Botón con icono SVG rediseñado. Se integra automáticamente en la barra **"ValCAD"** (la crea si no existe).
    - Menú: `Complementos > ValCAD`.
- **Componentes**:
    - Selector de Carpeta.
    - Lista de Archivos Encontrados (Feedback inmediato).
    - Botón "Procesar" (con icono) con indicador "TRABAJANDO..." alineado a la derecha.
    - Log de Registro: Expandido para ocupar todo el espacio vertical disponible.
    - Botón "?" (Ayuda): Abre el archivo de ayuda `ayuda_infcad.html` en el navegador.
    - Botón "Reiniciar": Elimina todas las capas del proyecto para empezar de cero.

---

## 🎨 Identidad Visual (Icono)

El icono (`icon.svg`) ha sido diseñado vectorialmente para representar la función del plugin:
- **Izquierda**: Polígono sólido rojo (Mundo GIS/InfCOP).
- **Derecha**: Representación alámbrica en líneas azules (Mundo CAD/ZWCAD).
- **Separador**: Línea diagonal verde ("Láser" de escaneo/transformación).
- **Uso**: Se usa el mismo archivo SVG para la ventana, el botón de la toolbar y el botón de la UI.

---

## 🛠️ Detalles Técnicos y Mantenimiento

### Correcciones Recientes (Diciembre 2024)
1.  **Icono Rediseñado y Optimizado (`icon.svg`)**:
    -   **Diseño**: Metáfora visual clara de "Hexágono Partido".
        -   **Izquierda (Rojo)**: Representa el estado inicial/conflictivo.
        -   **Derecha (Azul)**: Representa el estado limpio/CAD.
        -   **Separador (Verde)**: Línea láser diagonal que corta exactamente de esquina a esquina (0,24 a 24,0), maximizando el uso del espacio del botón.
    -   **Geometría**: Reconstrucción vectorial completa usando coordenadas explícitas para evitar problemas de renderizado en Qt (eliminación de `clipPath` y gradientes complejos). Tamaño ajustado al 90% para legibilidad óptima.
2.  **Integración en Entorno "ValCAD"**:
    -   **Toolbar**: El plugin busca activamente una barra de herramientas llamada "ValCAD". Si existe, se añade a ella; si no, la crea. Esto permite agrupar múltiples herramientas bajo una misma barra.
    -   **Menú**: Se instala bajo el submenú `Complementos > ValCAD`.
3.  **Portabilidad del Código**:
    -   Revisión completa de rutas e importaciones para garantizar que el plugin funcione desde cualquier directorio de instalación (uso de `os.path.dirname(__file__)` y cargas relativas).
4.  **Fix crítico en `merger.py`**:
    -   **Problema**: El uso de `processing.run("native:mergevectorlayers")` fallaba en Windows con el error "No se pudo escribir el objeto en OUTPUT".
    -   **Solución**: Reemplazado completamente por fusión manual usando `QgsVectorFileWriter`.
5.  **Asignación de CODELEM='K'**: Implementación directa para edificaciones.
6.  **Gestión de Rutas**: Normalización con `os.path.normpath`.

### Arquitectura Técnica
- **Sin dependencias externas**: El plugin usa exclusivamente la API de QGIS (`qgis.core`, `qgis.gui`).
- **Procesamiento asíncrono**: Uso de `QThread` y `Worker`.

### Requisitos
- QGIS 3.x (Probado en 3.13+)
- Python 3
- Sin dependencias externas

### Instalación
Copiar la carpeta `InfCAD` completa al directorio de plugins de QGIS.
**Nota:** El nombre de la carpeta de instalación no afecta al funcionamiento, gracias a la reciente actualización de portabilidad, pero se recomienda mantener `InfCAD` o similar.

- **Windows**: `%APPDATA%\QGIS\QGIS3\profiles\default\python\plugins\`
- **Linux**: `~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/`
- **macOS**: `~/Library/Application Support/QGIS/QGIS3/profiles/default/python/plugins/`

Luego, en QGIS:
1. Ir a `Complementos > Administrar e instalar complementos`
2. Pestaña "Instalados"
3. Activar "InfCAD"

---

## 🐛 Solución de Problemas

### Error: "No se pudo escribir el objeto en OUTPUT"
- **Causa**: Versiones antiguas del plugin usaban `processing.run` que tenía problemas con rutas de Windows.
- **Solución**: Actualizar a la versión más reciente (0.1+) que usa fusión manual.

### Las capas no se cargan
- **Verificar**: Que los archivos se llamen exactamente `ZONACON.shp`, `ZONACON_PARCELAS.shp` o `EDIFICACIONES.shp`.
- **Verificar**: Que los shapefiles estén completos (`.shp`, `.shx`, `.dbf`, `.prj`).

### El plugin no aparece en el menú
- **Verificar**: Que la carpeta se llame `InfCAD` (no `InfCAD-main` ni otro nombre).
- **Reiniciar**: QGIS después de copiar el plugin.

---

## 📝 Notas de Desarrollo

### Flujo de Datos
```
Input Shapefiles
    ↓
Loader (scan + load)
    ↓
GeometryFixer (native:fixgeometries)
    ↓
LayerMerger (manual merge con QgsVectorFileWriter)
    ↓
LayerConverter (polygons to lines + explode)
    ↓
LineDeduplicator (Hausdorff + priority logic)
    ↓
LineDissolve (dissolve by LAYER)
    ↓
Output: {CAPA}_final.shp
```

### Campos Clave
- **CODELEM**: Código de elemento original (V, H, E, P, F, K).
- **LAYER**: Campo calculado basado en prioridad, usado para simbología CAD.

---

## 📄 Licencia

Este plugin ha sido desarrollado por **José Martín Vázquez Morandeira** para facilitar el procesamiento de datos InfCOP en entornos QGIS/CAD.

---

## 🤝 Contacto y Soporte

Para reportar errores o solicitar mejoras, contactar al autor.
