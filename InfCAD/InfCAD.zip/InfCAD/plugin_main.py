
import os
import sys
from qgis.core import QgsProject
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import QAction, QDockWidget, QToolBar
from qgis.PyQt.QtGui import QIcon
from .gui.dock_widget import InfCOPDockWidgetWrapper
from .core.controller import InfCOPController

class InfCOPPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.dock_widget = None
        self.controller = None
        self.toolbar = None
        self.action = None
        self.toolbar_created = False

    def initGui(self):
        # Create dock widget and controller
        self.dock_widget = InfCOPDockWidgetWrapper(self.iface)
        self.controller = InfCOPController(self.dock_widget, self.iface)
        
        # Add dock widget (initially hidden)
        self.iface.addDockWidget(Qt.RightDockWidgetArea, self.dock_widget)
        self.dock_widget.hide()
        
        # Create toolbar action
        self._create_toolbar_action()
        
        # Set window icon for dock widget
        self.dock_widget.setWindowIcon(self.action.icon())
        
        # Add entry to Plugins menu
        self.iface.addPluginToMenu("&ValCAD", self.action)

    def _create_toolbar_action(self):
        """Create action and add to toolbar (ValGIS if exists, otherwise create InfCOP toolbar)"""
        # Create the action
        icon_path_svg = os.path.join(self.plugin_dir, 'icon.svg')
        icon_path_png = os.path.join(self.plugin_dir, 'icon.png')
        
        # Use SVG if exists, otherwise PNG, otherwise default
        if os.path.exists(icon_path_svg):
            icon = QIcon(icon_path_svg)
        elif os.path.exists(icon_path_png):
            icon = QIcon(icon_path_png)
        else:
            icon = QIcon()
        
        self.action = QAction(icon, "InfCOP Tools", self.iface.mainWindow())
        self.action.setObjectName("infcop_tools_action")
        self.action.setWhatsThis("Abrir panel de InfCOP Tools")
        self.action.setStatusTip("Procesamiento de shapefiles InfCOP")
        self.action.triggered.connect(self.toggle_dock_widget)
        
        # Try to find existing ValCAD toolbar
        valcad_toolbar = None
        for toolbar in self.iface.mainWindow().findChildren(QToolBar):
            if toolbar.objectName() == "ValCAD" or toolbar.windowTitle() == "ValCAD":
                valcad_toolbar = toolbar
                break
        
        if valcad_toolbar:
            # Add to existing ValCAD toolbar
            valcad_toolbar.addAction(self.action)
            self.toolbar = valcad_toolbar
            self.toolbar_created = False
        else:
            # Create new ValCAD toolbar
            self.toolbar = self.iface.addToolBar("ValCAD")
            self.toolbar.setObjectName("ValCAD")
            self.toolbar.addAction(self.action)
            self.toolbar_created = True
    
    def toggle_dock_widget(self):
        """Toggle visibility of dock widget"""
        if self.dock_widget.isVisible():
            self.dock_widget.hide()
        else:
            self.dock_widget.show()

    def unload(self):
        # Stop any running threads - wrap everything in try-except
        try:
            if self.controller and hasattr(self.controller, 'thread') and self.controller.thread:
                if self.controller.thread.isRunning():
                    self.controller.thread.quit()
                    self.controller.thread.wait()
        except (RuntimeError, AttributeError):
            # Thread already deleted or not accessible, ignore
            pass
            
        # Remove from Plugins menu
        try:
            if self.action:
                self.iface.removePluginMenu("&ValCAD", self.action)
        except:
            pass
        
        # Remove action from toolbar
        try:
            if self.action and self.toolbar:
                self.toolbar.removeAction(self.action)
                self.action.deleteLater()
                self.action = None
        except:
            pass
        
        # Remove toolbar only if we created it
        try:
            if self.toolbar and self.toolbar_created:
                self.iface.mainWindow().removeToolBar(self.toolbar)
                self.toolbar.deleteLater()
                self.toolbar = None
        except:
            pass
        
        # Remove dock widget
        try:
            if self.dock_widget:
                self.iface.removeDockWidget(self.dock_widget)
                self.dock_widget.close()
                self.dock_widget.deleteLater()
                self.dock_widget = None
        except:
            pass
        
        # Clean up controller
        self.controller = None
        
        # Remove module references to allow proper reload
        try:
            plugin_modules = [mod for mod in list(sys.modules.keys()) if mod.startswith('InfCAD')]
            for mod in plugin_modules:
                del sys.modules[mod]
        except:
            pass

