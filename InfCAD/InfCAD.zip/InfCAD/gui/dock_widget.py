
import os
import webbrowser
from qgis.PyQt import uic
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (QDockWidget, QFileDialog, QLabel, QCheckBox, QTableWidget,
                                 QTableWidgetItem, QPushButton, QHBoxLayout, QAbstractItemView,
                                 QHeaderView, QStyledItemDelegate)
from qgis.PyQt.QtGui import QIcon, QColor
from qgis.core import QgsProject, QgsRectangle

from ..core.utils import EDIF_MIID, EXCL_MIID

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'dock_widget.ui'))

class _NumItem(QTableWidgetItem):
    """Celda numérica: el valor real (float/int) va en DisplayRole, así se ordena por valor."""
    def __lt__(self, other):
        a, b = self.data(Qt.DisplayRole), other.data(Qt.DisplayRole)
        if isinstance(a, (int, float)) and isinstance(b, (int, float)):
            return a < b
        return super().__lt__(other)


class _DecimalDelegate(QStyledItemDelegate):
    """Muestra el número con separador de miles y N decimales sin cambiar el valor almacenado."""
    def __init__(self, decimals, parent=None):
        super().__init__(parent)
        self.decimals = decimals

    def displayText(self, value, locale):
        try:
            return f"{float(value):,.{self.decimals}f}"
        except (TypeError, ValueError):
            return str(value)


class InfCOPDockWidgetWrapper(QDockWidget, FORM_CLASS):
    def __init__(self, iface, parent=None):
        super(InfCOPDockWidgetWrapper, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface
        
        # Connect signals
        self.pushButton_select_folder.clicked.connect(self.select_folder)
        self.pushButton_help.clicked.connect(self.open_help)
        
        self.checkBox_adosados.setToolTip(
            "Une las edificaciones adosadas que son isla de un recinto mayor en un solo recinto; "
            "las paredes interiores van a la capa Aux_")
        self.checkBox_contactos.setToolTip(
            "Busca recintos que son isla de otro y se apoyan en él por un solo vértice "
            "(origen de nodos duplicados al crear topologías) y los marca en una capa de puntos")
        self.checkBox_cierres.setToolTip(
            "Corta los viales (V) y la hidrografía (H) con líneas en Aux_Cierres: cierra la boca de cada ramal "
            "contra el vial principal y une al exterior los huecos aislados con recintos dentro, para que "
            "ningún contorno envuelva una masa de recintos como si fuera una isla. Requiere el campo TIPO.")
        self._build_review_tab()

        # Set icon for run button
        icon_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'icon.svg')
        if os.path.exists(icon_path):
            self.pushButton_run.setIcon(QIcon(icon_path))
        
    def select_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Seleccionar Carpeta")
        if not folder:
            return
        self.lineEdit_folder.setText(folder)
        self.log(f"Carpeta seleccionada: {folder}")
        self.listWidget_files.clear()
        self.comboBox_finca.clear()
        self.comboBox_subfinca.clear()
        self.comboBox_tipo.clear()
        self.pushButton_run.setEnabled(False)

        try:
            from ..core.loader import InfCOPLoader, ZONE_LAYERS, BUILDINGS_LAYER
            from ..core.utils import is_integer_field
            loader = InfCOPLoader(folder)
            found = loader.scan()
            if not found:
                self.log("Advertencia: No se encontraron shapes InfCOP válidos (ZONACON, ZONACON_PARCELAS, EDIFICACIONES).")
                return
            self.listWidget_files.addItems(found)
            self.log(f"Shapes encontrados: {', '.join(found)}")

            has_edif = BUILDINGS_LAYER in found
            self.radioButton_both.setEnabled(has_edif)
            if not has_edif:
                self.radioButton_zone.setChecked(True)
                self.log("EDIFICACIONES no está en la carpeta: solo se podrá procesar ZONACON.")
            elif not self.radioButton_zone.isChecked():
                self.radioButton_both.setChecked(True)

            zone = next((z for z in ZONE_LAYERS if z in found), None)
            if zone is None:
                self.log("Advertencia: falta ZONACON; no se puede procesar.")
                return
            fields = loader.read_fields(zone)
            if fields is None:
                self.log(f"Error: no se pudo abrir {zone}.")
                return
            int_names = [f.name() for f in fields if is_integer_field(f)]
            if not int_names:
                self.log(f"Error: {zone} no tiene campos numéricos enteros para FINCA/SUBFINCA.")
                return

            self.comboBox_finca.addItems(int_names)
            self.comboBox_subfinca.addItem("(ninguno)", "")
            for n in int_names:
                self.comboBox_subfinca.addItem(n, n)
            self.comboBox_tipo.addItem("(ninguno)", "")
            for f in fields:
                self.comboBox_tipo.addItem(f.name(), f.name())
            self._preselect(self.comboBox_tipo, ["TIPO", "CODELEM"])
            self._preselect(self.comboBox_finca, ["FINCA"])
            self._preselect(self.comboBox_subfinca, ["SUBFINCA"])
            self.pushButton_run.setEnabled(True)
        except Exception as e:
            self.log(f"Error al escanear: {e}")

    @staticmethod
    def _preselect(combo, exact):
        """Preselecciona por nombre exacto (sin distinguir mayúsculas)."""
        for name in exact:  # el orden de 'exact' marca la prioridad
            for i in range(combo.count()):
                if combo.itemText(i).upper() == name:
                    combo.setCurrentIndex(i)
                    return

    def selected_mode(self):
        return 'both' if self.radioButton_both.isChecked() else 'zone'

    def selected_fields(self):
        """(campo FINCA, campo SUBFINCA o '', campo TIPO o '') elegidos en los desplegables."""
        finca = self.comboBox_finca.currentText()
        sub = self.comboBox_subfinca.currentData()
        tipo = self.comboBox_tipo.currentData()
        return finca, (sub or ""), (tipo or "")

    def log(self, message):
        self.textEdit_log.append(message)

    def open_help(self):
        """Open the help file in the default web browser"""
        help_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'ayuda_infcad.html')
        if os.path.exists(help_path):
            webbrowser.open('file:///' + help_path.replace('\\', '/'))
            self.log("Abriendo archivo de ayuda...")
        else:
            self.log(f"Error: No se encontró el archivo de ayuda en {help_path}")

    def set_working(self, working):
        self.label_status.setVisible(working)
        self.pushButton_run.setEnabled(not working and self.comboBox_finca.count() > 0)
        self.pushButton_reset.setEnabled(not working)
        self.pushButton_select_folder.setEnabled(not working)
        self.pushButton_help.setEnabled(not working)
        self.groupBox_mode.setEnabled(not working)
        self.groupBox_fields.setEnabled(not working)

    # ------------------------------------------------------------------ #
    # Pestaña «Revisión E»
    # ------------------------------------------------------------------ #
    COL_ZONE, COL_FINCA, COL_AREA, COL_RECT, COL_VERTS, COL_SCORE, COL_AUTO, COL_EDIF, COL_REASON = range(9)
    HEADERS = ["Capa", "Finca", "Área m²", "Rect.", "Vért.", "Punt.", "Auto", "Edificación\n(9100)", "Motivo"]
    COLOR_DOUBT = QColor(255, 243, 205)
    COLOR_CHANGED = QColor(205, 230, 255)

    def _build_review_tab(self):
        lay = self.verticalLayout_review
        lay.setContentsMargins(4, 4, 4, 4)
        self.tabWidget.setDocumentMode(True)
        self._review_items = []
        self._review_loading = False

        info = QLabel(
            "Recintos de TIPO E. Marca «Edificación» para MiID 9100; desmárcala para 9200 "
            "(finca excluida). Amarillo = dudoso; azul = cambiado por ti. Haz clic en una fila "
            "para ir al recinto. «Aplicar» escribe los cambios en MiID de los shapes de trabajo.")
        info.setWordWrap(True)
        lay.addWidget(info)

        row = QHBoxLayout()
        self.checkBox_only_doubtful = QCheckBox("Solo dudosos")
        self.checkBox_show_certain = QCheckBox("Incluir los confirmados por EDIFICACIONES")
        self.checkBox_only_doubtful.toggled.connect(self._apply_review_filter)
        self.checkBox_show_certain.toggled.connect(self._apply_review_filter)
        row.addWidget(self.checkBox_only_doubtful)
        row.addWidget(self.checkBox_show_certain)
        row.addStretch(1)
        lay.addLayout(row)

        self.tableWidget_review = QTableWidget(0, len(self.HEADERS))
        t = self.tableWidget_review
        t.setHorizontalHeaderLabels(self.HEADERS)
        t.setSelectionBehavior(QAbstractItemView.SelectRows)
        t.setSelectionMode(QAbstractItemView.SingleSelection)
        t.setEditTriggers(QAbstractItemView.NoEditTriggers)
        t.verticalHeader().setVisible(False)
        t.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
        t.horizontalHeader().setStretchLastSection(True)
        for col, dec in ((self.COL_AREA, 2), (self.COL_RECT, 2), (self.COL_VERTS, 0), (self.COL_SCORE, 2)):
            t.setItemDelegateForColumn(col, _DecimalDelegate(dec, t))
        t.setSortingEnabled(True)
        t.itemSelectionChanged.connect(self._review_row_selected)
        t.itemChanged.connect(self._review_item_changed)
        lay.addWidget(t, 1)

        self.label_review_status = QLabel("Sin datos: procesa una carpeta con recintos de TIPO E.")
        lay.addWidget(self.label_review_status)

        btns = QHBoxLayout()
        self.pushButton_apply_review = QPushButton("Aplicar cambios")
        self.pushButton_apply_review.setEnabled(False)
        btns.addStretch(1)
        btns.addWidget(self.pushButton_apply_review)
        lay.addLayout(btns)

    @staticmethod
    def _num_item(value):
        it = _NumItem()
        it.setData(Qt.DisplayRole, value)
        it.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
        return it

    def load_review(self, items):
        """Rellena la tabla con los recintos E (lista de dicts de pipeline.prepare_polygons)."""
        t = self.tableWidget_review
        self._review_loading = True
        t.setSortingEnabled(False)
        t.setRowCount(0)
        self._review_items = list(items or [])
        for k, item in enumerate(self._review_items):
            item['current'] = item['auto']
            r = t.rowCount()
            t.insertRow(r)
            cells = {
                self.COL_ZONE: QTableWidgetItem(item.get('zone', '')),
                self.COL_FINCA: QTableWidgetItem(str(item.get('finca', ''))),
                self.COL_AREA: self._num_item(float(item['area'])),
                self.COL_RECT: self._num_item(float(item['rect'])),
                self.COL_VERTS: self._num_item(int(item['verts'])),
                self.COL_SCORE: self._num_item(float(item['score'])),
                self.COL_AUTO: QTableWidgetItem(item['auto']),
                self.COL_REASON: QTableWidgetItem(item['reason']),
            }
            chk = QTableWidgetItem()
            chk.setFlags(Qt.ItemIsUserCheckable | Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            chk.setCheckState(Qt.Checked if item['auto'] == EDIF_MIID else Qt.Unchecked)
            cells[self.COL_EDIF] = chk
            for c, w in cells.items():
                t.setItem(r, c, w)
            # el índice del dict viaja en la fila (sobrevive a la ordenación)
            t.item(r, self.COL_ZONE).setData(Qt.UserRole, k)
            self._paint_row(r)
        t.setSortingEnabled(True)
        t.sortByColumn(self.COL_SCORE, Qt.AscendingOrder)
        self._review_loading = False
        self._apply_review_filter()
        self.pushButton_apply_review.setEnabled(False)

    def _item_for_row(self, row):
        idx = self.tableWidget_review.item(row, self.COL_ZONE).data(Qt.UserRole)
        return self._review_items[idx]

    def _paint_row(self, row):
        item = self._item_for_row(row)
        chk = self.tableWidget_review.item(row, self.COL_EDIF)
        now = EDIF_MIID if chk.checkState() == Qt.Checked else EXCL_MIID
        color = None
        if now != item['auto']:
            color = self.COLOR_CHANGED
        elif item['doubtful']:
            color = self.COLOR_DOUBT
        for c in range(self.tableWidget_review.columnCount()):
            it = self.tableWidget_review.item(row, c)
            if it is not None:
                it.setBackground(color if color else QColor(0, 0, 0, 0))
                if color:
                    it.setForeground(QColor(0, 0, 0))

    def _apply_review_filter(self):
        only_d = self.checkBox_only_doubtful.isChecked()
        show_c = self.checkBox_show_certain.isChecked()
        t = self.tableWidget_review
        shown = 0
        for r in range(t.rowCount()):
            item = self._item_for_row(r)
            hide = (item['certain'] and not show_c) or (only_d and not item['doubtful'])
            t.setRowHidden(r, hide)
            shown += 0 if hide else 1
        n_d = sum(1 for i in self._review_items if i['doubtful'])
        if self._review_items:
            self.label_review_status.setText(
                f"{len(self._review_items)} recintos E · {n_d} dudosos · {shown} mostrados.")

    def _review_item_changed(self, cell):
        if self._review_loading or cell.column() != self.COL_EDIF:
            return
        self._paint_row(cell.row())
        self.pushButton_apply_review.setEnabled(bool(self.review_changes()))

    def review_changes(self):
        """[(item, nuevo MiID)] de las filas cuyo valor difiere del ya escrito en los shapes."""
        out = []
        t = self.tableWidget_review
        for r in range(t.rowCount()):
            item = self._item_for_row(r)
            now = EDIF_MIID if t.item(r, self.COL_EDIF).checkState() == Qt.Checked else EXCL_MIID
            if now != item['current']:
                out.append((item, now))
        return out

    def review_refresh_baseline(self):
        """Tras aplicar: lo escrito pasa a ser la referencia; se quita el azul de «cambiado»."""
        self.pushButton_apply_review.setEnabled(False)
        t = self.tableWidget_review
        self._review_loading = True
        for r in range(t.rowCount()):
            item = self._item_for_row(r)
            chk = t.item(r, self.COL_EDIF)
            item['auto'] = EDIF_MIID if chk.checkState() == Qt.Checked else EXCL_MIID
            t.item(r, self.COL_AUTO).setText(item['auto'])
            self._paint_row(r)
        self._review_loading = False

    def _review_row_selected(self):
        rows = self.tableWidget_review.selectionModel().selectedRows()
        if not rows or self._review_loading:
            return
        item = self._item_for_row(rows[0].row())
        parts = [p for p in item['parts'] if p[1] is not None]
        if not parts:
            return
        layers = QgsProject.instance().mapLayersByName(f"{item.get('zone', 'ZONACON')}_MiID")
        canvas = self.iface.mapCanvas() if self.iface else None
        if not layers or canvas is None:
            return
        layer = layers[0]
        fids = [p[0] for p in item['parts']]
        box = None
        for f in layer.getFeatures(fids):
            g = f.geometry()
            if g is not None and not g.isNull():
                b = g.boundingBox()
                if box is None:
                    box = QgsRectangle(b)
                else:
                    box.combineExtentWith(b)
        if box is None:
            return
        margin = max(box.width(), box.height(), 10.0) * 1.5
        box.grow(margin)
        canvas.setExtent(box)
        canvas.refresh()
        canvas.flashFeatureIds(layer, fids)
