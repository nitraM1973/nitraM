
import os
import webbrowser
from qgis.PyQt import uic
from qgis.PyQt.QtWidgets import QDockWidget, QFileDialog
from qgis.PyQt.QtGui import QIcon

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'dock_widget.ui'))

class InfCOPDockWidgetWrapper(QDockWidget, FORM_CLASS):
    def __init__(self, iface, parent=None):
        super(InfCOPDockWidgetWrapper, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface
        
        # Connect signals
        self.pushButton_select_folder.clicked.connect(self.select_folder)
        self.pushButton_help.clicked.connect(self.open_help)
        
        # Set icon for run button
        icon_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'icon.svg')
        if os.path.exists(icon_path):
            self.pushButton_run.setIcon(QIcon(icon_path))
        
    def select_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Seleccionar Carpeta")
        if folder:
            self.lineEdit_folder.setText(folder)
            self.pushButton_run.setEnabled(True)
            self.log(f"Carpeta seleccionada: {folder}")
            
            # Clear previous items
            self.listWidget_files.clear()
            
            try:
                from ..core.loader import InfCOPLoader
                loader = InfCOPLoader(folder)
                found = loader.scan()
                
                if found:
                    self.listWidget_files.addItems(found)
                    self.log(f"Shapes encontrados: {', '.join(found)}")
                else:
                    self.log("Advertencia: No se encontraron shapes InfCOP válidos (ZONACON, ZONACON_PARCELAS, EDIFICACIONES).")
            except Exception as e:
                self.log(f"Error al escanear: {e}")

    def log(self, message):
        self.textEdit_log.append(message)

    def open_help(self):
        """Open the help file in the default web browser"""
        help_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'ayuda_infcad.html')
        if os.path.exists(help_path):
            webbrowser.open('file:///' + help_path.replace('\\', '/'))
            self.log("Abriendo archivo de ayuda...")
        else:
            self.log(f"Error: No se encontró el archivo de ayuda en {help_path}")

    def set_working(self, working):
        self.label_status.setVisible(working)
        self.pushButton_run.setEnabled(not working)
        self.pushButton_reset.setEnabled(not working)
        self.pushButton_select_folder.setEnabled(not working)
        self.pushButton_help.setEnabled(not working)
