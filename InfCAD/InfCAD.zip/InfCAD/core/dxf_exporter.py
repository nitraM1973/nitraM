import os
from qgis.core import QgsVectorLayer, QgsDxfExport, QgsProject, QgsMapSettings
from qgis.PyQt.QtCore import QFile, QIODevice, QSize
from .styling import build_renderer, color_for_layer_value, aci_for_color


class DxfExporter:
    """
    Exporta una capa de líneas final a DXF.
    - Cada entidad va a la capa DXF cuyo nombre es el valor de su campo LAYER.
    - Las entidades llevan el color de la clasificación por LAYER de QGIS.
    - Cada capa DXF se define con ese mismo color (visible en el gestor de capas CAD).
    """

    LAYER_FIELD = "LAYER"

    def __init__(self, output_folder):
        self.output_folder = output_folder

    def export(self, layer_path, output_name):
        """Devuelve (ruta_dxf, nº_entidades, lista_de_capas_dxf)."""
        layer = QgsVectorLayer(layer_path, output_name, "ogr")
        if not layer.isValid():
            raise Exception(f"No se pudo abrir la capa final: {layer_path}")

        if not layer.crs().isValid():
            project_crs = QgsProject.instance().crs()
            if project_crs.isValid():
                layer.setCrs(project_crs)

        idx = layer.fields().indexFromName(self.LAYER_FIELD)
        if idx < 0:
            raise Exception(
                f"La capa {output_name} no tiene el campo {self.LAYER_FIELD}.")

        dxf_layers = sorted(
            {str(v).strip() for v in layer.uniqueValues(idx)
             if v is not None and str(v).strip() not in ("", "NULL")})

        # Mismo estilo categorizado que en QGIS, pero línea fina (solo color,
        # sin grosor, para no generar polilíneas anchas en CAD)
        layer.setRenderer(build_renderer(layer, width=0))

        dxf_path = os.path.join(self.output_folder, f"{output_name}.dxf")
        if os.path.exists(dxf_path):
            os.remove(dxf_path)

        ms = QgsMapSettings()
        ms.setDestinationCrs(layer.crs())
        ms.setExtent(layer.extent())
        ms.setOutputSize(QSize(1000, 1000))
        ms.setLayers([layer])

        dxf = QgsDxfExport()
        dxf.setMapSettings(ms)
        dxf.addLayers([QgsDxfExport.DxfLayer(layer, idx)])
        if layer.crs().isValid():
            dxf.setDestinationCrs(layer.crs())
        dxf.setSymbologyExport(QgsDxfExport.FeatureSymbology)

        out_file = QFile(dxf_path)
        if not out_file.open(QIODevice.WriteOnly | QIODevice.Truncate):
            raise Exception(f"No se puede escribir el archivo: {dxf_path}")
        try:
            result = dxf.writeToFile(out_file, "UTF-8")
        finally:
            out_file.close()

        if int(result) != 0:
            raise Exception(
                f"QgsDxfExport devolvió el código de error {int(result)} "
                f"al exportar {output_name}.")

        # Color de cada capa en la tabla LAYER del DXF
        aci = {name: aci_for_color(color_for_layer_value(name))
               for name in dxf_layers}
        try:
            self._set_layer_table_colors(dxf_path, aci)
        except Exception as e:
            # El DXF ya es válido; solo se pierde el color de la definición de capa
            print(f"Warning: no se pudo ajustar el color de capas DXF: {e}")

        return dxf_path, layer.featureCount(), dxf_layers

    @staticmethod
    def _set_layer_table_colors(dxf_path, aci_by_layer):
        """Fija el código 62 (color ACI) de cada registro de la tabla LAYER."""
        with open(dxf_path, "r", encoding="utf-8", newline="") as f:
            raw = f.read()
        eol = "\r\n" if "\r\n" in raw else "\n"
        lines = raw.split(eol)

        pairs = []
        i = 0
        while i + 1 < len(lines):
            pairs.append((lines[i], lines[i + 1]))
            i += 2
        tail = lines[i:]  # línea suelta final (normalmente vacía)

        out = []
        in_layer_table = False
        k = 0
        n = len(pairs)
        while k < n:
            code, val = pairs[k][0].strip(), pairs[k][1].strip()

            if code == "0" and val == "TABLE" and k + 1 < n and \
                    pairs[k + 1][0].strip() == "2" and pairs[k + 1][1].strip() == "LAYER":
                in_layer_table = True
            elif code == "0" and val == "ENDTAB":
                in_layer_table = False

            if in_layer_table and code == "0" and val == "LAYER":
                # Registro completo hasta el siguiente código 0
                j = k + 1
                while j < n and pairs[j][0].strip() != "0":
                    j += 1
                record = pairs[k:j]
                name = next((v.strip() for c, v in record if c.strip() == "2"), None)
                if name in aci_by_layer:
                    color = str(aci_by_layer[name])
                    new_record, replaced = [], False
                    for c, v in record:
                        if c.strip() == "62":
                            new_record.append((c, f"{color:>6}"))
                            replaced = True
                        else:
                            new_record.append((c, v))
                    if not replaced:
                        new_record.append(("62", f"{color:>6}"))
                    record = new_record
                out.extend(record)
                k = j
                continue

            out.append(pairs[k])
            k += 1

        flat = []
        for c, v in out:
            flat.extend([c, v])
        flat.extend(tail)
        with open(dxf_path, "w", encoding="utf-8", newline="") as f:
            f.write(eol.join(flat))
