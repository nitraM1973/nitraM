
import processing
import os
from qgis.core import QgsVectorLayer

class LineDissolve:
    def __init__(self, temp_folder):
        self.temp_folder = temp_folder

    def dissolve_by_layer(self, layer_path, output_name):
        """
        Merge only CONTIGUOUS lines that have the same LAYER value.
        Non-contiguous lines with the same LAYER will remain separate.
        """
        try:
            # First, ensure geometries are valid before dissolve
            layer = QgsVectorLayer(layer_path, "temp", "ogr")
            
            # Revalidate geometries before dissolve to prevent crashes
            temp_revalidated = os.path.join(self.temp_folder, f"{output_name}_revalidated.shp")
            params_revalidate = {
                'INPUT': layer_path,
                'OUTPUT': temp_revalidated
            }
            processing.run("native:fixgeometries", params_revalidate)
            
            # Now dissolve with validated geometries
            temp_dissolved = os.path.join(self.temp_folder, f"{output_name}_temp.shp")
            
            params_dissolve = {
                'INPUT': temp_revalidated,
                'FIELD': ['LAYER'],
                'OUTPUT': temp_dissolved
            }
            processing.run("native:dissolve", params_dissolve)
            
            # Then, use multipart to singleparts to separate non-contiguous features
            output_path = os.path.join(self.temp_folder, f"{output_name}.shp")
            
            params_single = {
                'INPUT': temp_dissolved,
                'OUTPUT': output_path
            }
            
            result = processing.run("native:multiparttosingleparts", params_single)
            return result['OUTPUT']
            
        except Exception as e:
            # If dissolve fails, return the original layer
            print(f"Warning: Dissolve failed ({str(e)}), returning original layer")
            # Just copy the input to output
            import shutil
            output_path = os.path.join(self.temp_folder, f"{output_name}.shp")
            
            # Get all shapefile components
            base_path = layer_path.replace('.shp', '')
            output_base = output_path.replace('.shp', '')
            
            for ext in ['.shp', '.shx', '.dbf', '.prj', '.cpg']:
                src = base_path + ext
                dst = output_base + ext
                if os.path.exists(src):
                    shutil.copy2(src, dst)
            
            return output_path
