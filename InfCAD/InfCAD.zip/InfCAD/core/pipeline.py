"""
Procesamiento puro (sin tocar QgsProject ni la interfaz): se puede ejecutar en un
hilo secundario con seguridad. Todo se intercambia por rutas de archivo o datos
Python simples, nunca objetos de capa compartidos entre hilos.
"""
import os
import math
import bisect

from qgis.core import (
    QgsVectorLayer, QgsVectorFileWriter, QgsFeature, QgsField, QgsFields,
    QgsGeometry, QgsWkbTypes, QgsPointXY, QgsCoordinateTransformContext, QgsSpatialIndex, QgsRectangle, NULL,
)
from qgis.PyQt.QtCore import QVariant

from .utils import FIELD_X, FIELD_Y, FIELD_MIID, EDIF_MIID, EXCL_MIID
from . import classify

TOLERANCE = 0.025  # m; igual que la versión anterior (distancia de Hausdorff)

# Prioridad de CODELEM para calcular LAYER
PRIORITY_WITH_BUILDINGS = ['K', 'V', 'H', 'E', 'P', 'F']
PRIORITY_NO_BUILDINGS = ['K', 'E', 'V', 'H', 'P', 'F']



class _ShapeWriter:
    """Escritor de shapefile compatible con todas las versiones de QGIS 3.x.

    QgsVectorFileWriter.create() no existe en todas las versiones (p. ej. falla en
    QGIS 3.44), asi que se prueba en orden: create() -> constructor clasico ->
    capa en memoria volcada con writeAsVectorFormatV3/V2 al llamar a close().
    """

    def __init__(self, path, fields, wkb_type, crs):
        self._path = path
        self._fields = fields
        self._wkb = wkb_type
        self._crs = crs
        self._native = None
        self._mem = None
        self._error = False
        self._msg = ''
        self._open_native() or self._open_memory()

    def _open_native(self):
        W = QgsVectorFileWriter
        if hasattr(W, 'create'):
            try:
                opts = W.SaveVectorOptions()
                opts.driverName = "ESRI Shapefile"
                opts.fileEncoding = "UTF-8"
                w = W.create(self._path, self._fields, self._wkb, self._crs,
                             QgsCoordinateTransformContext(), opts)
                if w is not None and not w.hasError():
                    self._native = w
                    return True
            except Exception:
                pass
        try:
            w = W(self._path, "UTF-8", self._fields, self._wkb, self._crs, "ESRI Shapefile")
            if not w.hasError():
                self._native = w
                return True
            self._msg = w.errorMessage()
        except Exception as e:
            self._msg = str(e)
        return False

    def _open_memory(self):
        crs_id = self._crs.authid() if self._crs.isValid() else ''
        uri = "%s?crs=%s" % (QgsWkbTypes.displayString(self._wkb), crs_id)
        mem = QgsVectorLayer(uri, "infcad_tmp", "memory")
        if not mem.isValid():
            self._error = True
            self._msg = self._msg or "No se pudo crear la capa temporal para %s" % self._path
            return
        if self._crs.isValid():
            mem.setCrs(self._crs)
        mem.dataProvider().addAttributes([QgsField(f) for f in self._fields])
        mem.updateFields()
        self._mem = mem
        self._buf = []

    def hasError(self):
        if self._native is not None:
            return self._native.hasError() != 0
        return self._error

    def errorMessage(self):
        if self._native is not None:
            return self._native.errorMessage()
        return self._msg

    def addFeature(self, feat):
        if self._native is not None:
            return self._native.addFeature(feat)
        self._buf.append(QgsFeature(feat))
        return True

    def close(self):
        if self._native is not None:
            self._native = None  # destruir el escritor cierra y vuelca el archivo
            return
        if self._mem is None:
            return
        mem, self._mem = self._mem, None
        mem.dataProvider().addFeatures(self._buf)
        mem.updateExtents()
        W = QgsVectorFileWriter
        ctx = QgsCoordinateTransformContext()
        if hasattr(W, 'writeAsVectorFormatV3'):
            opts = W.SaveVectorOptions()
            opts.driverName = "ESRI Shapefile"
            opts.fileEncoding = "UTF-8"
            res = W.writeAsVectorFormatV3(mem, self._path, ctx, opts)
        else:
            opts = W.SaveVectorOptions()
            opts.driverName = "ESRI Shapefile"
            opts.fileEncoding = "UTF-8"
            res = W.writeAsVectorFormatV2(mem, self._path, ctx, opts)
        code = res[0] if isinstance(res, tuple) else res
        if code != 0:
            msg = res[1] if isinstance(res, tuple) and len(res) > 1 else ''
            raise Exception("No se pudo escribir %s: %s" % (self._path, msg))


def _create_writer(path, fields, wkb_type, crs):
    return _ShapeWriter(path, fields, wkb_type, crs)


# --------------------------------------------------------------------------- #
# Utilidades
# --------------------------------------------------------------------------- #
def _remove_shapefile(path):
    base = os.path.splitext(path)[0]
    for ext in ('.shp', '.shx', '.dbf', '.prj', '.cpg', '.qpj', '.shp.xml', '.sbn', '.sbx'):
        p = base + ext
        if os.path.exists(p):
            try:
                os.remove(p)
            except OSError:
                pass


def _is_null(value):
    return value is None or value == NULL


def _int_or_none(value):
    """Convierte el valor de un campo entero a int; None si es NULL/vacío."""
    if _is_null(value):
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def make_miid(finca, subfinca):
    """MiID = FINCA si SUBFINCA es 0 (o vacío); si no, 'FINCA-SUBFINCA'. None si FINCA vacía."""
    if finca is None:
        return None
    if not subfinca:
        return str(finca)
    return f"{finca}-{subfinca}"


TIPO_MIID = {'V': '9000', 'E': '9200', 'H': '9300'}
# Viales e hidrografía: su contorno envuelve manzanas/grupos de recintos, pero eso NO los convierte
# en contenedores reales (son huecos de la topología de líneas, no recintos que contengan nada).
ENVOLVENTE_MIIDS = {TIPO_MIID['V'], TIPO_MIID['H']}
IGNORAR_CONTENEDOR_VH = True   # True: V/H no cuentan como "recinto mayor" en islas y contactos
CIERRES_LAYER = "Aux_Cierres"


def _building_index(path):
    """Índice espacial de las edificaciones: (QgsSpatialIndex, {id: geometría})."""
    layer = QgsVectorLayer(path, "b", "ogr")
    geoms = {}
    index = QgsSpatialIndex()
    for f in layer.getFeatures():
        g = f.geometry()
        if g is not None and not g.isNull() and not g.isEmpty():
            geoms[f.id()] = g
            index.addFeature(f)
    return index, geoms


def _in_buildings(point_geom, index, geoms):
    for fid in index.intersects(point_geom.boundingBox()):
        if geoms[fid].intersects(point_geom):
            return True
    return False


def _clean_polygon(geom):
    """
    Devuelve una geometría poligonal válida, o None si no hay nada útil.
    Solo se llama a makeValid en las geometrías inválidas (más rápido que
    pasar native:fixgeometries sobre toda la capa).
    """
    if geom is None or geom.isNull() or geom.isEmpty():
        return None
    if geom.type() != QgsWkbTypes.PolygonGeometry:
        return None
    if geom.isGeosValid():
        return geom
    fixed = geom.makeValid()
    if fixed is None or fixed.isNull() or fixed.isEmpty():
        return None
    if fixed.type() == QgsWkbTypes.PolygonGeometry:
        return fixed
    # GeometryCollection con líneas/puntos sueltos: quedarse con los polígonos
    polys = [p for p in fixed.asGeometryCollection()
             if p.type() == QgsWkbTypes.PolygonGeometry]
    if not polys:
        return None
    result = polys[0]
    for p in polys[1:]:
        result = result.combine(p)
    return result


# --------------------------------------------------------------------------- #
# Paso 0: corregir geometrias de los shapes originales
# --------------------------------------------------------------------------- #
def _make_valid(geom):
    """makeValid (metodo 'Structure' si la version de QGIS/GEOS lo permite, igual que
    el algoritmo 'Corregir geometrias'; si no, el metodo por defecto)."""
    fixed = None
    method_enum = getattr(QgsGeometry, 'MakeValidMethod', None)
    structure = getattr(method_enum, 'MakeValidStructure', None) if method_enum is not None else None
    if structure is not None:
        try:
            fixed = geom.makeValid(structure)
        except Exception:
            fixed = None
    if fixed is None or fixed.isNull() or fixed.isEmpty():
        try:
            fixed = geom.makeValid()
        except Exception:
            fixed = None
    return fixed


def _polygons_only(geom):
    """Deja solo la parte poligonal de una geometria (makeValid puede devolver colecciones)."""
    if geom is None or geom.isNull() or geom.isEmpty():
        return None
    if geom.type() == QgsWkbTypes.PolygonGeometry:
        return geom
    polys = [p for p in geom.asGeometryCollection()
             if p.type() == QgsWkbTypes.PolygonGeometry and not p.isEmpty()]
    if not polys:
        return None
    result = polys[0]
    for p in polys[1:]:
        result = result.combine(p)
    return result


def _finite_extent(geom):
    bb = geom.boundingBox()
    return all(math.isfinite(v) for v in (bb.xMinimum(), bb.xMaximum(), bb.yMinimum(), bb.yMaximum()))


def fix_geometries(src_path, out_path, log=None):
    """
    Primer paso del proceso: copia el shape original a out_path (el original no se
    toca) corrigiendo las geometrias invalidas. Las entidades sin geometria, vacias,
    con coordenadas no finitas o que no se pueden reparar se descartan.
    Devuelve (total, corregidas, descartadas).
    """
    src = QgsVectorLayer(src_path, "src", "ogr")
    if not src.isValid():
        raise Exception(f"No se pudo abrir {src_path}")
    out_wkb = QgsWkbTypes.multiType(src.wkbType())
    _remove_shapefile(out_path)
    writer = _create_writer(out_path, src.fields(), out_wkb, src.crs())
    if writer.hasError():
        raise Exception(f"No se pudo crear {out_path}: {writer.errorMessage()}")
    total = n_fixed = n_drop = 0
    for feat in src.getFeatures():
        total += 1
        g = feat.geometry()
        if g is None or g.isNull() or g.isEmpty() or not _finite_extent(g):
            n_drop += 1
            continue
        if not g.isGeosValid():
            g = _polygons_only(_make_valid(g))
            if g is None or g.isNull() or g.isEmpty() or not _finite_extent(g):
                n_drop += 1
                continue
            n_fixed += 1
        elif g.type() != QgsWkbTypes.PolygonGeometry:
            n_drop += 1
            continue
        if not g.isMultipart():
            g.convertToMultiType()
        new = QgsFeature(src.fields())
        new.setAttributes(feat.attributes())
        new.setGeometry(g)
        writer.addFeature(new)
    writer.close()
    if log:
        log(f"Corregir geometrias {os.path.basename(src_path)}: {total} entidades; "
            f"{n_fixed} corregidas, {n_drop} descartadas (vacias o irreparables).")
    return total, n_fixed, n_drop


# --------------------------------------------------------------------------- #
# Paso 1: shape de trabajo con campos X, Y, MiID
# --------------------------------------------------------------------------- #
def prepare_polygons(src_path, out_path, kind, finca_field=None, subfinca_field=None, log=None,
                     tipo_field=None, buildings_path=None, review=None):
    """
    Copia src_path a out_path (no se toca el original), reparando geometrías
    inválidas y creando/rellenando los campos X, Y (punto sobre la superficie) y MiID.

    kind = 'fincas'        -> MiID desde finca_field / subfinca_field
    kind = 'edificaciones' -> MiID = 9100 siempre
    Si la capa ya trae CODELEM se conserva; en edificaciones se fuerza CODELEM = 'K'.

    Si se indica tipo_field (campo TIPO), tiene prioridad sobre FINCA/SUBFINCA:
        V -> 9000 | H -> 9300 | E -> 9200 si NO está en EDIFICACIONES, 9100 si sí lo está
    (las edificaciones son todas 9100).
    buildings_path = shape de edificaciones ya preparado.
    Las E que caen en EDIFICACIONES son 9100 (seguro). El resto se decide por la FORMA
    (ver classify.py): edificación -> 9100, finca excluida -> 9200. Sin EDIFICACIONES
    todas las E se deciden por la forma. Con EDIFICACIONES, una E fuera de ellas se deja
    en 9200 aunque su forma parezca de edificación, pero se marca como dudosa.
    review = lista opcional; se rellena con un dict por cada recinto E (para la pestaña
    de revisión): puntuación, motivo, MiID asignado y los fid/X/Y de sus partes.
    Cualquier otro TIPO sigue la regla FINCA/SUBFINCA.
    Devuelve (out_path, n_entidades, n_sin_miid).
    """
    log = log or (lambda m: None)
    src = QgsVectorLayer(src_path, "src", "ogr")
    if not src.isValid():
        raise Exception(f"No se pudo abrir {src_path}")

    is_edif = (kind == 'edificaciones')
    if not is_edif:
        if finca_field is None or src.fields().indexFromName(finca_field) < 0:
            raise Exception(f"El campo FINCA '{finca_field}' no existe en {os.path.basename(src_path)}.")
        if tipo_field and src.fields().indexFromName(tipo_field) < 0:
            raise Exception(f"El campo TIPO '{tipo_field}' no existe en {os.path.basename(src_path)}.")
        if subfinca_field and src.fields().indexFromName(subfinca_field) < 0:
            raise Exception(f"El campo SUBFINCA '{subfinca_field}' no existe en {os.path.basename(src_path)}.")

    reserved = {FIELD_X.upper(), FIELD_Y.upper(), FIELD_MIID.upper()}
    out_fields = QgsFields()
    keep = []  # (idx_origen, idx_destino)
    for i, f in enumerate(src.fields()):
        if f.name().upper() in reserved:
            continue  # se regeneran
        out_fields.append(f)
        keep.append((i, out_fields.count() - 1))
    codelem_idx = out_fields.indexFromName('CODELEM')
    if is_edif and codelem_idx < 0:
        out_fields.append(QgsField('CODELEM', QVariant.String, '', 1))
        codelem_idx = out_fields.count() - 1
    out_fields.append(QgsField(FIELD_X, QVariant.Double, 'double', 24, 15))
    out_fields.append(QgsField(FIELD_Y, QVariant.Double, 'double', 24, 15))
    out_fields.append(QgsField(FIELD_MIID, QVariant.String, 'string', 30))
    ix, iy, im = (out_fields.indexFromName(n) for n in (FIELD_X, FIELD_Y, FIELD_MIID))

    _remove_shapefile(out_path)
    writer = _create_writer(
        out_path, out_fields, QgsWkbTypes.MultiPolygon if is_edif else QgsWkbTypes.Polygon, src.crs())
    if writer.hasError():
        raise Exception(f"No se pudo crear {out_path}: {writer.errorMessage()}")

    if not is_edif:
        i_fin = src.fields().indexFromName(finca_field)
        i_sub = src.fields().indexFromName(subfinca_field) if subfinca_field else -1
        i_tipo = src.fields().indexFromName(tipo_field) if tipo_field else -1
        edif_index, edif_geoms = _building_index(buildings_path) if (i_tipo >= 0 and buildings_path) else (None, {})
        has_buildings = bool(buildings_path)

    n = n_bad_geom = n_no_miid = n_split = n_extra = n_e_edif = n_e_free = n_e_doubt = 0
    for feat in src.getFeatures():
        geom = _clean_polygon(feat.geometry())

        # Partes: en fincas, un recinto multiparte se divide en una entidad por parte
        if geom is None:
            parts = [None]
        elif is_edif:
            if not geom.isMultipart():
                geom.convertToMultiType()
            parts = [geom]
        elif geom.isMultipart():
            parts = [p for p in geom.asGeometryCollection() if not p.isEmpty()] or [geom]
            if len(parts) > 1:
                n_split += 1
                n_extra += len(parts) - 1
        else:
            parts = [geom]
        # puntos sobre la superficie de cada parte (X, Y propios)
        points = []
        for part in parts:
            pt = part.pointOnSurface() if part is not None else None
            points.append(pt if (pt is not None and not pt.isNull()) else None)

        # MiID: uno por recinto original, igual para todas sus partes
        e_info = None
        if is_edif:
            miid = EDIF_MIID
        else:
            miid = None
            if i_tipo >= 0:
                v = feat.attribute(i_tipo)
                tipo = '' if _is_null(v) else str(v).strip().upper()
                miid = TIPO_MIID.get(tipo)
                if tipo == 'E':
                    e_info = {'certain': False}
                    in_edif = (edif_index is not None and
                               any(_in_buildings(pt, edif_index, edif_geoms) for pt in points if pt is not None))
                    valid = [p for p in parts if p is not None]
                    if valid:
                        main = max(valid, key=lambda p: p.area())
                        metrics = classify.polygon_metrics(main)
                        score, reason = classify.building_score(*metrics)
                        guess, doubtful = classify.decide(score)
                    else:
                        metrics, score, reason, guess, doubtful = (0, 0, 0, 0, 0), 0.0, "sin geometría", EXCL_MIID, True
                    if in_edif:
                        miid = EDIF_MIID          # coincide con una edificación: seguro
                        e_info['certain'] = True
                        doubtful = False
                        reason = "coincide con una edificación de EDIFICACIONES"
                        n_e_edif += 1
                    elif has_buildings:
                        miid = EXCL_MIID          # EDIFICACIONES manda: fuera de ella = excluida
                        if guess == EDIF_MIID:    # ...pero si su forma parece edificación, a revisar
                            doubtful = True
                            reason = "no está en EDIFICACIONES pero su forma parece edificación; " + reason
                        n_e_free += 1
                    else:
                        miid = guess              # sin EDIFICACIONES: decide la forma
                        if guess == EDIF_MIID:
                            n_e_edif += 1
                        else:
                            n_e_free += 1
                    if doubtful:
                        n_e_doubt += 1
                    e_info.update(auto=miid, score=score, reason=reason, doubtful=doubtful,
                                  area=metrics[0], rect=metrics[1], verts=metrics[2],
                                  holes=metrics[3], aspect=metrics[4], parts=[])
            if miid is None:
                finca = _int_or_none(feat.attribute(i_fin))
                sub = _int_or_none(feat.attribute(i_sub)) if i_sub >= 0 else 0
                miid = make_miid(finca, sub)
            if miid is None:
                n_no_miid += 1

        if geom is None:
            n_bad_geom += 1

        for part, pt in zip(parts, points):
            new = QgsFeature(out_fields)
            for i_old, i_new in keep:
                new.setAttribute(i_new, feat.attribute(i_old))
            if part is not None:
                new.setGeometry(part)
            if pt is not None:
                p = pt.asPoint()
                new.setAttribute(ix, p.x())
                new.setAttribute(iy, p.y())
            if is_edif:
                new.setAttribute(codelem_idx, 'K')
            if miid is not None:
                new.setAttribute(im, miid)
            if e_info is not None:
                xy = (pt.asPoint().x(), pt.asPoint().y()) if pt is not None else (None, None)
                e_info['parts'].append((n, xy[0], xy[1]))   # n = fid que tendrá en el shape
            writer.addFeature(new)
            n += 1
        if e_info is not None and review is not None:
            fincas_txt = make_miid(_int_or_none(feat.attribute(i_fin)),
                                   _int_or_none(feat.attribute(i_sub)) if i_sub >= 0 else 0)
            e_info.update(finca=fincas_txt or "", paths=[out_path])
            review.append(e_info)
    writer.close()

    if n_e_edif or n_e_free:
        if buildings_path:
            log(f"  Recintos E: {n_e_edif} en EDIFICACIONES (MiID {EDIF_MIID}), {n_e_free} fuera (MiID {EXCL_MIID}).")
        else:
            log(f"  Recintos E (sin EDIFICACIONES, decididos por la forma): "
                f"{n_e_edif} edificación ({EDIF_MIID}), {n_e_free} finca excluida ({EXCL_MIID}).")
        if n_e_doubt:
            log(f"  {n_e_doubt} recinto(s) E dudosos: revísalos en la pestaña «Revisión E».")
    if n_split:
        log(f"  {os.path.basename(src_path)}: {n_split} recinto(s) multiparte divididos en partes (+{n_extra} entidades).")
    if n_bad_geom:
        log(f"  {os.path.basename(src_path)}: {n_bad_geom} entidad(es) sin geometría poligonal válida (se conservan sin geometría).")
    return out_path, n, n_no_miid


# Una edificación se considera ya presente en ZONACON si un recinto E la cubre así
# (solape / área de la edificación  Y  solape / área del recinto, ambos >= este valor)
OVERLAP_RATIO = 0.9


def _find_duplicate_buildings(zone, edif, tipo_field):
    """
    Edificaciones que ya existen en ZONACON como recinto E (misma huella, con
    holgura de OVERLAP_RATIO). Devuelve {id_edificación: id_recinto_E}.
    """
    idx_t = zone.fields().indexFromName(tipo_field) if tipo_field else -1
    if idx_t < 0:
        idx_t = zone.fields().indexFromName('CODELEM')
    if idx_t < 0:
        return {}
    index = QgsSpatialIndex()
    zgeoms = {}
    for f in zone.getFeatures():
        v = f.attribute(idx_t)
        if _is_null(v) or str(v).strip().upper() != 'E':
            continue
        g = f.geometry()
        if g is None or g.isNull() or g.isEmpty() or g.area() <= 0:
            continue
        zgeoms[f.id()] = (g, g.area())
        index.addFeature(f)
    if not zgeoms:
        return {}

    dups = {}
    for b in edif.getFeatures():
        bg = b.geometry()
        if bg is None or bg.isNull() or bg.isEmpty():
            continue
        barea = bg.area()
        if barea <= 0:
            continue
        best, best_inter = None, 0.0
        for zid in index.intersects(bg.boundingBox()):
            zg, zarea = zgeoms[zid]
            if not zg.intersects(bg):
                continue
            inter = zg.intersection(bg).area()
            if inter > best_inter and inter / barea >= OVERLAP_RATIO and inter / zarea >= OVERLAP_RATIO:
                best, best_inter = zid, inter
        if best is not None:
            dups[b.id()] = best
    return dups


def merge_polygons(zone_path, edif_path, out_path, tipo_field=None):
    """
    Fusiona el ZONACON preparado con las edificaciones preparadas en una sola capa.

    Antes de fusionar se detectan las edificaciones que ya están en ZONACON como
    recinto E (misma huella): NO se añaden otra vez (evita líneas casi coincidentes /
    microastillas). Ese recinto E de ZONACON pasa a representar la edificación:
    CODELEM = K y MiID = 9100.
    Devuelve (out_path, n_zona, n_edificaciones_añadidas, n_duplicadas).
    """
    zone = QgsVectorLayer(zone_path, "zone", "ogr")
    edif = QgsVectorLayer(edif_path, "edif", "ogr")
    if not zone.isValid() or not edif.isValid():
        raise Exception("No se pudieron abrir las capas preparadas para la fusión.")

    dups = _find_duplicate_buildings(zone, edif, tipo_field)
    promote = set(dups.values())   # recintos E de ZONACON que son edificaciones

    fields = QgsFields()
    names = set()
    for layer in (zone, edif):
        for f in layer.fields():
            if f.name().upper() not in names:
                names.add(f.name().upper())
                fields.append(f)
    i_cod = fields.indexFromName('CODELEM')
    i_miid = fields.indexFromName(FIELD_MIID)

    _remove_shapefile(out_path)
    writer = _create_writer(
        out_path, fields, QgsWkbTypes.MultiPolygon, zone.crs())
    if writer.hasError():
        raise Exception(f"No se pudo crear {out_path}: {writer.errorMessage()}")

    counts = []
    for layer, skip, prom in ((zone, set(), promote), (edif, set(dups), set())):
        mapping = [(i, fields.indexFromName(f.name())) for i, f in enumerate(layer.fields())]
        k = 0
        for feat in layer.getFeatures():
            if feat.id() in skip:
                continue
            new = QgsFeature(fields)
            new.setGeometry(feat.geometry())
            for i_old, i_new in mapping:
                new.setAttribute(i_new, feat.attribute(i_old))
            if feat.id() in prom:
                new.setAttribute(i_cod, 'K')
                new.setAttribute(i_miid, EDIF_MIID)
            writer.addFeature(new)
            k += 1
        counts.append(k)
    writer.close()
    return out_path, counts[0], counts[1], len(dups)


# --------------------------------------------------------------------------- #
# Edificaciones adosadas: un solo recinto por conjunto + líneas interiores a Aux_
# --------------------------------------------------------------------------- #
ADOSADO_SHARED_MIN = 0.30   # m de pared compartida mínima para considerar dos edificaciones adosadas
AUX_PREFIX = "Aux_"
ISLA_TOL = 0.10      # m; holgura para decidir que el conjunto encaja en el hueco de otro recinto
ISLA_COVER = 0.98    # fracción mínima del contorno exterior del conjunto que debe rodear ese recinto


def _filled(geom):
    """Polígono/multipolígono sin huecos (solo anillos exteriores)."""
    polys = geom.asMultiPolygon() if geom.isMultipart() else [geom.asPolygon()]
    outer = [[poly[0]] for poly in polys if poly and len(poly[0]) >= 4]
    return QgsGeometry.fromMultiPolygonXY(outer) if outer else geom


def _is_island(union, cluster_fids, layer, all_index, tol=ISLA_TOL):
    """
    True si el conjunto (polígono union) es una ISLA dentro de un recinto MÁS GRANDE:
    un único recinto lo rodea por completo y ningún otro recinto toca su contorno.
      - caso hueco:  el recinto tiene un hueco con la forma del conjunto (su anillo
                     interior recorre >= ISLA_COVER del contorno exterior del conjunto);
      - caso solape: el recinto contiene al conjunto (p. ej. EDIFICACIONES sobre ZONACON).
    El recinto, sin contar huecos, debe tener más área que el conjunto.
    """
    poly = union.asMultiPolygon()[0] if union.isMultipart() else union.asPolygon()
    ext = QgsGeometry.fromPolylineXY(poly[0])
    ext_len = ext.length()
    if ext_len <= 0:
        return False
    box = QgsRectangle(union.boundingBox())
    box.grow(tol)
    mine = set(cluster_fids)
    parents, others = [], []
    i_miid = layer.fields().indexFromName(FIELD_MIID)
    for fid in all_index.intersects(box):
        if fid in mine:
            continue
        feat = layer.getFeature(fid)
        g = feat.geometry()
        if g is None or g.isNull() or g.isEmpty() or g.type() != QgsWkbTypes.PolygonGeometry:
            continue
        rings_buf = _rings_geom(g).buffer(tol, 2)
        covered = ext.intersection(rings_buf)
        covered_len = covered.length() if covered is not None and not covered.isNull() else 0.0
        encloses = covered_len >= ISLA_COVER * ext_len or g.buffer(tol, 2).contains(union)
        if encloses and _filled(g).area() > union.area():
            if IGNORAR_CONTENEDOR_VH and _miid_text(feat, i_miid) in ENVOLVENTE_MIIDS:
                continue                 # vial/río que envuelve el conjunto: no es una isla real
            parents.append(fid)
        elif covered_len >= ADOSADO_SHARED_MIN:
            others.append(fid)       # otro recinto que toca el contorno del conjunto
    return len(parents) == 1 and not others


def _miid_text(feat, i_miid):
    if i_miid < 0:
        return ''
    v = feat.attribute(i_miid)
    return '' if _is_null(v) else str(v).strip()


def _rings_geom(geom):
    """Todos los anillos de un polígono/multipolígono como (multi)línea."""
    polys = geom.asMultiPolygon() if geom.isMultipart() else [geom.asPolygon()]
    rings = [ring for poly in polys for ring in poly if len(ring) >= 2]
    return QgsGeometry.fromMultiPolylineXY(rings)


def merge_adosados(poly_path, out_path, log=None, tol=TOLERANCE):
    """
    Une las edificaciones (recintos con MiID 9100) que comparten pared y forman una ISLA dentro
    de un recinto mayor en un único recinto por conjunto.

    - En out_path: igual que poly_path, pero cada conjunto de >= 2 edificaciones adosadas
      se sustituye por UN recinto (la unión de todas), con CODELEM = K si alguna lo era
      (si no, el de la primera), MiID = 9100 y X, Y = punto sobre la superficie de esa unión.
      El resto de campos se toma de la primera edificación del conjunto.
    - Las paredes interiores (las que dividen los adosados) NO van en el contorno: se
      devuelven como segmentos (x1, y1, x2, y2, 'Aux_' + CODELEM) para que acaben en la
      capa auxiliar 'Aux_<LAYER>'. El contorno exterior sigue el criterio normal del plugin.

    Solo se tratan los conjuntos que son ISLA de un recinto más grande (ver _is_island).
    Devuelve (out_path, n_conjuntos, n_edificaciones_unidas, segmentos_aux, n_omitidos, n_no_isla).
    Si un conjunto no se puede unir en un único polígono (p. ej. separaciones mayores que
    la tolerancia), se deja tal cual y se cuenta como omitido.
    """
    log = log or (lambda m: None)
    layer = QgsVectorLayer(poly_path, "p", "ogr")
    if not layer.isValid():
        raise Exception(f"No se pudo abrir {poly_path}")
    fields = layer.fields()
    i_miid = fields.indexFromName(FIELD_MIID)
    i_cod = fields.indexFromName('CODELEM')
    ix, iy = fields.indexFromName(FIELD_X), fields.indexFromName(FIELD_Y)
    if i_miid < 0:
        return poly_path, 0, 0, [], 0, 0

    # --- edificaciones candidatas
    members = {}   # fid -> (geom, código)
    index = QgsSpatialIndex()
    for f in layer.getFeatures():
        v = f.attribute(i_miid)
        if _is_null(v) or str(v).strip() != EDIF_MIID:
            continue
        g = f.geometry()
        if g is None or g.isNull() or g.isEmpty() or g.type() != QgsWkbTypes.PolygonGeometry:
            continue
        code = ''
        if i_cod >= 0 and not _is_null(f.attribute(i_cod)):
            code = str(f.attribute(i_cod)).strip().upper()
        members[f.id()] = (g, code or 'E')
        index.addFeature(f)

    # --- adyacencia (pared compartida) + componentes conexos
    parent = {fid: fid for fid in members}

    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a

    for fid, (g, _c) in members.items():
        box = QgsRectangle(g.boundingBox())
        box.grow(tol)
        buf = None
        for oid in index.intersects(box):
            if oid <= fid or oid not in members:
                continue
            if find(oid) == find(fid):
                continue
            og = members[oid][0]
            if g.distance(og) > tol:
                continue
            if buf is None:
                buf = g.buffer(tol, 2)
            shared = _rings_geom(og).intersection(buf)
            if shared is not None and not shared.isNull() and shared.length() >= ADOSADO_SHARED_MIN:
                parent[find(oid)] = find(fid)

    groups = {}
    for fid in members:
        groups.setdefault(find(fid), []).append(fid)

    all_index = QgsSpatialIndex(layer.getFeatures())   # todos los recintos (para el test de isla)

    # --- unión de cada conjunto y paredes interiores
    clusters = {}     # primer fid -> (union, código, [fids])
    skip = set()
    aux = []
    n_omitted = n_not_island = 0
    for fids in groups.values():
        if len(fids) < 2:
            continue
        fids.sort()
        union = QgsGeometry.unaryUnion([members[f][0] for f in fids])
        if (union is None or union.isNull() or union.isEmpty()
                or union.type() != QgsWkbTypes.PolygonGeometry
                or (union.isMultipart() and len(union.asMultiPolygon()) > 1)):
            n_omitted += 1
            continue
        if not _is_island(union, fids, layer, all_index):
            n_not_island += 1      # adosados pero no isla de un recinto mayor: se dejan como están
            continue
        codes = [members[f][1] for f in fids]
        code = 'K' if 'K' in codes else codes[0]

        outer = _rings_geom(union)
        noded = QgsGeometry.unaryUnion([_rings_geom(members[f][0]) for f in fids])
        if noded is not None and not noded.isNull() and not noded.isEmpty():
            polylines = noded.asMultiPolyline() if noded.isMultipart() else [noded.asPolyline()]
            for line in polylines:
                for a, b in zip(line, line[1:]):
                    if a.x() == b.x() and a.y() == b.y():
                        continue
                    mid = QgsGeometry.fromPointXY(QgsPointXY((a.x() + b.x()) / 2, (a.y() + b.y()) / 2))
                    if outer.distance(mid) > tol:      # no está sobre el contorno exterior
                        aux.append((a.x(), a.y(), b.x(), b.y(), AUX_PREFIX + code))
        clusters[fids[0]] = (union, code, fids)
        skip.update(fids[1:])

    # --- escribir la capa resultante
    _remove_shapefile(out_path)
    writer = _create_writer(
        out_path, fields, layer.wkbType(), layer.crs())
    if writer.hasError():
        raise Exception(f"No se pudo crear {out_path}: {writer.errorMessage()}")
    multi = QgsWkbTypes.isMultiType(layer.wkbType())
    n_members = 0
    for f in layer.getFeatures():
        if f.id() in skip:
            continue
        if f.id() in clusters:
            union, code, fids = clusters[f.id()]
            new = QgsFeature(fields)
            new.setAttributes(f.attributes())
            if multi and not union.isMultipart():
                union.convertToMultiType()
            new.setGeometry(union)
            if i_cod >= 0:
                new.setAttribute(i_cod, code)
            new.setAttribute(i_miid, EDIF_MIID)
            pt = union.pointOnSurface()
            if pt is not None and not pt.isNull():
                p = pt.asPoint()
                if ix >= 0:
                    new.setAttribute(ix, p.x())
                if iy >= 0:
                    new.setAttribute(iy, p.y())
            writer.addFeature(new)
            n_members += len(fids)
        else:
            writer.addFeature(f)
    writer.close()
    if n_not_island:
        log(f"  Adosados: {n_not_island} conjunto(s) de edificaciones adosadas NO son isla de un recinto mayor: "
            f"se dejan sin unir (sin Aux_).")
    if n_omitted:
        log(f"  Adosados: {n_omitted} conjunto(s) no se pudieron unir en un solo polígono (se dejan sin unir).")
    return out_path, len(clusters), n_members, aux, n_omitted, n_not_island


# --------------------------------------------------------------------------- #
# Contactos puntuales isla/contenedor (nodos duplicados al crear la topología)
# --------------------------------------------------------------------------- #
CONTACT_TYPES = {
    'V=V': "Vértice de la isla coincide con un vértice del contenedor",
    'V/A': "Vértice de la isla apoya en una arista del contenedor",
    'A/V': "Vértice del contenedor apoya en una arista de la isla",
}


def _ring_list(geom):
    """[(vértices sin repetir el de cierre)] de todos los anillos de un (multi)polígono."""
    polys = geom.asMultiPolygon() if geom.isMultipart() else [geom.asPolygon()]
    return [ring[:-1] for poly in polys for ring in poly if len(ring) >= 4]


def _vertex_is_isolated(v, prev, nxt, other_buf, tol=TOLERANCE):
    """
    True si el vértice v toca al otro polígono SOLO en un punto: ninguno de sus dos
    segmentos adyacentes discurre pegado (>= ADOSADO_SHARED_MIN) al contorno del otro.
    """
    for nb in (prev, nxt):
        seg_len = math.hypot(nb.x() - v.x(), nb.y() - v.y())
        if seg_len <= 2 * tol:
            continue
        inter = QgsGeometry.fromPolylineXY([v, nb]).intersection(other_buf)
        if inter is not None and not inter.isNull() and inter.length() >= min(ADOSADO_SHARED_MIN, 0.9 * seg_len):
            return False
    return True


def detect_island_contacts(poly_path, out_path, log=None, tol=TOLERANCE):
    """
    Busca recintos que son ISLA de otro (están dentro del contenedor, sin huecos) y
    se apoyan en él por un único punto (vértice). Así, al cerrar contornos
    topológicos, ese punto genera un nodo duplicado. Clasifica cada contacto:
      V=V : vértice de la isla = vértice del contenedor (nodos coincidentes)
      V/A : vértice de la isla sobre una arista del contenedor
      A/V : vértice del contenedor sobre una arista de la isla
    Un contacto a lo largo de un tramo (pared compartida) no se considera puntual.
    Escribe un shapefile de puntos en out_path (solo si hay contactos).
    Devuelve (out_path | None, n_contactos, {tipo: n}).
    """
    log = log or (lambda m: None)
    layer = QgsVectorLayer(poly_path, "p", "ogr")
    if not layer.isValid():
        raise Exception(f"No se pudo abrir {poly_path}")
    i_miid = layer.fields().indexFromName(FIELD_MIID)

    def miid_of(feat):
        if i_miid < 0 or _is_null(feat.attribute(i_miid)):
            return ''
        return str(feat.attribute(i_miid))

    index = QgsSpatialIndex(layer.getFeatures())
    cache = {}    # fid -> (geom, rings_geom, vértices por anillo, MiID)

    def info(fid, feat=None):
        if fid not in cache:
            f = feat if feat is not None else layer.getFeature(fid)
            g = f.geometry()
            if g is None or g.isNull() or g.isEmpty() or g.type() != QgsWkbTypes.PolygonGeometry:
                cache[fid] = None
            else:
                cache[fid] = (g, _rings_geom(g), _ring_list(g), miid_of(f))
        return cache[fid]

    filled_buf = {}   # fid -> relleno (sin huecos) con holgura
    contacts = []     # (x, y, tipo, miid_isla, miid_contenedor)
    seen = set()

    for fb in layer.getFeatures():
        bi = info(fb.id(), fb)
        if bi is None:
            continue
        b_geom, b_rings, b_rlist, b_miid = bi
        b_box = b_geom.boundingBox()
        box = QgsRectangle(b_box)
        box.grow(tol)
        for aid in index.intersects(box):
            if aid == fb.id():
                continue
            ai = info(aid)
            if ai is None:
                continue
            a_geom, a_rings, a_rlist, a_miid = ai
            if IGNORAR_CONTENEDOR_VH and a_miid.strip() in ENVOLVENTE_MIIDS:
                continue                       # un vial/río no es contenedor real
            # el contenedor debe ser mayor y su caja envolver a la de la isla
            a_box = QgsRectangle(a_geom.boundingBox())
            a_box.grow(tol)
            if not a_box.contains(b_box):
                continue
            if a_rings.distance(b_rings) > tol:
                continue                       # no se tocan
            if aid not in filled_buf:
                f = _filled(a_geom)
                filled_buf[aid] = (f.area(), f.buffer(tol, 2))
            f_area, f_buf = filled_buf[aid]
            if f_area <= b_geom.area() or not f_buf.contains(b_geom):
                continue                       # no es isla de este recinto

            a_buf = a_rings.buffer(tol, 2)
            b_buf = b_rings.buffer(tol, 2)

            # --- vértices de la isla que tocan al contenedor
            for ring in b_rlist:
                n = len(ring)
                for i, v in enumerate(ring):
                    pv = QgsGeometry.fromPointXY(v)
                    if a_rings.distance(pv) > tol:
                        continue
                    if not _vertex_is_isolated(v, ring[(i - 1) % n], ring[(i + 1) % n], a_buf, tol):
                        continue
                    near = a_geom.closestVertex(v)
                    kind = 'V=V' if near[4] <= tol * tol else 'V/A'
                    key = (fb.id(), aid, round(v.x() / tol), round(v.y() / tol))
                    if key not in seen:
                        seen.add(key)
                        contacts.append((v.x(), v.y(), kind, b_miid, a_miid))

            # --- vértices del contenedor que tocan a la isla (apoyan en una arista suya)
            gbox = QgsRectangle(b_box)
            gbox.grow(tol)
            for ring in a_rlist:
                n = len(ring)
                for i, w in enumerate(ring):
                    if not gbox.contains(w):
                        continue
                    pw = QgsGeometry.fromPointXY(w)
                    if b_rings.distance(pw) > tol:
                        continue
                    if b_geom.closestVertex(w)[4] <= tol * tol:
                        continue               # ya contado como V=V desde la isla
                    if not _vertex_is_isolated(w, ring[(i - 1) % n], ring[(i + 1) % n], b_buf, tol):
                        continue
                    key = (fb.id(), aid, round(w.x() / tol), round(w.y() / tol))
                    if key not in seen:
                        seen.add(key)
                        contacts.append((w.x(), w.y(), 'A/V', b_miid, a_miid))

    counts = {}
    for c in contacts:
        counts[c[2]] = counts.get(c[2], 0) + 1
    if not contacts:
        return None, 0, counts

    _remove_shapefile(out_path)
    fields = QgsFields()
    fields.append(QgsField('TIPO', QVariant.String, 'string', 8))
    fields.append(QgsField('DESCRIP', QVariant.String, 'string', 80))
    fields.append(QgsField('ISLA', QVariant.String, 'string', 30))
    fields.append(QgsField('CONTENEDOR', QVariant.String, 'string', 30))
    fields.append(QgsField(FIELD_X, QVariant.Double, 'double', 24, 15))
    fields.append(QgsField(FIELD_Y, QVariant.Double, 'double', 24, 15))
    writer = _create_writer(
        out_path, fields, QgsWkbTypes.Point, layer.crs())
    if writer.hasError():
        raise Exception(f"No se pudo crear {out_path}: {writer.errorMessage()}")
    for x, y, kind, isla, cont in contacts:
        f = QgsFeature(fields)
        f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(x, y)))
        f.setAttributes([kind, CONTACT_TYPES[kind], isla, cont, x, y])
        writer.addFeature(f)
    writer.close()
    return out_path, len(contacts), counts


# --------------------------------------------------------------------------- #
# Cierres de V/H: cortar viales e hidrografía en las bocas de sus ramales
# --------------------------------------------------------------------------- #
CIERRE_MAX_PRUEBAS = 40      # pares de vértices que se prueban por conexión de hueco antes de rendirse
CIERRE_VECINOS = 4           # anillos vecinos candidatos por hueco (además del exterior)
CIERRE_RADIOS = (10.0, 40.0, 160.0)   # m; búsqueda progresiva de anillos vecinos
CIERRE_ANCHO_MAX = 50.0      # m; ancho máximo de una boca de ramal (longitud máxima del cierre)
CIERRE_ANG_MIN = math.radians(8.0)    # giro mínimo para que un vértice cuente como esquina entrante
CIERRE_PAR = 1.2             # un vértice admite varios cierres si su longitud <= PAR * la más corta (cruces en X)
CIERRE_ARCO = 2.5            # en un mismo anillo, el camino entre extremos debe ser > ARCO * longitud del cierre
CIERRE_DUP = 0.6             # dos cierres son "el mismo" si sus dos extremos distan < DUP * longitud
CIERRE_TRAMO = 5.0           # m; longitud mínima del borde recto que debe continuar fuera de cada esquina de la boca
CIERRE_ALINEA = math.cos(math.radians(30.0))   # ese borde debe quedar a <= 30° de la dirección del cierre
CIERRE_TRANSV = 0.5          # el borde del ramal debe quedar a 60°-120° del cierre (|cos| <= 0.5)
CIERRE_VECINOS_BOCA = 7      # vértices vecinos que se miran por cada esquina entrante
CIERRE_SUELTA_L = 10.0       # m; escala a la que se mide si una esquina "suelta" tiene dos bordes rectos
CIERRE_SUELTA_GIRO = math.radians(30.0)   # giro mínimo entre esos dos bordes para que cuente como esquina fuerte
CIERRE_SUELTA_TIP = math.cos(math.radians(80.0))   # cuña (ángulo entre bordes) <= 80°: punta de isla; cos > TIP
CIERRE_SUELTA_TRANSV = 0.5   # cuña de 60°-120° sin ser punta (|cos| <= TRANSV): esquina en T
CIERRE_SLIVER_COS = 0.5     # dos cierres que comparten un extremo y forman menos de 60° (cos > 0.5) son uno solo: se queda el más corto
CIERRE_SLIVER_EXT = 0.15     # "comparten extremo" si distan menos de 0.15 * el cierre más corto
CIERRE_ESTRECHO = 2.0       # en una punta con cierre a ambos lados, si uno mide mas de 2 veces el otro solo se queda el estrecho
CIERRE_DUP_SUELTA = 1.0      # un cierre de esquina suelta es repetido si sus dos extremos estan a menos de 1.0 * el cierre mayor de los de otro
CIERRE_SNAP = 1.0            # m; si el cierre cae a menos de esto de un vértice del borde opuesto, se ajusta a él
CIERRE_HIT_COS = 0.7         # el borde opuesto debe quedar a >= 45° del cierre (|cos| <= 0.7)


class _UnionFind:
    def __init__(self, n):
        self.p = list(range(n))

    def find(self, a):
        while self.p[a] != a:
            self.p[a] = self.p[self.p[a]]
            a = self.p[a]
        return a

    def union(self, a, b):
        ra, rb = self.find(a), self.find(b)
        if ra != rb:
            self.p[rb] = ra
            return True
        return False


def _vertex_index(ring):
    """Índice espacial de los vértices de un anillo (id = posición en el anillo)."""
    idx = QgsSpatialIndex()
    for i, p in enumerate(ring):
        f = QgsFeature(i)
        f.setGeometry(QgsGeometry.fromPointXY(p))
        idx.addFeature(f)
    return idx


def _closest_vertex_pairs(ring_a, ring_b, idx_b, per_vertex=3, limit=CIERRE_MAX_PRUEBAS):
    """
    Pares de vértices (d2, punto_a, punto_b) más cercanos entre dos anillos, ordenados por
    distancia. Se recorre el anillo A y se consulta el índice de B: coste |A|·log|B|.
    """
    pairs = []
    for v in ring_a:
        for j in idx_b.nearestNeighbor(v, per_vertex):
            w = ring_b[j]
            pairs.append(((v.x() - w.x()) ** 2 + (v.y() - w.y()) ** 2, v, w))
    pairs.sort(key=lambda t: t[0])
    return pairs[:limit]


def _box_gap(a, b):
    dx = max(a.xMinimum() - b.xMaximum(), b.xMinimum() - a.xMaximum(), 0.0)
    dy = max(a.yMinimum() - b.yMaximum(), b.yMinimum() - a.yMaximum(), 0.0)
    return math.hypot(dx, dy)


def _reflex_vertices(nodes):
    """
    Esquinas ENTRANTES del polígono (ángulo interior > 180°, giro >= CIERRE_ANG_MIN) de todos sus
    anillos: las esquinas de las manzanas que dan a la calle y las concavidades del contorno
    exterior. La boca de un ramal queda siempre entre dos de ellas.
    nodes[0] = anillo exterior; el resto, huecos. Devuelve ([(nodo, posición, punto)], [(longitudes
    acumuladas, perímetro) por nodo]).
    """
    pts, cums = [], []
    for ni, ring in enumerate(nodes):
        n = len(ring)
        cum = [0.0]
        area2 = 0.0
        for i in range(n):
            a, b = ring[i], ring[(i + 1) % n]
            cum.append(cum[-1] + math.hypot(b.x() - a.x(), b.y() - a.y()))
            area2 += a.x() * b.y() - b.x() * a.y()
        cums.append((cum, cum[-1]))
        if area2 == 0.0:
            continue
        sgn = 1.0 if area2 > 0 else -1.0
        for i, v in enumerate(ring):
            p, q = ring[i - 1], ring[(i + 1) % n]
            ax, ay = v.x() - p.x(), v.y() - p.y()
            bx, by = q.x() - v.x(), q.y() - v.y()
            cross = ax * by - ay * bx
            if math.atan2(abs(cross), ax * bx + ay * by) < CIERRE_ANG_MIN:
                continue
            # exterior: el interior del polígono está dentro del anillo; huecos: fuera
            reflex = (cross * sgn < 0) if ni == 0 else (cross * sgn > 0)
            if reflex:
                pts.append((ni, i, v))
    return pts, cums


def _point_along(ring, cum, total, i, delta):
    """Punto del anillo a 'delta' m (con signo) de camino desde el vértice i (el anillo es cerrado)."""
    n = len(ring)
    t = (cum[i] + delta) % total
    k = min(max(bisect.bisect_right(cum, t) - 1, 0), n - 1)
    a, b = ring[k], ring[(k + 1) % n]
    seg = cum[k + 1] - cum[k]
    f = (t - cum[k]) / seg if seg > 0 else 0.0
    return a.x() + f * (b.x() - a.x()), a.y() + f * (b.y() - a.y())


def _mouth_corner_ok(ring, cum, total, i, away):
    """
    La esquina i es esquina de una BOCA real si en ella se cruzan DOS bordes largos:
      - uno que, por fuera del cierre, sigue recto en la dirección del cierre (el borde del vial
        principal que pasa de largo), y
      - otro transversal al cierre (el borde del ramal).
    En un escalón o un quiebro del contorno uno de los dos bordes mide solo unos metros o no queda
    transversal, y no es una boca.
    away = (ux, uy, d): vector unitario del cierre apuntando desde el otro extremo hacia esta esquina, y su longitud.
    """
    L = min(max(CIERRE_TRAMO, 0.75 * away[2]), 25.0)
    if total < 3.0 * L:
        return True                           # anillo diminuto: no se puede juzgar, no se filtra
    v = ring[i]
    roles = []
    for sgn in (1.0, -1.0):
        px, py = _point_along(ring, cum, total, i, sgn * L)
        ux, uy = px - v.x(), py - v.y()
        ul = math.hypot(ux, uy)
        if ul < 0.7 * L:
            roles.append((False, False))      # el borde se retuerce: ni recto ni transversal
            continue
        c = (ux * away[0] + uy * away[1]) / ul
        roles.append((c >= CIERRE_ALINEA, abs(c) <= CIERRE_TRANSV))
    return (roles[0][0] and roles[1][1]) or (roles[1][0] and roles[0][1])


def _prune_sliver_chords(chords):
    """
    Quita los cierres redundantes de un mismo entronque: dos cierres que comparten un extremo (la misma
    esquina entrante) y forman entre sí menos de 60° dejan entre ambos una cuña estrecha y cierran, en la
    práctica, la misma boca. Se conserva el más corto. Los cierres de una X (90° entre ellos) y los de una
    punta de isla (opuestos, 180°) no se tocan.
    chords = [(pa, pb, nodo_a, nodo_b)] con pa, pb como QgsPointXY; devuelve la lista filtrada (mismo orden).
    """
    def ln(c):
        return math.hypot(c[0].x() - c[1].x(), c[0].y() - c[1].y())

    kept = []
    for c in sorted(chords, key=ln):
        lc = ln(c)
        redundant = False
        for k in kept:
            lk = ln(k)
            r = CIERRE_SLIVER_EXT * min(lc, lk)
            for pa, pb in ((c[0], c[1]), (c[1], c[0])):          # pa: el extremo candidato a compartido
                for ka, kb in ((k[0], k[1]), (k[1], k[0])):
                    if math.hypot(pa.x() - ka.x(), pa.y() - ka.y()) <= r:
                        ux, uy = pb.x() - pa.x(), pb.y() - pa.y()
                        vx, vy = kb.x() - ka.x(), kb.y() - ka.y()
                        if (ux * vx + uy * vy) / (lc * lk) > CIERRE_SLIVER_COS:
                            redundant = True
        if not redundant:
            kept.append(c)
    keep_ids = {id(c) for c in kept}
    return [c for c in chords if id(c) in keep_ids]


def _loose_corner_chords(nodes, pts, cums, chords, contains_seg, edges_near):
    """
    Cierres para las esquinas entrantes "sueltas": las que quedan sin pareja en _mouth_chords porque el
    otro lado de la boca no tiene esquina (la punta de una isla triangular en una Y, la horquilla de un
    vial, un ramal cuyo lado opuesto es recto). Sin este paso solo se cerraba el entronque que tenía dos
    esquinas enfrentadas y el resto de la Y seguía abierto, de modo que las envolventes volvían a salir.

    Cada esquina fuerte suelta (dos bordes rectos a CIERRE_SUELTA_L m con un giro >= CIERRE_SUELTA_GIRO)
    lanza una línea hasta el borde opuesto:
      - punta de isla (cuña <= 80°): línea perpendicular al eje del brazo, a ambos lados, hasta el borde opuesto;
      - esquina en T (cuña de 60°-120°): prolonga el borde recto que pasa de largo, cruzando el ramal, y solo
        se acepta si acaba en un vértice del otro lado (si no, es el vial principal, que no se cierra).
    El cierre se acepta si mide <= CIERRE_ANCHO_MAX, va por dentro del polígono, no cruza otro cierre,
    el borde opuesto queda transversal y no es "el mismo" cierre que uno ya existente. Si cae a menos de
    CIERRE_SNAP de un vértice del borde opuesto se ajusta a él; si no (solo en puntas de isla), acaba sobre el borde.

    contains_seg(p, q) -> bool: el segmento p-q (tuplas x, y) está dentro del polígono.
    edges_near(xmin, ymin, xmax, ymax) -> [(nodo, i)]: aristas (i -> i+1) de los anillos cuya caja corta esa zona.
    Devuelve [(pa, pb, nodo_a, nodo_b)] con pa, pb como (x, y), solo los cierres nuevos.
    """
    def seg_cross(p, q, a, b):
        # p-q es una línea y a-b una arista: devuelve t (0..1 sobre p-q) y s (0..1 sobre a-b), o None
        rx, ry = q[0] - p[0], q[1] - p[1]
        sx, sy = b[0] - a[0], b[1] - a[1]
        den = rx * sy - ry * sx
        if abs(den) < 1e-12:
            return None
        qx, qy = a[0] - p[0], a[1] - p[1]
        t = (qx * sy - qy * sx) / den
        s = (qx * ry - qy * rx) / den
        if t < 0.0 or t > 1.0 or s < -1e-9 or s > 1.0 + 1e-9:
            return None
        return t, s

    def crosses(p, q, a, b):
        # cruce propio (los extremos que solo se tocan no cuentan)
        r = seg_cross(p, q, a, b)
        return r is not None and 1e-6 < r[0] < 1.0 - 1e-6 and 1e-6 < r[1] < 1.0 - 1e-6

    used = []                                   # puntos (x, y) que ya son extremo de algún cierre
    for pa, pb, _na, _nb in chords:
        used.append((pa.x(), pa.y()))
        used.append((pb.x(), pb.y()))
    lines = [((pa.x(), pa.y()), (pb.x(), pb.y())) for pa, pb, _na, _nb in chords]

    def near_used(v, r):
        return any(math.hypot(v[0] - u[0], v[1] - u[1]) <= r for u in used)

    out = []
    L = CIERRE_SUELTA_L
    for (ni, i, vp) in pts:
        v = (vp.x(), vp.y())
        if near_used(v, 0.5 * CIERRE_TRAMO):
            continue                            # esta esquina (o su redondeo) ya tiene cierre
        ring = nodes[ni]
        cum, total = cums[ni]
        if total < 3.0 * L:
            continue
        es = []
        for sgn in (1.0, -1.0):
            px, py = _point_along(ring, cum, total, i, sgn * L)
            ux, uy = px - v[0], py - v[1]
            ul = math.hypot(ux, uy)
            if ul < 0.85 * L:
                es = None                       # borde retorcido o con escalón: no es una esquina franca
                break
            es.append((ux / ul, uy / ul))
        if not es:
            continue
        e1, e2 = es
        c12 = e1[0] * e2[0] + e1[1] * e2[1]
        if math.pi - math.acos(max(-1.0, min(1.0, c12))) < CIERRE_SUELTA_GIRO:
            continue                            # casi recto: no es una esquina
        tip = c12 > CIERRE_SUELTA_TIP
        if tip:                                 # punta aguda: perpendicular al eje del brazo (se cierra a ambos lados)
            bx, by = e1[0] + e2[0], e1[1] + e2[1]
            bl = math.hypot(bx, by)
            if bl < 1e-9:
                continue
            nx, ny = -by / bl, bx / bl
            dirs = [(nx, ny), (-nx, -ny)]
            # punta redondeada: los cierres salen del vertice mas adelantado en el eje del brazo (-b), no de un
            # vertice del redondeo, cuyos rayos perpendiculares atravesarian el propio recinto de la isla
            ax_, ay_ = -bx / bl, -by / bl
            best_k, best_dot = i, v[0] * ax_ + v[1] * ay_
            m = len(ring)
            for step in (1, -1):
                walked, k = 0.0, i
                for _ in range(m):
                    k2 = (k + step) % m
                    walked += math.hypot(ring[k2].x() - ring[k].x(), ring[k2].y() - ring[k].y())
                    if walked > 3.0:
                        break
                    k = k2
                    dot = ring[k].x() * ax_ + ring[k].y() * ay_
                    if dot > best_dot + 1e-9:
                        best_k, best_dot = k, dot
            if best_k != i:
                i = best_k
                v = (ring[i].x(), ring[i].y())
                if near_used(v, 0.5 * CIERRE_TRAMO):
                    continue
        elif abs(c12) <= CIERRE_SUELTA_TRANSV:  # esquina en T con pareja perdida: se prolonga cada borde recto
            dirs = [(-e1[0], -e1[1]), (-e2[0], -e2[1])]
        else:
            continue                            # ángulo obtuso: un quiebro, no una boca

        cands = []
        for d in dirs:
            far = (v[0] + d[0] * CIERRE_ANCHO_MAX, v[1] + d[1] * CIERRE_ANCHO_MAX)
            near_pt = (v[0] + d[0] * 0.05, v[1] + d[1] * 0.05)
            best = None
            for (nj, j) in edges_near(min(v[0], far[0]), min(v[1], far[1]), max(v[0], far[0]), max(v[1], far[1])):
                n = len(nodes[nj])
                if nj == ni:
                    arc0 = abs(cum[i] - cum[j])
                    if min(arc0, total - arc0) < L:
                        continue                # las aristas de la propia esquina (y su redondeo)
                a, b = nodes[nj][j], nodes[nj][(j + 1) % n]
                a, b = (a.x(), a.y()), (b.x(), b.y())
                r = seg_cross(near_pt, far, a, b)
                if r is None:
                    continue
                hx, hy = near_pt[0] + r[0] * (far[0] - near_pt[0]), near_pt[1] + r[0] * (far[1] - near_pt[1])
                dist = math.hypot(hx - v[0], hy - v[1])
                if best is None or dist < best[0]:
                    best = (dist, nj, j, a, b, (hx, hy))
            if best is None or best[0] < 0.5:
                continue
            dist, nj, j, a, b, hit = best
            el = math.hypot(b[0] - a[0], b[1] - a[1])
            if el < 1e-9 or abs(((b[0] - a[0]) * d[0] + (b[1] - a[1]) * d[1]) / el) > CIERRE_HIT_COS:
                continue                        # el borde opuesto no queda transversal al cierre
            if nj == ni:                        # mismo anillo: que no sea el propio lado o una curva
                m = len(nodes[nj])
                arc = abs(cum[i] - cum[(j + 1) % m])
                if min(arc, total - arc) <= CIERRE_ARCO * dist:
                    continue
            end, snapped = hit, False
            for w in (a, b):
                if math.hypot(hit[0] - w[0], hit[1] - w[1]) <= CIERRE_SNAP:
                    end, snapped = w, True      # se ajusta al vértice: no se crean vértices nuevos
                    break
            if not tip and not snapped:
                continue                        # en T sin vértice enfrente es el vial principal que pasa de largo
            length = math.hypot(end[0] - v[0], end[1] - v[1])
            if length <= 1e-6 or length > CIERRE_ANCHO_MAX:
                continue
            # por dentro del polígono (con un pelo de margen en los extremos, que están sobre el contorno)
            ux, uy = (end[0] - v[0]) / length, (end[1] - v[1]) / length
            eps = min(0.02, 0.1 * length)
            if not contains_seg((v[0] + ux * eps, v[1] + uy * eps), (end[0] - ux * eps, end[1] - uy * eps)):
                continue
            cands.append((length, v, end, nj))
        if not cands:
            continue
        cands.sort(key=lambda t: t[0])
        if tip and len(cands) > 1 and cands[-1][0] > CIERRE_ESTRECHO * cands[0][0]:
            cands = cands[:1]                   # un lado es un vial estrecho y el otro cruza el vial ancho: se cierra el estrecho
        for length, pa, pb, nj in cands:
            if not tip and length > CIERRE_PAR * cands[0][0]:
                break                           # en T basta el cierre más corto (o varios iguales, como en una X)
            if any(crosses(pa, pb, la, lb) for la, lb in lines):
                continue
            dup = False
            for la, lb in lines:
                r = CIERRE_DUP_SUELTA * max(length, math.hypot(la[0] - lb[0], la[1] - lb[1]))
                same = (math.hypot(pa[0] - la[0], pa[1] - la[1]) < r and math.hypot(pb[0] - lb[0], pb[1] - lb[1]) < r)
                swap = (math.hypot(pa[0] - lb[0], pa[1] - lb[1]) < r and math.hypot(pb[0] - la[0], pb[1] - la[1]) < r)
                if same or swap:
                    dup = True
                    break
            if dup:
                continue
            lines.append((pa, pb))
            used.append(pa)
            used.append(pb)
            out.append((pa, pb, ni, nj))
    return out


def _mouth_chords(nodes, pg_engine, tol):
    """
    Cierres en las bocas de los ramales: une pares de esquinas entrantes MUTUAMENTE más próximas
    (<= CIERRE_ANCHO_MAX) cuyo segmento va por dentro del polígono. En un entronque en T se cierra el
    ramal contra el vial principal (el lado opuesto del principal no tiene esquinas); en un cruce
    en X, las cuatro bocas. De los cierres casi paralelos (esquinas redondeadas) se queda el más corto.
    Después se cierran también las esquinas sueltas sin pareja (ver _loose_corner_chords).
    Devuelve [(pa, pb, nodo_a, nodo_b)].
    """
    pts, cums = _reflex_vertices(nodes)
    if len(pts) < 2:
        return []
    index = QgsSpatialIndex()
    for k, (_ni, _i, v) in enumerate(pts):
        f = QgsFeature(k)
        f.setGeometry(QgsGeometry.fromPointXY(v))
        index.addFeature(f)

    valid = {}

    def pair_ok(k, j, d):
        key = (k, j) if k < j else (j, k)
        if key not in valid:
            nk, ik, vk = pts[k]
            nj, ij, vj = pts[j]
            ok = True
            if nk == nj:                       # mismo anillo: que no sea el propio lado o una curva
                cum, total = cums[nk]
                arc = abs(cum[ik] - cum[ij])
                if min(arc, total - arc) <= CIERRE_ARCO * d:
                    ok = False
            if ok:
                # boca real: el contorno sigue alineado con el cierre fuera de AMBAS esquinas
                ux, uy = (vk.x() - vj.x()) / d, (vk.y() - vj.y()) / d
                cum_k, tot_k = cums[nk]
                cum_j, tot_j = cums[nj]
                ok = (_mouth_corner_ok(nodes[nk], cum_k, tot_k, ik, (ux, uy, d)) and
                      _mouth_corner_ok(nodes[nj], cum_j, tot_j, ij, (-ux, -uy, d)))
            if ok:
                seg = QgsGeometry.fromPolylineXY([vk, vj])
                ok = pg_engine.contains(seg.constGet())
            valid[key] = ok
        return valid[key]

    cand = {}                                   # k -> [(d, j)] ordenado, solo cierres válidos
    for k, (_ni, _i, v) in enumerate(pts):
        lst = []
        for j in index.nearestNeighbor(v, CIERRE_VECINOS_BOCA):
            if j == k:
                continue
            w = pts[j][2]
            d = math.hypot(v.x() - w.x(), v.y() - w.y())
            if d <= tol or d > CIERRE_ANCHO_MAX:
                continue
            if pair_ok(k, j, d):
                lst.append((d, j))
        lst.sort()
        cand[k] = lst

    edges = []
    for k, lst in cand.items():
        if not lst:
            continue
        dk = lst[0][0]
        for d, j in lst:
            if d > CIERRE_PAR * dk:
                break
            if j > k and cand.get(j) and d <= CIERRE_PAR * cand[j][0][0] and any(jj == k for _d, jj in cand[j]):
                edges.append((d, k, j))
    edges.sort()

    chords, geoms = [], []
    cidx = QgsSpatialIndex()
    for d, k, j in edges:
        pa, pb = pts[k][2], pts[j][2]
        seg = QgsGeometry.fromPolylineXY([pa, pb])
        box = QgsRectangle(seg.boundingBox())
        box.grow(d)
        dup = False
        for c in cidx.intersects(box):
            ca, cb = chords[c][0], chords[c][1]
            if geoms[c].crosses(seg):
                dup = True
                break
            r = CIERRE_DUP * d
            same = (math.hypot(pa.x() - ca.x(), pa.y() - ca.y()) < r and math.hypot(pb.x() - cb.x(), pb.y() - cb.y()) < r)
            swap = (math.hypot(pa.x() - cb.x(), pa.y() - cb.y()) < r and math.hypot(pb.x() - ca.x(), pb.y() - ca.y()) < r)
            if same or swap:                    # casi paralelo a un cierre más corto ya aceptado
                dup = True
                break
        if dup:
            continue
        cf = QgsFeature(len(chords))
        cf.setGeometry(seg)
        cidx.addFeature(cf)
        chords.append((pa, pb, pts[k][0], pts[j][0]))
        geoms.append(seg)

    # esquinas sueltas (punta de isla, horquilla, ramal con un solo lado quebrado): también se cierran
    seg_ids = []
    seg_index = QgsSpatialIndex()
    for ni, ring in enumerate(nodes):
        n = len(ring)
        for i in range(n):
            f = QgsFeature(len(seg_ids))
            f.setGeometry(QgsGeometry.fromPolylineXY([ring[i], ring[(i + 1) % n]]))
            seg_index.addFeature(f)
            seg_ids.append((ni, i))

    def edges_near(x0, y0, x1, y1):
        return [seg_ids[e] for e in seg_index.intersects(QgsRectangle(x0, y0, x1, y1))]

    def contains_seg(p, q):
        g = QgsGeometry.fromPolylineXY([QgsPointXY(p[0], p[1]), QgsPointXY(q[0], q[1])])
        return pg_engine.contains(g.constGet())

    for pa, pb, na, nb in _loose_corner_chords(nodes, pts, cums, chords, contains_seg, edges_near):
        chords.append((QgsPointXY(pa[0], pa[1]), QgsPointXY(pb[0], pb[1]), na, nb))
    return _prune_sliver_chords(chords)


def _close_polygon(poly, rest_index, rest_pts, tol):
    """
    poly = [anillo exterior, huecos...] (listas de QgsPointXY cerradas) de un vial o río.
    1) Bocas: cierra cada ramal en su entronque (ver _mouth_chords).
    2) Huecos: cualquier hueco con recintos dentro que siga sin conectar con el exterior (p. ej. una
       calle que rodea una sola manzana, sin ramales) se une al exterior o a otro hueco con la
       conexión más corta por dentro del vial.
    Un polígono cuyos anillos quedan todos conectados por cierres ya no tiene islas: cada trozo es simplemente
    conexo. Los cierres son vértice a vértice (no crean vértices nuevos en los contornos).
    Devuelve (bocas, cierres_hueco, n_huecos_con_recintos, n_huecos_vacios, n_fallos).
    """
    rings = [r[:-1] for r in poly if len(r) >= 4]
    if not rings:
        return [], [], 0, 0, 0
    pg = QgsGeometry.fromPolygonXY(poly)
    pg_engine = QgsGeometry.createGeometryEngine(pg.constGet())
    pg_engine.prepareGeometry()

    # --- qué huecos envuelven recintos (los demás son vacíos: no se tocan)
    nodes = [rings[0]]                 # nodo 0 = exterior
    n_vacios = 0
    for ring in rings[1:]:
        hole = QgsGeometry.fromPolygonXY([ring + [ring[0]]])
        eng = QgsGeometry.createGeometryEngine(hole.constGet())
        eng.prepareGeometry()
        inside = False
        for fid in rest_index.intersects(hole.boundingBox()):
            if eng.intersects(QgsGeometry.fromPointXY(rest_pts[fid]).constGet()):
                inside = True
                break
        if inside:
            nodes.append(ring)
        else:
            n_vacios += 1
    n_env = len(nodes) - 1

    uf = _UnionFind(len(nodes))
    cut_geoms = []
    cut_index = QgsSpatialIndex()

    # --- 1) bocas de ramales
    mouths = []
    for pa, pb, na, nb in _mouth_chords(nodes, pg_engine, tol):
        seg = QgsGeometry.fromPolylineXY([pa, pb])
        cf = QgsFeature(len(cut_geoms))
        cf.setGeometry(seg)
        cut_index.addFeature(cf)
        cut_geoms.append(seg)
        mouths.append((pa, pb))
        uf.union(na, nb)

    if n_env == 0:
        return mouths, [], 0, n_vacios, 0

    # --- 2) huecos que siguen aislados
    boxes = [QgsGeometry.fromPolylineXY(r + [r[0]]).boundingBox() for r in nodes]
    box_index = QgsSpatialIndex()
    for i, b in enumerate(boxes):
        f = QgsFeature(i)
        f.setGeometry(QgsGeometry.fromRect(b))
        box_index.addFeature(f)
    vidx = {}

    def vindex(i):
        if i not in vidx:
            vidx[i] = _vertex_index(nodes[i])
        return vidx[i]

    def pairs_between(h, c):
        # se recorre el anillo con menos vértices y se consulta el índice del otro
        if len(nodes[h]) <= len(nodes[c]):
            return _closest_vertex_pairs(nodes[h], nodes[c], vindex(c))
        return [(d, pa, pb) for d, pb, pa in _closest_vertex_pairs(nodes[c], nodes[h], vindex(h))]

    pending = [h for h in range(1, len(nodes)) if uf.find(h) != uf.find(0)]
    holes_cuts = []

    def try_connect(h, c, pr):
        for d2, pa, pb in pr:
            if d2 <= tol * tol:
                uf.union(h, c)                 # ya se tocan en un vértice: unidos sin cortar
                return True
            seg = QgsGeometry.fromPolylineXY([pa, pb])
            if not pg_engine.contains(seg.constGet()):
                continue                       # se sale del polígono (cruza un hueco o el borde)
            if any(cut_geoms[k].crosses(seg) for k in cut_index.intersects(seg.boundingBox())):
                continue                       # cruzaría otro cierre
            cf = QgsFeature(len(cut_geoms))
            cf.setGeometry(seg)
            cut_index.addFeature(cf)
            cut_geoms.append(seg)
            holes_cuts.append((pa, pb))
            uf.union(h, c)
            return True
        return False

    edges = []
    for h in pending:
        found = []
        for r in CIERRE_RADIOS:
            box = QgsRectangle(boxes[h])
            box.grow(r)
            found = [n for n in box_index.intersects(box) if n not in (0, h)]
            if len(found) >= 2:
                break
        found.sort(key=lambda n: _box_gap(boxes[h], boxes[n]))
        for c in [0] + found[:CIERRE_VECINOS]:
            pr = pairs_between(h, c)
            if pr:
                edges.append((pr[0][0], h, c, pr))
    edges.sort(key=lambda e: e[0])
    for _w, h, c, pr in edges:
        if uf.find(h) != uf.find(c):
            try_connect(h, c, pr)

    # --- rezagados: se prueban contra el exterior sin límite de radio
    n_fail = 0
    for h in pending:
        if uf.find(h) != uf.find(0) and not try_connect(h, 0, pairs_between(h, 0)):
            n_fail += 1
    return mouths, holes_cuts, n_env, n_vacios, n_fail


def close_envelopes(poly_path, log=None, tol=TOLERANCE):
    """
    Corta los recintos V (viales, MiID 9000) y H (hidrografía, MiID 9300) con líneas de cierre
    para que ningún ramal quede envolviendo otros ni masas de recintos:
      - boca de cada ramal: línea entre las dos esquinas entrantes del entronque (el ramal queda
        cerrado contra el vial principal; en un cruce en X, los cuatro brazos);
      - hueco con recintos dentro que sigue aislado: línea al exterior (o a otro hueco).
    Todas las líneas van a la capa 'Aux_Cierres' y son vértice a vértice por dentro del vial: no crean
    vértices nuevos en los contornos, así que no rompen la deduplicación con las fincas vecinas.
    Devuelve (segmentos [(x1, y1, x2, y2, 'Aux_Cierres')], estadísticas).
    Requiere MiID 9000/9300, es decir, haber indicado el campo TIPO.
    """
    log = log or (lambda m: None)
    stats = {'poligonos': 0, 'bocas': 0, 'huecos': 0, 'cierres_hueco': 0, 'vacios': 0, 'fallos': 0, 'errores': 0}
    layer = QgsVectorLayer(poly_path, "p", "ogr")
    if not layer.isValid():
        raise Exception(f"No se pudo abrir {poly_path}")
    fields = layer.fields()
    i_miid, ix, iy = (fields.indexFromName(n) for n in (FIELD_MIID, FIELD_X, FIELD_Y))
    if i_miid < 0:
        return [], stats

    vh = []                                  # (MiID, [polígonos]) de V/H
    rest_index = QgsSpatialIndex()
    rest_pts = {}
    for f in layer.getFeatures():
        g = f.geometry()
        if g is None or g.isNull() or g.isEmpty() or g.type() != QgsWkbTypes.PolygonGeometry:
            continue
        miid = _miid_text(f, i_miid)
        if miid in ENVOLVENTE_MIIDS:
            polys = g.asMultiPolygon() if g.isMultipart() else [g.asPolygon()]
            polys = [pl for pl in polys if pl]
            if polys:
                vh.append((miid, polys))
            continue
        # recinto "normal": su punto interior (X, Y ya calculados) sirve para saber si está dentro de un hueco
        pt = None
        if ix >= 0 and iy >= 0 and not _is_null(f.attribute(ix)) and not _is_null(f.attribute(iy)):
            pt = QgsPointXY(float(f.attribute(ix)), float(f.attribute(iy)))
        else:
            ps = g.pointOnSurface()
            if ps is not None and not ps.isNull():
                pt = ps.asPoint()
        if pt is None:
            continue
        pf = QgsFeature(f.id())
        pf.setGeometry(QgsGeometry.fromPointXY(pt))
        rest_index.addFeature(pf)
        rest_pts[f.id()] = pt

    segments = []
    for miid, polys in vh:
        for poly in polys:
            try:
                mouths, hcuts, n_env, n_vac, n_fail = _close_polygon(poly, rest_index, rest_pts, tol)
            except Exception as e:           # un polígono raro no debe parar el proceso
                stats['errores'] += 1
                log(f"  Cierres: polígono {miid} omitido por error: {e}")
                continue
            stats['vacios'] += n_vac
            stats['huecos'] += n_env
            stats['fallos'] += n_fail
            if mouths or hcuts:
                stats['poligonos'] += 1
            stats['bocas'] += len(mouths)
            stats['cierres_hueco'] += len(hcuts)
            for pa, pb in mouths + hcuts:
                segments.append((pa.x(), pa.y(), pb.x(), pb.y(), CIERRES_LAYER))
    return segments, stats


# --------------------------------------------------------------------------- #
# Paso 2: polígonos -> segmentos (en memoria)
# --------------------------------------------------------------------------- #
def polygon_segments(poly_path, default_code=None):
    """
    Lista de segmentos (x1, y1, x2, y2, CODELEM) de todos los anillos de los polígonos.
    Equivale a polygonstolines + explodelines, pero sin escribir archivos intermedios.
    Se omiten segmentos de longitud cero.
    """
    layer = QgsVectorLayer(poly_path, "p", "ogr")
    if not layer.isValid():
        raise Exception(f"No se pudo abrir {poly_path}")
    idx = layer.fields().indexFromName('CODELEM')
    segs = []
    append = segs.append
    for feat in layer.getFeatures():
        geom = feat.geometry()
        if geom is None or geom.isNull():
            continue
        if default_code is not None:
            code = default_code
        else:
            v = feat.attribute(idx) if idx >= 0 else None
            code = '' if _is_null(v) else str(v).strip().upper()
        for poly in geom.asMultiPolygon() if geom.isMultipart() else [geom.asPolygon()]:
            for ring in poly:
                if len(ring) < 2:
                    continue
                px, py = ring[0].x(), ring[0].y()
                for pt in ring[1:]:
                    qx, qy = pt.x(), pt.y()
                    if qx != px or qy != py:
                        append((px, py, qx, qy, code))
                    px, py = qx, qy
    return segs


# --------------------------------------------------------------------------- #
# Paso 3: deduplicación con tolerancia (rejilla hash)
# --------------------------------------------------------------------------- #
def _dist_pt_seg(px, py, ax, ay, bx, by):
    dx, dy = bx - ax, by - ay
    l2 = dx * dx + dy * dy
    if l2 == 0.0:
        return math.hypot(px - ax, py - ay)
    t = ((px - ax) * dx + (py - ay) * dy) / l2
    if t <= 0.0:
        return math.hypot(px - ax, py - ay)
    if t >= 1.0:
        return math.hypot(px - bx, py - by)
    return math.hypot(px - (ax + t * dx), py - (ay + t * dy))


def _same_segment(a, b, tol):
    """
    Distancia de Hausdorff discreta <= tol entre dos segmentos de 2 vértices
    (es el mismo criterio que geom.hausdorffDistance de GEOS para estos casos).
    """
    return (_dist_pt_seg(a[0], a[1], b[0], b[1], b[2], b[3]) <= tol and
            _dist_pt_seg(a[2], a[3], b[0], b[1], b[2], b[3]) <= tol and
            _dist_pt_seg(b[0], b[1], a[0], a[1], a[2], a[3]) <= tol and
            _dist_pt_seg(b[2], b[3], a[0], a[1], a[2], a[3]) <= tol)


def dedupe_segments(segs, has_buildings, tol=TOLERANCE):
    """
    Agrupa segmentos coincidentes (dentro de tol) y devuelve [(x1,y1,x2,y2,LAYER)].
    Mismo resultado que la versión anterior, en tiempo ~lineal: se indexa el punto
    medio en una rejilla de celda 2*tol y solo se comparan segmentos de celdas vecinas.
    """
    priority = PRIORITY_WITH_BUILDINGS if has_buildings else PRIORITY_NO_BUILDINGS
    cell = 2.0 * tol
    inv = 1.0 / cell
    grid = {}
    for i, s in enumerate(segs):
        key = (int(math.floor((s[0] + s[2]) * 0.5 * inv)),
               int(math.floor((s[1] + s[3]) * 0.5 * inv)))
        grid.setdefault(key, []).append(i)

    done = bytearray(len(segs))
    out = []
    for i, s in enumerate(segs):
        if done[i]:
            continue
        cx = int(math.floor((s[0] + s[2]) * 0.5 * inv))
        cy = int(math.floor((s[1] + s[3]) * 0.5 * inv))
        codes = set()
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                bucket = grid.get((cx + dx, cy + dy))
                if not bucket:
                    continue
                for j in bucket:
                    if done[j]:
                        continue
                    if j == i or _same_segment(s, segs[j], tol):
                        done[j] = 1
                        if segs[j][4]:
                            codes.add(segs[j][4])
        out.append((s[0], s[1], s[2], s[3], layer_value(codes, priority)))
    return out


def layer_value(codes, priority):
    """Valor del campo LAYER a partir del conjunto de CODELEM de las líneas coincidentes."""
    codes = set(codes)
    ordered = []
    for p in priority:
        if p in codes:
            ordered.append(p)
            codes.discard(p)
    ordered.extend(sorted(codes))
    if not ordered:
        return ""
    if ordered[0] in ('H', 'V', 'E'):
        return ordered[0]
    return "_".join(ordered)


def write_lines(segments, out_path, crs):
    """Escribe los segmentos con su campo LAYER en un shapefile de líneas."""
    fields = QgsFields()
    fields.append(QgsField("LAYER", QVariant.String, '', 254))
    _remove_shapefile(out_path)
    writer = _create_writer(
        out_path, fields, QgsWkbTypes.LineString, crs)
    if writer.hasError():
        raise Exception(f"No se pudo crear {out_path}: {writer.errorMessage()}")
    for x1, y1, x2, y2, lay in segments:
        f = QgsFeature(fields)
        f.setGeometry(QgsGeometry.fromPolylineXY([QgsPointXY(x1, y1), QgsPointXY(x2, y2)]))
        f.setAttribute(0, lay)
        writer.addFeature(f)
    writer.close()
    return out_path


# --------------------------------------------------------------------------- #
# Paso 4: fusión de líneas contiguas por LAYER
# --------------------------------------------------------------------------- #
def dissolve_by_layer(lines_path, out_path):
    import processing
    tmp = os.path.splitext(out_path)[0] + "_dissolved.shp"
    _remove_shapefile(tmp)
    _remove_shapefile(out_path)
    processing.run("native:dissolve", {'INPUT': lines_path, 'FIELD': ['LAYER'], 'OUTPUT': tmp})
    processing.run("native:multiparttosingleparts", {'INPUT': tmp, 'OUTPUT': out_path})
    return out_path
