
import processing
import os

class GeometryFixer:
    def __init__(self, temp_folder):
        self.temp_folder = temp_folder

    def fix(self, layer, output_name):
        output_path = os.path.normpath(os.path.join(self.temp_folder, f"{output_name}.shp"))
        
        params = {
            'INPUT': layer,
            'OUTPUT': output_path
        }
        
        result = processing.run("native:fixgeometries", params)
        return result['OUTPUT']
