"""
Heurística para distinguir, entre los recintos TIPO = E de ZONACON, los que son
EDIFICACIONES (MiID 9100) de los que son FINCAS EXCLUIDAS (MiID 9200).

Se basa solo en la forma (no hay otro dato fiable):
  - edificación: tamaño razonable, muy regular (casi un rectángulo), pocos vértices,
    sin huecos, no demasiado alargada.
  - finca excluida: grande y/o irregular, muchos vértices, con huecos, alargada.

Cada recinto recibe una puntuación 0..1 (1 = parece edificación). Todos los umbrales
son constantes de este archivo, para poder ajustarlos con datos reales.
Este módulo no importa qgis: la parte de puntuación se puede probar aislada.
"""

SIMPLIFY_TOL = 0.30   # m; se simplifica antes de contar vértices (quita ruido de digitalización)

# Tamaño (m²): hasta AREA_OK la edificación es plausible; a partir de AREA_MAX ya no
AREA_MIN = 6.0
AREA_OK = 1500.0
AREA_MAX = 15000.0
# Rectangularidad = área / área del rectángulo orientado mínimo que la contiene
RECT_OK = 0.92
RECT_BAD = 0.70
# Vértices tras simplificar
VERTS_OK = 8
VERTS_BAD = 24
# Elongación (lado largo / lado corto)
ASPECT_OK = 5.0
ASPECT_BAD = 12.0

WEIGHTS = {'area': 0.30, 'rect': 0.30, 'verts': 0.20, 'holes': 0.10, 'aspect': 0.10}

# Puntuación >= SCORE_BUILDING -> edificación; <= SCORE_FINCA -> finca excluida;
# en medio -> DUDOSA (se decide con SCORE_DECIDE y se marca para revisión).
SCORE_BUILDING = 0.70
SCORE_FINCA = 0.40
SCORE_DECIDE = 0.55

# Topes: una forma perfecta no basta si el tamaño es de finca, si es una franja
# muy alargada o si tiene huecos; esos casos quedan como mucho en "dudosa".
CAP_AREA_DOUBTFUL = 5000.0    # área >= esto: la puntuación no pasa de CAP_DOUBTFUL
CAP_AREA_FINCA = 20000.0      # área >= esto: no pasa de CAP_FINCA
CAP_DOUBTFUL = 0.60
CAP_FINCA = 0.35


def _ramp(value, good, bad):
    """1 si value está en 'good' o mejor, 0 si está en 'bad' o peor, lineal entre medias."""
    if good < bad:
        if value <= good:
            return 1.0
        if value >= bad:
            return 0.0
        return (bad - value) / (bad - good)
    if value >= good:
        return 1.0
    if value <= bad:
        return 0.0
    return (value - bad) / (good - bad)


def building_score(area, rect, verts, holes, aspect):
    """Devuelve (puntuación 0..1, motivo en texto)."""
    parts = {
        'area': 0.5 if area < AREA_MIN else _ramp(area, AREA_OK, AREA_MAX),
        'rect': _ramp(rect, RECT_OK, RECT_BAD),
        'verts': _ramp(verts, VERTS_OK, VERTS_BAD),
        'holes': 1.0 if holes == 0 else 0.0,
        'aspect': _ramp(aspect, ASPECT_OK, ASPECT_BAD),
    }
    score = sum(WEIGHTS[k] * v for k, v in parts.items())
    if area >= CAP_AREA_FINCA:
        score = min(score, CAP_FINCA)
    elif area >= CAP_AREA_DOUBTFUL or holes or aspect >= ASPECT_BAD:
        score = min(score, CAP_DOUBTFUL)

    pro, con = [], []
    (pro if parts['area'] >= 0.99 else con if parts['area'] <= 0.3 else []).append(f"área {area:,.2f} m²")
    (pro if parts['rect'] >= 0.8 else con if parts['rect'] <= 0.3 else []).append(f"rectangularidad {rect:.2f}")
    (pro if parts['verts'] >= 0.8 else con if parts['verts'] <= 0.3 else []).append(f"{verts} vértices")
    if holes:
        con.append(f"{holes} hueco(s)")
    if parts['aspect'] <= 0.3:
        con.append(f"alargada {aspect:.1f}:1")
    reason = []
    if pro:
        reason.append("de edificación: " + ", ".join(pro))
    if con:
        reason.append("de finca: " + ", ".join(con))
    return score, "; ".join(reason)


def decide(score):
    """(MiID sugerido, dudosa?) a partir de la puntuación."""
    miid = '9100' if score >= SCORE_DECIDE else '9200'
    doubtful = SCORE_FINCA < score < SCORE_BUILDING
    return miid, doubtful


def polygon_metrics(part):
    """
    Métricas de un polígono simple (QgsGeometry). Se asume CRS en metros.
    Devuelve (area, rect, verts, holes, aspect).
    """
    area = part.area()
    poly = part.asPolygon()
    holes = max(len(poly) - 1, 0)

    rect, aspect = 0.5, 1.0
    try:
        _g, obb_area, _ang, w, h = part.orientedMinimumBoundingBox()
        if obb_area and obb_area > 0:
            rect = min(area / obb_area, 1.0)
        lo, hi = min(w, h), max(w, h)
        aspect = (hi / lo) if lo > 0 else 99.0
    except Exception:
        pass

    ring = poly[0] if poly else []
    try:
        simp = part.simplify(SIMPLIFY_TOL)
        sp = simp.asPolygon() if simp is not None and not simp.isNull() else []
        if sp and len(sp[0]) >= 4:
            ring = sp[0]
    except Exception:
        pass
    verts = max(len(ring) - 1, 0)
    return area, rect, verts, holes, aspect
