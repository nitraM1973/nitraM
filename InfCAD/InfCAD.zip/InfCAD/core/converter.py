
import processing
import os

class LayerConverter:
    def __init__(self, temp_folder):
        self.temp_folder = temp_folder

    def to_lines(self, layer_path, output_name):
        # 1. Polygons to Lines
        temp_lines = os.path.normpath(os.path.join(self.temp_folder, f"{output_name}_temp.shp"))
        params_poly = {
            'INPUT': layer_path,
            'OUTPUT': temp_lines
        }
        processing.run("native:polygonstolines", params_poly)
        
        # 2. Explode Lines
        output_path = os.path.normpath(os.path.join(self.temp_folder, f"{output_name}.shp"))
        params_explode = {
            'INPUT': temp_lines,
            'OUTPUT': output_path
        }
        result = processing.run("native:explodelines", params_explode)
        return result['OUTPUT']
