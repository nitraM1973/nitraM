
import os
from qgis.core import (
    QgsVectorLayer, QgsFeature, QgsGeometry, QgsSpatialIndex, 
    QgsField, QgsFields, QgsWkbTypes, QgsVectorFileWriter, QgsCoordinateTransformContext
)
from qgis.PyQt.QtCore import QVariant

class LineDeduplicator:
    def __init__(self, temp_folder):
        self.temp_folder = temp_folder
        self.tolerance = 0.025

    def process(self, layer_path, output_name, has_buildings=False):
        layer = QgsVectorLayer(layer_path, "lines", "ogr")
        
        # Prepare output layer
        output_path = os.path.join(self.temp_folder, f"{output_name}.shp")
        
        # Create fields structure - copy all fields EXCEPT any existing LAYER field
        # We only want CODELEM and other original fields, not LAYER
        fields = QgsFields()
        
        for field in layer.fields():
            # Skip any existing LAYER field to avoid duplication
            if field.name().upper() != "LAYER":
                fields.append(field)
        
        # Now add our new LAYER field
        fields.append(QgsField("LAYER", QVariant.String, len=254))
            
        writer = QgsVectorFileWriter(
            output_path,
            "UTF-8",
            fields,
            QgsWkbTypes.LineString,
            layer.crs(),
            "ESRI Shapefile"
        )
        
        # Spatial Index for fast querying
        index = QgsSpatialIndex(layer.getFeatures())
        
        # Track processed feature IDs to avoid duplicates
        processed_ids = set()
        
        features = {f.id(): f for f in layer.getFeatures()}
        
        for fid, feature in features.items():
            if fid in processed_ids:
                continue
                
            geom = feature.geometry()
            
            # Find candidates within tolerance
            candidates_ids = index.intersects(geom.boundingBox().buffered(self.tolerance))
            
            # Filter candidates that are actually "equal" geometrically within tolerance
            duplicates = []
            for cid in candidates_ids:
                if cid in processed_ids:
                    continue
                    
                cand_feat = features[cid]
                cand_geom = cand_feat.geometry()
                
                if geom.hausdorffDistance(cand_geom) <= self.tolerance:
                    duplicates.append(cand_feat)
            
            # Collect CODELEM values from all duplicates
            codelems = set()
            for dup in duplicates:
                val = dup['CODELEM']
                if val:
                    codelems.add(str(val).strip().upper())
                processed_ids.add(dup.id())
            
            # Priority Logic
            if has_buildings:
                # With buildings: K > V > H > E > P/F
                priority_order = ['K', 'V', 'H', 'E', 'P', 'F']
            else:
                # Without buildings: K > E > V > H > P/F
                priority_order = ['K', 'E', 'V', 'H', 'P', 'F']
            
            sorted_codelems = []
            
            # Filter and sort based on priority
            for p in priority_order:
                if p in codelems:
                    sorted_codelems.append(p)
                    codelems.remove(p)
            
            # Add remaining (if any unknown codes)
            sorted_codelems.extend(sorted(list(codelems)))
            
            # Create LAYER value
            layer_value = "_".join(sorted_codelems) if sorted_codelems else ""
            
            # Simplification rule: if starts with H, V, or E, keep only that letter
            if layer_value:
                first_code = sorted_codelems[0] if sorted_codelems else ""
                if first_code in ['H', 'V', 'E']:
                    layer_value = first_code
            
            # Create new feature to write
            new_feat = QgsFeature(fields)
            new_feat.setGeometry(geom)
            
            # Copy existing attributes (CODELEM and others, but NOT LAYER)
            for field in layer.fields():
                field_name = field.name()
                # Skip LAYER field from source
                if field_name.upper() == "LAYER":
                    continue
                # Copy other fields
                if field_name in [f.name() for f in fields]:
                    idx_new = fields.indexOf(field_name)
                    idx_old = layer.fields().indexOf(field_name)
                    new_feat.setAttribute(idx_new, feature.attribute(idx_old))
            
            # Set the new LAYER field with calculated value
            idx_layer = fields.indexOf("LAYER")
            new_feat.setAttribute(idx_layer, layer_value)
            
            writer.addFeature(new_feat)
            
        del writer
        return output_path

