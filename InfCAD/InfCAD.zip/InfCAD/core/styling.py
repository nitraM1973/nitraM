from qgis.core import QgsSymbol, QgsRendererCategory, QgsCategorizedSymbolRenderer
from qgis.PyQt.QtGui import QColor

# Color por primera letra del valor de LAYER (fuente única: estilo QGIS y DXF)
COLOR_MAP = {
    'K': QColor(255, 0, 0),      # Rojo: edificaciones
    'V': QColor(128, 128, 128),  # Gris: viales
    'H': QColor(0, 0, 255),      # Azul: hidrología
    'E': QColor(255, 255, 0),    # Amarillo: excluidos
    'P': QColor(0, 255, 0),      # Verde: parcelas
    'F': QColor(0, 255, 0),      # Verde: fincas
}
DEFAULT_COLOR = QColor(200, 200, 200)

# Equivalencia a índice de color AutoCAD (ACI) para la tabla de capas del DXF
_ACI_BY_RGB = {
    (255, 0, 0): 1,
    (255, 255, 0): 2,
    (0, 255, 0): 3,
    (0, 0, 255): 5,
    (128, 128, 128): 8,
    (200, 200, 200): 9,
}


def color_for_layer_value(value):
    text = str(value) if value else 'P'
    if text.upper().startswith('AUX_') and len(text) > 4:
        text = text[4:]            # Aux_K se pinta como K (mismo color que su capa de origen)
    first_char = text[0]
    return COLOR_MAP.get(first_char, DEFAULT_COLOR)


def aci_for_color(color):
    return _ACI_BY_RGB.get((color.red(), color.green(), color.blue()), 7)


def build_renderer(layer, width=0.5):
    """Renderer categorizado por LAYER. width=0 -> línea fina (sin grosor)."""
    field_index = layer.fields().indexOf('LAYER')
    categories = []
    for value in layer.uniqueValues(field_index):
        if not value:
            continue
        symbol = QgsSymbol.defaultSymbol(layer.geometryType())
        symbol.setColor(color_for_layer_value(value))
        symbol.setWidth(width)
        categories.append(QgsRendererCategory(value, symbol, str(value)))
    return QgsCategorizedSymbolRenderer('LAYER', categories)
