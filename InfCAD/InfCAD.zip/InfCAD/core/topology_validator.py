
import os
import processing
from qgis.core import (
    QgsVectorLayer, QgsFeature, QgsGeometry, QgsPoint, QgsPointXY,
    QgsField, QgsFields, QgsWkbTypes, QgsVectorFileWriter,
    QgsCoordinateTransformContext, QgsSpatialIndex, QgsCoordinateReferenceSystem
)
from qgis.PyQt.QtCore import QVariant


class TopologyValidator:
    """
    Validates geometry types and topology (gaps/overlaps) for polygon layers.
    Generates a LOG.shp point layer with error locations and descriptions.
    """
    
    def __init__(self, temp_folder):
        self.temp_folder = os.path.normpath(temp_folder)
        self.errors = []  # List of error dictionaries
    
    def clear_errors(self):
        """Clear accumulated errors"""
        self.errors = []
    
    def validate_geometry_type(self, layer, layer_name, expected_type='Polygon'):
        """
        Validate that a layer has the expected geometry type.
        
        Args:
            layer: QgsVectorLayer to validate
            layer_name: Name of the layer (for error messages)
            expected_type: Expected geometry type ('Polygon', 'LineString', 'Point')
        
        Returns:
            tuple: (is_valid: bool, error_message: str or None)
        """
        if not layer or not layer.isValid():
            return False, f"La capa {layer_name} no es válida"
        
        geom_type = QgsWkbTypes.geometryDisplayString(layer.geometryType())
        
        if expected_type == 'Polygon':
            if layer.geometryType() != QgsWkbTypes.PolygonGeometry:
                return False, f"La capa {layer_name} no es de tipo polígono (encontrado: {geom_type})"
        elif expected_type == 'LineString':
            if layer.geometryType() != QgsWkbTypes.LineGeometry:
                return False, f"La capa {layer_name} no es de tipo línea (encontrado: {geom_type})"
        elif expected_type == 'Point':
            if layer.geometryType() != QgsWkbTypes.PointGeometry:
                return False, f"La capa {layer_name} no es de tipo punto (encontrado: {geom_type})"
        
        return True, None
    
    def detect_gaps(self, layer_path, layer_name, tolerance=0.001):
        """
        Detect gaps between polygons in a layer.
        
        Args:
            layer_path: Path to the layer shapefile
            layer_name: Name of the layer (ZONACON or ZONACON_PARCELAS)
            tolerance: Minimum gap size to detect (in layer units, default 0.001m = 1mm)
        
        Returns:
            int: Number of gaps detected
        """
        try:
            # Step 1: Dissolve all polygons into one
            temp_dissolved = os.path.normpath(os.path.join(self.temp_folder, f"{layer_name}_gap_dissolved.shp"))
            
            params_dissolve = {
                'INPUT': layer_path,
                'FIELD': [],  # Dissolve all
                'OUTPUT': temp_dissolved
            }
            processing.run("native:dissolve", params_dissolve)
            
            # Step 2: Create bounding box of all features
            temp_bbox = os.path.normpath(os.path.join(self.temp_folder, f"{layer_name}_gap_bbox.shp"))
            
            params_bbox = {
                'INPUT': temp_dissolved,
                'OUTPUT': temp_bbox
            }
            processing.run("native:boundingboxes", params_bbox)
            
            # Step 3: Calculate difference (bbox - dissolved polygons = gaps)
            temp_gaps = os.path.normpath(os.path.join(self.temp_folder, f"{layer_name}_gaps.shp"))
            
            params_diff = {
                'INPUT': temp_bbox,
                'OVERLAY': temp_dissolved,
                'OUTPUT': temp_gaps
            }
            result_diff = processing.run("native:difference", params_diff)
            
            # Step 4: Check if gaps exist and extract centroids
            gaps_layer = QgsVectorLayer(result_diff['OUTPUT'], "gaps", "ogr")
            
            if gaps_layer.isValid() and gaps_layer.featureCount() > 0:
                # Filter by area (only gaps larger than tolerance²)
                min_area = tolerance * tolerance
                
                for feature in gaps_layer.getFeatures():
                    geom = feature.geometry()
                    area = geom.area()
                    
                    if area > min_area:
                        # Get point guaranteed to be on surface (inside the gap)
                        centroid = geom.pointOnSurface().asPoint()
                        
                        self.errors.append({
                            'point': centroid,
                            'error_type': 'GAP',
                            'source_layer': layer_name,
                            'description': f'Hueco entre polígonos',
                            'area': area
                        })
            
            return len([e for e in self.errors if e['error_type'] == 'GAP' and e['source_layer'] == layer_name])
            
        except Exception as e:
            print(f"Warning: Gap detection failed for {layer_name}: {str(e)}")
            return 0
    
    def detect_overlaps(self, layer_path, layer_name):
        """
        Detect overlaps between polygons in a layer.
        
        Args:
            layer_path: Path to the layer shapefile
            layer_name: Name of the layer (ZONACON or ZONACON_PARCELAS)
        
        Returns:
            int: Number of overlaps detected
        """
        try:
            layer = QgsVectorLayer(layer_path, "temp", "ogr")
            
            if not layer.isValid():
                return 0
            
            # Build spatial index for efficient searching
            index = QgsSpatialIndex(layer.getFeatures())
            
            # Cache features
            features = {f.id(): f for f in layer.getFeatures()}
            
            # Track processed pairs to avoid duplicates
            processed_pairs = set()
            
            overlap_count = 0
            
            for fid, feature in features.items():
                geom = feature.geometry()
                bbox = geom.boundingBox()
                
                # Find candidates that intersect bounding box
                candidate_ids = index.intersects(bbox)
                
                for cid in candidate_ids:
                    # Skip self and already processed pairs
                    if cid <= fid:
                        continue
                    
                    pair_key = (min(fid, cid), max(fid, cid))
                    if pair_key in processed_pairs:
                        continue
                    
                    processed_pairs.add(pair_key)
                    
                    candidate_geom = features[cid].geometry()
                    
                    # Check for actual overlap (intersection with area > 0)
                    if geom.intersects(candidate_geom):
                        intersection = geom.intersection(candidate_geom)
                        
                        # Only consider overlaps (area > 0), not just touching edges
                        if intersection.type() == QgsWkbTypes.PolygonGeometry and intersection.area() > 0:
                            # Get point guaranteed to be on surface (inside the overlap)
                            centroid = intersection.pointOnSurface().asPoint()
                            
                            self.errors.append({
                                'point': centroid,
                                'error_type': 'OVERLAP',
                                'source_layer': layer_name,
                                'description': f'Solape entre polígonos {fid} y {cid}',
                                'area': intersection.area()
                            })
                            
                            overlap_count += 1
            
            return overlap_count
            
        except Exception as e:
            print(f"Warning: Overlap detection failed for {layer_name}: {str(e)}")
            return 0
    
    def create_error_log(self, output_name='LOG', crs=None):
        """
        Create a point shapefile with all accumulated errors.
        
        Args:
            output_name: Name for the output file (default 'LOG')
            crs: QgsCoordinateReferenceSystem to assign to the layer
        
        Returns:
            str: Path to the created LOG.shp file, or None if no errors
        """
        if not self.errors:
            return None
        
        output_path = os.path.normpath(os.path.join(self.temp_folder, f"{output_name}.shp"))
        
        # Define fields
        fields = QgsFields()
        fields.append(QgsField('ERROR_ID', QVariant.Int))
        fields.append(QgsField('ERROR_TYPE', QVariant.String, len=50))
        fields.append(QgsField('SOURCE_LAYER', QVariant.String, len=100))
        fields.append(QgsField('DESCRIPTION', QVariant.String, len=254))
        fields.append(QgsField('AREA', QVariant.Double))
        
        # Use provided CRS or create an invalid one (valid object but empty) if None
        # QgsVectorFileWriter requires a QgsCoordinateReferenceSystem object, not None
        target_crs = crs if crs else QgsCoordinateReferenceSystem()

        # Create writer
        writer = QgsVectorFileWriter(
            output_path,
            "UTF-8",
            fields,
            QgsWkbTypes.Point,
            target_crs,
            "ESRI Shapefile"
        )
        
        if writer.hasError() != QgsVectorFileWriter.NoError:
            raise Exception(f"Error al crear LOG.shp: {writer.errorMessage()}")
        
        # Write features
        for idx, error in enumerate(self.errors, start=1):
            feat = QgsFeature(fields)
            
            # Create point geometry
            point_geom = QgsGeometry.fromPointXY(QgsPointXY(error['point']))
            feat.setGeometry(point_geom)
            
            # Set attributes
            feat.setAttribute('ERROR_ID', idx)
            feat.setAttribute('ERROR_TYPE', error['error_type'])
            feat.setAttribute('SOURCE_LAYER', error['source_layer'])
            feat.setAttribute('DESCRIPTION', error['description'])
            feat.setAttribute('AREA', round(error['area'], 4))
            
            writer.addFeature(feat)
        
        del writer
        
        return output_path
    
    def get_error_summary(self):
        """
        Get a summary of errors by type and layer.
        
        Returns:
            dict: Summary of errors
        """
        summary = {}
        
        for error in self.errors:
            layer = error['source_layer']
            error_type = error['error_type']
            
            if layer not in summary:
                summary[layer] = {'GAP': 0, 'OVERLAP': 0}
            
            summary[layer][error_type] += 1
        
        return summary
