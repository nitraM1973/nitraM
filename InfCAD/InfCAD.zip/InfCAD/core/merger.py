

import os
import glob
from qgis.core import (
    QgsVectorLayer, QgsVectorFileWriter, QgsFeature, 
    QgsField, QgsFields, QgsWkbTypes, QgsCoordinateTransformContext
)
from qgis.PyQt.QtCore import QVariant

class LayerMerger:
    def __init__(self, temp_folder):
        self.temp_folder = os.path.normpath(temp_folder)

    def merge_with_buildings(self, main_layer_path, edif_layer_path, output_name):
        # Normalize paths
        main_layer_path = os.path.normpath(main_layer_path)
        edif_layer_path = os.path.normpath(edif_layer_path)
        
        # Validate inputs
        if not os.path.exists(main_layer_path):
            raise Exception(f"Archivo principal no encontrado: {main_layer_path}")
        if not os.path.exists(edif_layer_path):
            raise Exception(f"Archivo edificaciones no encontrado: {edif_layer_path}")
        
        # Step 1: Create edificaciones with CODELEM='K' using QgsVectorFileWriter
        edif_with_k_path = os.path.normpath(os.path.join(self.temp_folder, f"{output_name}_edif.shp"))
        self._cleanup_shapefile(edif_with_k_path)
        
        # Load edificaciones layer
        edif_layer = QgsVectorLayer(edif_layer_path, "edif", "ogr")
        if not edif_layer.isValid():
            raise Exception(f"No se pudo cargar EDIFICACIONES: {edif_layer_path}")
        
        # Create fields structure with CODELEM
        fields = QgsFields()
        
        # Check if CODELEM already exists
        has_codelem = False
        for field in edif_layer.fields():
            if field.name().upper() == 'CODELEM':
                has_codelem = True
                fields.append(field)
            else:
                fields.append(field)
        
        # Add CODELEM if it doesn't exist
        if not has_codelem:
            fields.append(QgsField('CODELEM', QVariant.String, len=1))
        
        # Write edificaciones with CODELEM='K'
        writer = QgsVectorFileWriter(
            edif_with_k_path,
            "UTF-8",
            fields,
            edif_layer.wkbType(),
            edif_layer.crs(),
            "ESRI Shapefile"
        )
        
        if writer.hasError() != QgsVectorFileWriter.NoError:
            raise Exception(f"Error al crear shapefile de edificaciones: {writer.errorMessage()}")
        
        # Copy features and set CODELEM='K'
        codelem_idx = fields.indexOf('CODELEM')
        
        for feature in edif_layer.getFeatures():
            new_feat = QgsFeature(fields)
            new_feat.setGeometry(feature.geometry())
            
            # Copy existing attributes
            for i, field in enumerate(fields):
                if field.name().upper() != 'CODELEM':
                    old_idx = edif_layer.fields().indexOf(field.name())
                    if old_idx >= 0:
                        new_feat.setAttribute(i, feature.attribute(old_idx))
            
            # Set CODELEM='K'
            new_feat.setAttribute(codelem_idx, 'K')
            writer.addFeature(new_feat)
        
        del writer
        
        # Verify the output was created
        if not os.path.exists(edif_with_k_path):
            raise Exception(f"No se creó el archivo intermedio: {edif_with_k_path}")
        
        # Step 2: Merge Main and Edif (now with CODELEM='K') - Manual merge
        output_path = os.path.normpath(os.path.join(self.temp_folder, f"{output_name}.shp"))
        self._cleanup_shapefile(output_path)
        
        # Load main layer
        main_layer = QgsVectorLayer(main_layer_path, "main", "ogr")
        if not main_layer.isValid():
            raise Exception(f"No se pudo cargar capa principal: {main_layer_path}")
        
        # Load edif layer with K
        edif_k_layer = QgsVectorLayer(edif_with_k_path, "edif_k", "ogr")
        if not edif_k_layer.isValid():
            raise Exception(f"No se pudo cargar edificaciones procesadas: {edif_with_k_path}")
        
        # Merge fields from both layers
        merged_fields = QgsFields()
        field_names = set()
        
        # Add fields from main layer
        for field in main_layer.fields():
            merged_fields.append(field)
            field_names.add(field.name().upper())
        
        # Add fields from edif layer that don't exist in main
        for field in edif_k_layer.fields():
            if field.name().upper() not in field_names:
                merged_fields.append(field)
        
        # Create writer for merged output
        writer = QgsVectorFileWriter(
            output_path,
            "UTF-8",
            merged_fields,
            main_layer.wkbType(),
            main_layer.crs(),
            "ESRI Shapefile"
        )
        
        if writer.hasError() != QgsVectorFileWriter.NoError:
            raise Exception(f"Error al crear shapefile fusionado: {writer.errorMessage()}")
        
        # Copy features from main layer
        for feature in main_layer.getFeatures():
            new_feat = QgsFeature(merged_fields)
            new_feat.setGeometry(feature.geometry())
            
            # Copy attributes
            for i, field in enumerate(merged_fields):
                old_idx = main_layer.fields().indexOf(field.name())
                if old_idx >= 0:
                    new_feat.setAttribute(i, feature.attribute(old_idx))
            
            writer.addFeature(new_feat)
        
        # Copy features from edif layer
        for feature in edif_k_layer.getFeatures():
            new_feat = QgsFeature(merged_fields)
            new_feat.setGeometry(feature.geometry())
            
            # Copy attributes
            for i, field in enumerate(merged_fields):
                old_idx = edif_k_layer.fields().indexOf(field.name())
                if old_idx >= 0:
                    new_feat.setAttribute(i, feature.attribute(old_idx))
            
            writer.addFeature(new_feat)
        
        del writer
        
        # Verify output
        if not os.path.exists(output_path):
            raise Exception(f"No se creó el archivo fusionado: {output_path}")
        
        return output_path
    
    def _cleanup_shapefile(self, shapefile_path):
        """Remove all components of a shapefile if they exist"""
        base_path = shapefile_path.replace('.shp', '')
        for ext in ['.shp', '.shx', '.dbf', '.prj', '.cpg', '.qpj', '.shp.xml']:
            file_path = base_path + ext
            if os.path.exists(file_path):
                try:
                    os.remove(file_path)
                except Exception:
                    pass
