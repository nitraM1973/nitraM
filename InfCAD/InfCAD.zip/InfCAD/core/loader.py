import os

from qgis.core import QgsVectorLayer

# Shapes que el plugin reconoce en la carpeta (nombre sin extensión, en mayúsculas)
ZONE_LAYERS = ['ZONACON', 'ZONACON_PARCELAS']
BUILDINGS_LAYER = 'EDIFICACIONES'


class InfCOPLoader:
    """Localiza los shapes de entrada en una carpeta (sin distinguir mayúsculas)."""

    def __init__(self, folder, temp_folder=None):
        self.folder = folder
        self.temp_folder = temp_folder
        self.required_layers = ZONE_LAYERS + [BUILDINGS_LAYER]

    def paths(self):
        """Devuelve {NOMBRE_EN_MAYÚSCULAS: ruta_al_shp} de los shapes reconocidos."""
        found = {}
        try:
            names = sorted(os.listdir(self.folder))
        except OSError:
            return found
        for filename in names:
            stem, ext = os.path.splitext(filename)
            if ext.lower() != '.shp':
                continue
            key = stem.upper()
            if key in self.required_layers and key not in found:
                found[key] = os.path.join(self.folder, filename)
        return found

    def scan(self):
        return list(self.paths().keys())

    def read_fields(self, name):
        """Campos (QgsFields) de uno de los shapes, o None si no existe o no abre."""
        path = self.paths().get(name)
        if not path:
            return None
        layer = QgsVectorLayer(path, name, "ogr")
        return layer.fields() if layer.isValid() else None
