
import os
import glob
from qgis.core import QgsVectorLayer, QgsVectorFileWriter

class InfCOPLoader:
    def __init__(self, folder, temp_folder=None):
        self.folder = folder
        self.temp_folder = temp_folder
        self.required_layers = ['ZONACON', 'ZONACON_PARCELAS', 'EDIFICACIONES']

    def scan(self):
        found = []
        files = glob.glob(os.path.join(self.folder, "*.shp"))
        for file_path in files:
            filename = os.path.basename(file_path)
            name_no_ext = os.path.splitext(filename)[0].upper()
            if name_no_ext in self.required_layers:
                found.append(name_no_ext)
        return found

    def load_layers(self):
        loaded_layers = {}
        errors = []
        
        # Case insensitive search
        files = glob.glob(os.path.join(self.folder, "*.shp"))
        
        for file_path in files:
            filename = os.path.basename(file_path)
            name_no_ext = os.path.splitext(filename)[0].upper()
            
            if name_no_ext in self.required_layers:
                layer = QgsVectorLayer(file_path, name_no_ext, "ogr")
                if layer.isValid():
                    # If temp_folder is provided, save to temp and return path
                    # Otherwise return the layer object
                    if self.temp_folder:
                        temp_path = os.path.join(self.temp_folder, f"{name_no_ext}_original.shp")
                        # Save layer to temp folder
                        options = QgsVectorFileWriter.SaveVectorOptions()
                        options.driverName = "ESRI Shapefile"
                        error = QgsVectorFileWriter.writeAsVectorFormatV3(
                            layer,
                            temp_path,
                            layer.transformContext(),
                            options
                        )
                        if error[0] == QgsVectorFileWriter.NoError:
                            loaded_layers[name_no_ext] = QgsVectorLayer(temp_path, name_no_ext, "ogr")
                        else:
                            error_msg = f"ADVERTENCIA: No se pudo copiar {filename} a carpeta temporal."
                            errors.append(error_msg)
                    else:
                        loaded_layers[name_no_ext] = layer
                else:
                    error_msg = f"ADVERTENCIA: La capa {filename} no es válida o no se pudo cargar."
                    errors.append(error_msg)
                    print(error_msg)
        
        # If there were errors, raise an exception with details
        if errors and not loaded_layers:
            raise Exception("No se pudieron cargar capas válidas. Errores: " + "; ".join(errors))
        
        # Return layers and errors separately
        return loaded_layers, errors
