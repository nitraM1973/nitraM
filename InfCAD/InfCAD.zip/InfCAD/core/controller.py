import os

from qgis.PyQt.QtGui import QColor
from qgis.core import QgsProject, QgsVectorLayer, QgsCoordinateReferenceSystem, QgsFeatureRequest
from qgis.PyQt.QtCore import QObject, QThread, QUrl, pyqtSignal, pyqtSlot
from qgis.PyQt.QtGui import QDesktopServices

from . import pipeline
from .loader import InfCOPLoader, ZONE_LAYERS, BUILDINGS_LAYER
from .dxf_exporter import DxfExporter
from .styling import build_renderer
from .utils import create_temp_folder, FIELD_X, FIELD_Y, FIELD_MIID

MODE_BOTH = 'both'   # ZONACON + EDIFICACIONES
MODE_ZONE = 'zone'   # solo ZONACON


class Worker(QObject):
    """
    Se ejecuta en un hilo secundario. NO toca QgsProject, el árbol de capas ni la
    interfaz: solo procesa archivos y avisa por señales. Las capas las crea y añade
    al proyecto el hilo principal (ver InfCOPController.add_layer).
    """
    finished = pyqtSignal()                      # SIEMPRE se emite al terminar (con o sin error)
    error = pyqtSignal(str)
    log = pyqtSignal(str)
    layer_ready = pyqtSignal(str, str, bool, bool)   # nombre, ruta .shp, visible, estilo LAYER
    results = pyqtSignal(object)

    def __init__(self, folder, mode, finca_field, subfinca_field, tipo_field="", fallback_crs_wkt="",
                 adosados=True, contactos=True, cierres=True):
        super().__init__()
        self.folder = folder
        self.mode = mode
        self.finca_field = finca_field
        self.subfinca_field = subfinca_field
        self.tipo_field = tipo_field
        self.fallback_crs_wkt = fallback_crs_wkt
        self.adosados = adosados
        self.contactos = contactos
        self.cierres = cierres
        self.temp_folder = None
        self.final_layers = {}
        self.e_review = []

    def run(self):
        try:
            self._run()
        except Exception as e:
            import traceback
            self.log.emit(traceback.format_exc())
            self.error.emit(str(e))
        finally:
            self.finished.emit()

    def _run(self):
        log = self.log.emit
        paths = InfCOPLoader(self.folder).paths()

        zones = [z for z in ZONE_LAYERS if z in paths]
        if not zones:
            raise Exception("No se encontró ZONACON (ni ZONACON_PARCELAS) en la carpeta.")
        if not self.finca_field:
            raise Exception("Falta indicar el campo FINCA.")

        with_buildings = (self.mode == MODE_BOTH)
        if with_buildings and BUILDINGS_LAYER not in paths:
            log("No se encontró EDIFICACIONES: se procesa solo ZONACON.")
            with_buildings = False
        if not with_buildings:
            log("Modo: solo ZONACON." if self.mode == MODE_ZONE else "Modo: solo ZONACON (sin EDIFICACIONES).")
        else:
            log("Modo: ZONACON + EDIFICACIONES.")

        self.temp_folder = create_temp_folder(self.folder)
        log(f"Carpeta temporal creada: {self.temp_folder}")

        # --- Paso 0: corregir geometrias de los shapes originales; el resto del proceso
        #     trabaja con las copias corregidas (los originales no se modifican) ---
        log("--- Corrigiendo geometrias de los shapes originales ---")
        to_fix = list(zones) + ([BUILDINGS_LAYER] if with_buildings else [])
        for name in to_fix:
            fixed_path = os.path.join(self.temp_folder, f"{name}_fix.shp")
            try:
                pipeline.fix_geometries(paths[name], fixed_path, log=log)
            except Exception as e:
                if name in ('ZONACON', BUILDINGS_LAYER):
                    raise
                log(f"{name} omitido: {e}")
                zones.remove(name)
                continue
            paths[name] = fixed_path

        # --- EDIFICACIONES (se prepara una sola vez) ---
        edif_prepared = None
        if with_buildings:
            out = os.path.join(self.temp_folder, "EDIFICACIONES_MiID.shp")
            _, n, _ = pipeline.prepare_polygons(paths[BUILDINGS_LAYER], out, 'edificaciones', log=log)
            log(f"EDIFICACIONES: {n} entidades; campos X, Y, MiID (= {pipeline.EDIF_MIID}) creados.")
            edif_prepared = out
            self.layer_ready.emit("EDIFICACIONES_MiID", out, False, False)

        # --- ZONACON / ZONACON_PARCELAS ---
        for name in zones:
            log(f"--- Procesando {name} ---")
            out = os.path.join(self.temp_folder, f"{name}_MiID.shp")
            sub = self.subfinca_field or None
            zone_review = []
            try:
                _, n, n_no = pipeline.prepare_polygons(
                    paths[name], out, 'fincas', self.finca_field, sub, log=log,
                    tipo_field=self.tipo_field or None, buildings_path=edif_prepared,
                    review=zone_review)
            except Exception as e:
                if name != 'ZONACON':
                    log(f"{name} omitido: {e}")
                    continue
                raise
            msg = f"{name}: {n} entidades; campos X, Y, MiID creados."
            if n_no:
                msg += f" ({n_no} sin valor en {self.finca_field}: MiID vacío)"
            log(msg)
            self.layer_ready.emit(f"{name}_MiID", out, False, False)

            source = out
            if with_buildings:
                merged = os.path.join(self.temp_folder, f"{name}_merged.shp")
                _, nz, ne, nd = pipeline.merge_polygons(
                    out, edif_prepared, merged, tipo_field=self.tipo_field or None)
                log(f"Fusión {name} + EDIFICACIONES: {nz} + {ne} entidades (con X, Y, MiID).")
                if nd:
                    log(f"  {nd} edificación(es) ya estaban en {name} como recinto E: no se añaden "
                        f"duplicadas (ese recinto pasa a CODELEM K, MiID {pipeline.EDIF_MIID}).")
                source = merged
                for it in zone_review:
                    it['paths'].append(merged)   # los fid de ZONACON se conservan en la capa fusionada

            for it in zone_review:
                it['zone'] = name
            self.e_review.extend(zone_review)

            aux_segments = []
            if self.adosados:
                ados = os.path.join(self.temp_folder, f"{name}_adosados.shp")
                _, n_cl, n_mem, aux_segments, _n_om, _n_ni = pipeline.merge_adosados(source, ados, log=log)
                if n_cl:
                    log(f"Adosados: {n_mem} edificaciones unidas en {n_cl} conjunto(s) (un recinto, un X/Y y un MiID "
                        f"por conjunto); {len(aux_segments)} segmentos de pared interior van a Aux_*.")
                    source = ados
                else:
                    log("Adosados: no hay conjuntos de edificaciones adosadas que sean isla de un recinto mayor.")

            if self.contactos:
                cpath = os.path.join(self.temp_folder, f"{name}_contactos.shp")
                _, n_c, counts = pipeline.detect_island_contacts(source, cpath)
                if n_c:
                    log(f"Contactos puntuales isla/contenedor: {n_c} "
                        f"(vértice=vértice: {counts.get('V=V', 0)}; "
                        f"vértice de isla en arista: {counts.get('V/A', 0)}; "
                        f"vértice de contenedor en arista de isla: {counts.get('A/V', 0)}). "
                        f"Revisa la capa {name}_contactos.")
                    self.layer_ready.emit(f"{name}_contactos", cpath, True, False)
                else:
                    log("Contactos puntuales isla/contenedor: ninguno.")

            cierre_segments = []
            if self.cierres:
                if not self.tipo_field:
                    log("Cierres de envolventes: hace falta el campo TIPO para identificar viales (V) e hidrografía (H).")
                else:
                    cierre_segments, st = pipeline.close_envelopes(source, log=log)
                    if st['cierres_hueco'] or st['bocas']:
                        log(f"Cierres de V/H: {st['bocas'] + st['cierres_hueco']} línea(s) en {pipeline.CIERRES_LAYER} "
                            f"({st['bocas']} en bocas de ramales, {st['cierres_hueco']} para huecos aislados con recintos "
                            f"dentro) en {st['poligonos']} polígono(s) V/H.")
                        if st['fallos']:
                            log(f"  ADVERTENCIA: {st['fallos']} hueco(s) no se pudieron cerrar (no hay un cierre que quede "
                                f"dentro del vial); revísalos a mano.")
                    else:
                        log("Cierres de V/H: no se encontraron ramales ni huecos que cerrar.")

            segments = pipeline.polygon_segments(source) + aux_segments + cierre_segments
            log(f"Segmentos de línea: {len(segments)}")

            deduped = pipeline.dedupe_segments(segments, has_buildings=with_buildings)
            log(f"Duplicados eliminados: {len(segments) - len(deduped)}; campo LAYER calculado.")

            crs = QgsVectorLayer(out, "c", "ogr").crs()
            if not crs.isValid() and self.fallback_crs_wkt:
                crs = QgsCoordinateReferenceSystem.fromWkt(self.fallback_crs_wkt)
            lines = pipeline.write_lines(
                deduped, os.path.join(self.temp_folder, f"{name}_deduplicated.shp"), crs)
            final = pipeline.dissolve_by_layer(
                lines, os.path.join(self.temp_folder, f"{name}_final.shp"))
            log(f"Líneas fusionadas por LAYER: {name}_final.")
            self.final_layers[name] = final
            self.layer_ready.emit(f"{name}_final", final, True, True)

        self.results.emit({'temp_folder': self.temp_folder, 'layers': dict(self.final_layers),
                           'e_review': list(self.e_review)})


class InfCOPController(QObject):
    # QObject + pyqtSlot: garantiza que los slots se ejecuten en el hilo principal
    def __init__(self, dock_widget, iface):
        super().__init__()
        self.dock = dock_widget
        self.iface = iface
        self.thread = None
        self.worker = None
        self.results = None
        self.failed = False

        self.dock.pushButton_run.clicked.connect(self.run_process)
        self.dock.pushButton_reset.clicked.connect(self.reset_plugin)
        self.dock.pushButton_apply_review.clicked.connect(self.apply_review)

    # ------------------------------------------------------------------ #
    def run_process(self):
        if self.thread is not None:
            return  # ya hay un proceso en marcha
        folder = self.dock.lineEdit_folder.text()
        if not folder or not os.path.exists(folder):
            self.dock.log("Error: Carpeta inválida.")
            return

        finca, subfinca, tipo = self.dock.selected_fields()
        if not finca:
            self.dock.log("Error: elige el campo FINCA (numérico entero) de ZONACON.")
            return

        project_crs = QgsProject.instance().crs()
        crs_wkt = project_crs.toWkt() if project_crs.isValid() else ""
        mode = self.dock.selected_mode()   # leer ANTES de bloquear los controles
        adosados = self.dock.checkBox_adosados.isChecked()
        contactos = self.dock.checkBox_contactos.isChecked()
        cierres = self.dock.checkBox_cierres.isChecked()

        self.clear_previous_run()
        self.dock.set_working(True)
        self.dock.log("Iniciando proceso...")
        self.results = None
        self.failed = False

        self.thread = QThread()
        self.worker = Worker(folder, mode, finca, subfinca, tipo, crs_wkt, adosados, contactos, cierres)
        self.worker.moveToThread(self.thread)

        self.thread.started.connect(self.worker.run)
        self.worker.log.connect(self.dock.log)
        self.worker.layer_ready.connect(self.add_layer)      # se ejecuta en el hilo principal
        self.worker.results.connect(self.on_results)
        self.worker.error.connect(self.on_error)
        self.worker.finished.connect(self.thread.quit)
        self.worker.finished.connect(self.worker.deleteLater)
        self.thread.finished.connect(self.on_thread_finished)
        self.thread.start()

    def clear_previous_run(self):
        """Deja QGIS como nuevo antes de cada proceso: vacía el proyecto por completo
        (capas, grupos, etc.) conservando solo su SRC, y vacía la pestaña «Revisión E»,
        el registro y los resultados guardados."""
        project = QgsProject.instance()
        crs = project.crs()
        project.clear()
        if crs.isValid():
            project.setCrs(crs)   # clear() lo reinicia; se necesita para capas sin .prj
        if self.iface and self.iface.mapCanvas():
            self.iface.mapCanvas().refresh()
        self.results = None
        self.dock.load_review([])
        self.dock.textEdit_log.clear()

    # ---- slots (hilo principal) --------------------------------------- #
    @pyqtSlot(str, str, bool, bool)
    def add_layer(self, name, path, visible, styled):
        layer = QgsVectorLayer(path, name, "ogr")
        if not layer.isValid():
            self.dock.log(f"ADVERTENCIA: no se pudo cargar la capa {name} ({path}).")
            return
        if not layer.crs().isValid():
            crs = QgsProject.instance().crs()
            if crs.isValid():
                layer.setCrs(crs)
        if styled:
            layer.setRenderer(build_renderer(layer, width=0.5))
        elif name.endswith('_contactos') and layer.renderer() is not None:
            sym = layer.renderer().symbol()
            sym.setColor(QColor(255, 0, 0))
            sym.setSize(4)
        QgsProject.instance().addMapLayer(layer)
        node = QgsProject.instance().layerTreeRoot().findLayer(layer.id())
        if node:
            node.setItemVisibilityChecked(visible)
        if styled:
            layer.triggerRepaint()
            if self.iface and self.iface.mapCanvas():
                self.iface.mapCanvas().setExtent(layer.extent())
                self.iface.mapCanvas().refresh()

    @pyqtSlot(object)
    def on_results(self, results):
        self.results = results

    @pyqtSlot(str)
    def on_error(self, msg):
        self.failed = True
        self.dock.log(f"ERROR: {msg}")

    @pyqtSlot()
    def on_thread_finished(self):
        # El hilo ya terminó: es seguro liberar y encadenar la exportación DXF
        if self.thread is not None:
            self.thread.deleteLater()
        self.thread = None
        self.worker = None
        if not self.failed:
            self.dock.load_review((self.results or {}).get('e_review', []))
            self.export_dxf()
            self.dock.set_result_folder((self.results or {}).get('temp_folder'))
            self.dock.log(f"Proceso finalizado con éxito. Resultado en: {(self.results or {}).get('temp_folder')}")
        else:
            self.dock.log("Proceso terminado con errores. Revisa el registro.")
        self.dock.set_working(False)

    def export_dxf(self):
        """Exporta las capas *_final a DXF (hilo principal)."""
        if not self.results or not self.results.get('layers'):
            self.dock.log("No hay capas finales para exportar a DXF.")
            return
        exporter = DxfExporter(self.results['temp_folder'])
        for layer_name, layer_path in self.results['layers'].items():
            try:
                dxf_path, n_feat, dxf_layers = exporter.export(layer_path, f"{layer_name}_final")
                self.dock.log(
                    f"DXF exportado: {dxf_path} ({n_feat} líneas, "
                    f"{len(dxf_layers)} capas: {', '.join(dxf_layers)})")
            except Exception as e:
                self.dock.log(f"ERROR exportando {layer_name} a DXF: {e}")

    # ---- pestaña «Revisión E» ------------------------------------------ #
    def apply_review(self):
        """Escribe en MiID (ZONACON_MiID.shp y ZONACON_merged.shp) los cambios hechos a mano."""
        changes = self.dock.review_changes()   # [(item, nuevo_miid)]
        if not changes:
            self.dock.log("Revisión E: no hay cambios que aplicar.")
            return
        by_path = {}
        for item, miid in changes:
            for path in item['paths']:
                by_path.setdefault(path, []).append((item, miid))
        n_ok = n_skip = 0
        for path, entries in by_path.items():
            layer = self._project_layer_for(path)
            own = layer is None
            if own:
                layer = QgsVectorLayer(path, "r", "ogr")
            if not layer.isValid():
                self.dock.log(f"Revisión E: no se pudo abrir {path}.")
                continue
            prov = layer.dataProvider()
            i_miid = layer.fields().indexFromName(FIELD_MIID)
            changes_map = {}
            for item, miid in entries:
                for fid, x, y in item['parts']:
                    # comprobación de seguridad: el fid sigue siendo ese recinto (mismo X, Y)
                    feat = next(layer.getFeatures(QgsFeatureRequest(fid)), None)
                    if feat is None or not self._same_point(feat, x, y):
                        n_skip += 1
                        continue
                    changes_map[fid] = {i_miid: miid}
            if changes_map and not prov.changeAttributeValues(changes_map):
                self.dock.log(f"Revisión E: no se pudo escribir en {os.path.basename(path)}.")
                continue
            if not own:
                prov.reloadData()
                layer.triggerRepaint()
            if path.endswith('_MiID.shp'):
                n_ok += len({id(i) for i, _ in entries})
        for item, miid in changes:
            item['current'] = miid
        self.dock.review_refresh_baseline()
        msg = f"Revisión E: {n_ok} recinto(s) actualizados en MiID."
        if n_skip:
            msg += f" ({n_skip} entidad(es) omitidas: no coincidían con el shape.)"
        self.dock.log(msg)

    @staticmethod
    def _same_point(feat, x, y):
        if x is None or y is None:
            return True   # recinto sin punto: no se puede comprobar
        try:
            return abs(float(feat[FIELD_X]) - x) <= 1e-6 and abs(float(feat[FIELD_Y]) - y) <= 1e-6
        except (TypeError, ValueError):
            return False

    @staticmethod
    def _project_layer_for(path):
        """Capa del proyecto cuyo origen es este shapefile (None si ya no está cargada)."""
        target = os.path.normcase(os.path.normpath(path))
        for lyr in QgsProject.instance().mapLayers().values():
            if isinstance(lyr, QgsVectorLayer):
                src = os.path.normcase(os.path.normpath(lyr.source().split('|')[0]))
                if src == target:
                    return lyr
        return None

    def reset_plugin(self):
        self.dock.set_result_folder(None)
        self.dock.load_review([])
        self.dock.textEdit_log.clear()
        project = QgsProject.instance()
        all_layer_ids = list(project.mapLayers().keys())
        if all_layer_ids:
            project.removeMapLayers(all_layer_ids)
            self.dock.log(f"Se eliminaron {len(all_layer_ids)} capas del proyecto.")
        else:
            self.dock.log("No hay capas para eliminar.")
        self.dock.log("Plugin reiniciado.")
