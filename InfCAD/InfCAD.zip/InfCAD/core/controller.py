
import os
import shutil
from qgis.core import QgsProject, QgsVectorLayer
from qgis.PyQt.QtCore import QObject, QThread, pyqtSignal
from .loader import InfCOPLoader
from .geometry_fixer import GeometryFixer
from .merger import LayerMerger
from .converter import LayerConverter
from .deduplicator import LineDeduplicator
from .line_dissolve import LineDissolve
from .utils import create_temp_folder, get_next_temp_folder_name

class Worker(QObject):
    finished = pyqtSignal()
    error = pyqtSignal(str)
    log = pyqtSignal(str)
    
    def __init__(self, folder):
        super().__init__()
        self.folder = folder
        self.temp_folder = None

    def set_layer_visibility(self, layer, visible):
        if layer and layer.isValid():
            node = QgsProject.instance().layerTreeRoot().findLayer(layer.id())
            if node:
                node.setItemVisibilityChecked(visible)

    def run(self):
        try:
            # 0. Setup
            self.temp_folder = create_temp_folder(self.folder)
            self.log.emit(f"Carpeta temporal creada: {self.temp_folder}")
            
            # 1. Load Data
            loader = InfCOPLoader(self.folder, self.temp_folder)
            layers, load_errors = loader.load_layers()
            
            # Report any loading errors
            if load_errors:
                for error in load_errors:
                    self.log.emit(error)
            
            if not layers:
                raise Exception("No se encontraron shapes válidos (ZONACON, ZONACON_PARCELAS, EDIFICACIONES) en la carpeta.")
            
            self.log.emit(f"Capas cargadas correctamente: {', '.join(layers.keys())}")
            
            # Load original layers to project
            loaded_layer_objects = {}
            for layer_name, layer in layers.items():
                QgsProject.instance().addMapLayer(layer)
                loaded_layer_objects[layer_name] = layer
                self.log.emit(f"Capa original {layer_name} añadida al proyecto.")
            
            # Check CRS
            crs_warnings = []
            project_crs = QgsProject.instance().crs()
            
            for layer_name, layer in layers.items():
                if not layer.crs().isValid():
                    crs_warnings.append(layer_name)
            
            if crs_warnings:
                warning_msg = f"ADVERTENCIA: Los siguientes shapes NO tienen sistema de coordenadas definido: {', '.join(crs_warnings)}. "
                warning_msg += "Se recomienda asignarles un CRS antes de procesar. "
                if project_crs.isValid():
                    warning_msg += f"Se usará el CRS del proyecto ({project_crs.authid()}) para las capas generadas."
                else:
                    warning_msg += "El proyecto tampoco tiene CRS definido."
                self.log.emit(warning_msg)
            
            # Use project CRS if available, otherwise use first valid layer CRS
            target_crs = project_crs if project_crs.isValid() else None
            if not target_crs:
                for layer in layers.values():
                    if layer.crs().isValid():
                        target_crs = layer.crs()
                        break
            
            # Process ZONACON and ZONACON_PARCELAS independently
            target_layers = ['ZONACON', 'ZONACON_PARCELAS']
            
            for layer_name in target_layers:
                if layer_name not in layers:
                    continue
                
                self.log.emit(f"--- Procesando {layer_name} ---")
                main_layer = layers[layer_name]
                
                # Step 0: Fix Geometry Main Layer
                fixer = GeometryFixer(self.temp_folder)
                fixed_main = fixer.fix(main_layer, f"{layer_name}_fixed")
                self.log.emit(f"Geometrías corregidas para {layer_name}")
                
                # Load to project
                fixed_layer_obj = QgsVectorLayer(fixed_main, f"{layer_name}_fixed", "ogr")
                if target_crs and target_crs.isValid():
                    fixed_layer_obj.setCrs(target_crs)
                QgsProject.instance().addMapLayer(fixed_layer_obj)
                
                # Hide original
                self.set_layer_visibility(main_layer, False)
                
                # Step 1 & 2: Handle Buildings and Merge
                current_layer_obj = fixed_layer_obj
                
                if 'EDIFICACIONES' in layers:
                    self.log.emit("Procesando EDIFICACIONES...")
                    edif_layer = layers['EDIFICACIONES']
                    
                    self.log.emit(f"Corrigiendo geometrías de EDIFICACIONES...")
                    fixed_edif = fixer.fix(edif_layer, "EDIFICACIONES_fixed")
                    self.log.emit(f"EDIFICACIONES corregido: {fixed_edif}")
                    
                    # Load fixed edificaciones to project
                    fixed_edif_obj = QgsVectorLayer(fixed_edif, "EDIFICACIONES_fixed", "ogr")
                    if target_crs and target_crs.isValid():
                        fixed_edif_obj.setCrs(target_crs)
                    QgsProject.instance().addMapLayer(fixed_edif_obj)
                    
                    # Hide original EDIFICACIONES
                    if 'EDIFICACIONES' in loaded_layer_objects:
                        self.set_layer_visibility(loaded_layer_objects['EDIFICACIONES'], False)
                    
                    self.log.emit(f"Fusionando con {layer_name}...")
                    merger = LayerMerger(self.temp_folder)
                    merged_layer = merger.merge_with_buildings(fixed_main, fixed_edif, f"{layer_name}_merged")
                    self.log.emit("Edificaciones fusionadas.")
                    
                    # Load to project
                    merged_layer_obj = QgsVectorLayer(merged_layer, f"{layer_name}_merged", "ogr")
                    if target_crs and target_crs.isValid():
                        merged_layer_obj.setCrs(target_crs)
                    QgsProject.instance().addMapLayer(merged_layer_obj)
                    
                    # Hide previous layers
                    self.set_layer_visibility(fixed_layer_obj, False)
                    self.set_layer_visibility(fixed_edif_obj, False)
                    
                    current_layer_obj = merged_layer_obj
                else:
                    merged_layer = fixed_main
                    self.log.emit("No se encontró capa EDIFICACIONES, saltando fusión.")

                # Step 3: Convert to Lines
                converter = LayerConverter(self.temp_folder)
                lines_layer = converter.to_lines(merged_layer, f"{layer_name}_lines")
                self.log.emit("Convertido a líneas.")
                
                # Load to project
                lines_layer_obj = QgsVectorLayer(lines_layer, f"{layer_name}_lines", "ogr")
                if target_crs and target_crs.isValid():
                    lines_layer_obj.setCrs(target_crs)
                QgsProject.instance().addMapLayer(lines_layer_obj)
                
                # Hide previous
                self.set_layer_visibility(current_layer_obj, False)
                
                # Step 4 & 5: Deduplicate and Attribute Logic
                deduplicator = LineDeduplicator(self.temp_folder)
                has_buildings = 'EDIFICACIONES' in layers
                final_layer = deduplicator.process(lines_layer, f"{layer_name}_deduplicated", has_buildings=has_buildings)
                self.log.emit(f"Líneas duplicadas eliminadas y atributos LAYER generados para {layer_name}.")
                
                # Load to project
                final_layer_obj = QgsVectorLayer(final_layer, f"{layer_name}_deduplicated", "ogr")
                if target_crs and target_crs.isValid():
                    final_layer_obj.setCrs(target_crs)
                QgsProject.instance().addMapLayer(final_layer_obj)
                
                # Hide previous
                self.set_layer_visibility(lines_layer_obj, False)
                
                # Step 6: Dissolve lines by LAYER value
                dissolver = LineDissolve(self.temp_folder)
                dissolved_layer = dissolver.dissolve_by_layer(final_layer, f"{layer_name}_final")
                self.log.emit(f"Líneas fusionadas por valor de LAYER para {layer_name}.")
                
                # Load dissolved layer to project
                dissolved_layer_obj = QgsVectorLayer(dissolved_layer, f"{layer_name}_final", "ogr")
                if target_crs and target_crs.isValid():
                    dissolved_layer_obj.setCrs(target_crs)
                QgsProject.instance().addMapLayer(dissolved_layer_obj)
                
                # Hide previous
                self.set_layer_visibility(final_layer_obj, False)
                
                # Apply categorized styling
                self.apply_categorized_style(dissolved_layer_obj)
                self.log.emit(f"Estilo categorizado aplicado a {layer_name}_final.")
                
            self.finished.emit()
            
        except Exception as e:
            self.error.emit(str(e))
    
    def apply_categorized_style(self, layer):
        """Apply categorized symbology to layer based on LAYER field"""
        from qgis.core import QgsSymbol, QgsRendererCategory, QgsCategorizedSymbolRenderer
        from qgis.PyQt.QtGui import QColor
        
        # Define colors for each LAYER value
        color_map = {
            'K': QColor(255, 0, 0),      # Red for buildings
            'V': QColor(128, 128, 128),  # Gray for roads
            'H': QColor(0, 0, 255),      # Blue for hydrology
            'E': QColor(255, 255, 0),    # Yellow for excluded
            'P': QColor(0, 255, 0),      # Green for parcels
            'F': QColor(0, 255, 0),      # Green for fincas
        }
        
        categories = []
        
        # Get unique values from LAYER field
        field_index = layer.fields().indexOf('LAYER')
        unique_values = layer.uniqueValues(field_index)
        
        for value in unique_values:
            if not value:
                continue
                
            # Get color based on first character
            first_char = str(value)[0] if value else 'P'
            color = color_map.get(first_char, QColor(200, 200, 200))
            
            # Create symbol
            symbol = QgsSymbol.defaultSymbol(layer.geometryType())
            symbol.setColor(color)
            symbol.setWidth(0.5)
            
            # Create category
            category = QgsRendererCategory(value, symbol, str(value))
            categories.append(category)
        
        # Apply renderer
        renderer = QgsCategorizedSymbolRenderer('LAYER', categories)
        layer.setRenderer(renderer)
        layer.triggerRepaint()

class InfCOPController:
    def __init__(self, dock_widget, iface):
        self.dock = dock_widget
        self.iface = iface
        self.thread = None
        self.worker = None
        
        # Connect UI signals
        self.dock.pushButton_run.clicked.connect(self.run_process)
        self.dock.pushButton_reset.clicked.connect(self.reset_plugin)

    def run_process(self):
        folder = self.dock.lineEdit_folder.text()
        if not folder or not os.path.exists(folder):
            self.dock.log("Error: Carpeta inválida.")
            return

        self.dock.set_working(True)
        self.dock.log("Iniciando proceso...")
        
        self.thread = QThread()
        self.worker = Worker(folder)
        self.worker.moveToThread(self.thread)
        
        self.thread.started.connect(self.worker.run)
        self.worker.finished.connect(self.thread.quit)
        self.worker.finished.connect(self.worker.deleteLater)
        self.thread.finished.connect(self.thread.deleteLater)
        self.worker.finished.connect(self.on_finished)
        self.worker.error.connect(self.on_error)
        self.worker.log.connect(self.dock.log)
        
        self.thread.start()

    def on_finished(self):
        self.dock.set_working(False)
        self.dock.log("Proceso finalizado con éxito.")

    def on_error(self, msg):
        self.dock.set_working(False)
        self.dock.log(f"ERROR: {msg}")

    def reset_plugin(self):
        # Remove ALL layers from project
        project = QgsProject.instance()
        all_layer_ids = list(project.mapLayers().keys())
        
        if all_layer_ids:
            project.removeMapLayers(all_layer_ids)
            self.dock.log(f"Se eliminaron {len(all_layer_ids)} capas del proyecto.")
        else:
            self.dock.log("No hay capas para eliminar.")
            
        self.dock.log("Plugin reiniciado.")
