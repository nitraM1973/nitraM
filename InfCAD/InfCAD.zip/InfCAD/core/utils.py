import os
import glob

from qgis.PyQt.QtCore import QVariant

# Campos que el plugin añade a los shapes de trabajo
FIELD_X = "X"
FIELD_Y = "Y"
FIELD_MIID = "MiID"
EDIF_MIID = "9100"   # edificación
EXCL_MIID = "9200"   # finca excluida (E que no es edificación)

_INTEGER_TYPES = (QVariant.Int, QVariant.UInt, QVariant.LongLong, QVariant.ULongLong)


def is_integer_field(field):
    """True si el campo es numérico entero (Integer/Integer64, o Real sin decimales)."""
    if field.type() in _INTEGER_TYPES:
        return True
    return field.type() == QVariant.Double and field.length() > 0 and field.precision() == 0


def get_next_temp_folder_name(base_path):
    pattern = os.path.join(base_path, "Temp*")
    dirs = [d for d in glob.glob(pattern) if os.path.isdir(d)]

    max_num = 0
    for d in dirs:
        try:
            num = int(os.path.basename(d).replace("Temp", ""))
            if num > max_num:
                max_num = num
        except ValueError:
            continue

    return f"Temp{max_num + 1:03d}"


def create_temp_folder(base_path):
    folder_name = get_next_temp_folder_name(base_path)
    full_path = os.path.join(base_path, folder_name)
    os.makedirs(full_path, exist_ok=True)
    return full_path
