
import os
import glob

def get_next_temp_folder_name(base_path):
    # Find existing TempXXX folders
    pattern = os.path.join(base_path, "Temp*")
    dirs = [d for d in glob.glob(pattern) if os.path.isdir(d)]
    
    max_num = 0
    for d in dirs:
        try:
            name = os.path.basename(d)
            num = int(name.replace("Temp", ""))
            if num > max_num:
                max_num = num
        except ValueError:
            continue
            
    return f"Temp{max_num + 1:03d}"

def create_temp_folder(base_path):
    # Normalize path to ensure consistent separators
    base_path = os.path.normpath(base_path)
    folder_name = get_next_temp_folder_name(base_path)
    full_path = os.path.join(base_path, folder_name)
    os.makedirs(full_path, exist_ok=True)
    return full_path
